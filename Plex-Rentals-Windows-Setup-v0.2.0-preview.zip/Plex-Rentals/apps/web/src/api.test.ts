import { afterEach, expect, it, vi } from 'vitest';
import { successSchema } from '@reelrequest/shared';
import { api, ApiError } from './api';
afterEach(() => vi.unstubAllGlobals());
it('sends JSON mutations with same-origin credentials', async () => {
  const fetchMock = vi.fn().mockResolvedValue(Response.json({ ok: true }));
  vi.stubGlobal('fetch', fetchMock);
  await api('/requests/1/support', successSchema, 'PATCH', { reason: 'Movie Night' });
  expect(fetchMock.mock.calls[0]?.[0]).toBe('/api/requests/1/support');
  expect(fetchMock.mock.calls[0]?.[1]).toMatchObject({
    method: 'PATCH',
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    body: '{"reason":"Movie Night"}',
  });
});
it('invalidates authentication on lost session and preserves the safe error', async () => {
  const dispatchEvent = vi.fn();
  vi.stubGlobal('window', { dispatchEvent });
  vi.stubGlobal(
    'fetch',
    vi
      .fn()
      .mockResolvedValue(
        Response.json(
          { error: { code: 'PROFILE_REQUIRED', message: 'Choose a profile.' } },
          { status: 401 },
        ),
      ),
  );
  await expect(api('/list', successSchema)).rejects.toBeInstanceOf(ApiError);
  expect(dispatchEvent).toHaveBeenCalledOnce();
  expect(dispatchEvent.mock.calls[0]?.[0].type).toBe('reelrequest:auth');
});
