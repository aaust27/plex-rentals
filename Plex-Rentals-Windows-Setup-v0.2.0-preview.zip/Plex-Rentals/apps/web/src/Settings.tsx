import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import {
  MAX_AVATAR_BYTES,
  devicesResponseSchema,
  presetAvatars,
  profilesResponseSchema,
  profileCreateSchema,
  profileUpdateSchema,
  fuzzyMatchesResponseSchema,
  integrationsResponseSchema,
  integrationServiceSchema,
  plexSettingsSchema,
  plexSyncResultSchema,
  plexTestResponseSchema,
  type Profile,
  type IntegrationService,
} from '@reelrequest/shared';
import { api, ignoredResponse, message } from './api';
import { useSession, ErrorText } from './session';
import { Avatar } from './Avatar';
import { PixelAvatar } from './PixelAvatar';
import { Modal } from './Modal';
import { useRefreshFamily, DateStamp } from './Family';


export function More() {
  const { session, switchProfile } = useSession();
  const [error, setError] = useState('');
  return (
    <main className="family-page more-page">
      <h1>Make yourself at home.</h1>
      {session.profile && (
        <div className="current-profile">
          <Avatar {...session.profile} />
          <div>
            <h2>{session.profile.name}</h2>
            <p>{session.profile.isAdmin ? 'Family admin' : 'Family member'}</p>
          </div>
        </div>
      )}
      <nav className="more-links"><Link to="/settings/suggestions">✧ Suggestion box <span>›</span></Link>
        <Link to="/movie-night">
          ✦ Movie Night <span>›</span>
        </Link>
        <Link to="/notifications">
          ♫ Notifications <span>›</span>
        </Link>
        <Link to="/library">
          ◫ Plex Library <span>›</span>
        </Link>
        <Link to="/list">
          ▢ My List <span>›</span>
        </Link>
        <button
          onClick={() => {
            void switchProfile().catch((e) => setError(message(e)));
          }}
        >
          ◉ Switch profile <span>›</span>
        </button>
        {session.profile?.isAdmin && (
          <Link to="/settings">
            ⚙ Household settings <span>›</span>
          </Link>
        )}
        <Link to="/about">
          ⓘ About Plex Rentals <span>›</span>
        </Link>
      </nav>
      <p className="muted">
        Effects can be changed using the Effects button at the top of the screen.
      </p>
      <Link className="outline-button" to="/settings/shortcuts">Add a home-screen shortcut →</Link>
      <ErrorText error={error} />
    </main>
  );
}
export function Settings() {
  const { session, refresh } = useSession();
  const query = useQuery({
    queryKey: ['admin-profiles', session.profile?.id, session.profile?.maxRatingLevel],
    queryFn: ({ signal }) =>
      api('/admin/profiles', profilesResponseSchema, 'GET', undefined, signal),
  });
  const devices = useQuery({
    queryKey: ['devices', session.profile?.id, session.profile?.maxRatingLevel],
    queryFn: ({ signal }) => api('/admin/devices', devicesResponseSchema, 'GET', undefined, signal),
  });
  const [params, setParams] = useSearchParams();
  const [editing, setEditing] = useState<Profile | null | undefined>(() =>
    params.get('new') === '1' ? null : undefined,
  );
  const [passcode, setPasscode] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [busy, setBusy] = useState(false);
  const [revoking, setRevoking] = useState<number | null>(null);
  const invalidate = useRefreshFamily();
  const navigate = useNavigate();
  return (
    <main className="family-page settings-page">
      <div className="row-heading">
        <h1>Household settings</h1><Link className="outline-button" to="/settings/shortcuts">Home-screen shortcuts</Link><Link className="outline-button" to="/settings/suggestions">Suggestion box</Link>
        <Link to="/requests" className="text-button">
          Dashboard
        </Link>
      </div>
      <section>
        <div className="row-heading">
          <h2>The family</h2>
          <button className="outline-button" onClick={() => setEditing(null)}>
            ＋ Add profile
          </button>
        </div>
        {query.isPending ? (
          <p role="status">Loading profiles…</p>
        ) : query.isError ? (
          <>
            <ErrorText error={message(query.error)} />
            <button
              className="outline-button"
              onClick={() => {
                void query.refetch();
              }}
            >
              Try again
            </button>
          </>
        ) : (
          <div className="settings-profiles">
            {query.data.profiles.map((profile) => (
              <button
                key={profile.id}
                className="settings-profile"
                onClick={() => setEditing(profile)}
              >
                <Avatar {...profile} small />
                <span>
                  <strong>{profile.name}</strong>
                  <small>
                    {profile.isAdmin
                      ? 'Admin'
                      : profile.maxRatingLevel
                        ? `Rating limit: level ${profile.maxRatingLevel}`
                        : 'No rating limit'}
                    {profile.hasPin ? ' · PIN protected' : ''}
                  </small>
                </span>
                <span>›</span>
              </button>
            ))}
          </div>
        )}
      </section>
      <section>
        <h2>Household passcode</h2>
        <p className="muted">
          Used once when a new device joins. Changing it does not remove trusted devices.
        </p>
        <form
          onSubmit={(event) => {
            event.preventDefault();
            setBusy(true);
            setError('');
            setSuccess('');
            void api('/admin/settings', ignoredResponse, 'PUT', { passcode })
              .then(() => {
                setPasscode('');
                setSuccess('Household passcode updated.');
              })
              .catch((e) => setError(message(e)))
              .finally(() => setBusy(false));
          }}
        >
          <label htmlFor="new-passcode">New passcode (at least 8 characters)</label>
          <input
            id="new-passcode"
            type="password"
            autoComplete="new-password"
            minLength={8}
            maxLength={256}
            required
            value={passcode}
            onChange={(event) => setPasscode(event.target.value)}
          />
          <button className="outline-button" disabled={busy}>
            {busy ? 'Saving…' : 'Change passcode'}
          </button>
        </form>
      </section>
      <section>
        <h2>Trusted devices</h2>
        {devices.isPending ? (
          <p>Loading devices…</p>
        ) : devices.isError ? (
          <>
            <ErrorText error={message(devices.error)} />
            <button
              className="outline-button"
              onClick={() => {
                void devices.refetch();
              }}
            >
              Try again
            </button>
          </>
        ) : (
          devices.data.devices.map((device) => (
            <div className="device-row" key={device.id}>
              <div>
                <strong>
                  {device.label || 'Family device'}
                  {device.isCurrent ? ' (this device)' : ''}
                </strong>
                <small>
                  Last used{' '}
                  {device.lastSeenAt ? (
                    <DateStamp value={device.lastSeenAt} />
                  ) : (
                    <DateStamp value={device.createdAt} />
                  )}
                </small>
              </div>
              <button className="text-button" onClick={() => setRevoking(device.id)}>
                Revoke
              </button>
            </div>
          ))
        )}
      </section>
      <section>
        <h2>Connections</h2>
        <PlexSettings />
        <AutomationSettings />
        <Link className="text-button" to="/about">
          About & attribution →
        </Link>
      </section>
      <ErrorText error={error} />
      <p className="save-message" role="status">
        {success}
      </p>
      {editing !== undefined && (
        <ProfileEditor
          profile={editing}
          onClose={() => {
            setEditing(undefined);
            setParams({});
          }}
          onSaved={() => {
            setEditing(undefined);
            setParams({});
            void query.refetch();
            void refresh();
            invalidate();
          }}
        />
      )}
      {revoking !== null && (
        <Modal title="Revoke this device?" onClose={() => setRevoking(null)}>
          <p>This device will need the household passcode to join again.</p>
          <ErrorText error={error} />
          <button
            className="primary-button"
            disabled={busy}
            onClick={() => {
              setBusy(true);
              setError('');
              void api(`/admin/devices/${revoking}`, ignoredResponse, 'DELETE')
                .then(async () => {
                  setRevoking(null);
                  await refresh();
                  invalidate();
                  void devices.refetch();
                  navigate('/settings');
                })
                .catch((e) => setError(message(e)))
                .finally(() => setBusy(false));
            }}
          >
            Revoke device
          </button>
          <button className="text-button" onClick={() => setRevoking(null)}>
            Keep device
          </button>
        </Modal>
      )}
    </main>
  );
}
function AutomationSettings() {
  const query = useQuery({
    queryKey: ['automation-integrations'],
    queryFn: ({ signal }) =>
      api('/admin/integrations', integrationsResponseSchema, 'GET', undefined, signal),
  });
  if (query.isPending) return <p role="status">Checking Sonarr and Radarr…</p>;
  if (query.isError) return <ErrorText error={message(query.error)} />;
  return (
    <div className="integration-settings">
      <h3>Request automation</h3>
      <p className="muted">
        Requests always wait for approval. Enabling a service does not submit the existing backlog.
      </p>
      {query.data.services.map((service) => (
        <IntegrationEditor
          key={`${service.service}:${service.version ?? 'none'}:${service.connected}`}
          service={service}
          refresh={() => void query.refetch()}
        />
      ))}
    </div>
  );
}
function IntegrationEditor({
  service,
  refresh,
}: {
  service: IntegrationService;
  refresh: () => void;
}) {
  const label = service.service === 'radarr' ? 'Radarr' : 'Sonarr';
  const [enabled, setEnabled] = useState(service.enabled);
  const [url, setUrl] = useState(service.baseUrl);
  const [key, setKey] = useState('');
  const [quality, setQuality] = useState(service.qualityProfileId?.toString() ?? '');
  const [root, setRoot] = useState(service.rootFolderPath ?? '');
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const [note, setNote] = useState('');
  async function save(test = false) {
    setBusy(test ? 'test' : 'save');
    setError('');
    setNote('');
    try {
      await api(`/admin/integrations/${service.service}`, integrationServiceSchema, 'PUT', {
        enabled,
        baseUrl: url,
        ...(key.trim() ? { apiKey: key.trim() } : {}),
        qualityProfileId: quality ? Number(quality) : null,
        rootFolderPath: root || null,
      });
      setKey('');
      if (test) {
        const result = await api(
          `/admin/integrations/${service.service}/test`,
          integrationServiceSchema,
          'POST',
        );
        setNote(`Connected to ${label}${result.version ? ` ${result.version}` : ''}.`);
      } else setNote(`${label} settings saved.`);
      refresh();
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy('');
    }
  }
  return (
    <form
      className="integration-card"
      onSubmit={(event) => {
        event.preventDefault();
        void save(false);
      }}
    >
      <div className="row-heading">
        <h4>{label}</h4>
        <span className={service.connected ? 'connection-good' : 'connection-bad'}>
          {service.connected
            ? `Connected${service.version ? ` · ${service.version}` : ''}`
            : 'Not connected'}
        </span>
      </div>
      <label className="checkbox-row">
        <input
          type="checkbox"
          checked={enabled}
          onChange={(event) => setEnabled(event.target.checked)}
        />
        Enable {label} for newly approved {service.service === 'radarr' ? 'movies' : 'TV requests'}
      </label>
      <label htmlFor={`${service.service}-url`}>Server URL</label>
      <input
        id={`${service.service}-url`}
        type="url"
        required
        value={url}
        onChange={(event) => setUrl(event.target.value)}
      />
      <label htmlFor={`${service.service}-key`}>
        API key {service.apiKeyConfigured ? '(saved — leave blank to keep)' : ''}
      </label>
      <input
        id={`${service.service}-key`}
        type="password"
        autoComplete="off"
        value={key}
        onChange={(event) => setKey(event.target.value)}
        placeholder={service.apiKeyConfigured ? '••••••••' : 'Required'}
      />
      <label htmlFor={`${service.service}-quality`}>Default quality profile</label>
      <select
        id={`${service.service}-quality`}
        value={quality}
        onChange={(event) => setQuality(event.target.value)}
      >
        <option value="">Choose after testing connection</option>
        {service.qualityProfiles.map((option) => (
          <option key={option.id} value={option.id}>
            {option.name}
          </option>
        ))}
      </select>
      <label htmlFor={`${service.service}-root`}>Root folder</label>
      <select
        id={`${service.service}-root`}
        value={root}
        onChange={(event) => setRoot(event.target.value)}
      >
        <option value="">Choose after verifying the QNAP mount</option>
        {service.rootFolders.map((option) => (
          <option key={option.id} value={option.path}>
            {option.path}
          </option>
        ))}
      </select>
      <div className="settings-actions">
        <button
          className="outline-button"
          type="button"
          disabled={Boolean(busy)}
          onClick={() => void save(true)}
        >
          {busy === 'test' ? 'Testing…' : 'Save & test connection'}
        </button>
        <button className="primary-button" disabled={Boolean(busy)}>
          {busy === 'save' ? 'Saving…' : 'Save settings'}
        </button>
      </div>
      {service.error && !error && <p className="integration-error">{service.error}</p>}
      <ErrorText error={error} />
      <p className="save-message" role="status">
        {note}
      </p>
    </form>
  );
}
function PlexSettings() {
  const query = useQuery({
    queryKey: ['plex-settings'],
    queryFn: ({ signal }) => api('/admin/plex', plexSettingsSchema, 'GET', undefined, signal),
  });
  const matches = useQuery({
    queryKey: ['plex-matches'],
    queryFn: ({ signal }) =>
      api('/admin/plex/matches', fuzzyMatchesResponseSchema, 'GET', undefined, signal),
  });
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const [note, setNote] = useState('');
  const refresh = useRefreshFamily();
  async function run(kind: 'test' | 'sync') {
    setBusy(kind);
    setError('');
    setNote('');
    try {
      if (kind === 'test') {
        const result = await api('/admin/plex/test', plexTestResponseSchema, 'POST');
        setNote(
          `Connected to ${result.serverName}${result.version ? ` · Plex ${result.version}` : ''}.`,
        );
      } else {
        const result = await api('/admin/plex/sync', plexSyncResultSchema, 'POST');
        setNote(
          `Synced ${result.items} titles across ${result.sections} libraries. ${result.requestsAvailable} requests became available.`,
        );
        refresh();
      }
      await Promise.all([query.refetch(), matches.refetch()]);
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy('');
    }
  }
  if (query.isPending) return <p role="status">Checking Plex…</p>;
  if (query.isError) return <ErrorText error={message(query.error)} />;
  return (
    <div className="plex-settings">
      <p className="muted">
        {query.data.connected
          ? `Connected to ${query.data.serverName}.`
          : query.data.configured
            ? 'Plex is configured but not reachable right now.'
            : 'Plex is not configured on the server.'}
      </p>
      {query.data.lastSuccessfulSyncAt && (
        <p>
          <small>
            Last synced <DateStamp value={query.data.lastSuccessfulSyncAt} />
          </small>
        </p>
      )}
      <div className="settings-actions">
        <button
          className="outline-button"
          disabled={Boolean(busy)}
          onClick={() => {
            void run('test');
          }}
        >
          {busy === 'test' ? 'Testing…' : 'Test connection'}
        </button>
        <button
          className="primary-button"
          disabled={Boolean(busy) || !query.data.connected}
          onClick={() => {
            void run('sync');
          }}
        >
          {busy === 'sync' ? 'Syncing…' : 'Sync now'}
        </button>
      </div>
      {query.data.sections.length > 0 && (
        <fieldset>
          <legend>Included libraries</legend>
          {query.data.sections.map((section) => (
            <label className="checkbox-row" key={section.key}>
              <input
                type="checkbox"
                checked={section.included}
                onChange={async (event) => {
                  const selected = query.data.sections
                    .filter((value) => value.included)
                    .map((value) => value.key);
                  const next = event.target.checked
                    ? [...selected, section.key]
                    : selected.filter((value) => value !== section.key);
                  if (!next.length) {
                    setError('Keep at least one Plex library selected.');
                    return;
                  }
                  setBusy('sections');
                  setError('');
                  try {
                    await api('/admin/plex/sections', ignoredResponse, 'PUT', { sectionIds: next });
                    await query.refetch();
                    setNote('Included libraries updated. Run Sync now to refresh the mirror.');
                  } catch (e) {
                    setError(message(e));
                  } finally {
                    setBusy('');
                  }
                }}
              />
              {section.title} <small>({section.type === 'show' ? 'TV' : 'Movies'})</small>
            </label>
          ))}
        </fieldset>
      )}
      {matches.data?.matches.length ? (
        <div className="fuzzy-matches">
          <h3>Matches to review</h3>
          {matches.data.matches.map((match) => (
            <div className="device-row" key={match.titleId}>
              <div>
                <strong>
                  {match.title} ({match.year ?? '—'})
                </strong>
                <small>
                  Plex: {match.plexTitle} ({match.plexYear ?? '—'})
                </small>
              </div>
              <div>
                <button
                  className="text-button"
                  onClick={async () => {
                    await api(`/admin/plex/matches/${match.titleId}`, ignoredResponse, 'POST', {
                      accept: true,
                    });
                    refresh();
                    void matches.refetch();
                  }}
                >
                  Accept
                </button>
                <button
                  className="text-button"
                  onClick={async () => {
                    await api(`/admin/plex/matches/${match.titleId}`, ignoredResponse, 'POST', {
                      accept: false,
                    });
                    void matches.refetch();
                  }}
                >
                  Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : null}
      <ErrorText error={error} />
      <p className="save-message" role="status">
        {note}
      </p>
    </div>
  );
}
function ProfileEditor({
  profile,
  onClose,
  onSaved,
}: {
  profile: Profile | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = useState(profile?.name ?? '');
  const [avatar, setAvatar] = useState(profile?.avatar ?? 'preset:explorer');
  const [color, setColor] = useState(profile?.color ?? '#F7A823');
  const [rating, setRating] = useState(profile?.maxRatingLevel?.toString() ?? '');
  const [admin, setAdmin] = useState(profile?.isAdmin ?? false);
  const [pin, setPin] = useState('');
  const [removePin, setRemovePin] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [deleting, setDeleting] = useState(false);
  async function photo(file: File | undefined) {
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      setError('Choose a JPEG, PNG or WebP photo.');
      return;
    }
    if (file.size > MAX_AVATAR_BYTES) {
      setError('Choose a photo up to 2 MB.');
      return;
    }
    try {
      const result = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () =>
          typeof reader.result === 'string'
            ? resolve(reader.result)
            : reject(new Error('The photo could not be read.'));
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      setAvatar(result);
      setError('');
    } catch {
      setError('The photo could not be read. Try another.');
    }
  }
  async function submit() {
    setBusy(true);
    setError('');
    try {
      const values = {
        name,
        avatar,
        color,
        maxRatingLevel: rating ? Number(rating) : null,
        isAdmin: admin,
        ...(removePin ? { pin: null } : pin ? { pin } : {}),
      };
      const body = profile ? profileUpdateSchema.parse(values) : profileCreateSchema.parse(values);
      await api(
        `/admin/profiles${profile ? `/${profile.id}` : ''}`,
        ignoredResponse,
        profile ? 'PATCH' : 'POST',
        body,
      );
      onSaved();
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal title={profile ? `Edit ${profile.name}` : 'Add someone to the family'} onClose={onClose}>
      <form
        className="profile-editor"
        onSubmit={(event) => {
          event.preventDefault();
          void submit();
        }}
      >
        <div className="editor-avatar">
          <Avatar avatar={avatar} name={name || 'New profile'} color={color} />
        </div>
        <label htmlFor="profile-name">Display name</label>
        <input
          id="profile-name"
          required
          maxLength={40}
          value={name}
          onChange={(event) => setName(event.target.value)}
        />
        <fieldset>
          <legend>Choose an avatar</legend>
          <div className="avatar-presets">
            {presetAvatars.map((value) => (
              <button
                type="button"
                key={value}
                aria-label={value}
                aria-pressed={avatar === `preset:${value}`}
                onClick={() => setAvatar(`preset:${value}`)}
              >
                <Avatar avatar={`preset:${value}`} name={value} color={color} small />
              </button>
            ))}
          </div>
        </fieldset>
        <PixelAvatar color={color} onChoose={setAvatar} />
        {avatar.startsWith('data:image/') && (
          <button
            type="button"
            className="text-button"
            onClick={() => setAvatar('preset:explorer')}
          >
            Remove custom avatar
          </button>
        )}
        <label htmlFor="avatar-photo">
          Or use an unmodified photo (JPEG, PNG, WebP; up to 2 MB)
        </label>
        <input
          id="avatar-photo"
          type="file"
          accept="image/jpeg,image/png,image/webp"
          onChange={(event) => {
            void photo(event.target.files?.[0]);
          }}
        />
        <label htmlFor="profile-color">Accent color</label>
        <input
          id="profile-color"
          type="color"
          value={color}
          onChange={(event) => setColor(event.target.value)}
        />
        <label htmlFor="profile-rating">Maximum content rating</label>
        <select
          id="profile-rating"
          value={rating}
          onChange={(event) => setRating(event.target.value)}
        >
          <option value="">No limit</option>
          <option value="1">G / TV-G / TV-Y / TV-Y7</option>
          <option value="2">PG / TV-PG</option>
          <option value="3">PG-13 / TV-14</option>
          <option value="4">R / TV-MA</option>
          <option value="5">NC-17</option>
        </select>
        <p className="muted">Rating-limited profiles also hide unrated titles.</p>
        <label htmlFor="new-profile-pin">
          {profile?.hasPin
            ? 'Change four-digit PIN (leave blank to keep)'
            : 'Optional four-digit PIN'}
        </label>
        <input
          id="new-profile-pin"
          type="password"
          inputMode="numeric"
          autoComplete="new-password"
          pattern="[0-9]{4}"
          maxLength={4}
          value={pin}
          disabled={removePin}
          onChange={(event) => setPin(event.target.value.replace(/\D/g, ''))}
        />
        {profile?.hasPin && (
          <label className="checkbox-row">
            <input
              type="checkbox"
              checked={removePin}
              onChange={(event) => setRemovePin(event.target.checked)}
            />
            Remove profile PIN
          </label>
        )}
        <label className="checkbox-row">
          <input
            type="checkbox"
            checked={admin}
            onChange={(event) => setAdmin(event.target.checked)}
          />
          Household admin
        </label>
        <ErrorText error={error} />
        <button className="primary-button" disabled={busy}>
          {busy ? 'Saving…' : 'Save profile'}
        </button>
        {profile && !deleting && (
          <button
            className="text-button danger-text"
            type="button"
            onClick={() => setDeleting(true)}
          >
            Delete profile…
          </button>
        )}
        {deleting && (
          <div className="delete-confirm">
            <p>Delete {profile?.name}? This cannot be undone.</p>
            <button
              type="button"
              className="outline-button"
              disabled={busy}
              onClick={() => {
                setBusy(true);
                setError('');
                void api(`/admin/profiles/${profile!.id}`, ignoredResponse, 'DELETE')
                  .then(onSaved)
                  .catch((e) => setError(message(e)))
                  .finally(() => setBusy(false));
              }}
            >
              Delete profile
            </button>
            <button type="button" className="text-button" onClick={() => setDeleting(false)}>
              Keep profile
            </button>
          </div>
        )}
      </form>
    </Modal>
  );
}
