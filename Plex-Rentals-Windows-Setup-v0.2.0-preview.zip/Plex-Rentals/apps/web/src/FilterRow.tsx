import { useLayoutEffect, useRef, useState, type ReactNode } from 'react';
export function FilterRow({ children, className = '', 'aria-label': label = 'Filters' }: {children: ReactNode; className?: string; 'aria-label'?: string}) {
 const ref = useRef<HTMLDivElement>(null);
 const [expanded,setExpanded]=useState(false);
 const [overflow,setOverflow]=useState(false);
 useLayoutEffect(()=>{
  const row=ref.current!;
  const measure=()=>{
   const mobile=window.matchMedia('(max-width: 640px)').matches;
   const items=Array.from(row.children) as HTMLElement[];
   const top=items[0]?.offsetTop ?? 0;
   let more=false;
   for(const item of items){const extra=mobile && item.offsetTop>top+4; more ||= extra; item.inert=extra && !expanded; item.style.visibility=extra && !expanded?'hidden':'';}
   setOverflow(more);
  };
  const observer=new ResizeObserver(measure);observer.observe(row);measure();
  return ()=>observer.disconnect();
 },[children,expanded]);
 return <div className={`compact-filters ${expanded?'is-expanded':''}`} role="group" aria-label={label}>
  <div ref={ref} className={`filter-row ${className}`} >{children}</div>
  {overflow && <button className="filter-expand" aria-label={expanded?'Show fewer filters':'Show all filters'} aria-expanded={expanded} onClick={()=>setExpanded(!expanded)}>{expanded?'−':'+'}</button>}
 </div>;
}
