import { ScrollFilters } from './ScrollFilters';
import { useEffect, useRef, useState } from 'react';
import { useInfiniteQuery } from '@tanstack/react-query';
import { Link, useSearchParams } from 'react-router-dom';
import { discoverResponseSchema, discoveryCollections, type TitleCard } from '@reelrequest/shared';
import { api } from './api';
import { useSession } from './session';

const positions = new Map<string, number>();
export function Explore({
  render,
  nineties = false,
}: {
  render: (title: TitleCard) => React.ReactNode;
  nineties?: boolean;
}) {
  const [params, setParams] = useSearchParams();
  const { session } = useSession();
  const sentinel = useRef<HTMLDivElement>(null);
  const [expanded, setExpanded] = useState(false);
  const ownsFullscreen = useRef(false);
  const wantsFullscreen = useRef(false);
  const exitGallery = () => {
    wantsFullscreen.current = false;
    setExpanded(false);
    if (ownsFullscreen.current && document.fullscreenElement) {
      void document.exitFullscreen().catch(() => undefined);
    }
    ownsFullscreen.current = false;
  };
  const enterGallery = async () => {
    wantsFullscreen.current = true;
    setExpanded(true);
    // Keep dialogs and navigation in the fullscreen tree. LAN HTTP and some
    // browsers may reject fullscreen; the wide gallery remains usable there.
    if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
      try {
        await document.documentElement.requestFullscreen();
        if (!wantsFullscreen.current) {
          if (document.fullscreenElement) await document.exitFullscreen();
          return;
        }
        ownsFullscreen.current = true;
      } catch { /* Wide layout is the fallback. */ }
    }
  };
  useEffect(() => {
    if (!expanded) return;
    document.body.classList.add('gallery-expanded');
    const leave = () => {
      if (!document.fullscreenElement && ownsFullscreen.current) {
        ownsFullscreen.current = false;
        setExpanded(false);
      }
    };
    const escape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setExpanded(false);
    };
    const desktop = matchMedia('(min-width: 901px)');
    const resize = () => { if (!desktop.matches) setExpanded(false); };
    document.addEventListener('fullscreenchange', leave);
    document.addEventListener('keydown', escape);
    desktop.addEventListener('change', resize);
    return () => {
      wantsFullscreen.current = false;
      document.body.classList.remove('gallery-expanded');
      document.removeEventListener('fullscreenchange', leave);
      document.removeEventListener('keydown', escape);
      desktop.removeEventListener('change', resize);
      if (ownsFullscreen.current && document.fullscreenElement) {
        void document.exitFullscreen().catch(() => undefined);
      }
      ownsFullscreen.current = false;
    };
  }, [expanded]);
  const effective = new URLSearchParams(params);
  if (nineties) {
    effective.set('decade', '1990');
    effective.delete('franchise');
    effective.delete('similar');
    effective.delete('collection');
  }
  const key = `${session.profile?.id}:${nineties}:${params}`;
  const query = useInfiniteQuery({
    queryKey: [
      'discover',
      session.profile?.id,
      session.profile?.maxRatingLevel,
      effective.toString(),
    ],
    initialPageParam: 1,
    queryFn: ({ pageParam, signal }) =>
      api(
        `/discover?${effective}&page=${pageParam}`,
        discoverResponseSchema,
        'GET',
        undefined,
        signal,
      ),
    getNextPageParam: (last) => last.nextPage ?? undefined,
    staleTime: 6 * 60 * 60_000,
    gcTime: 6 * 60 * 60_000,
  });
  useEffect(() => {
    const frame = requestAnimationFrame(() => window.scrollTo(0, positions.get(key) ?? 0));
    const save = () => positions.set(key, window.scrollY);
    window.addEventListener('scroll', save, { passive: true });
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('scroll', save);
    };
  }, [key]);
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (
          entries[0]?.isIntersecting &&
          query.hasNextPage &&
          !query.isFetching &&
          !query.isError &&
          (query.data?.pages.at(-1)?.items.length ?? 0) > 0
        )
          void query.fetchNextPage();
      },
      { rootMargin: '600px' },
    );
    if (sentinel.current) observer.observe(sentinel.current);
    return () => observer.disconnect();
  }, [query.hasNextPage, query.isFetching, query.isError, query.fetchNextPage, query.data]);
  const set = (name: string, value: string) => {
    const next = new URLSearchParams(params);
    if (value) next.set(name, value);
    else next.delete(name);
    setParams(next);
  };
  const collection =
    discoveryCollections[params.get('collection') as keyof typeof discoveryCollections];
  const items = [
    ...new Map(
      query.data?.pages.flatMap((page) => page.items).map((item) => [item.tmdbId, item]) ?? [],
    ).values(),
  ].filter((title) => !nineties || (title.year != null && title.year >= 1990 && title.year <= 1999));
  return (
    <main
      id="main-content"
      className={`browse-main explore-page ${nineties ? 'nineties-page' : ''}`}
    >
      <div className="gallery-controls">
        <button className="outline-button" aria-pressed={expanded}
          onClick={() => expanded ? exitGallery() : void enterGallery()}>
          {expanded ? '↙ Exit full-screen gallery' : '⛶ Full-screen gallery'}
        </button>
        {expanded && <span className="muted">Press Esc to return</span>}
      </div>
      {nineties && (
        <header className="retro-welcome">
          <span>File &nbsp; Edit &nbsp; View &nbsp; Favorites &nbsp; Help</span>
          <h1>Welcome to the Plex Rentals ’90s Movie Homepage!</h1>
          <p>★ Your guide to movies released from 1990–1999 ★</p>
          <div className="retro-badges">
            <b>WORLD WIDE WEB</b>
            <b>BEST VIEWED WITH POPCORN</b>
            <b>100% NINETIES</b>
          </div>
          <hr />
        </header>
      )}
      {!nineties && <p className="eyebrow">THERE’S ALWAYS ANOTHER GREAT MOVIE</p>}
      {!nineties && (
        <h1>
          {collection?.name ??
            (params.has('franchise')
              ? 'The movie collection'
              : params.has('similar')
                ? 'More like this'
                : params.has('cast')
                  ? 'More with this cast member'
                  : params.has('director')
                    ? 'From this filmmaker'
                    : 'Explore everything')}
        </h1>
      )}
      <p className="muted">
        {collection?.description ??
          'Follow your curiosity. Mix filters and find something unexpected.'}
      </p>
      <Link to="/">← Home</Link>
      {!params.has('franchise') && !params.has('similar') && (
        <ScrollFilters activeCount={['genre','decade','score','runtime','provider','availability'].filter(key=>params.has(key)).length}><div className="explore-filters">
          {(
            [
              [
                'genre',
                'Genre',
                [
                  ['28', 'Action'],
                  ['12', 'Adventure'],
                  ['16', 'Animation'],
                  ['35', 'Comedy'],
                  ['18', 'Drama'],
                  ['27', 'Horror'],
                  ['9648', 'Mystery'],
                  ['878', 'Science fiction'],
                  ['10751', 'Family'],
                  ['99', 'Documentary'],
                ],
              ],
              [
                'decade',
                'Decade',
                Array.from({ length: 10 }, (_, i) => [String(1930 + i * 10), `${1930 + i * 10}s`]),
              ],
              [
                'score',
                'Rating',
                [
                  ['6', '6+'],
                  ['7', '7+'],
                  ['8', '8+'],
                ],
              ],
              [
                'runtime',
                'Length',
                [
                  ['99', 'Under 100 min'],
                  ['120', 'Up to 2 hours'],
                  ['180', 'Up to 3 hours'],
                ],
              ],
              [
                'provider',
                'Service',
                [
                  ['8', 'Netflix'],
                  ['15', 'Hulu'],
                  ['350', 'Apple TV'],
                  ['337', 'Disney+'],
                ],
              ],
              [
                'availability',
                'Availability',
                [
                  ['ready', 'Ready in Plex'],
                  ['request', 'Can request'],
                  ['soon', 'Coming soon'],
                ],
              ],
            ] as [string, string, string[][]][]
          )
            .filter(([name]) => !nineties || name !== 'decade')
            .map(([name, label, options]) => (
              <label key={name}>
                {label}
                <select
                  aria-label={label}
                  value={params.get(name) ?? ''}
                  onChange={(event) => set(name, event.target.value)}
                >
                  <option value="">All</option>
                  {options.map(([value, text]) => (
                    <option key={value} value={value}>
                      {text}
                    </option>
                  ))}
                </select>
              </label>
            ))}
          <button className="text-button" onClick={() => setParams({})}>
            Reset filters
          </button>
        </div></ScrollFilters>
      )}
      {params.has('provider') && (
        <p className="provider-attribution">
          Streaming availability provided by JustWatch via TMDB.
        </p>
      )}
      {query.data?.pages.some((page) => page.stale) && (
        <p role="status">Showing saved results while the catalog reconnects.</p>
      )}
      <p className="muted" role="status">
        {items.length} movies discovered{query.isFetching ? ' · Finding more…' : ''}
      </p>
      <div className="poster-grid discovery-grid">
        {items.map((title) => (
          <div key={title.tmdbId}>{render(title)}</div>
        ))}
      </div>
      {query.isError && (
        <p role="alert">
          Could not load more movies. <button onClick={() => void query.refetch()}>Retry</button>
        </p>
      )}
      {!query.isFetching && !items.length && (
        <p>No matches on these pages. Try another filter or keep exploring.</p>
      )}
      <div ref={sentinel} />
      {query.hasNextPage && (
        <button
          className="outline-button"
          disabled={query.isFetching}
          onClick={() => void query.fetchNextPage()}
        >
          Load more movies
        </button>
      )}
      {!query.hasNextPage && !query.isPending && (
        <p className="muted">
          You’ve reached the end of this selection. Change a filter to explore another direction.
        </p>
      )}
    </main>
  );
}
