import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useParams } from 'react-router-dom';
import {
  movieNightResponseSchema,
  profilesResponseSchema,
  type MovieNight as MovieNightRecord,
} from '@reelrequest/shared';
import { api, message } from './api';
import { ErrorText, useSession } from './session';

const labels = ['Nope', 'Maybe', 'Sure', 'Love'] as const;
function poster(path: string | null) {
  return path
    ? path.startsWith('/demo-')
      ? `/api/demo-art${path}`
      : `https://image.tmdb.org/t/p/w342${path}`
    : '';
}

export function MovieNightBanner() {
  const { session } = useSession();
  const query = useQuery({
    queryKey: ['movie-night-current', session.profile?.id],
    queryFn: ({ signal }) =>
      api('/movie-nights/current', movieNightResponseSchema, 'GET', undefined, signal),
  });
  return query.data?.movieNight ? (
    <Link className="movie-night-banner" to={`/movie-night/${query.data.movieNight.id}`}>
      <span>✦ Movie Night is in progress</span>
      <strong>Join the vote ›</strong>
    </Link>
  ) : null;
}

export function MovieNight() {
  const { session } = useSession();
  const { id } = useParams();
  const client = useQueryClient();
  const profiles = useQuery({
    queryKey: ['profiles'],
    queryFn: ({ signal }) => api('/profiles', profilesResponseSchema, 'GET', undefined, signal),
  });
  const current = useQuery({
    queryKey: ['movie-night-current', session.profile?.id, id],
    queryFn: ({ signal }) =>
      api(
        id ? `/movie-nights/${id}` : '/movie-nights/current',
        movieNightResponseSchema,
        'GET',
        undefined,
        signal,
      ),
  });
  const [participants, setParticipants] = useState<number[]>([session.profile!.id]);
  const [type, setType] = useState<'both' | 'movie' | 'tv'>('both');
  const [runtime, setRuntime] = useState('');
  const [mode, setMode] = useState<'own_device' | 'pass_phone'>('own_device');
  const [night, setNight] = useState<MovieNightRecord | null>(null);
  const [voter, setVoter] = useState(session.profile!.id);
  const [showVotes, setShowVotes] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const active = night ?? current.data?.movieNight ?? null;
  async function mutate(path: string, method: string, body?: unknown) {
    setBusy(true);
    setError('');
    try {
      const result = await api(path, movieNightResponseSchema, method, body);
      setNight(result.movieNight);
      await client.invalidateQueries({ queryKey: ['movie-night-current'] });
    } catch (reason) {
      setError(message(reason));
    } finally {
      setBusy(false);
    }
  }
  if (current.isPending || profiles.isPending)
    return (
      <main className="family-page">
        <p role="status">Setting the scene…</p>
      </main>
    );
  if (!active)
    return (
      <main className="family-page movie-night-page" id="main-content">
        <p className="eyebrow">EVERYONE GETS A SAY</p>
        <h1>Start Movie Night</h1>
        <p>
          Pick the family members joining tonight. Plex Rentals will choose ten titles everyone is
          allowed to see.
        </p>
        <fieldset>
          <legend>Who is joining?</legend>
          {profiles.data?.profiles.map((profile) => (
            <label className="checkbox-row" key={profile.id}>
              <input
                type="checkbox"
                checked={participants.includes(profile.id)}
                disabled={profile.id === session.profile!.id}
                onChange={() =>
                  setParticipants((items) =>
                    items.includes(profile.id)
                      ? items.filter((id) => id !== profile.id)
                      : [...items, profile.id],
                  )
                }
              />
              {profile.name}
            </label>
          ))}
        </fieldset>
        <label>
          Titles
          <select value={type} onChange={(event) => setType(event.target.value as typeof type)}>
            <option value="both">Movies and TV</option>
            <option value="movie">Movies</option>
            <option value="tv">TV Shows</option>
          </select>
        </label>
        <label>
          Maximum runtime
          <input
            type="number"
            min="30"
            max="360"
            placeholder="No limit"
            value={runtime}
            onChange={(event) => setRuntime(event.target.value)}
          />
        </label>
        <label>
          Voting mode
          <select value={mode} onChange={(event) => setMode(event.target.value as typeof mode)}>
            <option value="own_device">Each person’s device</option>
            <option value="pass_phone">Pass this phone</option>
          </select>
        </label>
        <ErrorText error={error} />
        <button
          className="primary-button"
          disabled={busy || !participants.length}
          onClick={() =>
            void mutate('/movie-nights', 'POST', {
              participants,
              type,
              maxRuntime: runtime ? Number(runtime) : null,
              inPlexOnly: true,
              mode,
            })
          }
        >
          ✦ Start Movie Night
        </button>
      </main>
    );
  const isHost = active.hostProfileId === session.profile!.id;
  const winner = active.candidates.find((item) => item.titleId === active.winnerTitleId);
  return (
    <main className="family-page movie-night-page" id="main-content">
      <p className="eyebrow">HOSTED BY {active.hostName.toUpperCase()}</p>
      <h1>{active.status === 'closed' ? 'Tonight’s pick' : 'Movie Night'}</h1>
      {winner && (
        <section className="night-winner">
          <h2>{winner.title.title}</h2>
          <p>{winner.matchPercent ?? 0}% family match</p>
          <Link
            className="primary-button"
            to={`/title/${winner.title.mediaType}/${winner.title.tmdbId}`}
          >
            ▶ Open tonight’s pick
          </Link>
        </section>
      )}
      {active.status === 'voting' && active.filters.mode === 'pass_phone' && isHost && (
        <label>
          Voting as
          <select value={voter} onChange={(event) => setVoter(Number(event.target.value))}>
            {active.participants.map((profile) => (
              <option key={profile.id} value={profile.id}>
                {profile.name}
              </option>
            ))}
          </select>
        </label>
      )}
      <div className="night-actions">
        {active.status === 'voting' && isHost && (
          <button
            className="outline-button"
            disabled={busy}
            onClick={() => void mutate(`/movie-nights/${active.id}/reshuffle`, 'POST')}
          >
            ↻ Reshuffle
          </button>
        )}
        {active.status === 'closed' && (
          <button className="text-button" onClick={() => setShowVotes(!showVotes)}>
            {showVotes ? 'Hide votes' : 'Show votes'}
          </button>
        )}
      </div>
      <ErrorText error={error} />
      <div className="night-grid">
        {active.candidates.map((candidate, index) => (
          <article
            className={
              candidate.titleId === active.winnerTitleId ? 'night-card winner' : 'night-card'
            }
            key={candidate.titleId}
          >
            {poster(candidate.title.posterPath) ? (
              <img src={poster(candidate.title.posterPath)} alt={candidate.title.title} />
            ) : (
              <div className="image-fallback">{candidate.title.title}</div>
            )}
            <h2>
              {index + 1}. {candidate.title.title}
            </h2>
            {candidate.matchPercent !== null && (
              <strong>
                {candidate.matchPercent}% Family Match{candidate.hasNope ? ' · has a Nope' : ''}
              </strong>
            )}
            {active.status === 'voting' ? (
              <div className="vote-buttons">
                {labels.map((label, vote) => (
                  <button
                    key={label}
                    aria-pressed={
                      (active.filters.mode === 'pass_phone' ? null : candidate.myVote) === vote
                    }
                    disabled={busy}
                    onClick={() =>
                      void mutate(`/movie-nights/${active.id}/vote`, 'PUT', {
                        titleId: candidate.titleId,
                        vote,
                        ...(active.filters.mode === 'pass_phone' ? { voterProfileId: voter } : {}),
                      })
                    }
                  >
                    {label}
                  </button>
                ))}
              </div>
            ) : (
              showVotes && (
                <ul>
                  {candidate.votes.map((vote) => (
                    <li key={vote.profileId}>
                      {vote.name}: {labels[vote.vote]}
                    </li>
                  ))}
                </ul>
              )
            )}
            {active.status === 'voting' && isHost && (
              <button
                className="text-button"
                disabled={busy}
                onClick={() =>
                  void mutate(`/movie-nights/${active.id}/close`, 'POST', {
                    titleId: candidate.titleId,
                  })
                }
              >
                Choose as tonight’s pick
              </button>
            )}
          </article>
        ))}
      </div>
    </main>
  );
}
