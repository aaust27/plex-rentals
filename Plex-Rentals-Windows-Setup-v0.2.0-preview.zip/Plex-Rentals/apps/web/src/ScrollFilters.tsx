import {useEffect,useRef,useState,type ReactNode} from 'react';
export function ScrollFilters({children,activeCount}:{children:ReactNode;activeCount:number}){
 const [collapsed,setCollapsed]=useState(false);const shell=useRef<HTMLElement>(null);const ignoreUntil=useRef(0);
 useEffect(()=>{
  let previous=window.scrollY,travel=0,direction=0;
  const onScroll=()=>{
   const y=window.scrollY,delta=y-previous;previous=y;
   if(Date.now()<ignoreUntil.current||Math.abs(delta)<2)return;
   const nextDirection=Math.sign(delta);travel=nextDirection===direction?travel+Math.abs(delta):Math.abs(delta);direction=nextDirection;
   if(shell.current?.contains(document.activeElement))return;
   const change=(value:boolean)=>{setCollapsed(value);ignoreUntil.current=Date.now()+450;travel=0;};
   if(y<80){if(collapsed)change(false);return;}
   if(delta>0&&travel>64&&!collapsed&&shell.current&&shell.current.getBoundingClientRect().top<=8)change(true);
   else if(delta<0&&travel>32&&collapsed)change(false);
  };
  window.addEventListener('scroll',onScroll,{passive:true});return()=>window.removeEventListener('scroll',onScroll);
 },[collapsed]);
 return <section ref={shell} className={`scroll-filter-shell ${collapsed?'is-collapsed':''}`} aria-label="Explore filters"><button className="scroll-filter-toggle" aria-expanded={!collapsed} aria-controls="explore-filter-fields" onClick={()=>{ignoreUntil.current=Date.now()+600;setCollapsed(!collapsed);}}><span>☷ Filters <small>{activeCount?`${activeCount} active`:'Find your next movie'}</small></span><span aria-hidden="true">{collapsed?'+':'−'}</span></button><div className="scroll-filter-reveal" inert={collapsed} aria-hidden={collapsed}><div id="explore-filter-fields">{children}</div></div></section>;
}
