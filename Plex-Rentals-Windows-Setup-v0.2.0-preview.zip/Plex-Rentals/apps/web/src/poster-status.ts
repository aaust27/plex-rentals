import type { TitleCard } from '@reelrequest/shared';
import { plexLabels, releaseLabels, requestLabels } from './state-labels';
export function posterStatus(title: TitleCard): { label: string; state: string } | null {
  if (title.requestStatus === 'watched') return { label: requestLabels.watched, state: 'watched' };
  if (title.plexState === 'available') return { label: plexLabels.available, state: 'available' };
  if (title.requestStatus === 'looking') return { label: requestLabels.looking, state: 'looking' };
  if (title.releaseState === 'coming_soon')
    return { label: releaseLabels.coming_soon, state: 'soon' };
  if (title.requestStatus === 'requested')
    return { label: requestLabels.requested, state: 'requested' };
  return null;
}
