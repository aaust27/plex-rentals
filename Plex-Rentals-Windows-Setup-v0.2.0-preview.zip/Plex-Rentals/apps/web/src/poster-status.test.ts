import { describe, expect, it } from 'vitest';
import type { TitleCard } from '@reelrequest/shared';
import { posterStatus } from './poster-status';
const base: TitleCard = {
  tmdbId: 1,
  mediaType: 'movie',
  title: 'Test',
  year: null,
  releaseDate: null,
  posterPath: null,
  backdropPath: null,
  tmdbScore: null,
  certification: null,
  runtimeMin: null,
  seasonCount: null,
  colorHex: '#123456',
  plexState: 'unavailable',
  releaseState: 'released',
};
describe('poster status precedence', () => {
  it('shows watched before availability, availability before looking, and looking before release', () => {
    expect(posterStatus({ ...base, requestStatus: 'watched', plexState: 'available' })?.state).toBe(
      'watched',
    );
    expect(posterStatus({ ...base, requestStatus: 'looking', plexState: 'available' })?.state).toBe(
      'available',
    );
    expect(
      posterStatus({ ...base, requestStatus: 'looking', releaseState: 'coming_soon' })?.state,
    ).toBe('looking');
    expect(
      posterStatus({ ...base, requestStatus: 'requested', releaseState: 'coming_soon' })?.state,
    ).toBe('soon');
    expect(posterStatus({ ...base, requestStatus: 'requested' })?.state).toBe('requested');
  });
  it('does not imply a request or availability for unknown/unavailable titles', () => {
    expect(posterStatus(base)).toBeNull();
    expect(posterStatus({ ...base, plexState: 'unknown' })).toBeNull();
    expect(posterStatus({ ...base, requestStatus: 'passed' })).toBeNull();
  });
});
