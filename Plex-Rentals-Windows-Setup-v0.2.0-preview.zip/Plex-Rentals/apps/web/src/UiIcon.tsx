const paths = {
  settings:
    'M9 3h6l.5 2.5 2 1.2 2.5-.8 3 5.2-2 1.7v2.4l2 1.7-3 5.2-2.5-.8-2 1.2L15 24H9l-.5-2.5-2-1.2-2.5.8-3-5.2 2-1.7v-2.4l-2-1.7 3-5.2 2.5.8 2-1.2L9 3Z M16 13.5a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
  home: 'M3 10 12 3l9 7v11h-6v-7H9v7H3Z',
  search: 'M21 21l-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0',
  requests: 'M8 3h8v4H8ZM8 5H5v16h14V5h-3M8 12h8M8 16h5',
  library: 'M3 4h5v17H3ZM11 4h4v17h-4ZM18 4l3 16',
  more: 'M4 6h16M4 12h16M4 18h16',
  bell: 'M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4',
};
export function UiIcon({ name }: { name: keyof typeof paths }) {
  return (
    <svg
      className="ui-icon"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d={paths[name]} transform={name === 'settings' ? 'translate(1 0) scale(.9)' : undefined} />
    </svg>
  );
}
