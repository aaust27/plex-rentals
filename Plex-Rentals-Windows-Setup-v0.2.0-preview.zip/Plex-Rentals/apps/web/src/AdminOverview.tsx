import {formatBytes} from './TransferDetails';
import { useState } from 'react';
import { useInfiniteQuery, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import {
  requestsResponseSchema,
  requestTrackingSchema,
  type RequestRecord,
  requestStatus,
} from '@reelrequest/shared';
import { api, ignoredResponse } from './api';
import { Modal } from './Modal';
import { useSession } from './session';
import { requestLabels } from './state-labels';

function LiveStatus({ request }: { request: RequestRecord }) {
  const { session } = useSession();
  const active = ['requested', 'looking'].includes(request.status);
  const query = useQuery({
    queryKey: ['request-tracking', session.profile?.id, request.id],
    queryFn: ({ signal }) =>
      api(`/requests/${request.id}/tracking`, requestTrackingSchema, 'GET', undefined, signal),
    enabled: active,
    refetchInterval: active ? 10_000 : false,
  });
  return (
    <span className="command-tracking">
      {active ? (query.data?.state ?? 'Checking…') : requestLabels[request.status]}
      {query.data?.progress != null && active ? ` · ${query.data.progress}%` : ''}
      {active && query.data?.speedBytesPerSecond != null && <span> · ~{formatBytes(query.data.speedBytesPerSecond)}/s</span>}
      {active && query.data?.eta && <span> · ETA {query.data.eta}</span>}
      {query.isError && ' · Connection interrupted'}
      {active && query.data?.progress != null && <progress max={100} value={query.data.progress} aria-label={`${request.title.title} download progress`} />}
    </span>
  );
}
export function AdminOverview() {
  const { session } = useSession();
  const client = useQueryClient();
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [status, setStatus] = useState('');
  const [show, setShow] = useState(true);
  const preview = useQuery({
    queryKey: ['approval-preview', session.profile?.id],
    queryFn: ({ signal }) =>
      api('/admin/approval-preview', requestsResponseSchema, 'GET', undefined, signal),
    enabled: confirm,
    staleTime: 0,
  });
  const board = useInfiniteQuery({
    queryKey: ['admin-status-board', session.profile?.id, status],
    initialPageParam: '',
    enabled: show,
    queryFn: ({ pageParam, signal }) =>
      api(
        `/admin/requests?limit=20${status ? `&status=${status}` : ''}${pageParam ? `&cursor=${encodeURIComponent(pageParam)}` : ''}`,
        requestsResponseSchema,
        'GET',
        undefined,
        signal,
      ),
    getNextPageParam: (last) => last.nextCursor ?? undefined,
    refetchInterval: show ? 15_000 : false,
  });
  async function approve() {
    setBusy(true);
    setError('');
    try {
      await api('/admin/approve-all', ignoredResponse, 'POST', {
        ids: preview.data!.requests.map((request) => request.id),
      });
      setConfirm(false);
      await client.invalidateQueries();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Approval failed');
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="admin-overview">
      <div className="row-heading"><div><p className="eyebrow">OPERATIONS</p><h2>Live activity</h2><p className="muted">Approve the next watch. Follow it all the way to Plex.</p></div>
        <button className="primary-button" onClick={() => setConfirm(true)}>
          Approve all pending
        </button>
        <button className="outline-button" aria-expanded={show} onClick={() => setShow(!show)}>
          All statuses {show ? '▴' : '▾'}
        </button>
      </div>
      {show && (
        <section>
          <h2>All request statuses</h2>
          <p className="muted">
            Request status, approval, submission, and live download/import progress. 
          </p>
          <label>
            Filter status{' '}
            <select
              aria-label="Filter status"
              value={status}
              onChange={(event) => setStatus(event.target.value)}
            >
              <option value="">All statuses</option>
              {requestStatus.options.map((value) => (
                <option key={value} value={value}>
                  {requestLabels[value]}
                </option>
              ))}
            </select>
          </label>
          {board.isPending && <p>Loading statuses…</p>}
          {board.isError && (
            <p role="alert">
              Could not load statuses. <button onClick={() => void board.refetch()}>Retry</button>
            </p>
          )}
          {board.data && !board.data.pages.some(page=>page.requests.length) && <p className="command-empty">All clear here. Requests will appear as your household adds movies.</p>}
          <div className="status-board">
            {board.data?.pages
              .flatMap((page) => page.requests)
              .map((request) => (
                <article key={request.id} className={request.automation?.lastError ? 'needs-attention' : ''}>
                  <Link to={`/admin/requests/${request.id}`}>
                    <strong>{request.title.title}</strong>
                  </Link>
                  <span>
                    {requestLabels[request.status]} ·{' '}
                    {request.automation?.decision ?? 'pending approval'} ·{' '}
                    {request.automation?.submissionStatus ?? 'not submitted'}
                  </span>
                  <LiveStatus request={request} />
                  {request.automation?.lastError && <small>{request.automation.lastError}</small>}
                </article>
              ))}
          </div>
          {board.hasNextPage && (
            <button
              className="outline-button"
              disabled={board.isFetching}
              onClick={() => void board.fetchNextPage()}
            >
              More statuses
            </button>
          )}
        </section>
      )}
      {confirm && (
        <Modal
          title="Approve all pending requests?"
          onClose={() => {
            if (!busy) setConfirm(false);
          }}
        >
          <p>
            This approves the following pending requests across all pages and current dashboard
            filters. Downloads may start when eligible; release protections remain active.
            Previously declined or approved requests are excluded.
          </p>
          {preview.isPending && <p>Loading pending requests…</p>}
          {preview.isError && (
            <p role="alert">
              Could not load pending requests.{' '}
              <button onClick={() => void preview.refetch()}>Retry</button>
            </p>
          )}
          <ul className="bulk-preview">
            {preview.data?.requests.map((request) => (
              <li key={request.id}>
                {request.title.title} ({request.title.year})
              </li>
            ))}
          </ul>
          {error && <p role="alert">{error}</p>}
          <button
            className="primary-button"
            disabled={busy || preview.isFetching || !preview.data?.requests.length}
            onClick={() => void approve()}
          >
            {busy ? 'Approving…' : `Approve ${preview.data?.requests.length ?? 0} requests`}
          </button>
          <p className="muted">Up to 500 pending requests per batch.</p>
        </Modal>
      )}
    </section>
  );
}

