import {
  homeResponseSchema,
  familyDetailResponseSchema,
  apiErrorSchema,
} from '@reelrequest/shared';

async function failure(response: Response, fallback: string): Promise<Error> {
  try {
    const parsed = apiErrorSchema.safeParse(await response.json());
    if (parsed.success) return new Error(parsed.data.error.message);
  } catch {
    /* A proxy may return HTML rather than the API error envelope. */
  }
  return new Error(fallback);
}
export async function getHome(type: string, signal: AbortSignal) {
  const response = await fetch(`/api/home${type ? `?type=${encodeURIComponent(type)}` : ''}`, {
    signal: AbortSignal.any([signal, AbortSignal.timeout(90000)]),
  });
  if (response.status === 401 || response.status === 403)
    window.dispatchEvent(new CustomEvent('reelrequest:auth'));
  if (!response.ok)
    throw await failure(response, 'The catalog could not be loaded. Please try again.');
  const parsed = homeResponseSchema.safeParse(await response.json());
  if (!parsed.success) throw new Error('The catalog response could not be read. Please try again.');
  return parsed.data;
}
export async function getDetail(type: string, id: string, signal: AbortSignal) {
  const response = await fetch(
    `/api/titles/${encodeURIComponent(type)}/${encodeURIComponent(id)}`,
    { signal: AbortSignal.any([signal, AbortSignal.timeout(90000)]) },
  );
  if (response.status === 401 || response.status === 403)
    window.dispatchEvent(new CustomEvent('reelrequest:auth'));
  if (!response.ok)
    throw await failure(
      response,
      response.status === 404
        ? 'This title could not be found.'
        : 'This title could not be loaded. Please try again.',
    );
  const parsed = familyDetailResponseSchema.safeParse(await response.json());
  if (!parsed.success) throw new Error('The title response could not be read. Please try again.');
  return parsed.data;
}
