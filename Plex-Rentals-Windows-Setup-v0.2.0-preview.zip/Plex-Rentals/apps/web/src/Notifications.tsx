import { useEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { notificationsResponseSchema, pushConfigSchema } from '@reelrequest/shared';
import { api, ignoredResponse, message } from './api';
import { DateStamp, useRefreshFamily } from './Family';
import { ErrorText, useSession } from './session';
import { UiIcon } from './UiIcon';

function bytes(value: string) {
  const padded = `${value}${'='.repeat((4 - (value.length % 4)) % 4)}`
    .replace(/-/g, '+')
    .replace(/_/g, '/');
  return Uint8Array.from(atob(padded), (character) => character.charCodeAt(0));
}

export function NotificationBell() {
  const { session } = useSession();
  const query = useQuery({
    queryKey: ['notifications', session.profile?.id],
    queryFn: ({ signal }) =>
      api('/notifications', notificationsResponseSchema, 'GET', undefined, signal),
    refetchInterval: 60_000,
  });
  return (
    <Link
      className="notification-bell"
      to="/notifications"
      aria-label={`${query.data?.unread ?? 0} unread notifications`}
    >
      <UiIcon name="bell" />
      {Boolean(query.data?.unread) && <span>{query.data!.unread}</span>}
    </Link>
  );
}

export function NotificationToast() {
  const { session } = useSession();
  const initialized = useRef(false);
  const latest = useRef(0);
  const [toast, setToast] = useState<{ id: number; body: string } | null>(null);
  const query = useQuery({
    queryKey: ['notifications', session.profile?.id],
    queryFn: ({ signal }) =>
      api('/notifications', notificationsResponseSchema, 'GET', undefined, signal),
  });
  useEffect(() => {
    const newest = query.data?.notifications.find((item) => !item.readAt);
    if (!initialized.current) {
      initialized.current = true;
      latest.current = newest?.id ?? 0;
      return;
    }
    if (newest && newest.id > latest.current) {
      latest.current = newest.id;
      setToast({ id: newest.id, body: newest.body });
      const timer = setTimeout(() => setToast(null), 6000);
      return () => clearTimeout(timer);
    }
  }, [query.data]);
  return toast ? (
    <div className="notification-toast" role="status">
      <Link to="/notifications" onClick={() => setToast(null)}>
        <UiIcon name="bell" />
        <span>{toast.body}</span>
      </Link>
      <button
        className="toast-dismiss"
        aria-label="Dismiss notification"
        onClick={() => setToast(null)}
      >
        ×
      </button>
    </div>
  ) : null;
}

export function Notifications() {
  const { session } = useSession();
  const refresh = useRefreshFamily();
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const query = useQuery({
    queryKey: ['notifications', session.profile?.id],
    queryFn: ({ signal }) =>
      api('/notifications', notificationsResponseSchema, 'GET', undefined, signal),
  });
  const push = useQuery({
    queryKey: ['push-config'],
    queryFn: ({ signal }) => api('/push/config', pushConfigSchema, 'GET', undefined, signal),
  });
  async function enablePush() {
    setError('');
    if (!push.data?.enabled || !push.data.publicKey) throw new Error('Push is not configured yet.');
    if (!('serviceWorker' in navigator) || !('PushManager' in window))
      throw new Error('This browser does not support web push.');
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') throw new Error('Notification permission was not granted.');
    const registration = await navigator.serviceWorker.register('/sw.js');
    const subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: bytes(push.data.publicKey),
    });
    const serialized = subscription.toJSON();
    if (!serialized.endpoint || !serialized.keys?.p256dh || !serialized.keys.auth)
      throw new Error('The browser returned an incomplete push subscription.');
    await api('/push/subscribe', ignoredResponse, 'POST', {
      endpoint: serialized.endpoint,
      keys: serialized.keys,
    });
    setStatus('Push notifications are enabled on this device.');
  }
  return (
    <main className="family-page notifications-page" id="main-content">
      <div className="row-heading">
        <div>
          <p className="eyebrow">FAMILY UPDATES</p>
          <h1>Notifications</h1>
        </div>
        {Boolean(query.data?.unread) && (
          <button
            className="text-button"
            onClick={() => {
              void api('/notifications/read', ignoredResponse, 'POST', { all: true }).then(refresh);
            }}
          >
            Mark all read
          </button>
        )}
      </div>
      {push.data?.enabled && (
        <section className="notification-opt-in">
          <h2>Updates on this device</h2>
          <p>Get request and Plex updates even when Plex Rentals is closed.</p>
          <p className="muted">On iPhone or iPad, add Plex Rentals to the Home Screen first.</p>
          <button
            className="outline-button"
            onClick={() => {
              void enablePush().catch((reason) => setError(message(reason)));
            }}
          >
            Enable push notifications
          </button>
        </section>
      )}
      {status && (
        <p role="status" className="success-text">
          {status}
        </p>
      )}
      <ErrorText error={error} />
      {query.isPending ? (
        <p role="status">Loading notifications…</p>
      ) : query.isError ? (
        <ErrorText error={message(query.error)} />
      ) : query.data.notifications.length ? (
        <div className="notification-list">
          {query.data.notifications.map((item) => {
            const to = item.kind === 'suggestion' ? '/settings/suggestions' :
              item.mediaType && item.tmdbId
                ? `/title/${item.mediaType}/${item.tmdbId}`
                : '/requests';
            return (
              <Link
                className={item.readAt ? 'notification-row' : 'notification-row unread'}
                to={to}
                key={item.id}
                onClick={() => {
                  if (!item.readAt)
                    void api('/notifications/read', ignoredResponse, 'POST', {
                      ids: [item.id],
                    }).then(refresh);
                }}
              >
                <span className="notification-dot" />
                <div>
                  <strong>{item.body}</strong>
                  <small>
                    <DateStamp value={item.createdAt} />
                  </small>
                </div>
                <span>›</span>
              </Link>
            );
          })}
        </div>
      ) : (
        <section className="empty-state">
          <h2>All caught up.</h2>
          <p>Request and Plex updates will appear here.</p>
        </section>
      )}
    </main>
  );
}
