import { presetAvatars } from '@reelrequest/shared';
import type { CSSProperties } from 'react';
const colors = [
  '#F7A823',
  '#5AB8F0',
  '#9B6BF0',
  '#EF8D65',
  '#71C69F',
  '#EC89AD',
  '#8DB3E2',
  '#D0AE67',
  '#EF7A7C',
  '#B2C76B',
  '#BA91CA',
  '#73C7D5',
];
export function Avatar({
  avatar,
  name,
  color,
  small = false,
}: {
  avatar: string;
  name: string;
  color: string;
  small?: boolean;
}) {
  const number =
    Math.max(
      0,
      presetAvatars.findIndex((value) => avatar === `preset:${value}`),
    ) + 1;
  const index = (number - 1) % 12;
  const skin = ['#edbb91', '#bd815c', '#955c42', '#f1caaa'][index % 4];
  const hair = ['#37241f', '#242022', '#683e22', '#dcaf64'][index % 4];
  return (
    <span
      className={`profile-avatar ${small ? 'small-avatar' : ''}`}
      style={{ '--profile-color': color } as CSSProperties}
    >
      {avatar.startsWith('/api/avatars/') || avatar.startsWith('data:image/') ? (
        <img src={avatar} alt={name} />
      ) : (
        <svg viewBox="0 0 100 100" role="img" aria-label={name}>
          <defs>
            <radialGradient id={`avatar-${number}`}>
              <stop stopColor={colors[index]} />
              <stop offset="1" stopColor="#171b26" />
            </radialGradient>
          </defs>
          <circle cx="50" cy="50" r="50" fill={colors[index]} />
          <circle cx="50" cy="56" r="48" fill="#000" opacity=".18" />
          <path d="M15 100 Q17 68 50 69 Q85 71 87 100" fill={hair} />
          <path d="M39 65H61V80Q50 88 39 80Z" fill={skin} />
          <ellipse cx="50" cy="44" rx="29" ry="34" fill={hair} />
          <ellipse cx="50" cy="47" rx="23" ry="29" fill={skin} />
          <path
            d={
              index % 2
                ? 'M24 38Q24 8 51 12Q78 13 78 38Q58 33 46 22Q41 35 24 38'
                : 'M25 32Q19 3 56 10Q80 11 77 35L65 21Q48 30 25 32'
            }
            fill={hair}
          />
          <ellipse cx="41" cy="46" rx="3" ry="4" fill="#292025" />
          <ellipse cx="60" cy="46" rx="3" ry="4" fill="#292025" />
          <circle cx="42" cy="45" r="1" fill="white" />
          <circle cx="61" cy="45" r="1" fill="white" />
          <path
            d="M41 60Q50 67 60 59"
            fill="white"
            stroke="#804b3a"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
          {index % 3 === 0 && (
            <g stroke="#362822" strokeWidth="2" fill="none">
              <circle cx="40" cy="46" r="9" />
              <circle cx="61" cy="46" r="9" />
              <path d="M49 46H52" />
            </g>
          )}
          {index > 7 && <path d="M19 27Q22 1 51 5Q79 7 80 27Z" fill={colors[(index + 3) % 12]} />}
        </svg>
      )}
    </span>
  );
}
