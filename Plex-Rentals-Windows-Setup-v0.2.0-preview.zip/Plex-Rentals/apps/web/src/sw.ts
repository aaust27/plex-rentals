/// <reference lib="webworker" />

const worker = globalThis as unknown as ServiceWorkerGlobalScope & {
  __WB_MANIFEST: { url: string; revision: string | null }[];
};

const shellCache = 'reelrequest-shell-v1';
const runtimeCache = 'reelrequest-runtime-v1';
const shell = (
  self as unknown as ServiceWorkerGlobalScope & {
    __WB_MANIFEST: { url: string; revision: string | null }[];
  }
).__WB_MANIFEST.map((entry) => entry.url);

worker.addEventListener('install', (event) => {
  event.waitUntil(caches.open(shellCache).then((cache) => cache.addAll(shell)));
  void worker.skipWaiting();
});
worker.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((key) => ![shellCache, runtimeCache].includes(key))
            .map((key) => caches.delete(key)),
        ),
      ),
  );
  void worker.clients.claim();
});
worker.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.pathname.startsWith('/api/')) return;
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request).catch(
        async () => (await caches.match('/index.html')) ?? Response.error(),
      ),
    );
    return;
  }
  if (url.origin === worker.location.origin) {
    event.respondWith(
      caches.match(event.request).then(
        (cached) =>
          cached ??
          fetch(event.request).then((response) => {
            if (response.ok)
              void caches
                .open(runtimeCache)
                .then((cache) => cache.put(event.request, response.clone()));
            return response;
          }),
      ),
    );
  }
});
worker.addEventListener('push', (event) => {
  const data = event.data?.json() as { title?: string; body?: string; url?: string } | undefined;
  event.waitUntil(
    worker.registration.showNotification(data?.title ?? 'Plex Rentals', {
      body: data?.body ?? 'Your family has a movie update.',
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      data: { url: data?.url ?? '/notifications' },
    }),
  );
});
worker.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = new URL(
    String((event.notification.data as { url?: string } | undefined)?.url ?? '/'),
    worker.location.origin,
  ).href;
  event.waitUntil(
    worker.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(async (clients) => {
      const existing = clients.find((client) => 'focus' in client) as WindowClient | undefined;
      if (existing) {
        await existing.navigate(url);
        return existing.focus();
      }
      return worker.clients.openWindow(url);
    }),
  );
});
