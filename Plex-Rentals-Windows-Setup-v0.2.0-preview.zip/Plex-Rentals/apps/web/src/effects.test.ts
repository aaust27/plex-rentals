import { describe, expect, it } from 'vitest';
import { defaultEffects, resolveEffects } from './effects';

describe('per-device Effects preference', () => {
  it('defaults to Lite for reduced motion or constrained hardware', () => {
    expect(defaultEffects({ reducedMotion: true, memory: 16, cores: 8 })).toBe('lite');
    expect(defaultEffects({ reducedMotion: false, memory: 4, cores: 8 })).toBe('lite');
    expect(defaultEffects({ reducedMotion: false, memory: 8, cores: 4 })).toBe('lite');
  });
  it('defaults to Full on other devices, including absent hardware hints', () => {
    expect(defaultEffects({ reducedMotion: false, memory: 8, cores: 8 })).toBe('full');
    expect(defaultEffects({ reducedMotion: false })).toBe('full');
  });
  it('honors a valid saved setting and ignores invalid storage values', () => {
    expect(resolveEffects('full', { reducedMotion: true })).toBe('full');
    expect(resolveEffects('lite', { reducedMotion: false })).toBe('lite');
    expect(resolveEffects('broken', { reducedMotion: true })).toBe('lite');
    expect(resolveEffects(null, { reducedMotion: false })).toBe('full');
  });
});
