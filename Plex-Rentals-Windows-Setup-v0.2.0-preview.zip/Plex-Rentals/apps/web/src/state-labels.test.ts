import { describe, expect, it } from 'vitest';
import { plexState, releaseState, requestStatus } from '@reelrequest/shared';
import { plexLabels, releaseLabels, requestLabels } from './state-labels';

describe('shared state presentation', () => {
  it('provides labels for the complete shared contract', () => {
    expect(Object.keys(requestLabels).sort()).toEqual([...requestStatus.options].sort());
    expect(Object.keys(releaseLabels).sort()).toEqual([...releaseState.options].sort());
    expect(Object.keys(plexLabels).sort()).toEqual([...plexState.options].sort());
  });
  it('never presents unknown Plex availability as missing', () => {
    expect(plexLabels[plexState.enum.unknown]).toBe("Can't confirm Plex right now");
  });
});
