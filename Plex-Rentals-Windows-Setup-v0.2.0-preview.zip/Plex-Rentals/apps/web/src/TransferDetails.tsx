import type { RequestTracking } from '@reelrequest/shared';
export function formatBytes(value: number) {
  const units = ['B', 'KiB', 'MiB', 'GiB', 'TiB'];
  let i = 0;
  while (value >= 1024 && i < 4) {
    value /= 1024;
    i++;
  }
  return `${value.toFixed(i ? 1 : 0)} ${units[i]}`;
}
export function TransferDetails({ tracking }: { tracking: RequestTracking }) {
  const stages = ['queued', 'downloading', 'transferring', 'plex', 'ready'];
  const current = stages.indexOf(tracking.stage);
  return (
    <div className="transfer-details">
      <ol className="transfer-stages" aria-label="Delivery stages">
        {['Queued', 'Downloading', 'NAS import', 'Plex confirmation', 'Ready'].map((label, i) => (
          <li
            key={label}
            className={current === i ? 'current' : current > i ? 'done' : ''}
            aria-current={current === i ? 'step' : undefined}
          >
            <span aria-hidden="true">{current > i ? '✓' : i + 1}</span>
            {label}
          </li>
        ))}
      </ol>
      <div className="transfer-metrics">
        {tracking.bytesTotal !== null && tracking.bytesDownloaded !== null && (
          <span>
            <strong>{formatBytes(tracking.bytesDownloaded)}</strong> of{' '}
            {formatBytes(tracking.bytesTotal)}
          </span>
        )}
        {tracking.stage === 'downloading' && (
          <span>
            {tracking.speedBytesPerSecond === null
              ? 'Measuring speed…'
              : `${formatBytes(tracking.speedBytesPerSecond)}/s estimated`}
          </span>
        )}
        {tracking.eta && <span>ETA {tracking.eta}</span>}
      </div>
      {tracking.stage === 'plex' && (
        <small className="muted">Imported media is waiting for Plex to confirm availability.</small>
      )}
    </div>
  );
}
