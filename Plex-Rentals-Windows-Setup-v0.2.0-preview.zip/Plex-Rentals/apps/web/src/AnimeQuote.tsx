import { useEffect, useState } from 'react';

export const animeQuotes = [
  {
    text: 'Because I am here!',
    character: 'All Might',
    series: 'My Hero Academia',
    source: 'https://myheroacademia.fandom.com/wiki/Toshinori_Yagi',
  },
  {
    text: 'Stand up and walk. Keep moving forward.',
    character: 'Edward Elric',
    series: 'Fullmetal Alchemist',
    source: 'https://note.com/vega_meigen/n/nf76ffb222ae6',
  },
  {
    text: 'And now in the name of Moon I’ll punish you!',
    character: 'Sailor Moon',
    series: 'Sailor Moon',
    source: 'https://en.wikiquote.org/wiki/Sailor_Moon',
  },
  {
    text: 'Believe it!',
    character: 'Naruto Uzumaki',
    series: 'Naruto',
    source: 'https://en.wikiquote.org/wiki/Naruto',
  },
  {
    text: 'Whatever happens, happens.',
    character: 'Spike Spiegel',
    series: 'Cowboy Bebop',
    source: 'https://en.wikiquote.org/wiki/Cowboy_Bebop',
  },
  {
    text: 'Believe in the Kamina who believes in you!',
    character: 'Kamina',
    series: 'Gurren Lagann',
    source: 'https://en.wikiquote.org/wiki/Gurren_Lagann',
  },
  {
    text: 'I’m gonna be King of the Pirates!',
    character: 'Monkey D. Luffy',
    series: 'One Piece',
    source: 'https://one-piece.com/greg/o20150121_0339/index.html',
  },
] as const;
export function quoteForDay(date: Date) {
  const localDay = Date.UTC(date.getFullYear(), date.getMonth(), date.getDate());
  return animeQuotes[Math.floor(localDay / 86400000) % animeQuotes.length]!;
}
export function AnimeQuote() {
  const [date, setDate] = useState(() => new Date());
  useEffect(() => {
    const timer = setInterval(() => setDate(new Date()), 30_000);
    const refresh = () => setDate(new Date());
    window.addEventListener('focus', refresh);
    return () => {
      clearInterval(timer);
      window.removeEventListener('focus', refresh);
    };
  }, []);
  const quote = quoteForDay(date);
  return (
    <div className="anime-daily-quote">
      <p className="eyebrow">TODAY’S ANIME QUOTE</p>
      <h1>“{quote.text}”</h1>
      <p>
        — {quote.character} <span>· {quote.series}</span>
      </p>
      <a href={quote.source} target="_blank" rel="noreferrer">
        Quote source
      </a>
    </div>
  );
}
