import { FilterRow } from './FilterRow';
import { useState, type ReactNode } from 'react';
import { useInfiniteQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { libraryResponseSchema, discoverResponseSchema, type TitleCard } from '@reelrequest/shared';
import { api } from './api';
import { useSession } from './session';
export function StandUp({ render }: { render: (title: TitleCard) => ReactNode }) {
  const { session } = useSession();
  const [sort, setSort] = useState('added');
  const [view, setView] = useState<'discover' | 'library'>('discover');
  const [availability, setAvailability] = useState('all');
  const discovery = useInfiniteQuery({
    queryKey: [
      'standup-discover',
      session.profile?.id,
      session.profile?.maxRatingLevel,
      availability,
    ],
    initialPageParam: 1,
    queryFn: ({ pageParam, signal }) =>
      api(
        `/discover?collection=standup&availability=${availability}&page=${pageParam}`,
        discoverResponseSchema,
        'GET',
        undefined,
        signal,
      ),
    getNextPageParam: (last) => last.nextPage ?? undefined,
    staleTime: 60_000,
    enabled: view === 'discover',
  });
  const query = useInfiniteQuery({
    queryKey: ['standup', session.profile?.id, session.profile?.maxRatingLevel, sort],
    enabled: view === 'library',
    initialPageParam: '',
    queryFn: ({ pageParam, signal }) =>
      api(
        `/library?section=standup&sort=${sort}${pageParam ? `&cursor=${encodeURIComponent(pageParam)}` : ''}`,
        libraryResponseSchema,
        'GET',
        undefined,
        signal,
      ),
    getNextPageParam: (last) => last.nextCursor ?? undefined,
    staleTime: 60_000,
  });
  const active = view === 'discover' ? discovery : query;
  const items = [
    ...new Map(
      active.data?.pages
        .flatMap((page) => page.items)
        .map((item) => [`${item.mediaType}:${item.tmdbId}`, item]) ?? [],
    ).values(),
  ];
  return (
    <main id="main-content" className="browse-main standup-page">
      <header className="comedy-stage">
        <div className="comedy-sign">THE LAUGH LOUNGE</div>
        <svg className="comedy-mic" viewBox="0 0 80 120" aria-hidden="true">
          <rect x="26" y="8" width="28" height="52" rx="14" />
          <path
            d="M18 39v8a22 22 0 0 0 44 0v-8M40 70v36m-19 0h38"
            fill="none"
            stroke="currentColor"
            strokeWidth="5"
          />
          <path d="M30 22h20M30 31h20M30 40h20" stroke="#1b1119" strokeWidth="3" />
        </svg>
        <p className="eyebrow">ONE MIC. A ROOM FULL OF LAUGHS.</p>
        <h1>Stand-up comedy</h1>
        <p>Discover your next favorite special. Best seat in the house.</p>
      </header>
      <div className="row-heading">
        <Link className="filter-chip" to="/">
          ← All movies & shows
        </Link>
        <FilterRow className="" aria-label="Comedy collections">
          <button
            className="filter-chip"
            aria-pressed={view === 'discover'}
            onClick={() => setView('discover')}
          >
            Discover specials
          </button>
          <button
            className="filter-chip"
            aria-pressed={view === 'library'}
            onClick={() => setView('library')}
          >
            In your Plex
          </button>
        </FilterRow>
        {view === 'discover' ? (
          <label>
            Show{' '}
            <select
              aria-label="Special availability"
              value={availability}
              onChange={(event) => setAvailability(event.target.value)}
            >
              <option value="all">All specials</option>
              <option value="request">Not in Plex · released</option>
              <option value="soon">Coming soon</option>
            </select>
          </label>
        ) : (
          <label>
            Sort specials{' '}
            <select
              aria-label="Sort specials"
              value={sort}
              onChange={(event) => setSort(event.target.value)}
            >
              <option value="added">Recently added</option>
              <option value="title">Title</option>
              <option value="year">Newest releases</option>
            </select>
          </label>
        )}
      </div>
      <h2>{view === 'discover' ? 'Discover stand-up specials' : 'On stage in your library'}</h2>
      {view === 'discover' && (
        <p className="muted">
          Explore the full TMDB stand-up catalog, including lesser-known specials. Open a poster to
          request it. Catalog listings don’t guarantee a download is available.
        </p>
      )}
      {active.isPending && <p role="status">Opening the comedy club…</p>}
      {active.isError && (
        <p role="alert">
          We couldn’t load the comedy library.{' '}
          <button onClick={() => void active.refetch()}>Try again</button>
        </p>
      )}
      <div className="poster-grid">
        {items.map((title) => (
          <div key={`${title.mediaType}:${title.tmdbId}`}>{render(title)}</div>
        ))}
      </div>
      {active.isSuccess && !items.length && (
        <p>
          {view === 'discover'
            ? 'No matching specials on these pages. Try All specials or load more.'
            : 'No matched specials are visible for this profile yet. Check the selected Plex libraries and this profile’s age settings.'}
        </p>
      )}
      <p className="muted" role="status">
        {items.length} specials loaded{active.isFetching ? ' · Loading…' : ''}
      </p>
      {active.hasNextPage && (
        <button
          className="outline-button"
          disabled={active.isFetching}
          onClick={() => void active.fetchNextPage()}
        >
          More specials
        </button>
      )}
    </main>
  );
}
