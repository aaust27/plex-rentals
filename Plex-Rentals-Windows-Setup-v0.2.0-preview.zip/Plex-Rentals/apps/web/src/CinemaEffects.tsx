import { motion, useScroll, useSpring } from 'motion/react';

/** Decorative effects mount only in Full mode; no timers or particle render loops. */
export function CinemaEffects() {
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 100, damping: 30 });
  return (
    <div className="cinema-effects" aria-hidden="true">
      <div className="cinema-aurora cinema-aurora-gold" />
      <div className="cinema-aurora cinema-aurora-blue" />
      <div className="cinema-grid" />
      <motion.div className="cinema-progress" style={{ scaleX: progress }} />
    </div>
  );
}
