import {TransferDetails} from './TransferDetails';
import { FilterRow } from './FilterRow';
import { AdminOverview } from './AdminOverview';
import { useEffect, useRef, useState } from 'react';
import { useInfiniteQuery, useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useParams } from 'react-router-dom';
import {
  adminStatsSchema,
  plexItemsResponseSchema,
  listResponseSchema,
  requestReasonSchema,
  requestResponseSchema,
  requestTrackingSchema,
  requestsResponseSchema,
  openRequestStatuses,
  requestStatus,
  type RequestRecord,
  type RequestReason,
  type TitleCard,
  type TitleDetail,
} from '@reelrequest/shared';
import { api, ignoredResponse, message } from './api';
import { useSession, ErrorText, AdminGuard } from './session';
import { Modal } from './Modal';
import { Avatar } from './Avatar';
import { requestLabels } from './state-labels';
import { posterStatus } from './poster-status';

export function useRefreshFamily() {
  const client = useQueryClient();
  return () => {
    void client.invalidateQueries({
      predicate: (q) => !['session', 'profiles'].includes(String(q.queryKey[0])),
    });
  };
}
export function DateStamp({ value }: { value: string }) {
  const { session } = useSession();
  const date = new Date(
    value.endsWith('Z') || value.includes('+') ? value : `${value.replace(' ', 'T')}Z`,
  );
  return (
    <time dateTime={value}>
      {Number.isNaN(date.getTime())
        ? value
        : new Intl.DateTimeFormat('en-US', {
            timeZone: session.timeZone,
            month: 'short',
            day: 'numeric',
            year: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
          }).format(date)}
    </time>
  );
}
function Thumbnail({ title }: { title: TitleCard }) {
  const [failed, setFailed] = useState(false);
  return title.posterPath && !failed ? (
    <img
      className="request-thumbnail"
      src={
        title.posterPath.startsWith('/demo-')
          ? `/api/demo-art${title.posterPath}`
          : `https://image.tmdb.org/t/p/w342${title.posterPath}`
      }
      alt={`${title.title}${title.year ? ` (${title.year})` : ''}`}
      loading="lazy"
      onError={() => setFailed(true)}
    />
  ) : (
    <span className="request-thumbnail thumb-fallback" aria-label={title.title}>
      ◉
    </span>
  );
}
function AutomationState({ request }: { request: RequestRecord }) {
  const automation = request.automation;
  if (
    (!automation || automation.decision === 'pending') &&
    !['requested', 'looking'].includes(request.status)
  )
    return null;
  const label = !automation
    ? 'Awaiting approval'
    : automation.decision === 'pending'
      ? 'Awaiting approval'
      : automation.decision === 'declined'
        ? 'Declined'
        : automation.submissionStatus === 'sent'
          ? `Sent to ${automation.service === 'radarr' ? 'Radarr' : 'Sonarr'}`
          : automation.submissionStatus === 'failed'
            ? 'Integration needs attention'
            : automation.submissionStatus === 'queued' ||
                automation.submissionStatus === 'submitting'
              ? 'Approved — sending'
              : automation.submissionStatus === 'skipped'
                ? 'Approved — no longer needed'
                : 'Approved — not submitted';
  const state =
    automation?.decision === 'declined' ? 'declined' : (automation?.submissionStatus ?? 'pending');
  return <span className={`approval-pill approval-${state}`}>{label}</span>;
}
export function RequestHistory({ request }: { request: RequestRecord }) {
  const eventTime = (value: string) =>
    Date.parse(/[zZ]$|[+-]\d{2}:\d{2}$/.test(value) ? value : `${value.replace(' ', 'T')}Z`);
  const { session } = useSession();
  const tracking = useQuery({
    queryKey: ['request-tracking', session.profile?.id, request.id],
    queryFn: ({ signal }) =>
      api(`/requests/${request.id}/tracking`, requestTrackingSchema, 'GET', undefined, signal),
    refetchInterval: ['available', 'watched', 'cancelled'].includes(request.status) ? false : 5_000,
    staleTime: 4_000,
  });
  const activity = [
    ...request.events.map((event) => ({
      key: `status-${event.id}`,
      label: requestLabels[event.toStatus],
      actorName: event.actorName,
      createdAt: event.createdAt,
    })),
    ...request.activity.map((event) => ({ ...event, key: `automation-${event.id}` })),
    ...(tracking.data?.events ?? []).map((event, index) => ({
      ...event,
      key: `download-${index}`,
      actorName: tracking.data?.source ?? 'Download manager',
    })),
  ].sort((a, b) => eventTime(a.createdAt) - eventTime(b.createdAt));
  return (
    <section className="request-history">
      <h3>Request history</h3>
      <div className="request-tracking" aria-live="polite">
        <strong>
          {tracking.data?.state ??
            (tracking.isError ? 'Tracking unavailable · retrying' : 'Checking current status…')}
        </strong>
        {tracking.data?.progress != null && (
          <>
            <div
              className="download-progress"
              role="progressbar"
              aria-label="Download progress"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={tracking.data.progress}
            >
              <div
                className="download-progress-fill"
                style={{ width: `${tracking.data.progress}%` }}
              />
            </div>
            <span>
              {tracking.data.progress}% downloaded
              {tracking.data.eta ? ` · ETA ${tracking.data.eta}` : ''}
            </span>
          </>
        )}
        {tracking.data && <TransferDetails tracking={tracking.data} />}
        {tracking.data && (
          <small>
            {tracking.data.source} · Checked{' '}
            {new Date(tracking.data.checkedAt).toLocaleTimeString()} ·{' '}
            {tracking.isError
              ? 'Connection interrupted · retrying'
              : ['available', 'watched', 'cancelled'].includes(request.status)
                ? 'Tracking complete'
                : ''}
          </small>
        )}
        <button
          className="text-button"
          disabled={tracking.isFetching}
          onClick={() => void tracking.refetch()}
        >
          {tracking.isFetching ? 'Checking…' : 'Refresh status'}
        </button>
      </div>
      <ol>
        {activity.map((event) => (
          <li key={event.key}>
            <strong>{event.label}</strong>
            <span>
              {event.actorName ?? 'Automatic'} · <DateStamp value={event.createdAt} />
            </span>
          </li>
        ))}
      </ol>
    </section>
  );
}
export function RequestBlock({ request }: { request: RequestRecord }) {
  return (
    <section className="request-block">
      <div className="row-heading">
        <h2>
          {request.isSupporter ? 'You requested this' : `Requested by ${request.createdByName}`}
        </h2>
        <span className={`status-pill state-${request.status}`}>
          {requestLabels[request.status]}
        </span>
      </div>
      <p className="muted">
        <DateStamp value={request.createdAt} />
        {request.seasons && ` · Seasons ${request.seasons.join(', ')}`}
      </p>
      {request.rental && (
        <p className="rental-status">
          ◷ 7-day rental ·{' '}
          {request.rental.deletedAt
            ? 'Rental ended'
            : request.rental.expiresAt
              ? <>Ends <DateStamp value={request.rental.expiresAt} /></>
              : 'Timer starts when ready in Plex'}
        </p>
      )}
      {(request.automation || ['requested', 'looking'].includes(request.status)) && (
        <p className="approval-line">
          <AutomationState request={request} />
          {request.automation?.scopeLabel && <small>{request.automation.scopeLabel}</small>}
        </p>
      )}
      {request.automation?.declineReason && (
        <p className="integration-message">Reason: {request.automation.declineReason}</p>
      )}
      {request.automation?.lastError && (
        <p className="integration-error" role="alert">
          {request.automation.lastError}
        </p>
      )}
      <div className="supporter-list">
        {request.supporters.map((person) => (
          <div className="supporter" key={person.profileId}>
            <Avatar avatar={person.avatar} name={person.name} color={person.color} small />
            <div>
              <strong>{person.name}</strong>
              <small>
                <DateStamp value={person.createdAt} />
              </small>
              {person.reason && <span className="reason-tag">{person.reason}</span>}
              {person.note && <p>{person.note}</p>}
            </div>
          </div>
        ))}
      </div>
      <RequestHistory request={request} />
    </section>
  );
}
function Confirmation({ request, onClose }: { request: RequestRecord; onClose: () => void }) {
  const { session } = useSession();
  const mine = request.supporters.find((person) => person.profileId === session.profile?.id);
  const [reason, setReason] = useState<RequestReason | null>(mine?.reason ?? null);
  const [note, setNote] = useState(mine?.note ?? '');
  const [error, setError] = useState('');
  const [state, setState] = useState('Saved');
  const [activity, setActivity] = useState(0);
  const refresh = useRefreshFamily();
  const values = useRef({ reason: mine?.reason ?? null, note: mine?.note ?? '' });
  const saved = useRef(JSON.stringify(values.current));
  const queue = useRef(Promise.resolve());
  const alive = useRef(true);
  const closing = useRef(false);
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);
  const touch = () => setActivity((value) => value + 1);
  function save() {
    const next = { ...values.current };
    const encoded = JSON.stringify(next);
    if (encoded === saved.current) return queue.current;
    setState('Saving…');
    const task = queue.current
      .catch(() => undefined)
      .then(async () => {
        await api(`/requests/${request.id}/support`, requestResponseSchema, 'PATCH', next);
        saved.current = encoded;
        if (alive.current) {
          setState('Saved');
          setError('');
        }
        refresh();
      });
    queue.current = task;
    void task.catch((e) => {
      if (alive.current) {
        setError(message(e));
        setState('Not saved');
      }
    });
    return task;
  }
  async function close() {
    if (closing.current) return;
    closing.current = true;
    try {
      await save();
      onClose();
    } catch {
      closing.current = false;
    }
  }
  useEffect(() => {
    const timer = setTimeout(() => {
      void close();
    }, 8000);
    return () => clearTimeout(timer);
  }, [activity]);
  useEffect(() => {
    const timer = setTimeout(() => {
      void save().catch(() => undefined);
    }, 400);
    return () => clearTimeout(timer);
  }, [note]);
  return (
    <Modal
      title={request.automation?.decision === 'approved' ? 'Request approved' : 'Request sent — your admin will see it'}
      onClose={() => {
        void close();
      }}
    >
      <div className="confirmation-sheet" onPointerDown={touch} onKeyDown={touch}>
        <p className="muted">
          {request.rental
            ? 'Your 7-day rental is set. The clock starts only after Plex confirms the movie is ready, then the library copy is removed automatically.'
            : request.automation?.decision === 'approved'
            ? `Your ${request.title.mediaType === 'tv' ? 'show' : 'movie'} is approved. Downloads begin when it is released and a suitable file is available.`
            : `This ${request.title.mediaType === 'tv' ? 'show' : 'movie'} is awaiting admin approval. Up to 10 new requests per profile each day are approved automatically; the allowance resets at midnight Central time.`}
          {' '}Add a reason or a note if you like.
        </p>

      <FilterRow className="wrap">
          {requestReasonSchema.options.map((value) => (
            <button
              className="filter-chip"
              key={value}
              aria-pressed={reason === value}
              onClick={() => {
                const next = reason === value ? null : value;
                setReason(next);
                values.current.reason = next;
                void save().catch(() => undefined);
                touch();
              }}
            >
              {value}
            </button>
          ))}
        </FilterRow>
        <label htmlFor="request-note">
          Add a note <span className="muted">(optional)</span>
        </label>
        <textarea
          id="request-note"
          maxLength={140}
          value={note}
          rows={3}
          onChange={(event) => {
            setNote(event.target.value);
            values.current.note = event.target.value;
            touch();
          }}
        />
        <div className="row-heading">
          <small>{note.length}/140</small>
          <small role="status">{state}</small>
        </div>
        <ErrorText error={error} />
        {error && (
          <button
            className="outline-button"
            onClick={() => {
              void save().catch(() => undefined);
              touch();
            }}
          >
            Retry saving
          </button>
        )}
        <Link
          className="text-button"
          to="/notifications"
          onClick={() => {
            void close();
          }}
        >
          Get updates on this device
        </Link>
        <button
          className="primary-button"
          onClick={() => {
            void close();
          }}
        >
          Done
        </button>
      </div>
    </Modal>
  );
}
export function RequestControls({
  title,
  request,
  season,
  compact = false,
}: {
  title: TitleCard | TitleDetail;
  request: RequestRecord | null;
  season?: number;
  compact?: boolean;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [confirm, setConfirm] = useState<RequestRecord | null>(null);
  const [seasonPicker, setSeasonPicker] = useState(false);
  const [rentConfirm, setRentConfirm] = useState(false);
  const [selected, setSelected] = useState<number[] | null>(season === undefined ? null : [season]);
  const [playback, setPlayback] = useState(false);
  const [received, setReceived] = useState(false);
  const refresh = useRefreshFamily();
  const active = request && openRequestStatuses.includes(request.status) ? request : null;
  useEffect(() => {
    if (!received) return;
    const timer = setTimeout(() => setReceived(false), 1800);
    return () => clearTimeout(timer);
  }, [received]);
  async function send(seasons: number[] | null = null, rent = false) {
    setBusy(true);
    setError('');
    try {
      const result = await api('/requests', requestResponseSchema, 'POST', {
        mediaType: title.mediaType,
        tmdbId: title.tmdbId,
        ...(title.mediaType === 'tv' ? { seasons } : {}),
        ...(rent ? { rent: true } : {}),
      });
      setSeasonPicker(false);
      setRentConfirm(false);
      setConfirm(result.request);
      setReceived(true);
      refresh();
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  async function change(action: 'support' | 'watched') {
    if (!request) return;
    setBusy(true);
    setError('');
    try {
      await api(
        `/requests/${request.id}/${action}`,
        ignoredResponse,
        action === 'support' ? 'DELETE' : 'POST',
      );
      refresh();
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className={`request-controls ${compact ? 'compact-controls' : ''}`}>
      <ErrorText error={error} />
      {title.plexState === 'available' ? (
        <>
          {'watchUrl' in title && title.watchUrl ? (
            <a className="primary-button" href={title.watchUrl} target="_blank" rel="noreferrer">
              ▶ Watch in Plex
            </a>
          ) : (
            <button className="primary-button" onClick={() => setPlayback(true)}>
              ▶ Watch in Plex
            </button>
          )}
          {request?.status === 'available' && request.isSupporter && (
            <button
              className="text-button"
              disabled={busy}
              onClick={() => {
                void change('watched');
              }}
            >
              ✓ Mark Watched
            </button>
          )}
        </>
      ) : active?.isSupporter ? (
        <>
          <button className="primary-button requested-button" disabled>
            ✓ Requested
          </button>
          {active.status === 'requested' && (
            <button
              className="text-button"
              disabled={busy}
              onClick={() => {
                void change('support');
              }}
            >
              Withdraw my request
            </button>
          )}
          {!compact && active.rental && (
            <button
              className="text-button"
              disabled={busy}
              onClick={() => {
                void send(null, false);
              }}
            >
              Keep permanently instead
            </button>
          )}
        </>
      ) : title.plexState === 'unknown' ? (
        <p className="muted">Can’t confirm Plex right now. Try refreshing availability.</p>
      ) : (
        <>
          <button
            className="primary-button"
            disabled={busy}
            onClick={() => {
              if (title.mediaType === 'tv' && !active) setSeasonPicker(true);
              else void send();
            }}
          >
            {busy
              ? 'Sending…'
              : active
                ? '＋ Me Too'
                : title.releaseState === 'coming_soon'
                  ? '➤ Request When Available'
                  : '➤ Send Request'}
          </button>
          {!compact && title.mediaType === 'movie' && !active && (
            <button
              className="outline-button rental-button"
              disabled={busy}
              onClick={() => setRentConfirm(true)}
            >
              ◷ Rent for 7 days
            </button>
          )}
          {!compact && (
            <p className="muted request-hint">
              Your request will appear in My Requests so you can track its status.
            </p>
          )}
        </>
      )}
      {received && (
        <div className="request-received" role="status" onAnimationEnd={() => setReceived(false)}>
          ✓ Request received
        </div>
      )}
      {seasonPicker && (
        <Modal title="Which seasons?" onClose={() => setSeasonPicker(false)}>
          <label className="checkbox-row">
            <input type="checkbox" checked={selected === null} onChange={() => setSelected(null)} />
            All seasons
          </label>
          {'seasons' in title ? (
            title.seasons.map((item) => (
              <label className="checkbox-row" key={item.number}>
                <input
                  type="checkbox"
                  checked={selected?.includes(item.number) ?? false}
                  onChange={() =>
                    setSelected((value) =>
                      value?.includes(item.number)
                        ? value.filter((number) => number !== item.number)
                        : [...(value ?? []), item.number],
                    )
                  }
                />
                {item.name}
              </label>
            ))
          ) : (
            <p className="muted">
              Choose All seasons, or open title details for individual seasons.
            </p>
          )}
          <ErrorText error={error} />
          <button
            className="primary-button"
            disabled={busy || (selected !== null && !selected.length)}
            onClick={() => {
              void send(selected);
            }}
          >
            {busy ? 'Sending…' : 'Send Request'}
          </button>
        </Modal>
      )}
      {rentConfirm && (
        <Modal title="Rent this movie for 7 days?" onClose={() => setRentConfirm(false)}>
          <p>
            The seven-day clock starts when Plex confirms the movie is available. At the end,
            Plex Rentals will permanently remove that movie’s library file through Radarr.
          </p>
          <p className="muted">Only this explicitly rented movie is affected.</p>
          <div className="button-row">
            <button className="text-button" onClick={() => setRentConfirm(false)}>
              Cancel
            </button>
            <button
              className="primary-button"
              disabled={busy}
              onClick={() => {
                void send(null, true);
              }}
            >
              {busy ? 'Sending…' : 'Confirm 7-day rental'}
            </button>
          </div>
        </Modal>
      )}
      {confirm && <Confirmation request={confirm} onClose={() => setConfirm(null)} />}
      {playback && (
        <Modal title="Plex playback" onClose={() => setPlayback(false)}>
          <p>Open the title details to hand this movie or show off to Plex.</p>
        </Modal>
      )}
    </div>
  );
}
export function Bookmark({ title, saved }: { title: TitleCard; saved: boolean }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const refresh = useRefreshFamily();
  return (
    <>
      <button
        className={`icon-button bookmark-button ${saved ? 'bookmarked' : ''}`}
        aria-label={saved ? 'Remove from My List' : 'Add to My List'}
        aria-pressed={saved}
        disabled={busy}
        onClick={() => {
          setBusy(true);
          setError('');
          void api(
            `/list/${title.mediaType}/${title.tmdbId}`,
            ignoredResponse,
            saved ? 'DELETE' : 'PUT',
          )
            .then(refresh)
            .catch((e) => setError(message(e)))
            .finally(() => setBusy(false));
        }}
      >
        {saved ? '▣' : '▢'}
      </button>
      {error && (
        <p className="bookmark-error" role="alert">
          {error}
        </p>
      )}
    </>
  );
}
function RequestRow({ request, admin = false }: { request: RequestRecord; admin?: boolean }) {
  const pill =
    request.status === 'passed'
      ? { label: requestLabels.passed, state: 'passed' }
      : posterStatus(request.title);
  const [actions, setActions] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const start = useRef(0);
  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );
  return (
    <article
      className={`request-row ${request.status === 'available' ? 'request-available' : ''}`}
      onPointerDown={(event) => {
        start.current = event.clientX;
        timer.current = setTimeout(() => setActions(true), 550);
      }}
      onPointerUp={(event) => {
        if (timer.current) clearTimeout(timer.current);
        if (Math.abs(event.clientX - start.current) > 60) setActions(true);
      }}
      onPointerCancel={() => {
        if (timer.current) clearTimeout(timer.current);
      }}
    >
      <Link
        to={
          admin
            ? `/admin/requests/${request.id}`
            : `/title/${request.title.mediaType}/${request.title.tmdbId}`
        }
        onClick={(event) => {
          if (actions) event.preventDefault();
        }}
      >
        <Thumbnail title={request.title} />
        <div className="request-row-copy">
          <h2>{request.title.title}</h2>
          {pill && <span className={`status-pill state-${pill.state}`}>{pill.label}</span>}
          <p>
            Requested by {request.createdByName}
            {request.supporters.length > 1 ? ` + ${request.supporters.length - 1}` : ''}
          </p>
          <small>
            <DateStamp value={request.createdAt} />
          </small>
          <AutomationState request={request} />
        </div>
        <span className="row-chevron" aria-hidden="true">
          ›
        </span>
      </Link>
      {request.isSupporter && (
        <button
          className="row-actions"
          aria-label={`Actions for ${request.title.title}`}
          onClick={() => setActions(true)}
        >
          •••
        </button>
      )}
      {actions && (
        <Modal title={request.title.title} onClose={() => setActions(false)}>
          <RequestControls title={request.title} request={request} />
          <button className="text-button" onClick={() => setActions(false)}>
            Close
          </button>
        </Modal>
      )}
    </article>
  );
}
export function RequestsPage({ admin = false }: { admin?: boolean }) {
  const { session, live } = useSession();
  const [filter, setFilter] = useState('all');
  const [mine, setMine] = useState(false);
  const [sort, setSort] = useState('newest');
  const [person, setPerson] = useState('');
  const [type, setType] = useState('');
  const search = new URLSearchParams({ scope: mine ? 'mine' : 'family', sort, limit: '30' });
  if (requestStatus.options.some((value) => value === filter)) search.set('status', filter);
  if (filter === 'coming_soon' || filter === 'ready') search.set('filter', filter);
  if (['awaiting', 'approved', 'declined', 'attention'].includes(filter))
    search.set('approval', filter);
  if (person) search.set('person', person);
  if (type) search.set('type', type);
  const query = useInfiniteQuery({
    queryKey: [
      'requests',
      session.profile?.id,
      session.profile?.maxRatingLevel,
      admin,
      search.toString(),
    ],
    initialPageParam: null as string | null,
    queryFn: ({ pageParam, signal }) =>
      api(
        `${admin ? '/admin' : ''}/requests?${search}${pageParam ? `&cursor=${encodeURIComponent(pageParam)}` : ''}`,
        requestsResponseSchema,
        'GET',
        undefined,
        signal,
      ),
    getNextPageParam: (last) => last.nextCursor ?? undefined,
  });
  const stats = useQuery({
    queryKey: ['stats', session.profile?.id, session.profile?.maxRatingLevel],
    queryFn: ({ signal }) => api('/admin/stats', adminStatsSchema, 'GET', undefined, signal),
    enabled: admin,
  });
  const rows = query.data?.pages.flatMap((page) => page.requests) ?? [];
  const filters = [
    ['all', 'All'],
    ['requested', 'Requested'],
    ['looking', 'Looking'],
    ['available', 'Available in Plex'],
    ['watched', 'Watched'],
    ['coming_soon', 'Coming Soon'],
    ...(admin
      ? [
          ['awaiting', 'Awaiting approval'],
          ['approved', 'Approved'],
          ['attention', 'Needs attention'],
          ['declined', 'Declined'],
          ['ready', 'Ready to Get'],
          ['passed', 'Not this time'],
        ]
      : []),
  ];
  return (
    <main className={`family-page ${admin ? 'dashboard-page' : ''}`}>
      <div className="row-heading">
        <div>{admin && <p className="eyebrow">PLEX RENTALS · ADMIN</p>}<h1>{admin ? 'Command center' : 'My Requests'}</h1>{admin && <p className="muted">Your household’s movie night, under control.</p>}</div>
        {admin && (
          <Link className="icon-button" to="/settings" aria-label="Household settings">
            ⚙
          </Link>
        )}
      </div>
      {admin && <>
        <div className="command-metrics">
          {([['all','Total requests',stats.data?.total],['requested','Requested',stats.data?.counts.requested],['looking','In progress',stats.data?.counts.looking],['available','Ready in Plex',stats.data?.counts.available]] as const).map(([value,label,count])=><button key={value} aria-pressed={filter===value} onClick={()=>setFilter(value)}><span>{label}</span><strong>{count ?? '—'}</strong><small>View requests ↗</small></button>)}
        </div>
        <Link className="outline-button" to="/admin/storage">Storage dashboard →</Link><AdminOverview />
        <div className="command-queue-heading"><div><p className="eyebrow">HOUSEHOLD QUEUE</p><h2>Every request. One place.</h2></div><button className="outline-button" onClick={()=>setFilter('attention')}>Needs attention ↗</button></div>
      </>}
      <FilterRow className="wrap">
        {filters.map(([value, label]) => {
          const count = stats.data
            ? value === 'all'
              ? stats.data.total
              : value === 'coming_soon'
                ? stats.data.comingSoon
                : value === 'ready'
                  ? stats.data.readyToGet
                  : stats.data.counts[value as keyof typeof stats.data.counts]
            : undefined;
          return (
            <button
              key={value}
              className="filter-chip"
              aria-pressed={filter === value}
              onClick={() => setFilter(value!)}
            >
              {label}
              {count === undefined ? '' : ` (${count})`}
            </button>
          );
        })}
        {!admin && (
          <button className="filter-chip" aria-pressed={mine} onClick={() => setMine(!mine)}>
            Mine
          </button>
        )}
      </FilterRow>
      <p className="live-status" role="status">
        <span className={live ? 'live-dot' : 'offline-dot'} />
        {live ? 'Live updates' : 'Reconnecting live updates…'}
      </p>
      {admin && (
        <div className="dashboard-filters">
          <label>
            Sort
            <select value={sort} onChange={(event) => setSort(event.target.value)}>
              <option value="newest">Newest first</option>
              <option value="oldest">Oldest first</option>
              <option value="supporters">Most supporters</option>
            </select>
          </label>
          <label>
            Person
            <select value={person} onChange={(event) => setPerson(event.target.value)}>
              <option value="">Everyone</option>
              {stats.data?.byPerson.map((item) => (
                <option key={item.profileId} value={item.profileId}>
                  {item.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            Type
            <select value={type} onChange={(event) => setType(event.target.value)}>
              <option value="">Movies & TV</option>
              <option value="movie">Movies</option>
              <option value="tv">TV Shows</option>
            </select>
          </label>
        </div>
      )}
      <div className="dashboard-layout">
        <section className="requests-list">
          {query.isPending ? (
            <p role="status">Loading requests…</p>
          ) : query.isError ? (
            <>
              <ErrorText error={message(query.error)} />
              <button
                className="outline-button"
                onClick={() => {
                  void query.refetch();
                }}
              >
                Try again
              </button>
            </>
          ) : rows.length ? (
            <>
              {admin && (
                <table className="desktop-request-table">
                  <thead>
                    <tr>
                      <th>Title</th>
                      <th>Requested by</th>
                      <th>When</th>
                      <th>Status</th>
                      <th>People</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((request) => (
                      <tr key={request.id}>
                        <td>
                          <Link to={`/admin/requests/${request.id}`}>
                            <Thumbnail title={request.title} />
                            <strong>{request.title.title}</strong>
                          </Link>
                        </td>
                        <td>{request.createdByName}</td>
                        <td>
                          <DateStamp value={request.createdAt} />
                        </td>
                        <td>
                          <span className="table-statuses">
                            <span
                              className={`status-pill state-${request.status === 'passed' ? 'passed' : (posterStatus(request.title)?.state ?? request.status)}`}
                            >
                              {request.status === 'passed'
                                ? requestLabels.passed
                                : (posterStatus(request.title)?.label ??
                                  requestLabels[request.status])}
                            </span>
                            <AutomationState request={request} />
                          </span>
                        </td>
                        <td>{request.supporters.length}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
              <div className={admin ? 'mobile-request-rows' : ''}>
                {rows.map((request) => (
                  <RequestRow key={request.id} request={request} admin={admin} />
                ))}
              </div>
            </>
          ) : (
            <div className="empty-state">
              <h2>No requests here yet.</h2>
              <p>Browse the catalog and pick something for the next movie night.</p>
              <Link className="outline-button" to="/">
                Find a movie
              </Link>
            </div>
          )}
          {query.hasNextPage && (
            <button
              className="outline-button load-more"
              disabled={query.isFetchingNextPage}
              onClick={() => {
                void query.fetchNextPage();
              }}
            >
              {query.isFetchingNextPage ? 'Loading…' : 'Load more'}
            </button>
          )}
        </section>
        {admin && stats.data && (
          <aside className="dashboard-aside">
            <section>
              <h2>Most Requested</h2>
              {stats.data.mostRequested.map((item) => (
                <Link key={item.id} to={`/admin/requests/${item.id}`}>
                  {item.title.title}
                  <span>{item.supporters.length} people</span>
                </Link>
              ))}
            </section>
            <section>
              <h2>Requests by Person</h2>
              {stats.data.byPerson.map((item) => (
                <p key={item.profileId}>
                  {item.name}
                  <span>{item.count}</span>
                </p>
              ))}
            </section>
            <section>
              <h2>Coming Soon</h2>
              {stats.data.comingSoonRequests.map((item) => (
                <Link key={item.id} to={`/admin/requests/${item.id}`}>
                  {item.title.title}
                </Link>
              ))}
            </section>
            <section>
              <h2>Recently Available</h2>
              {stats.data.recentlyAvailable.map((item) => (
                <Link key={item.id} to={`/admin/requests/${item.id}`}>
                  {item.title.title}
                </Link>
              ))}
            </section>
          </aside>
        )}
      </div>
    </main>
  );
}
export function RequestsRoute() {
  const { session } = useSession();
  return session.profile?.isAdmin ? (
    <AdminGuard>
      <RequestsPage admin />
    </AdminGuard>
  ) : (
    <RequestsPage />
  );
}
export function AdminRequest() {
  const { id = '' } = useParams();
  const { session } = useSession();
  const query = useQuery({
    queryKey: ['admin-request', session.profile?.id, session.profile?.maxRatingLevel, id],
    queryFn: ({ signal }) =>
      api(`/admin/requests/${id}`, requestResponseSchema, 'GET', undefined, signal),
  });
  return (
    <main className="family-page">
      <Link className="text-button" to="/requests">
        ← Dashboard
      </Link>
      {query.isPending ? (
        <p role="status">Loading request…</p>
      ) : query.isError ? (
        <>
          <ErrorText error={message(query.error)} />
          <button
            className="outline-button"
            onClick={() => {
              void query.refetch();
            }}
          >
            Try again
          </button>
        </>
      ) : (
        <AdminRequestForm key={query.data.request.id} request={query.data.request} />
      )}
    </main>
  );
}
function AdminRequestForm({ request }: { request: RequestRecord }) {
  const [noteDraft, setNote] = useState<string | null>(null);
  const [statusDraft, setStatus] = useState<RequestRecord['status'] | null>(null);
  const note = noteDraft ?? request.adminNote ?? '';
  const status = statusDraft ?? request.status;
  const [plexKey, setPlexKey] = useState('');
  const { session } = useSession();
  const plex = useQuery({
    queryKey: ['plex-items', session.profile?.id, session.profile?.maxRatingLevel],
    queryFn: ({ signal }) =>
      api('/admin/plex/items', plexItemsResponseSchema, 'GET', undefined, signal),
    enabled: status === 'available' && request.status !== 'available',
  });
  const nextStatuses: Record<RequestRecord['status'], readonly RequestRecord['status'][]> = {
    requested: ['looking', 'available', 'passed'],
    looking: ['available', 'passed'],
    available: ['watched'],
    watched: ['requested'],
    passed: ['requested'],
    cancelled: ['requested'],
  };
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState('');
  const [approval, setApproval] = useState<'approve' | 'decline' | null>(null);
  const [declineReason, setDeclineReason] = useState('');
  const refresh = useRefreshFamily();
  async function decide(decision: 'approved' | 'declined') {
    setBusy(true);
    setError('');
    setSaved('');
    try {
      await api(`/admin/requests/${request.id}/approval`, requestResponseSchema, 'POST', {
        decision,
        ...(decision === 'declined' ? { reason: declineReason } : {}),
      });
      setSaved(decision === 'approved' ? 'Request approved.' : 'Request declined.');
      setApproval(null);
      setDeclineReason('');
      refresh();
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <div className="admin-request-heading">
        <Thumbnail title={request.title} />
        <div>
          <h1>{request.title.title}</h1>
          <Link
            className="text-button"
            to={`/title/${request.title.mediaType}/${request.title.tmdbId}`}
          >
            View full title details →
          </Link>
        </div>
      </div>
      <RequestBlock request={request} />
      {['requested', 'looking'].includes(request.status) && (
        <section className="approval-panel">
          <h2>Approval</h2>
          <p>
            <strong>{request.title.mediaType === 'movie' ? 'Movie' : 'TV'} scope:</strong>{' '}
            {request.title.mediaType === 'movie'
              ? 'This movie'
              : request.seasons === null
                ? 'Entire series, including future seasons'
                : `Seasons ${request.seasons.join(', ')}`}
          </p>
          <AutomationState request={request} />
          {request.automation?.decidedAt && (
            <p className="muted">
              {request.automation.decidedByName ?? 'Admin'} ·{' '}
              <DateStamp value={request.automation.decidedAt} />
            </p>
          )}
          {request.automation?.submissionStatus === 'failed' && (
            <button
              className="outline-button"
              disabled={busy}
              onClick={() => {
                setBusy(true);
                setError('');
                void api(`/admin/requests/${request.id}/retry`, requestResponseSchema, 'POST')
                  .then(() => {
                    setSaved('Submission queued for retry.');
                    refresh();
                  })
                  .catch((e) => setError(message(e)))
                  .finally(() => setBusy(false));
              }}
            >
              Retry submission
            </button>
          )}
          {request.automation?.decision !== 'approved' && (
            <div className="settings-actions">
              <button className="primary-button" onClick={() => setApproval('approve')}>
                Approve request
              </button>
              <button className="outline-button" onClick={() => setApproval('decline')}>
                Decline
              </button>
            </div>
          )}
        </section>
      )}
      <form
        className="admin-request-form"
        onSubmit={(event) => {
          event.preventDefault();
          setBusy(true);
          setError('');
          setSaved('');
          void api(`/admin/requests/${request.id}`, requestResponseSchema, 'PATCH', {
            ...(statusDraft !== null && statusDraft !== request.status
              ? { status: statusDraft }
              : {}),
            ...(noteDraft !== null ? { adminNote: note || null } : {}),
            ...(status === 'available' && plexKey ? { plexRatingKey: plexKey } : {}),
          })
            .then(() => {
              setSaved('Request updated. The family will see it live.');
              setStatus(null);
              setNote(null);
              setPlexKey('');
              refresh();
            })
            .catch((e) => setError(message(e)))
            .finally(() => setBusy(false));
        }}
      >
        <h2>Manage request</h2>
        <label htmlFor="request-status">Status</label>
        <select
          id="request-status"
          value={status}
          onChange={(event) => setStatus(requestStatus.parse(event.target.value))}
        >
          {[request.status, ...nextStatuses[request.status]].map((value) => (
            <option value={value} key={value}>
              {value === 'requested' && request.status !== 'requested'
                ? 'Reopen · Requested'
                : requestLabels[value]}
            </option>
          ))}
        </select>
        {status === 'available' && request.status !== 'available' && (
          <>
            <label htmlFor="plex-item">Match a stored Plex item</label>
            <select
              id="plex-item"
              required
              value={plexKey}
              onChange={(event) => setPlexKey(event.target.value)}
            >
              <option value="">Choose a matching item</option>
              {plex.data?.items
                .filter((item) => item.mediaType === request.title.mediaType)
                .map((item) => (
                  <option value={item.ratingKey} key={item.ratingKey}>
                    {item.title}
                    {item.year ? ` (${item.year})` : ''}
                  </option>
                ))}
            </select>
            <p className="muted">
              These are stored library entries. Demo entries simulate a match; your live Plex
              library is not connected yet.
            </p>
            {plex.isError && <ErrorText error={message(plex.error)} />}
          </>
        )}
        <label htmlFor="admin-note">Admin note</label>
        <textarea
          id="admin-note"
          rows={4}
          maxLength={2000}
          value={note}
          onChange={(event) => setNote(event.target.value)}
        />
        <ErrorText error={error} />
        <p role="status" className="save-message">
          {saved}
        </p>
        <button
          className="primary-button"
          disabled={
            busy ||
            (noteDraft === null && statusDraft === null) ||
            (status === 'available' && request.status !== 'available' && !plexKey)
          }
        >
          {busy ? 'Saving…' : 'Save changes'}
        </button>
      </form>
      {approval && (
        <Modal
          title={approval === 'approve' ? `Approve ${request.title.title}?` : 'Decline request'}
          onClose={() => setApproval(null)}
        >
          <p>
            {approval === 'approve'
              ? `This approves ${request.automation?.scopeLabel || (request.title.mediaType === 'movie' ? 'the movie' : request.seasons === null ? 'the entire series, including future seasons' : `seasons ${request.seasons.join(', ')}`)}. It will be sent only if the matching integration is enabled and configured.`
              : 'The family will see that this request was declined.'}
          </p>
          {approval === 'decline' && (
            <>
              <label htmlFor="decline-reason">Reason</label>
              <textarea
                id="decline-reason"
                rows={3}
                maxLength={500}
                required
                value={declineReason}
                onChange={(event) => setDeclineReason(event.target.value)}
              />
            </>
          )}
          <ErrorText error={error} />
          <button
            className="primary-button"
            disabled={busy || (approval === 'decline' && !declineReason.trim())}
            onClick={() => void decide(approval === 'approve' ? 'approved' : 'declined')}
          >
            {busy ? 'Saving…' : approval === 'approve' ? 'Confirm approval' : 'Decline request'}
          </button>
          <button className="text-button" onClick={() => setApproval(null)}>
            Cancel
          </button>
        </Modal>
      )}
    </>
  );
}
export function MyList() {
  const { session } = useSession();
  const query = useInfiniteQuery({
    queryKey: ['list', session.profile?.id, session.profile?.maxRatingLevel],
    initialPageParam: null as string | null,
    queryFn: ({ pageParam, signal }) =>
      api(
        `/list?limit=30${pageParam ? `&cursor=${encodeURIComponent(pageParam)}` : ''}`,
        listResponseSchema,
        'GET',
        undefined,
        signal,
      ),
    getNextPageParam: (last) => last.nextCursor ?? undefined,
  });
  const items = query.data?.pages.flatMap((page) => page.items) ?? [];
  return (
    <main className="family-page">
      <h1>My List</h1>
      <p className="muted">Your own shortlist for movie night.</p>
      {query.isPending ? (
        <p role="status">Loading your list…</p>
      ) : query.isError ? (
        <>
          <ErrorText error={message(query.error)} />
          <button
            className="outline-button"
            onClick={() => {
              void query.refetch();
            }}
          >
            Try again
          </button>
        </>
      ) : items.length ? (
        <div className="poster-grid list-grid">
          {items.map((title) => (
            <article key={`${title.mediaType}-${title.tmdbId}`}>
              <Link to={`/title/${title.mediaType}/${title.tmdbId}`}>
                <Thumbnail title={title} />
                {posterStatus(title) && (
                  <span className={`status-pill state-${posterStatus(title)!.state}`}>
                    {posterStatus(title)!.label}
                  </span>
                )}
              </Link>
              <Bookmark title={title} saved />
            </article>
          ))}
        </div>
      ) : (
        <section className="empty-state">
          <h2>A good movie starts with a little list.</h2>
          <p>Tap the bookmark on any title to save it here.</p>
          <Link className="outline-button" to="/">
            Browse titles
          </Link>
        </section>
      )}
      {query.hasNextPage && (
        <button
          className="outline-button load-more"
          disabled={query.isFetchingNextPage}
          onClick={() => {
            void query.fetchNextPage();
          }}
        >
          Load more
        </button>
      )}
    </main>
  );
}



