import { afterEach, expect, it, vi } from 'vitest';
import { getHome } from './catalog-api';

afterEach(() => vi.unstubAllGlobals());
it('shows the safe server explanation for rejected TMDB configuration', async () => {
  vi.stubGlobal(
    'fetch',
    vi.fn().mockResolvedValue(
      Response.json(
        {
          error: {
            code: 'TMDB_CONFIGURATION',
            message: 'TMDB is not configured with a valid read access token.',
          },
        },
        { status: 503 },
      ),
    ),
  );
  await expect(getHome('', new AbortController().signal)).rejects.toThrow(
    'valid read access token',
  );
});
it('does not expose raw proxy responses or schema diagnostics to the user', async () => {
  vi.stubGlobal(
    'fetch',
    vi.fn().mockResolvedValue(new Response('<h1>internal debug</h1>', { status: 502 })),
  );
  await expect(getHome('', new AbortController().signal)).rejects.toThrow(
    'The catalog could not be loaded.',
  );
  vi.stubGlobal('fetch', vi.fn().mockResolvedValue(Response.json({ unexpected: true })));
  await expect(getHome('', new AbortController().signal)).rejects.toThrow(
    'The catalog response could not be read.',
  );
});
