import { useEffect, useRef, useState } from 'react';

export function PixelAvatar({
  color,
  onChoose,
}: {
  color: string;
  onChoose: (value: string) => void;
}) {
  const [source, setSource] = useState<HTMLImageElement | null>(null);
  const [zoom, setZoom] = useState(1);
  const [x, setX] = useState(50);
  const [y, setY] = useState(50);
  const [pixels, setPixels] = useState(32);
  const [palette, setPalette] = useState('natural');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const canvas = useRef<HTMLCanvasElement>(null);
  const generation = useRef(0);
  useEffect(
    () => () => {
      generation.current++;
    },
    [],
  );
  async function load(file?: File) {
    if (!file) return;
    const version = ++generation.current;
    setError('');
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 20_000_000) {
      setError('Choose a JPEG, PNG or WebP photo under 20 MB.');
      return;
    }
    setBusy(true);
    const url = URL.createObjectURL(file);
    try {
      const photo = new Image();
      photo.src = url;
      await photo.decode();
      if (version !== generation.current) return;
      if (photo.naturalWidth * photo.naturalHeight > 50_000_000) throw new Error('Too large');
      setSource(photo);
      setZoom(1);
      setX(50);
      setY(50);
    } catch {
      if (version === generation.current)
        setError('This photo could not be opened. Try a smaller JPEG.');
    } finally {
      URL.revokeObjectURL(url);
      if (version === generation.current) setBusy(false);
    }
  }
  useEffect(() => {
    if (!source || !canvas.current) return;
    const tiny = document.createElement('canvas');
    tiny.width = pixels;
    tiny.height = pixels;
    const ctx = tiny.getContext('2d');
    const output = canvas.current.getContext('2d');
    if (!ctx || !output) return;
    const side = Math.min(source.naturalWidth, source.naturalHeight) / zoom;
    if (pixels === 0) {
      output.imageSmoothingEnabled = true;
      output.imageSmoothingQuality = 'high';
      output.fillStyle = color;
      output.fillRect(0, 0, 256, 256);
      output.drawImage(source, ((source.naturalWidth - side) * x) / 100,
        ((source.naturalHeight - side) * y) / 100, side, side, 0, 0, 256, 256);
      return;
    }
    ctx.fillStyle = color;
    ctx.fillRect(0, 0, pixels, pixels);
    ctx.drawImage(
      source,
      ((source.naturalWidth - side) * x) / 100,
      ((source.naturalHeight - side) * y) / 100,
      side,
      side,
      0,
      0,
      pixels,
      pixels,
    );
    const frame = ctx.getImageData(0, 0, pixels, pixels);
    for (let i = 0; i < frame.data.length; i += 4) {
      const light =
        frame.data[i]! * 0.299 + frame.data[i + 1]! * 0.587 + frame.data[i + 2]! * 0.114;
      if (palette === 'gameboy') {
        const shades = [
          [15, 56, 15],
          [48, 98, 48],
          [139, 172, 15],
          [155, 188, 15],
        ];
        const shade = shades[Math.min(3, Math.floor(light / 64))]!;
        frame.data[i] = shade[0]!;
        frame.data[i + 1] = shade[1]!;
        frame.data[i + 2] = shade[2]!;
      } else {
        for (let channel = 0; channel < 3; channel++) {
          frame.data[i + channel] =
            Math.round((palette === 'mono' ? light : frame.data[i + channel]!) / 32) * 32;
        }
      }
    }
    ctx.putImageData(frame, 0, 0);
    output.imageSmoothingEnabled = false;
    output.clearRect(0, 0, 256, 256);
    output.drawImage(tiny, 0, 0, 256, 256);
  }, [source, zoom, x, y, pixels, palette, color]);
  return (
    <fieldset className="pixel-avatar-editor">
      <legend>Make my profile picture</legend>
      <p>
        Your original photo stays on this device. Only the finished avatar is saved to Plex Rentals
        when you save the profile.
      </p>
      <label className="avatar-source-action avatar-source-camera">
        <span className="avatar-source-icon" aria-hidden="true">◉</span>
        <span>
          <strong>Take a selfie</strong>
          <small>Open your camera for a natural or pixel portrait.</small>
        </span>
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp"
          capture="user"
          disabled={busy}
          onChange={(e) => {
            void load(e.target.files?.[0]);
            e.target.value = '';
          }}
        />
      </label>
      <label className="avatar-source-action avatar-source-upload">
        <span className="avatar-source-icon" aria-hidden="true">↑</span>
        <span>
          <strong>Upload a photo</strong>
          <small>Choose an existing picture from this device.</small>
        </span>
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp"
          disabled={busy}
          onChange={(e) => {
            void load(e.target.files?.[0]);
            e.target.value = '';
          }}
        />
      </label>
      {busy && <p role="status">Opening photo locally…</p>}
      {error && <p role="alert">{error}</p>}
      {source && (
        <>
          <canvas ref={canvas} width={256} height={256} aria-label="Profile picture preview"
            style={{ imageRendering: pixels === 0 ? 'auto' : 'pixelated' }} />
          <label>
            Zoom
            <input
              type="range"
              min="1"
              max="4"
              step="0.05"
              value={zoom}
              onChange={(e) => setZoom(Number(e.target.value))}
            />
          </label>
          <label>
            Horizontal position
            <input
              type="range"
              min="0"
              max="100"
              value={x}
              onChange={(e) => setX(Number(e.target.value))}
            />
          </label>
          <label>
            Vertical position
            <input
              type="range"
              min="0"
              max="100"
              value={y}
              onChange={(e) => setY(Number(e.target.value))}
            />
          </label>
          <label>
            Picture style
            <select value={pixels} onChange={(e) => setPixels(Number(e.target.value))}>
              <option value={0}>Normal photo</option>
              <option value={16}>Chunky</option>
              <option value={32}>Classic</option>
              <option value={64}>Detailed</option>
            </select>
          </label>
          <label>
            Colors
            <select disabled={pixels === 0} value={palette} onChange={(e) => setPalette(e.target.value)}>
              <option value="natural">Natural</option>
              <option value="gameboy">Retro green</option>
              <option value="mono">Black and white</option>
            </select>
          </label>
          <button
            type="button"
            className="outline-button"
            disabled={busy}
            onClick={() => {
              if (canvas.current) {
                onChoose(canvas.current.toDataURL('image/png'));
                setSource(null);
              }
            }}
          >
            {pixels === 0 ? 'Use this photo' : 'Use this pixel avatar'}
          </button>
          <button
            type="button"
            className="text-button"
            onClick={() => {
              generation.current++;
              setSource(null);
              setBusy(false);
            }}
          >
            Discard preview
          </button>
        </>
      )}
    </fieldset>
  );
}
