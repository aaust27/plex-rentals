import { describe, expect, it } from 'vitest';
import { parseHealth } from './health';

describe('health response', () => {
  const valid = { status: 'ok', phase: 2, database: 'ready', plexMode: 'mock', plexReady: true };
  it('accepts a real Phase 2 response', () => {
    expect(parseHealth(valid)).toEqual(valid);
  });
  it('rejects empty and malformed responses instead of reporting success', () => {
    for (const value of [
      null,
      {},
      '',
      { ...valid, database: 'broken' },
      { ...valid, plexMode: 'live' },
    ]) {
      expect(() => parseHealth(value)).toThrow('unexpected response');
    }
  });
});
