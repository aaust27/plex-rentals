import { useState } from 'react';
import { useInfiniteQuery, useQueryClient } from '@tanstack/react-query';
import { titleSocialResponseSchema } from '@reelrequest/shared';
import { api, ignoredResponse, message } from './api';
import { useSession, ErrorText } from './session';
import { DateStamp } from './Family';

export function TitleSocial({ mediaType, tmdbId }: { mediaType: 'movie' | 'tv'; tmdbId: number }) {
  const { session } = useSession();
  const client = useQueryClient();
  const [score, setScore] = useState('');
  const [body, setBody] = useState('');
  const [mentions, setMentions] = useState<number[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const path = `/titles/${mediaType}/${tmdbId}/social`;
  const key = ['title-social', session.profile?.id, mediaType, tmdbId];
  const query = useInfiniteQuery({
    queryKey: key,
    initialPageParam: null as number | null,
    queryFn: ({ pageParam, signal }) =>
      api(
        path + (pageParam ? `?before=${pageParam}` : ''),
        titleSocialResponseSchema,
        'GET',
        undefined,
        signal,
      ),
    getNextPageParam: (p) => p.nextCursor ?? undefined,
    refetchInterval: 30000,
  });
  const data = query.data?.pages[0];
  async function save(kind: 'rating' | 'comments') {
    setBusy(true);
    setError('');
    setNotice('');
    try {
      await api(
        `${path}/${kind}`,
        ignoredResponse,
        kind === 'rating' ? 'PUT' : 'POST',
        kind === 'rating' ? { score: Number(score) } : { body, mentions },
      );
      if (kind === 'comments') {
        setBody('');
        setMentions([]);
      }
      setNotice(kind === 'rating' ? 'Your rating is saved.' : 'Comment posted.');
      await client.invalidateQueries({ queryKey: key });
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="title-social" aria-labelledby="household-reviews">
      <header className="social-heading">
        <div>
          <span className="eyebrow">THE HOUSEHOLD VERDICT</span>
          <h2 id="household-reviews">Worth movie night?</h2>
          <p className="muted">Your people. Their honest takes.</p>
        </div>
        <div className="social-average">
          <span aria-hidden="true">★</span> {data?.average == null ? '—' : data.average.toFixed(1)}
          <small>/ 10 · {data?.count ?? 0} ratings</small>
        </div>
      </header>
      {query.isPending ? (
        <p role="status">Loading household reviews…</p>
      ) : query.isError ? (
        <>
          <ErrorText error={message(query.error)} />
          <button className="outline-button" onClick={() => void query.refetch()}>
            Try again
          </button>
        </>
      ) : (
        data && (
          <>
            <form
              className="social-rate"
              onSubmit={(e) => {
                e.preventDefault();
                void save('rating');
              }}
            >
              <label>
                Your rating
                <select
                  aria-label="Your rating"
                  value={score || String(data.myScore ?? '')}
                  onChange={(e) => setScore(e.target.value)}
                >
                  <option value="">Choose stars</option>
                  {Array.from({ length: 21 }, (_, i) => i / 2).map((n) => (
                    <option key={n} value={n}>
                      {n} / 10 stars
                    </option>
                  ))}
                </select>
              </label>
              <button className="primary-button" disabled={busy || score === ''}>
                Save rating
              </button>
              <span className="muted">Half stars welcome. You can change your rating anytime.</span>
            </form>
            {data.ratings.length > 0 && (
              <ul className="social-ratings" aria-label="Household ratings">
                {data.ratings.map((r) => (
                  <li key={r.profileId}>
                    <span>{r.name}</span>
                    <strong>
                      ★ {r.score}
                      <small> / 10</small>
                    </strong>
                  </li>
                ))}
              </ul>
            )}
            <h3>Start a conversation</h3>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                void save('comments');
              }}
              className="social-compose"
            >
              <label htmlFor="movie-comment">Your comment</label>
              <textarea
                id="movie-comment"
                value={body}
                onChange={(e) => setBody(e.target.value)}
                maxLength={2000}
                rows={3}
                placeholder="What did you think? Keep spoilers out of the spotlight."
                required
              />
              <div className="social-compose-footer">
                <label>
                  Tag someone
                  <select
                    aria-label="Tag someone"
                    value=""
                    onChange={(e) => {
                      const id = Number(e.target.value);
                      if (id && !mentions.includes(id)) setMentions([...mentions, id]);
                    }}
                    disabled={mentions.length >= 10}
                  >
                    <option value="">＋ Choose a person</option>
                    {data.people
                      .filter(
                        (p) =>
                          p.profileId !== session.profile?.id && !mentions.includes(p.profileId),
                      )
                      .map((p) => (
                        <option key={p.profileId} value={p.profileId}>
                          {p.name}
                        </option>
                      ))}
                  </select>
                </label>
                <span className="muted">{body.length}/2000</span>
                <button className="primary-button" disabled={busy || !body.trim()}>
                  Post comment
                </button>
              </div>
              {mentions.length > 0 && (
                <div className="social-tags">
                  {mentions.map((id) => (
                    <button
                      type="button"
                      className="filter-chip"
                      key={id}
                      aria-label={`Remove tag ${data.people.find((p) => p.profileId === id)?.name}`}
                      onClick={() => setMentions(mentions.filter((n) => n !== id))}
                    >
                      @{data.people.find((p) => p.profileId === id)?.name} ×
                    </button>
                  ))}
                </div>
              )}
              <small className="muted">
                Comments are visible to the household. Tagged people receive a notification.
              </small>
            </form>
            <div className="social-comments">
              {query.data?.pages
                .flatMap((p) => p.comments)
                .map((c) => (
                  <article key={c.id}>
                    <header>
                      <strong>{c.name}</strong>
                      <small className="muted">
                        <DateStamp value={c.createdAt} />
                      </small>
                    </header>
                    {c.mentions.length > 0 && (
                      <div className="social-tags">
                        {c.mentions.map((p) => (
                          <span key={p.profileId}>@{p.name}</span>
                        ))}
                      </div>
                    )}
                    <p>{c.body}</p>
                  </article>
                ))}
              {!data.comments.length && <p className="muted">Be the first to leave a take.</p>}
            </div>
            {query.hasNextPage && (
              <button
                className="outline-button"
                disabled={query.isFetchingNextPage}
                onClick={() => void query.fetchNextPage()}
              >
                Older comments
              </button>
            )}
          </>
        )
      )}
      <ErrorText error={error} />
      <p role="status" className="social-notice">
        {notice}
      </p>
    </section>
  );
}
