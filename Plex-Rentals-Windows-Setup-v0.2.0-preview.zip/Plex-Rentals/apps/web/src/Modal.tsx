import { useEffect, useRef, useState, type ReactNode } from 'react';
export function Modal({
  title,
  children,
  onClose,
  trailer = false,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
  trailer?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  // Capture before React commits autoFocus inside the dialog.
  const [returnFocus] = useState(() =>
    document.activeElement instanceof HTMLElement ? document.activeElement : null,
  );
  useEffect(() => {
    const dialog = ref.current;
    dialog?.showModal();
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      dialog?.close();
      document.body.style.overflow = overflow;
      if (returnFocus?.isConnected) returnFocus.focus();
    };
  }, [returnFocus]);
  return (
    <dialog
      ref={ref}
      className={trailer ? 'modal trailer-modal' : 'modal'}
      aria-label={title}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
    >
      <div className="modal-heading">
        <h2>{title}</h2>
        <button className="icon-button" autoFocus onClick={onClose} aria-label={`Close ${title}`}>
          ×
        </button>
      </div>
      {children}
    </dialog>
  );
}
