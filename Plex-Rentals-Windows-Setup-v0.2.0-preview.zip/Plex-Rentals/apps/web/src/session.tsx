import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useNavigate } from 'react-router-dom';
import {
  profilesResponseSchema,
  sessionResponseSchema,
  type Profile,
  type SessionResponse,
} from '@reelrequest/shared';
import { api, ignoredResponse, message } from './api';
import { Avatar } from './Avatar';
import { ReelIcon } from './App';
import { Modal } from './Modal';

const Context = createContext<{
  session: SessionResponse;
  refresh: () => Promise<void>;
  switchProfile: () => Promise<void>;
  live: boolean;
} | null>(null);
export function useSession() {
  const value = useContext(Context);
  if (!value) throw new Error('Session provider missing');
  return value;
}
export function ErrorText({ error }: { error: string }) {
  return error ? (
    <p className="form-error" role="alert">
      {error}
    </p>
  ) : null;
}
export function PinForm({
  heading,
  submit,
  cancel,
}: {
  heading: string;
  submit: (pin: string) => Promise<void>;
  cancel?: () => void;
}) {
  const [pin, setPin] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [touchInput] = useState(
    () => typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches,
  );
  async function send() {
    if (pin.length !== 4 || busy) return;
    setBusy(true);
    setError('');
    try {
      await submit(pin);
    } catch (e) {
      setError(message(e));
      setPin('');
    } finally {
      setBusy(false);
    }
  }
  return (
    <form
      className="pin-form"
      onSubmit={(event) => {
        event.preventDefault();
        void send();
      }}
    >
      <h2>{heading}</h2>
      <label className="sr-only" htmlFor="profile-pin">
        Four-digit PIN
      </label>
      <input
        id="profile-pin"
        aria-label="Four-digit PIN"
        autoFocus={!touchInput}
        type="password"
        inputMode="none"
        autoComplete="off"
        maxLength={4}
        pattern="[0-9]{4}"
        value={pin}
        onChange={(event) => setPin(event.target.value.replace(/\D/g, ''))}
      />
      <div className="pin-keypad">
        {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'Clear', '0', '⌫'].map((key) => (
          <button
            type="button"
            disabled={busy}
            key={key}
            aria-label={key === '⌫' ? 'Delete last digit' : key}
            onClick={() =>
              setPin((value) =>
                key === 'Clear' ? '' : key === '⌫' ? value.slice(0, -1) : (value + key).slice(0, 4),
              )
            }
          >
            {key}
          </button>
        ))}
      </div>
      <ErrorText error={error} />
      <button className="primary-button" disabled={pin.length !== 4 || busy}>
        {busy ? 'Checking…' : 'Continue'}
      </button>
      {cancel && (
        <button type="button" className="text-button" onClick={cancel}>
          Back
        </button>
      )}
    </form>
  );
}
function WelcomeFrame({ children }: { children: ReactNode }) {
  return (
    <main className="family-welcome" id="main-content">
      <div className="sunset-slot" aria-hidden="true" data-artwork-slot="welcome-backdrop">
        <div className="sunset-halo" />
      </div>
      <Link className="wordmark welcome-brand" to="/">
        <ReelIcon />
        <span>
          Plex<span className="accent-text"> Rentals</span>
        </span>
      </Link>
      {children}
      <footer>A private family app connected to Plex.</footer>
    </main>
  );
}
function Gate({ configured, refresh }: { configured: boolean; refresh: () => Promise<void> }) {
  const [passcode, setPasscode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  return (
    <WelcomeFrame>
      <div className="gate-card">
        <p className="eyebrow">OUR FAMILY. OUR MOVIE NIGHTS.</p>
        <h1>{configured ? 'Welcome home.' : 'One last setup step.'}</h1>
        <p>
          {configured
            ? 'Enter your household passcode to join the family’s movie spot. This device will be remembered.'
            : 'Ask the person running Plex Rentals to set HOUSEHOLD_PASSCODE, SESSION_SECRET and ADMIN_PIN on the server, then restart the app.'}
        </p>
        {configured && (
          <form
            onSubmit={(event) => {
              event.preventDefault();
              setBusy(true);
              setError('');
              void api('/household/join', sessionResponseSchema, 'POST', { passcode })
                .then(refresh)
                .catch((e) => setError(message(e)))
                .finally(() => setBusy(false));
            }}
          >
            <label htmlFor="household-passcode">Household passcode</label>
            <input
              autoFocus
              id="household-passcode"
              type="password"
              autoComplete="current-password"
              required
              value={passcode}
              onChange={(event) => setPasscode(event.target.value)}
            />
            <ErrorText error={error} />
            <button className="primary-button" disabled={busy}>
              {busy ? 'Joining…' : 'Join the family →'}
            </button>
          </form>
        )}
      </div>
    </WelcomeFrame>
  );
}
function WhoWatching({ refresh }: { refresh: () => Promise<void> }) {
  const profiles = useQuery({
    queryKey: ['profiles'],
    queryFn: ({ signal }) => api('/profiles', profilesResponseSchema, 'GET', undefined, signal),
  });
  const [chosen, setChosen] = useState<Profile | null>(null);
  const [adding, setAdding] = useState(false);
  const [adminChoice, setAdminChoice] = useState<Profile | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const client = useQueryClient();
  async function select(profile: Profile, pin?: string) {
    setBusy(true);
    setError('');
    try {
      await api('/session', sessionResponseSchema, 'POST', {
        profileId: profile.id,
        ...(pin ? { pin } : {}),
      });
      await client.cancelQueries();
      client.removeQueries({
        predicate: (q) => !['session', 'profiles'].includes(String(q.queryKey[0])),
      });
      await refresh();
      navigate('/');
    } catch (e) {
      setError(message(e));
      throw e;
    } finally {
      setBusy(false);
    }
  }
  return (
    <WelcomeFrame>
      <div className="watching-heading">
        <h1>Who’s watching?</h1>
        <p>Same great movies. A happier family.</p>
      </div>
      {profiles.isPending ? (
        <p role="status">Getting the family together…</p>
      ) : profiles.isError ? (
        <div>
          <ErrorText error={message(profiles.error)} />
          <button
            className="outline-button"
            onClick={() => {
              void profiles.refetch();
            }}
          >
            Try again
          </button>
        </div>
      ) : (
        <div className="profiles-grid">
          {profiles.data.profiles.map((profile) => (
            <button
              className="profile-choice"
              key={profile.id}
              disabled={busy}
              onClick={() => {
                if (profile.hasPin) setChosen(profile);
                else void select(profile).catch(() => undefined);
              }}
            >
              <Avatar {...profile} />
              <strong>{profile.name}</strong>
              {profile.hasPin && <small>PIN protected</small>}
            </button>
          ))}
          <button
            className="profile-choice add-profile"
            onClick={() => {
              setError('');
              setAdding(true);
              const admins = profiles.data.profiles.filter((profile) => profile.isAdmin);
              setAdminChoice(admins.length === 1 ? admins[0]! : null);
            }}
          >
            <span className="profile-avatar">＋</span>
            <strong>Add</strong>
          </button>
        </div>
      )}
      <ErrorText error={error} />
      {adding && (
        <Modal title="Add to the family" onClose={() => setAdding(false)}>
          {adminChoice ? (
            <PinForm
              heading={`Admin PIN · ${adminChoice.name}`}
              submit={async (pin) => {
                await api('/session', sessionResponseSchema, 'POST', {
                  profileId: adminChoice.id,
                  ...(adminChoice.hasPin ? { pin } : {}),
                });
                await api('/admin/unlock', sessionResponseSchema, 'POST', { pin });
                await client.cancelQueries();
                client.removeQueries({
                  predicate: (q) => !['session', 'profiles'].includes(String(q.queryKey[0])),
                });
                navigate('/settings?new=1');
                await refresh();
              }}
              cancel={() => setAdding(false)}
            />
          ) : (
            <>
              <p>Choose an admin to continue.</p>
              {profiles.data?.profiles
                .filter((profile) => profile.isAdmin)
                .map((profile) => (
                  <button
                    key={profile.id}
                    className="settings-profile"
                    onClick={() => setAdminChoice(profile)}
                  >
                    <Avatar {...profile} small />
                    {profile.name}
                  </button>
                ))}
            </>
          )}
        </Modal>
      )}
      {chosen && (
        <Modal title={`Welcome, ${chosen.name}`} onClose={() => setChosen(null)}>
          <PinForm
            heading="Enter your PIN"
            submit={(pin) => select(chosen, pin)}
            cancel={() => setChosen(null)}
          />
        </Modal>
      )}
    </WelcomeFrame>
  );
}
export function SessionProvider({ children }: { children: ReactNode }) {
  const client = useQueryClient();
  const navigate = useNavigate();
  const [switching, setSwitching] = useState(false);
  const [live, setLive] = useState(false);
  const query = useQuery({
    queryKey: ['session'],
    queryFn: ({ signal }) => api('/session', sessionResponseSchema, 'GET', undefined, signal),
    retry: false,
    refetchInterval: 60000,
  });
  async function refresh() {
    await query.refetch();
  }
  async function switchProfile() {
    setSwitching(true);
    try {
      await api('/session', ignoredResponse, 'DELETE');
      await client.cancelQueries();
      client.clear();
      navigate('/');
      await query.refetch();
    } finally {
      setSwitching(false);
    }
  }
  useEffect(() => {
    const refreshSession = () => {
      void client.invalidateQueries({ queryKey: ['session'] });
    };
    window.addEventListener('reelrequest:auth', refreshSession);
    return () => window.removeEventListener('reelrequest:auth', refreshSession);
  }, [client]);
  const profileId = query.data?.profile?.id;
  useEffect(() => {
    if (!profileId || switching) return;
    const stream = new EventSource('/api/stream');
    stream.onopen = () => {
      setLive(true);
      void client.invalidateQueries({ queryKey: ['session'] });
      void client.invalidateQueries({
        predicate: (q) => !['session', 'profiles'].includes(String(q.queryKey[0])),
      });
    };
    stream.onerror = () => setLive(false);
    const resetPrivate = async () => {
      setSwitching(true);
      try {
        await client.cancelQueries();
        client.removeQueries({ predicate: (q) => q.queryKey[0] !== 'session' });
        await client.fetchQuery({
          queryKey: ['session'],
          queryFn: ({ signal }) => api('/session', sessionResponseSchema, 'GET', undefined, signal),
          staleTime: 0,
        });
        navigate('/');
      } catch {
        // The session query's error screen keeps private content hidden until retry.
      } finally {
        setSwitching(false);
      }
    };
    const changed = (event: Event) => {
      if (event instanceof MessageEvent) {
        try {
          if (JSON.parse(String(event.data)).kind === 'profiles') {
            void resetPrivate();
            return;
          }
        } catch {
          /* Refetch on an unknown invalidation event. */
        }
      }
      void client.invalidateQueries({
        predicate: (q) => !['session', 'profiles'].includes(String(q.queryKey[0])),
      });
    };
    const sessionChanged = () => {
      void resetPrivate();
    };
    stream.addEventListener('change', changed);
    stream.addEventListener('requests', changed);
    stream.addEventListener('session', sessionChanged);
    return () => {
      stream.close();
      setLive(false);
    };
  }, [profileId, switching, client, navigate]);
  if (query.isPending || switching)
    return (
      <WelcomeFrame>
        <p role="status">Getting ready for movie night…</p>
      </WelcomeFrame>
    );
  if (query.isError)
    return (
      <WelcomeFrame>
        <ErrorText error={message(query.error)} />
        <button
          className="outline-button"
          onClick={() => {
            void refresh();
          }}
        >
          Try again
        </button>
      </WelcomeFrame>
    );
  if (!query.data.trusted) return <Gate configured={query.data.configured} refresh={refresh} />;
  if (!query.data.profile) return <WhoWatching refresh={refresh} />;
  return (
    <Context.Provider value={{ session: query.data, refresh, switchProfile, live }}>
      <div key={`${profileId}:${query.data.profile.maxRatingLevel}:${query.data.profile.isAdmin}`}>
        {children}
      </div>
    </Context.Provider>
  );
}
export function AdminGuard({ children }: { children: ReactNode }) {
  const { session, refresh } = useSession();
  if (!session.profile?.isAdmin)
    return (
      <main className="family-page">
        <h1>Admin access</h1>
        <p>Switch to an admin profile to manage the household.</p>
        <Link to="/more">Switch profile</Link>
      </main>
    );
  if (!session.adminUnlocked)
    return (
      <main className="family-page unlock-page">
        <PinForm
          heading="Unlock the dashboard"
          submit={async (pin) => {
            await api('/admin/unlock', sessionResponseSchema, 'POST', { pin });
            await refresh();
          }}
        />
        <p className="muted">Admin access stays unlocked on this device for 12 hours.</p>
      </main>
    );
  return <>{children}</>;
}
