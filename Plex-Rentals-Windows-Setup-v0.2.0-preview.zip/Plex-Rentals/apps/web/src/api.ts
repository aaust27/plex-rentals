import { apiErrorSchema } from '@reelrequest/shared';
export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public code: string,
  ) {
    super(message);
  }
}
export async function api<T>(
  path: string,
  schema: { parse: (value: unknown) => T },
  method = 'GET',
  body?: unknown,
  signal?: AbortSignal,
): Promise<T> {
  const response = await fetch(`/api${path}`, {
    method,
    credentials: 'same-origin',
    headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    signal: signal
      ? AbortSignal.any([signal, AbortSignal.timeout(15000)])
      : AbortSignal.timeout(15000),
  });
  if (!response.ok) {
    const parsed = apiErrorSchema.safeParse(await response.json().catch(() => null));
    const error = new ApiError(
      parsed.success ? parsed.data.error.message : 'Something went wrong. Please try again.',
      response.status,
      parsed.success ? parsed.data.error.code : 'UNKNOWN',
    );
    if (response.status === 401 || response.status === 403)
      window.dispatchEvent(new CustomEvent('reelrequest:auth', { detail: error.code }));
    throw error;
  }
  return schema.parse(response.status === 204 ? {} : await response.json());
}
export const ignoredResponse = { parse: (_value: unknown) => undefined };
export function message(error: unknown): string {
  return error instanceof Error ? error.message : 'Something went wrong. Please try again.';
}
