import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
type InstallPrompt = Event & { prompt:()=>Promise<void>;userChoice:Promise<{outcome:'accepted'|'dismissed'}> };
export function InstallApp(){
 const [prompt,setPrompt]=useState<InstallPrompt|null>(null);const [note,setNote]=useState('');
 const installed=window.matchMedia('(display-mode: standalone)').matches;
 useEffect(()=>{const available=(e:Event)=>{e.preventDefault();setPrompt(e as InstallPrompt);};window.addEventListener('beforeinstallprompt',available);return()=>window.removeEventListener('beforeinstallprompt',available);},[]);
 async function install(){if(!prompt)return;try{await prompt.prompt();const choice=await prompt.userChoice;setNote(choice.outcome==='accepted'?'Installation requested. Follow your device’s confirmation.':'You can install later.');setPrompt(null);}catch{setNote('Use the browser menu instructions below.');}}

 return <section className="install-app"><h2>{installed?'Plex Rentals is installed':'Add Plex Rentals to your home screen'}</h2><p>A shortcut opens your movie collection in one tap.</p>{!window.isSecureContext&&<p className="muted">On this local network address, use a browser shortcut. Full app installation and push notifications depend on browser support and HTTPS. Stay connected to your home network.</p>}{prompt&&!installed&&<button className="primary-button" onClick={()=>void install()}>Install app</button>}
 <div className="shortcut-guides">
 <article><h3>iPhone</h3><ol><li>Open Plex Rentals in Safari.</li><li>Open Share, then choose Add to Home Screen. If missing, use Edit Actions to add it.</li><li>Name it Plex Rentals and tap Add.</li></ol><a href="https://support.apple.com/guide/iphone/open-as-web-app-iphea86e5236/ios" target="_blank" rel="noreferrer">Apple instructions ↗</a></article>
 <article><h3>Android</h3><ol><li>Open Plex Rentals in Chrome.</li><li>Tap the three-dot menu, then Add to home screen.</li><li>Choose Create shortcut or Install if offered, then confirm Add.</li></ol><a href="https://support.google.com/chrome/answer/15085120?co=GENIE.Platform%3DAndroid" target="_blank" rel="noreferrer">Chrome instructions ↗</a></article>
 <article><h3>Windows</h3><ol><li>Right-click your Windows Desktop and choose New → Shortcut.</li><li>Paste the address below, then click Next.</li><li>Name it Plex Rentals and click Finish.</li></ol><label>Shortcut address<input readOnly value={`${window.location.origin}/`} onFocus={e=>e.target.select()}/></label><p>For a separate app window in Edge: open ⋯ → More tools → Apps → Install this site as an app.</p><a href="https://support.microsoft.com/en-us/edge/install-manage-or-uninstall-apps-in-microsoft-edge" target="_blank" rel="noreferrer">Edge instructions ↗</a></article>
 </div>{note&&<p role="status">{note}</p>}</section>;
}
export function ShortcutSettings(){return <main id="main-content" className="family-page"><Link to="/more">← More</Link><h1>Home-screen shortcuts</h1><InstallApp/></main>;}
