import {StorageDashboard} from './StorageDashboard';
import { TitleSocial } from './TitleSocial';
import { ShortcutSettings } from './InstallApp';
import { Suggestions, SuggestionReview } from './Suggestions';
import { FilterRow } from './FilterRow';
import { useEffect, useState, type CSSProperties } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { AnimatePresence, LayoutGroup, MotionConfig, motion } from 'motion/react';
import type { MotionStyle } from 'motion/react';
import { Link, Navigate, Route, Routes, useLocation, useParams, useSearchParams } from 'react-router-dom';
import {
  libraryResponseSchema,
  openRequestStatuses,
  requestResponseSchema,
  searchResponseSchema,
  type HomeResponse,
  type TitleCard,
  type TitleDetail,
} from '@reelrequest/shared';
import { useEffects } from './effects';
import { getHome, getDetail } from './catalog-api';
import { plexLabels, releaseLabels, requestLabels } from './state-labels';
import { ReelIcon } from './App';
import { useSession, AdminGuard } from './session';
import { Avatar } from './Avatar';
import {
  RequestControls,
  RequestBlock,
  Bookmark,
  RequestsRoute,
  AdminRequest,
  MyList,
  DateStamp,
} from './Family';
import { api, ignoredResponse, message } from './api';
import { More, Settings } from './Settings';
import { NotificationBell, Notifications, NotificationToast } from './Notifications';
import { posterStatus } from './poster-status';
import { Modal } from './Modal';
import { MovieNight, MovieNightBanner } from './MovieNight';
import { CinemaEffects } from './CinemaEffects';
import { UiIcon } from './UiIcon';
import { Explore } from './Explore';
import { StandUp } from './StandUp';
import { AnimeQuote } from './AnimeQuote';
import { DiscoveryHub } from './DiscoveryHub';

const imageUrl = (path: string, size = 'w500') =>
  path.startsWith('/demo-') ? `/api/demo-art${path}` : `https://image.tmdb.org/t/p/${size}${path}`;
function collectionDestination(id: string) {
  const filters: Record<string, string> = {
    'popular-movies': '',
    'top-rated-movies': 'score=8',
    'action-movies': 'genre=28',
    'comedy-movies': 'collection=comedy',
    'science-fiction-movies': 'genre=878',
    'family-movies': 'collection=comfort',
    'animated-movies': 'genre=16',
    'thriller-movies': 'collection=mystery',
    'documentary-movies': 'genre=99',
    'classic-movies': 'decade=1990',
    'critically-acclaimed-movies': 'score=8',
    'under-100': 'collection=short',
    'coming-soon': 'availability=soon',
    netflix: 'provider=8',
    hulu: 'provider=15',
    'apple-tv': 'provider=350',
    'disney-plus': 'provider=337',
  };
  return Object.hasOwn(filters, id) ? `/explore?${filters[id]}` : null;
}
function Picture({
  path,
  alt,
  className = '',
  size = 'w500',
  eager = false,
}: {
  path: string | null;
  alt: string;
  className?: string;
  size?: string;
  eager?: boolean;
}) {
  const [failed, setFailed] = useState(false);
  return path && !failed ? (
    <img
      className={className}
      src={imageUrl(path, size)}
      srcSet={
        path.startsWith('/demo-') || size === 'original' || size === 'w185'
          ? undefined
          : size === 'w1280'
            ? `${imageUrl(path, 'w780')} 780w, ${imageUrl(path, 'w1280')} 1280w`
            : `${imageUrl(path, 'w342')} 342w, ${imageUrl(path, 'w500')} 500w`
      }
      sizes={
        size === 'w1280' ? '(max-width: 700px) 100vw, 800px' : '(max-width: 700px) 30vw, 180px'
      }
      alt={alt}
      loading={eager ? 'eager' : 'lazy'}
      onError={() => setFailed(true)}
    />
  ) : (
    <div className={`image-fallback ${className}`} role="img" aria-label={alt}>
      <span aria-hidden="true">◉</span>
      <strong>{alt}</strong>
    </div>
  );
}
function status(title: TitleCard) {
  return posterStatus(title)?.label ?? plexLabels[title.plexState];
}
function stateClass(title: TitleCard) {
  return posterStatus(title)?.state ?? title.plexState;
}
function Meta({ title }: { title: TitleCard }) {
  return (
    <div className="title-meta">
      <span className="score">★ {title.tmdbScore === null ? '—' : title.tmdbScore.toFixed(1)}</span>
      <span>
        {title.mediaType === 'movie'
          ? formatReleaseDate(title.releaseDate)
          : (title.year ?? 'Year TBD')}
      </span>
      <span>
        {title.mediaType === 'tv'
          ? `${title.seasonCount ?? '—'} seasons`
          : title.runtimeMin
            ? `${Math.floor(title.runtimeMin / 60)}h ${title.runtimeMin % 60}m`
            : 'Runtime TBD'}
      </span>
      <span>{title.certification ?? 'Unrated'}</span>
    </div>
  );
}
function formatReleaseDate(value: string | null) {
  if (!value) return 'Release date TBD';
  return new Intl.DateTimeFormat(undefined, {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
    timeZone: 'UTC',
  }).format(new Date(`${value}T00:00:00Z`));
}
function Poster({ title, scope, animate }: { title: TitleCard; scope: string; animate: boolean }) {
  const [peek, setPeek] = useState(false);
  const { session } = useSession();
  const preview = useQuery({
    queryKey: [
      'title',
      session.profile?.id,
      session.profile?.maxRatingLevel,
      title.mediaType,
      String(title.tmdbId),
    ],
    queryFn: ({ signal }) => getDetail(title.mediaType, String(title.tmdbId), signal),
    enabled: peek,
  });
  return (
    <article className="poster-card">
      <Link
        to={`/title/${title.mediaType}/${title.tmdbId}`}
        state={{ posterId: `${scope}-${title.mediaType}-${title.tmdbId}`, poster: title }}
        aria-label={`${title.title}. ${status(title)}`}
        onClick={(event) => {
          if (!event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey) {
            event.preventDefault();
            setPeek(true);
          }
        }}
      >
        <motion.div
          {...(animate ? { layoutId: `${scope}-${title.mediaType}-${title.tmdbId}` } : {})}
          className="poster-frame"
          style={{ '--poster-color': title.colorHex } as MotionStyle}
          {...(animate ? { whileHover: { y: -5, scale: 1.035 } } : {})}
          transition={{ type: 'spring', stiffness: 300, damping: 25 }}
        >
          <Picture
            path={title.posterPath}
            alt={`${title.title}${title.year ? ` (${title.year})` : ''}`}
          />
          <div className="poster-corner-tags">
            {title.releaseState === 'coming_soon' && (
              <span className="corner-tag corner-soon">Coming soon</span>
            )}
            {title.requestStatus === 'requested' && (
              <span className="corner-tag corner-requested">Requested</span>
            )}
            {title.requestStatus === 'looking' && (
              <span className="corner-tag corner-requested">Finding it</span>
            )}
            {title.requestStatus === 'watched' && <span className="corner-tag">Watched</span>}
          </div>
          {title.plexState === 'available' && (
            <span className="plex-corner-marker" aria-hidden="true">
              <svg viewBox="0 0 24 24">
                <path d="M7 4h5l7 8-7 8H7l7-8-7-8Z" />
              </svg>
            </span>
          )}
        </motion.div>
        <span className="poster-copy">
          <strong>{title.title}</strong>
          <small>
            {title.mediaType === 'movie'
              ? formatReleaseDate(title.releaseDate)
              : (title.year ?? 'Year TBD')}
          </small>
        </span>
      </Link>
      <QuickRequest title={title} />
      {peek && (
        <Modal title={title.title} onClose={() => setPeek(false)}>
          <div className="quick-preview">
            <Picture path={title.backdropPath ?? title.posterPath} alt={title.title} size="w1280" />
            <Meta title={preview.data?.title ?? title} />
            <p>{status(preview.data?.title ?? title)}</p>
            {preview.isPending && <p role="status">Loading movie details…</p>}
            {preview.isError && (
              <p role="alert">
                Details could not load.{' '}
                <button className="text-button" onClick={() => void preview.refetch()}>
                  Retry
                </button>
              </p>
            )}
            {preview.data && (
              <>
                <p className="preview-synopsis">
                  {preview.data.title.overview || 'A synopsis is not available yet.'}
                </p>
                <RequestControls
                  title={preview.data.title}
                  request={preview.data.request}
                  compact
                />
                {preview.data.title.trailerKey && <PreviewTrailer title={preview.data.title} />}
              </>
            )}
            <Link className="outline-button" to={`/title/${title.mediaType}/${title.tmdbId}`}>
              Full details →
            </Link>
          </div>
        </Modal>
      )}
    </article>
  );
}
function QuickRequest({ title }: { title: TitleCard }) {
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const client = useQueryClient();
  const canRequest =
    title.mediaType === 'movie' &&
    title.plexState === 'unavailable' &&
    title.requestStatus === undefined;
  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(''), 2600);
    return () => window.clearTimeout(timer);
  }, [notice]);
  if (!canRequest) return null;
  return (
    <div className="quick-request">
      <button
        type="button"
        className="quick-request-button"
        disabled={busy}
        aria-label={`Request ${title.title}`}
        onClick={() => {
          setBusy(true);
          setNotice('');
          void api('/requests', requestResponseSchema, 'POST', {
            mediaType: title.mediaType,
            tmdbId: title.tmdbId,
          })
            .then(() => {
              setNotice('✓ Request sent');
              void client.invalidateQueries({ queryKey: ['home'] });
              void client.invalidateQueries({ queryKey: ['discover'] });
              void client.invalidateQueries({ queryKey: ['search'] });
            })
            .catch((error) => setNotice(message(error)))
            .finally(() => setBusy(false));
        }}
      >
        {busy ? '…' : '＋ Request'}
      </button>
      {notice && (
        <span className="quick-request-notice" role="status">
          {notice}
        </span>
      )}
    </div>
  );
}
function Notice({ data }: { data: Pick<HomeResponse, 'mode' | 'notice' | 'stale' | 'plexMode'> }) {
  return (
    <details className="catalog-notice">
      <summary>
        {data.mode === 'demo' ? 'Fictional preview catalog' : 'Live catalog'} ·{' '}
        {data.plexMode === 'mock' ? 'simulated Plex badges' : 'live Plex mirror'}
        {data.stale ? ' · Saved results' : ''}
      </summary>
      <p>
        {data.notice ?? 'Plex availability is a preview. Live library connection comes later.'}
        {data.stale && ' Showing saved results while the catalog is unavailable.'}
      </p>
    </details>
  );
}
function PreviewTrailer({ title }: { title: TitleDetail }) {
  const [play, setPlay] = useState(false);
  return play ? (
    <iframe
      className="preview-trailer"
      title={`${title.title} trailer`}
      src={`https://www.youtube-nocookie.com/embed/${title.trailerKey}?rel=0`}
      allow="encrypted-media; picture-in-picture; fullscreen"
      allowFullScreen
      referrerPolicy="strict-origin-when-cross-origin"
    />
  ) : (
    <button className="outline-button" onClick={() => setPlay(true)}>
      ▷ Watch trailer
    </button>
  );
}
function FeaturedMovie({ title }: { title: TitleCard }) {
  const { session } = useSession();
  const detail = useQuery({
    queryKey: [
      'title',
      session.profile?.id,
      session.profile?.maxRatingLevel,
      title.mediaType,
      String(title.tmdbId),
    ],
    queryFn: ({ signal }) => getDetail(title.mediaType, String(title.tmdbId), signal),
  });
  return (
    <section className="featured-movie" aria-label="Featured movie">
      <Picture path={title.backdropPath ?? title.posterPath} alt="" size="w1280" eager />
      <div className="featured-copy">
        <p className="eyebrow">TONIGHT'S SPOTLIGHT</p>
        <h2>{title.title}</h2>
        <Meta title={title} />
        <p className="featured-synopsis">
          {detail.data?.title.overview || 'Make a little room for a great movie night.'}
        </p>
        <div className="featured-actions">
          {detail.data && (
            <RequestControls title={detail.data.title} request={detail.data.request} compact />
          )}
          <Link className="outline-button" to={`/title/${title.mediaType}/${title.tmdbId}`}>
            Explore movie →
          </Link>
        </div>
      </div>
    </section>
  );
}
function Loading() {
  return (
    <div role="status" aria-label="Loading catalog" className="loading-grid">
      {Array.from({ length: 6 }, (_, i) => (
        <div className="skeleton" key={i} />
      ))}
      <span className="sr-only">Loading…</span>
    </div>
  );
}
function Failure({ message, retry }: { message: string; retry: () => void }) {
  return (
    <section className="empty-state" role="alert">
      <h1>A little intermission.</h1>
      <p>{message}</p>
      <button className="outline-button" onClick={retry}>
        Try again
      </button>
      <Link to="/">Back to browse</Link>
    </section>
  );
}
const streamingServices: Record<string, string> = {
  netflix: 'Netflix',
  hulu: 'Hulu',
  'apple-tv': 'Apple TV',
  'disney-plus': 'Disney+',
};
function BrowseDestinations({
  type,
  anime,
  rows,
}: {
  type: '' | 'movie' | 'tv';
  anime: boolean;
  rows: HomeResponse['rows'];
}) {
  return (
    <nav className="home-destination-nav" aria-label="Browse destinations">
      <div className="destination-row destination-main">
        <Link className="filter-chip" aria-current={!anime && !type ? 'page' : undefined} to="/">
          For You
        </Link>
        <Link
          className="filter-chip"
          aria-current={!anime && type === 'movie' ? 'page' : undefined}
          to="/?type=movie"
        >
          Movies
        </Link>
        <Link
          className="filter-chip"
          aria-current={!anime && type === 'tv' ? 'page' : undefined}
          to="/?type=tv"
        >
          TV Shows
        </Link>
        <Link className="filter-chip" to="/list">
          My List
        </Link>
        <Link className="filter-chip anime-chip" aria-current={anime ? 'page' : undefined} to="/anime">
          ✦ Anime
        </Link>
        <Link className="filter-chip comedy-chip" to="/standup">
          🎙 Stand-up
        </Link>
      </div>
      <div className="destination-row destination-services">
        {Object.entries(streamingServices).map(([id, name]) => {
          const logo = rows.find((row) => row.id === id)?.logoPath;
          return (
            <Link
              key={id}
              className={`filter-chip provider-chip provider-${id}`}
              to={`/browse/${id}?type=movie`}
            >
              {logo && <img src={imageUrl(logo, 'w92')} alt="" />}
              <span>{name}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
function AnimeWelcome() {
  return (
    <section className="anime-welcome" aria-labelledby="anime-welcome-title">
      <div className="anime-orbit" aria-hidden="true">
        <span className="anime-moon" />
        <span className="anime-star star-one">✦</span>
        <span className="anime-star star-two">✧</span>
      </div>
      <div className="anime-welcome-copy">
        <p className="eyebrow">ENTER THE MULTIVERSE</p>
        <h2 id="anime-welcome-title">Every world starts with one episode.</h2>
        <p>
          New releases, legendary series, feature films and deep cuts—curated for the anime fans
          in the family.
        </p>
        <div className="anime-portals">
          <Link to="/browse/anime-trending">Trending now</Link>
          <Link to="/browse/anime-new">Fresh releases</Link>
          <Link to="/browse/anime-favorites">Fan favorites</Link>
          <Link to="/browse/anime-movies">Anime films</Link>
        </div>
      </div>
    </section>
  );
}
function Home({
  animate,
  grid = false,
  anime = false,
}: {
  animate: boolean;
  grid?: boolean;
  anime?: boolean;
}) {
  const { session } = useSession();
  const [params] = useSearchParams();
  const type = params.get('type') === 'movie' ? 'movie' : params.get('type') === 'tv' ? 'tv' : '';
  const { rowId } = useParams();
  const animeTheme = anime || Boolean(rowId?.startsWith('anime-'));
  const [browseValue, setBrowseValue] = useState('');
  const [pickVersion, setPickVersion] = useState(0);
  const recentLibrary = useQuery({
    queryKey: ['home-recent-library', session.profile?.id, session.profile?.maxRatingLevel, type],
    queryFn: ({ signal }) =>
      api(
        `/library?sort=added${type ? `&type=${type}` : ''}`,
        libraryResponseSchema,
        'GET',
        undefined,
        signal,
      ),
    staleTime: 60_000,
  });
  const query = useQuery({
    queryKey: ['home', session.profile?.id, session.profile?.maxRatingLevel, type],
    queryFn: ({ signal }) => getHome(type, signal),
  });
  if (query.isError)
    return (
      <Failure
        message={query.error.message}
        retry={() => {
          void query.refetch();
        }}
      />
    );
  const browseQuery = browseValue.trim().toLocaleLowerCase();
  const sourceRows = query.data
    ? [
        ...(recentLibrary.data?.items.length
          ? [
              {
                id: 'recently-added',
                title: 'Recently Added to Plex',
                items: recentLibrary.data.items.slice(0, 20),
              },
            ]
          : []),
        ...query.data.rows,
      ]
    : [];
  const rows =
    sourceRows
      .filter(
        (row) =>
          row.items.length > 0 &&
          (!grid || row.id === rowId) &&
          (!anime || row.id.startsWith('anime-')),
      )
      .map((row) => ({
        ...row,
        items:
          grid && browseQuery
            ? row.items.filter((item) => item.title.toLocaleLowerCase().includes(browseQuery))
            : grid
              ? row.items
              : (() => {
                  const offset =
                    (Math.floor(Date.now() / 86400000) + pickVersion * 7) % row.items.length;
                  return [...row.items.slice(offset), ...row.items.slice(0, offset)].slice(0, 20);
                })(),
      })) ?? [];
  const featured = rows
    .flatMap((row) => row.items)
    .find(
      (title) =>
        title.mediaType === 'movie' && title.releaseState !== 'coming_soon' && title.backdropPath,
    );
  // Keep the dedicated Coming Soon collection overlapping; limit other repetitions to two rows.
  const appearances = new Map<string, number>();
  const displayRows = grid
    ? rows
    : rows
        .map((row) => ({
          ...row,
          items: row.items.filter((title) => {
            if (row.id === 'coming-soon' || row.id === 'family-requests') return true;
            const key = `${title.mediaType}:${title.tmdbId}`;
            const count = appearances.get(key) ?? 0;
            appearances.set(key, count + 1);
            return count < 2;
          }),
        }))
        .filter((row) => row.items.length > 0);
  return (
    <main id="main-content" className={`browse-main ${animeTheme ? 'anime-page' : ''}`}>
      <div className={`browse-heading ${grid || animeTheme ? '' : 'home-heading'}`}>
        <div>
          <p className="eyebrow">
            {animeTheme ? 'ANIME • NEW WORLDS AWAIT' : 'OUR FAMILY. OUR MOVIE NIGHTS.'}
          </p>
          {anime && !grid ? (
            <AnimeQuote />
          ) : (
            <h1>{grid ? (rows[0]?.title ?? 'Browse titles') : 'Find your next movie night.'}</h1>
          )}
        </div>
        {grid && (
          <Link className="outline-button" to={`/${type ? `?type=${type}` : ''}`}>
            ← All collections
          </Link>
        )}
      </div>
      {!grid && <BrowseDestinations type={type} anime={animeTheme} rows={query.data?.rows ?? []} />}
      {anime && !grid && <AnimeWelcome />}
      {!grid && featured && (
        <FeaturedMovie key={`${featured.mediaType}-${featured.tmdbId}`} title={featured} />
      )}
      {grid && rowId && streamingServices[rowId] && (
        <>
          <label className="sr-only" htmlFor="provider-search">
            Search this streaming collection
          </label>
          <input
            id="provider-search"
            className="search-input"
            type="search"
            value={browseValue}
            placeholder={`Search ${streamingServices[rowId]} movies`}
            onChange={(event) => setBrowseValue(event.target.value)}
          />
          <p className="provider-attribution">
            Streaming availability data provided by JustWatch via TMDB.
          </p>
        </>
      )}
      {!grid && !anime && (
        <DiscoveryHub
          rows={rows}
          refresh={() => setPickVersion((value) => value + 1)}
          render={(title) => <Poster title={title} scope="surprise" animate={animate} />}
        />
      )}
      {!grid && <MovieNightBanner />}
      {query.data && <Notice data={query.data} />}
      {query.isPending ? (
        <>
          <p role="status" className="muted">
            {session.profile?.maxRatingLevel
              ? 'Checking age ratings…'
              : 'Finding something for movie night…'}
          </p>
          <Loading />
        </>
      ) : rows.length === 0 ? (
        <section className="empty-state">
          <h2>No titles here yet.</h2>
          <p>Try another filter or check back soon.</p>
        </section>
      ) : (
        displayRows.map((row) => (
          <motion.section
            className="poster-section"
            key={row.id}
            aria-labelledby={`row-${row.id}`}
            initial={animate ? { opacity: 0, y: 18 } : false}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.05 }}
            transition={{ duration: 0.4 }}
          >
            <div className="row-heading">
              <h2 id={`row-${row.id}`}>
                {row.logoPath && (
                  <img className="collection-logo" src={imageUrl(row.logoPath, 'w92')} alt="" />
                )}
                {row.title}
              </h2>
              {!grid && (
                <Link
                  to={
                    collectionDestination(row.id) ??
                    `/browse/${row.id}${type ? `?type=${type}` : ''}`
                  }
                >
                  See All <span aria-hidden="true">›</span>
                </Link>
              )}
            </div>
            <div className={grid ? 'poster-grid' : 'poster-row'}>
              {row.items.map((title) => (
                <Poster
                  key={`${title.mediaType}-${title.tmdbId}`}
                  title={title}
                  scope={row.id}
                  animate={animate}
                />
              ))}
            </div>
          </motion.section>
        ))
      )}
      {!grid && !anime && (
        <div className="home-bottom-picks">
          <button className="outline-button" onClick={() => setPickVersion((value) => value + 1)}>
            Show me different picks
          </button>
        </div>
      )}
      {!grid && rows.some((row) => Boolean(streamingServices[row.id])) && (
        <p className="provider-attribution">
          Streaming availability data provided by JustWatch via TMDB.
        </p>
      )}
    </main>
  );
}
function Library({ animate }: { animate: boolean }) {
  const { session } = useSession();
  const [params, setParams] = useSearchParams();
  const type = params.get('type') === 'movie' ? 'movie' : params.get('type') === 'tv' ? 'tv' : '';
  const genre = params.get('genre') ?? '';
  const sort = ['added', 'title', 'year', 'score'].includes(params.get('sort') ?? '')
    ? params.get('sort')!
    : 'added';
  const query = useQuery({
    queryKey: ['library', session.profile?.id, session.profile?.maxRatingLevel, type, genre, sort],
    queryFn: ({ signal }) => {
      const search = new URLSearchParams({ limit: '100', sort });
      if (type) search.set('type', type);
      if (genre) search.set('genre', genre);
      return api(`/library?${search}`, libraryResponseSchema, 'GET', undefined, signal);
    },
  });
  const update = (values: Record<string, string>) => {
    const next = new URLSearchParams(params);
    Object.entries(values).forEach(([key, value]) =>
      value ? next.set(key, value) : next.delete(key),
    );
    setParams(next);
  };
  return (
    <main className="browse-main library-page" id="main-content">
      <div className="browse-heading">
        <div>
          <p className="eyebrow">YOUR PLEX LIBRARY</p>
          <h1>Already on the shelf.</h1>
        </div>
        {query.data?.lastSuccessfulSyncAt && (
          <small className="muted">
            Synced <DateStamp value={query.data.lastSuccessfulSyncAt} />
          </small>
        )}
      </div>
      <FilterRow className="wrap" aria-label="Library filters">
        {[
          ['', 'All'],
          ['movie', 'Movies'],
          ['tv', 'TV Shows'],
        ].map(([value, label]) => (
          <button
            className="filter-chip"
            key={value}
            aria-pressed={type === value}
            onClick={() => update({ type: value! })}
          >
            {label}
          </button>
        ))}
        {query.data?.genres.map((value) => (
          <button
            className="filter-chip"
            key={value}
            aria-pressed={genre === value}
            onClick={() => update({ genre: genre === value ? '' : value })}
          >
            {value}
          </button>
        ))}
      </FilterRow>
      <label className="library-sort">
        Sort{' '}
        <select value={sort} onChange={(event) => update({ sort: event.target.value })}>
          <option value="added">Recently Added</option>
          <option value="title">A–Z</option>
          <option value="year">Year</option>
          <option value="score">TMDB score</option>
        </select>
      </label>
      {query.isPending ? (
        <Loading />
      ) : query.isError ? (
        <Failure
          message={query.error.message}
          retry={() => {
            void query.refetch();
          }}
        />
      ) : query.data.items.length ? (
        <section className="poster-grid" aria-label="Plex library titles">
          {query.data.items.map((title) => (
            <Poster
              key={`${title.mediaType}-${title.tmdbId}`}
              title={title}
              scope="library"
              animate={animate}
            />
          ))}
        </section>
      ) : (
        <section className="empty-state">
          <h2>No matching Plex titles.</h2>
          <p>Try another filter or ask an admin to sync Plex.</p>
        </section>
      )}
    </main>
  );
}
function Search({ animate }: { animate: boolean }) {
  const { session } = useSession();
  const suggestions = useQuery({
    queryKey: ['home', session.profile?.id, session.profile?.maxRatingLevel, ''],
    queryFn: ({ signal }) => getHome('', signal),
    staleTime: 5 * 60 * 1000,
  });
  const [value, setValue] = useState('');
  const [queryText, setQueryText] = useState('');
  const [filter, setFilter] = useState<'all' | 'movie' | 'tv' | 'available' | 'unavailable'>('all');
  const [genre, setGenre] = useState('');
  const storageKey = `reelrequest:searches:${session.profile?.id ?? 0}`;
  const [recent, setRecent] = useState<string[]>(() => {
    try {
      const saved: unknown = JSON.parse(localStorage.getItem(storageKey) ?? '[]');
      return Array.isArray(saved)
        ? saved.filter((item): item is string => typeof item === 'string').slice(0, 8)
        : [];
    } catch {
      return [];
    }
  });
  useEffect(() => {
    const timer = window.setTimeout(() => {
      const next = value.trim();
      setQueryText(next);
    }, 250);
    return () => window.clearTimeout(timer);
  }, [value, storageKey]);
  useEffect(() => {
    const next = value.trim();
    if (!next) return;
    const timer = window.setTimeout(() => {
      setRecent((current) => {
        const updated = [
          next,
          ...current.filter((item) => item !== next && !next.startsWith(item)),
        ].slice(0, 8);
        try {
          localStorage.setItem(storageKey, JSON.stringify(updated));
        } catch {
          /* Storage is optional. */
        }
        return updated;
      });
    }, 1200);
    return () => clearTimeout(timer);
  }, [value, storageKey]);
  const params = new URLSearchParams();
  if (queryText) params.set('q', queryText);
  if (filter === 'movie' || filter === 'tv') params.set('type', filter);
  if (filter === 'available' || filter === 'unavailable') params.set('plex', filter);
  if (genre) params.set('genre', genre);
  const result = useQuery({
    queryKey: ['search', session.profile?.id, queryText, filter, genre],
    queryFn: ({ signal }) =>
      api(`/search?${params.toString()}`, searchResponseSchema, 'GET', undefined, signal),
    staleTime: 6 * 60 * 60 * 1000,
    gcTime: 24 * 60 * 60 * 1000,
    placeholderData: (previous) => previous,
  });
  const typing = value.trim() !== queryText;
  const instant = [
    ...new Map(
      (suggestions.data?.rows.flatMap((row) => row.items) ?? []).map((title) => [
        `${title.mediaType}:${title.tmdbId}`,
        title,
      ]),
    ).values(),
  ]
    .filter(
      (title) =>
        (!value.trim() ||
          title.title.toLocaleLowerCase().includes(value.trim().toLocaleLowerCase())) &&
        (filter === 'all' ||
          filter === title.mediaType ||
          (filter === 'available' && title.plexState === 'available') ||
          (filter === 'unavailable' && title.plexState === 'unavailable')),
    )
    .slice(0, value.trim() ? 6 : 12);
  return (
    <main className="family-page search-page" id="main-content">
      <p className="eyebrow">FIND SOMETHING GREAT</p>
      <h1>Search</h1>
      <p className="muted">Find your next movie, a favorite show, or someone from the cast.</p>
      <label className="sr-only" htmlFor="catalog-search">
        Search movies, shows or people
      </label>
      <input
        id="catalog-search"
        className="search-input"
        autoFocus
        type="search"
        value={value}
        placeholder="Movies, shows or people"
        onChange={(event) => setValue(event.target.value)}
      />
      <p className="search-feedback" role="status" aria-live="polite">
        {typing || result.isFetching
          ? 'Searching the catalog…'
          : queryText
            ? `${result.data?.results.length ?? 0} results for “${queryText}”`
            : 'Start typing, or explore a suggestion below.'}
      </p>
      {!genre && instant.length > 0 && (!value.trim() || typing || result.isFetching) && (
        <section className="instant-search">
          <h2>
            {value.trim()
              ? 'Matching titles from your home screen'
              : 'Something to get you started'}
          </h2>
          <div className="poster-row">
            {instant.map((title) => (
              <Poster
                key={`${title.mediaType}-${title.tmdbId}`}
                title={title}
                scope="instant-search"
                animate={animate}
              />
            ))}
          </div>
        </section>
      )}
      <FilterRow className="wrap" aria-label="Search filters">
        {(
          [
            ['all', 'All'],
            ['movie', 'Movies'],
            ['tv', 'TV'],
            ['available', 'In Plex'],
            ['unavailable', 'Not in Plex'],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            className="filter-chip"
            aria-pressed={filter === key}
            onClick={() => setFilter(key)}
          >
            {label}
          </button>
        ))}
      </FilterRow>
      {!queryText && recent.length > 0 && (
        <section>
          <h2>Recent searches</h2>
          <FilterRow className="wrap">
            {recent.map((item) => (
              <button className="filter-chip" key={item} onClick={() => setValue(item)}>
                {item}
              </button>
            ))}
          </FilterRow>
        </section>
      )}
      {!queryText && result.data?.genres.length ? (
        <section>
          <h2>Browse genres</h2>
          <FilterRow className="wrap">
            {result.data.genres.map((item) => (
              <button
                className="filter-chip"
                aria-pressed={genre === item}
                key={item}
                onClick={() => setGenre(genre === item ? '' : item)}
              >
                {item}
              </button>
            ))}
          </FilterRow>
        </section>
      ) : null}
      {!typing && !result.isPlaceholderData && result.data?.person && (
        <section className="person-result">
          <div className="row-heading">
            <div>
              <p className="eyebrow">PERSON</p>
              <h2>{result.data.person.name}</h2>
            </div>
            <Picture
              path={result.data.person.profilePath}
              alt={result.data.person.name}
              size="w185"
            />
          </div>
          {result.data.person.knownFor.length > 0 && (
            <>
              <h3>Known for</h3>
              <div className="poster-row">
                {result.data.person.knownFor.map((title) => (
                  <Poster
                    key={`${title.mediaType}-${title.tmdbId}`}
                    title={title}
                    scope="known-for"
                    animate={animate}
                  />
                ))}
              </div>
            </>
          )}
        </section>
      )}
      {result.isPending || typing || result.isPlaceholderData ? (
        <Loading />
      ) : result.isError ? (
        <Failure message={result.error.message} retry={() => void result.refetch()} />
      ) : result.data.results.length ? (
        <section className="poster-grid" aria-label="Search results">
          {result.data.results.map((title) => (
            <Poster
              key={`${title.mediaType}-${title.tmdbId}`}
              title={title}
              scope="search"
              animate={animate}
            />
          ))}
        </section>
      ) : queryText || genre || filter !== 'all' ? (
        <section className="empty-state">
          <h2>No matches yet.</h2>
          <p>Try another title, person or filter.</p>
        </section>
      ) : null}
    </main>
  );
}
function DetailsFields({ title }: { title: TitleDetail }) {
  return (
    <div className="detail-fields">
      <dl>
        <dt>{title.mediaType === 'tv' ? 'Creators' : 'Director'}</dt>
        <dd>
          {title.crew
            .filter((person) => /director|creator/i.test(person.job))
            .map((person) => person.name)
            .join(', ') || 'Not listed'}
        </dd>
        <dt>Release status</dt>
        <dd>{releaseLabels[title.releaseState]}</dd>
        <dt>Theaters</dt>
        <dd>{title.releaseTheatrical ?? 'TBD'}</dd>
        <dt>Digital</dt>
        <dd>{title.releaseDigital ?? 'TBD'}</dd>
        <dt>Physical</dt>
        <dd>{title.releasePhysical ?? 'TBD'}</dd>
        {title.mediaType === 'tv' && (
          <>
            <dt>Next air date</dt>
            <dd>{title.nextAirDate ?? 'TBD'}</dd>
          </>
        )}
      </dl>
      {title.mediaType === 'tv' && (
        <>
          <h3>Seasons</h3>
          {title.seasons.length === 0 ? (
            <p>Season information is not available.</p>
          ) : (
            title.seasons.map((season) => (
              <div className="season" key={season.number}>
                <strong>{season.name}</strong>
                <span>
                  {season.episodeCount} episodes · {season.airDate ?? 'Date TBD'}
                </span>
                <small>
                  {season.inPlex === null
                    ? 'Plex status unknown'
                    : season.inPlex
                      ? 'In Plex'
                      : 'Not in Plex'}
                </small>
              </div>
            ))
          )}
          <p className="muted">Use Send Request to choose all seasons or individual seasons.</p>
        </>
      )}
    </div>
  );
}
function Detail({ animate }: { animate: boolean }) {
  const { session } = useSession();
  const { mediaType = '', tmdbId = '' } = useParams();
  const location = useLocation();
  const query = useQuery({
    queryKey: ['title', session.profile?.id, session.profile?.maxRatingLevel, mediaType, tmdbId],
    queryFn: ({ signal }) => getDetail(mediaType, tmdbId, signal),
  });
  const [tab, setTab] = useState('Cast');
  const [expanded, setExpanded] = useState(false);
  const [trailer, setTrailer] = useState(false);
  const [shareNote, setShareNote] = useState('');
  const client = useQueryClient();
  const transitionState = location.state as { posterId?: string; poster?: TitleCard } | null;
  const posterId = transitionState?.posterId;
  useEffect(() => {
    window.scrollTo(0, 0);
    if ((mediaType === 'movie' || mediaType === 'tv') && /^\d+$/.test(tmdbId))
      void api('/signals', ignoredResponse, 'POST', {
        signals: [{ mediaType, tmdbId: Number(tmdbId), kind: 'detail_view' }],
      }).catch(() => undefined);
  }, [mediaType, tmdbId]);
  if (query.isPending)
    return (
      <main className="detail-main">
        {!session.profile?.maxRatingLevel && transitionState?.poster && (
          <motion.div
            className="detail-hero"
            {...(animate && posterId ? { layoutId: posterId } : {})}
          >
            <div className="backdrop-image">
              <Picture
                path={transitionState.poster.posterPath}
                alt={transitionState.poster.title}
                eager
              />
            </div>
            <div className="hero-fade" />
            <div className="detail-title">
              <h1>{transitionState.poster.title}</h1>
            </div>
          </motion.div>
        )}
        <Loading />
      </main>
    );
  if (query.isError)
    return (
      <Failure
        message={query.error.message}
        retry={() => {
          void query.refetch();
        }}
      />
    );
  const title = query.data.title;
  const activeRequest =
    query.data.request && openRequestStatuses.includes(query.data.request.status)
      ? query.data.request
      : null;
  async function share() {
    try {
      if (navigator.share) await navigator.share({ title: title.title, url: window.location.href });
      else {
        await navigator.clipboard.writeText(window.location.href);
        setShareNote('Title link copied.');
      }
    } catch (error) {
      if (!(error instanceof Error && error.name === 'AbortError'))
        setShareNote(`Share this link: ${window.location.href}`);
    }
  }
  return (
    <main
      id="main-content"
      className="detail-main"
      style={{ '--title-color': title.colorHex } as CSSProperties}
    >
      <motion.div className="detail-hero" {...(animate && posterId ? { layoutId: posterId } : {})}>
        <motion.div
          className="backdrop-image"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1, scale: animate ? 1.08 : 1 }}
          transition={{ opacity: { duration: 0.5 }, scale: { duration: animate ? 20 : 0 } }}
        >
          <Picture
            path={title.backdropPath ?? title.posterPath}
            alt={`${title.title} backdrop`}
            size="w1280"
            eager
          />
        </motion.div>
        <div className="hero-fade" />
        <div className="detail-tools">
          <Link className="icon-button" to="/" aria-label="Back to browse">
            ←
          </Link>
          <button
            className="icon-button"
            onClick={() => {
              void share();
            }}
            aria-label="Share title"
          >
            ↥
          </button>
          <Bookmark title={title} saved={query.data.inMyList} />
        </div>
        <div className="detail-title">
          {title.logoPath ? (
            <Picture
              className="title-logo"
              size="original"
              path={title.logoPath}
              alt={title.title}
            />
          ) : (
            <h1>{title.title}</h1>
          )}
        </div>
      </motion.div>
      <div className="detail-content">
        <p className="sr-only" role="status">
          {shareNote}
        </p>
        {shareNote.startsWith('Share') && <p>{shareNote}</p>}
        <Meta title={title} />
        <div className="reaction-buttons" aria-label="Your reaction">
          <button
            aria-pressed={query.data.reaction === 'up'}
            onClick={() => {
              void api('/reactions', ignoredResponse, 'PUT', {
                mediaType: title.mediaType,
                tmdbId: title.tmdbId,
                reaction: query.data.reaction === 'up' ? null : 'up',
              }).then(() => client.invalidateQueries({ queryKey: ['title'] }));
            }}
          >
            👍 More like this
          </button>
          <button
            aria-pressed={query.data.reaction === 'down'}
            onClick={() => {
              void api('/reactions', ignoredResponse, 'PUT', {
                mediaType: title.mediaType,
                tmdbId: title.tmdbId,
                reaction: query.data.reaction === 'down' ? null : 'down',
              }).then(() => client.invalidateQueries({ queryKey: ['title'] }));
            }}
          >
            👎 Less like this
          </button>
        </div>
        <div className="genres">
          {title.genres.map((genre) => (
            <span key={genre.id}>{genre.name}</span>
          ))}
        </div>
        <p className={`synopsis ${expanded ? '' : 'clamped'}`}>
          {title.overview || 'A synopsis is not available yet.'}
        </p>
        {title.overview.length > 180 && (
          <button className="text-button" onClick={() => setExpanded(!expanded)}>
            {expanded ? 'Less' : 'More'}
          </button>
        )}
        <div
          className={`status-box state-${title.plexState === 'available' ? 'available' : (activeRequest?.status ?? stateClass(title))}`}
        >
          <strong>
            {title.plexState === 'available' ? '✓ ' : 'ⓘ '}
            {title.plexState === 'available'
              ? plexLabels.available
              : activeRequest
                ? `${activeRequest.isSupporter ? 'You requested this' : `Requested by ${activeRequest.createdByName}`} · ${requestLabels[activeRequest.status]}`
                : status(title)}
          </strong>
          <p>
            {title.plexState === 'available'
              ? `Ready to watch with your family.${title.resolution ? ` ${title.resolution}.` : ''}`
              : activeRequest
                ? `${activeRequest.supporters.length} ${activeRequest.supporters.length === 1 ? 'person wants' : 'people want'} this. Updates appear in My Requests.`
                : title.plexState === 'unknown'
                  ? 'Availability has not been confirmed.'
                  : 'Request to add this title to the family library.'}
          </p>
          {query.data.plexMode === 'mock' && (
            <small>Preview state · live Plex is not connected.</small>
          )}
        </div>
        <>
          {title.plexState === 'unknown' && !activeRequest ? (
            <button
              className="outline-button trailer-button"
              onClick={() => {
                void query.refetch();
              }}
            >
              Retry availability
            </button>
          ) : (
            <RequestControls title={title} request={query.data.request} />
          )}
        </>
        {title.trailerKey && (
          <button
            className="outline-button trailer-button"
            onClick={() => {
              setTrailer(true);
              void api('/signals', ignoredResponse, 'POST', {
                signals: [
                  { mediaType: title.mediaType, tmdbId: title.tmdbId, kind: 'trailer_play' },
                ],
              }).catch(() => undefined);
            }}
          >
            ▷ Watch Trailer
          </button>
        )}
        <Notice data={query.data} />
        {query.data.request && <RequestBlock request={query.data.request} />}
        <TitleSocial key={title.mediaType + title.tmdbId} mediaType={title.mediaType} tmdbId={title.tmdbId} />
        <FilterRow className="">
          {title.mediaType === 'movie' && (
            <>
              <Link className="filter-chip" to={`/explore?similar=${title.tmdbId}`}>
                More like this →
              </Link>
              <Link className="filter-chip" to={`/explore?franchise=${title.tmdbId}`}>
                Explore its franchise →
              </Link>
            </>
          )}
          {title.crew
            .filter((person) => person.job === 'Director')
            .map((person) => (
              <Link className="filter-chip" key={person.id} to={`/explore?director=${person.id}`}>
                More from {person.name} →
              </Link>
            ))}
        </FilterRow>
        <div role="tablist" className="detail-tabs" aria-label="Title information">
          {['Cast', 'Related', 'Details'].map((name, index) => (
            <button
              key={name}
              id={`tab-${name}`}
              role="tab"
              aria-selected={tab === name}
              aria-controls="title-panel"
              tabIndex={tab === name ? 0 : -1}
              onKeyDown={(event) => {
                if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
                  event.preventDefault();
                  const next = ['Cast', 'Related', 'Details'][
                    (index + (event.key === 'ArrowRight' ? 1 : 2)) % 3
                  ]!;
                  setTab(next);
                  document.getElementById(`tab-${next}`)?.focus();
                }
              }}
              onClick={() => setTab(name)}
            >
              {name}
            </button>
          ))}
        </div>
        <section id="title-panel" role="tabpanel" aria-labelledby={`tab-${tab}`}>
          {tab === 'Cast' ? (
            title.cast.length ? (
              <div className="cast-grid">
                {title.cast.map((person) => (
                  <article key={person.id}>
                    <Picture path={person.profilePath} alt={person.name} size="w185" />
                    <Link to={`/explore?cast=${person.id}`}>{person.name} →</Link>
                    <span>{person.character}</span>
                  </article>
                ))}
              </div>
            ) : (
              <p className="muted">Cast information is not available.</p>
            )
          ) : tab === 'Related' ? (
            title.recommendations.length ? (
              <div className="poster-grid">
                {title.recommendations.map((related) => (
                  <Poster
                    key={`${related.mediaType}-${related.tmdbId}`}
                    title={related}
                    scope="related"
                    animate={animate}
                  />
                ))}
              </div>
            ) : (
              <p className="muted">No related titles yet.</p>
            )
          ) : (
            <DetailsFields title={title} />
          )}
        </section>
      </div>
      {trailer && title.trailerKey && (
        <Modal title={`${title.title} trailer`} onClose={() => setTrailer(false)} trailer>
          <p className="muted">Swipe down outside the video or press Escape to close.</p>
          <iframe
            title={`${title.title} trailer player`}
            src={`https://www.youtube-nocookie.com/embed/${title.trailerKey}?autoplay=1&rel=0`}
            allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
            allowFullScreen
            referrerPolicy="strict-origin-when-cross-origin"
          />
          <p className="muted">
            If playback is blocked,{' '}
            <a
              href={`https://www.youtube.com/watch?v=${title.trailerKey}`}
              target="_blank"
              rel="noreferrer"
            >
              open on YouTube ↗
            </a>
            .
          </p>
          {title.plexState !== 'unknown' && (
            <RequestControls title={title} request={query.data.request} />
          )}
        </Modal>
      )}
    </main>
  );
}
function About() {
  return (
    <main className="about-main product-about" id="main-content">
      <p className="eyebrow">PLEX RENTALS</p>
      <h1>Your next great movie night starts here.</h1>
      <p>A personal movie gallery, a shared family watchlist, and a clear path from “let’s watch that” to ready in Plex.</p>
      <div><span className="about-pill">Self-hosted</span><span className="about-pill">Made for families</span><span className="about-pill">Desktop + mobile</span></div>
      <div className="about-feature-grid">
        {[
          ['A world to browse', 'Discover movies and shows through mood, genre, decade, cast, and streaming-service shelves. Expand Explore into a full-screen desktop gallery.'],
          ['Find your people’s favorites', 'Personal profiles, watchlists, half-point ratings, reactions, and comments help the next choice feel personal.'],
          ['A little friendly debate', 'Start a Movie Night, build a shortlist, and vote together. Anime and stand-up have their own spaces to explore.'],
          ['Request it. Follow it.', 'Shared requests, approval controls, release-date safeguards, and delivery stages keep everyone informed. Connected services provide progress and availability.'],
          ['Your library, connected', 'See what is already in Plex and open it there to watch. Optional Sonarr and Radarr connections handle approved requests.'],
          ['Stay in control', 'Admin tools, notifications, a shared suggestion box, backups, and optional read-only storage reviews help keep your household organized.'],
        ].map(([title, description]) => <article key={title}><h2>{title}</h2><p>{description}</p></article>)}
      </div>
      <p>Install the app on supported devices over HTTPS. Plex Rentals is an independent project, not affiliated with Plex. Playback takes place in Plex; this app does not include movies, streaming subscriptions, or indexer accounts.</p>
      <a href="https://www.themoviedb.org/" target="_blank" rel="noreferrer">
        <img className="tmdb-logo" src="/tmdb-logo.svg" alt="The Movie Database" />
      </a>
      <p>This product uses the TMDB API but is not endorsed or certified by TMDB.</p>
      <p>
        When TMDB is not configured, clearly labeled fictional titles demonstrate the interface.
      </p>
      <Link className="outline-button" to="/">
        Back to browse
      </Link>
    </main>
  );
}
export function App() {
  const effects = useEffects();
  const [settings, setSettings] = useState(false);
  const location = useLocation();
  const { session } = useSession();
  return (
    <MotionConfig reducedMotion={effects.animate ? 'user' : 'always'}>
      <LayoutGroup>
        <div className="catalog-shell">
          {effects.animate && <CinemaEffects />}
          <a className="skip-link" href="#main-content">
            Skip to content
          </a>
          <header className="catalog-header">
            <Link className="wordmark" to="/" aria-label="Plex Rentals home">
              <ReelIcon />
              <span>
                Plex<span className="accent-text"> Rentals</span>
              </span>
            </Link>
            <nav className="desktop-navigation" aria-label="Main navigation">
              <Link to="/" aria-current={location.pathname === '/' ? 'page' : undefined}>
                Home
              </Link>
              <Link
                to="/search"
                aria-current={location.pathname === '/search' ? 'page' : undefined}
              >
                Search
              </Link>
              <Link
                to="/requests"
                aria-current={location.pathname.includes('requests') ? 'page' : undefined}
              >
                Requests
              </Link>
              <Link
                to="/library"
                aria-current={location.pathname === '/library' ? 'page' : undefined}
              >
                Library
              </Link>
              <Link to="/more" aria-current={location.pathname === '/more' ? 'page' : undefined}>
                More
              </Link>
            </nav>
            <button
              className="effects-trigger settings-trigger"
              aria-label="Open display settings"
              title="Settings"
              aria-expanded={settings}
              aria-controls="catalog-effects"
              onClick={() => setSettings(!settings)}
            >
              <UiIcon name="settings" />
            </button>
            {session.profile && (
              <>
                <NotificationBell />
                <Link
                  to={session.profile.isAdmin ? '/settings' : '/more'}
                  aria-label={session.profile.isAdmin ? 'Open profile settings' : 'Open profile menu'}
                  title={session.profile.isAdmin ? 'Profile settings' : 'Profile menu'}
                >
                  <Avatar {...session.profile} small />
                </Link>
              </>
            )}
          </header>
          {settings && (
            <section className="effects-panel" id="catalog-effects">
              <div className="modal-heading">
                <h2>Settings</h2>
                <button
                  className="icon-button"
                  aria-label="Close display settings"
                  onClick={() => setSettings(false)}
                >
                  ×
                </button>
              </div>
              <details className="settings-effects">
                <summary>
                  Effects <span>{effects.mode === 'full' ? 'Full' : 'Lite'}</span>
                </summary>
                <p>Choose the feel for this device.</p>
                <div className="effects-options">
                  {(['full', 'lite'] as const).map((mode) => (
                    <button
                      key={mode}
                      aria-pressed={effects.mode === mode}
                      onClick={() => effects.setMode(mode)}
                    >
                      {mode === 'full' ? 'Full · movie magic' : 'Lite · quiet and simple'}
                    </button>
                  ))}
                </div>
                <p className="effects-note">
                  {effects.reducedMotion
                    ? 'Your reduced-motion preference is respected.'
                    : effects.saved
                      ? 'Saved on this device.'
                      : 'Applies for this visit; browser storage is unavailable.'}
                </p>
              </details>
            </section>
          )}
          <NotificationToast />
          <AnimatePresence mode="popLayout" initial={false}>
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: effects.animate ? 0.2 : 0 }}
            >
              <Routes location={location}>
                <Route path="/" element={<Home animate={effects.animate} />} />
                <Route
                  path="/explore"
                  element={
                    <Explore
                      render={(title) => (
                        <Poster title={title} scope="explore" animate={effects.animate} />
                      )}
                    />
                  }
                />
                <Route path="/nineties" element={<Navigate to="/" replace />} />
                <Route path="/search" element={<Search animate={effects.animate} />} />
                <Route
                  path="/standup"
                  element={
                    <StandUp
                      render={(title) => (
                        <Poster title={title} scope="standup" animate={effects.animate} />
                      )}
                    />
                  }
                />
                <Route path="/anime" element={<Home animate={effects.animate} anime />} />
                <Route path="/browse/:rowId" element={<Home animate={effects.animate} grid />} />
                <Route
                  path="/title/:mediaType/:tmdbId"
                  element={<Detail animate={effects.animate} />}
                />
                <Route path="/about" element={<About />} />
                <Route path="/requests" element={<RequestsRoute />} />
                <Route path="/list" element={<MyList />} />
                <Route path="/library" element={<Library animate={effects.animate} />} />
                <Route path="/settings/shortcuts" element={<ShortcutSettings />} />
                <Route path="/settings/suggestions" element={<Suggestions />} />
                <Route path="/settings/suggestions/review" element={<SuggestionReview />} />
                <Route path="/admin/storage" element={<AdminGuard><StorageDashboard /></AdminGuard>} />
                <Route path="/notifications" element={<Notifications />} />
                <Route path="/movie-night" element={<MovieNight />} />
                <Route path="/movie-night/:id" element={<MovieNight />} />
                <Route path="/more" element={<More />} />
                <Route
                  path="/settings"
                  element={
                    <AdminGuard>
                      <Settings />
                    </AdminGuard>
                  }
                />
                <Route
                  path="/admin/requests/:id"
                  element={
                    <AdminGuard>
                      <AdminRequest />
                    </AdminGuard>
                  }
                />
                <Route
                  path="*"
                  element={
                    <main className="empty-state">
                      <h1>This reel isn’t here.</h1>
                      <Link to="/">Back to browse</Link>
                    </main>
                  }
                />
              </Routes>
            </motion.div>
          </AnimatePresence>
          <footer className="catalog-footer">
            <Link to="/" aria-current={location.pathname === '/' ? 'page' : undefined}>
              <UiIcon name="home" /> <span>Home</span>
            </Link>
            <Link to="/search" aria-current={location.pathname === '/search' ? 'page' : undefined}>
              <UiIcon name="search" /> <span>Search</span>
            </Link>
            <Link
              to="/requests"
              aria-current={location.pathname.includes('requests') ? 'page' : undefined}
            >
              <UiIcon name="requests" /> <span>Requests</span>
            </Link>
            <Link
              to="/library"
              aria-current={location.pathname === '/library' ? 'page' : undefined}
            >
              <UiIcon name="library" /> <span>Library</span>
            </Link>
            <Link to="/more" aria-current={location.pathname === '/more' ? 'page' : undefined}>
              <UiIcon name="more" /> <span>More</span>
            </Link>
          </footer>
        </div>
      </LayoutGroup>
    </MotionConfig>
  );
}


