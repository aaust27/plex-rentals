import { useState } from 'react';
import { useInfiniteQuery, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { suggestionsResponseSchema, type Suggestion } from '@reelrequest/shared';
import { api, ignoredResponse, message } from './api';
import { useSession, AdminGuard } from './session';
import { DateStamp } from './Family';
const labels = {
  pending: 'Awaiting approval',
  approved: 'Ready to implement',
  implementing: 'In progress',
  completed: 'Completed',
  declined: 'Not planned',
  blocked: 'Needs input',
};
function Review({ item }: { item: Suggestion }) {
  const [note, setNote] = useState(item.note);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const client = useQueryClient();
  async function update(status: string, implementNow = false) {
    setBusy(true);
    setError('');
    try {
      await api(`/suggestions/${item.id}`, ignoredResponse, 'PATCH', {
        status,
        note,
        implementNow,
      });
      await client.invalidateQueries({ queryKey: ['suggestions'] });
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="suggestion-review">
      <label>
        Admin response
        <textarea maxLength={2000} value={note} onChange={(e) => setNote(e.target.value)} />
      </label>
      {['pending', 'blocked', 'declined'].includes(item.status) && (
        <>
          <label className="suggestion-switch">
            <input
              type="checkbox"
              role="switch"
              checked={item.implementNow}
              disabled={busy}
              onChange={(e) => void update('approved', e.target.checked)}
            />
            Implement without another approval
          </label>
          <div className="suggestion-actions">
            <button
              disabled={busy}
              className="primary-button"
              onClick={() => void update('approved')}
            >
              Approve change
            </button>
            <button
              disabled={busy}
              className="outline-button"
              onClick={() => void update('declined')}
            >
              Not planned
            </button>
          </div>
        </>
      )}
      {item.status === 'approved' && (
        <button disabled={busy} className="outline-button" onClick={() => void update('pending')}>
          Return to review
        </button>
      )}
      {error && <p role="alert">{error}</p>}
    </div>
  );
}
export function Suggestions({ review = false }: { review?: boolean }) {
  const { session } = useSession();
  const client = useQueryClient();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [implementNow, setImplementNow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const admin = Boolean(session.profile?.isAdmin && session.adminUnlocked);
  const query = useInfiniteQuery({
    queryKey: ['suggestions', session.profile?.id],
    initialPageParam: null as number | null,
    queryFn: ({ pageParam, signal }) =>
      api(
        `/suggestions${pageParam ? `?before=${pageParam}` : ''}`,
        suggestionsResponseSchema,
        'GET',
        undefined,
        signal,
      ),
    getNextPageParam: (page) => page.nextCursor ?? undefined,
    refetchInterval: 15000,
  });
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError('');
    setSuccess('');
    try {
      await api('/suggestions', ignoredResponse, 'POST', {
        title,
        body,
        implementNow: admin && implementNow,
      });
      setTitle('');
      setBody('');
      setImplementNow(false);
      setSuccess('Suggestion saved. Admins have been notified.');
      await client.invalidateQueries({ queryKey: ['suggestions'] });
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <main id="main-content" className="family-page suggestions-page">
      <p className="eyebrow">BUILT WITH THE FAMILY</p>
      <div className="row-heading">
        <div>
          <h1>Suggestion box</h1>
          <p>A better movie night starts with your ideas.</p>
        </div>
        {session.profile?.isAdmin && !review && (
          <Link className="outline-button" to="/settings/suggestions/review">
            Admin review
          </Link>
        )}
      </div>
      <p className="muted">
        Everyone in this household can see suggestions and their status. Approved ideas enter the
        Codex work queue; changes are not instantaneous.
      </p>
      <form className="suggestion-compose" onSubmit={submit}>
        <h2>What would you change?</h2>
        <label>
          Title
          <input
            required
            minLength={3}
            maxLength={120}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="A short name for your idea"
          />
        </label>
        <label>
          Tell us about it
          <textarea
            required
            minLength={5}
            maxLength={4000}
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="What should work differently, and why? Please don’t include passwords or private information."
          />
        </label>
        {admin && (
          <label className="suggestion-switch">
            <input
              type="checkbox"
              role="switch"
              checked={implementNow}
              onChange={(e) => setImplementNow(e.target.checked)}
            />
            Implement without approval{' '}
            <small>Admin only · sends this idea straight to the approved queue.</small>
          </label>
        )}
        <button className="primary-button" disabled={busy}>
          {busy ? 'Submitting…' : 'Submit suggestion'}
        </button>
        {error && <p role="alert">{error}</p>}
        {success && <p role="status">{success}</p>}
      </form>
      <h2>The family’s ideas</h2>
      {query.isPending && <p>Loading suggestions…</p>}
      {query.isError && (
        <p role="alert">
          Could not load suggestions. <button onClick={() => void query.refetch()}>Retry</button>
        </p>
      )}
      <div className="suggestion-feed">
        {query.data?.pages
          .flatMap((page) => page.items)
          .map((item) => (
            <article key={item.id}>
              <div className="row-heading">
                <span className={`suggestion-status suggestion-${item.status}`}>
                  {labels[item.status]}
                </span>
                <small>#{item.id}</small>
              </div>
              <h2>{item.title}</h2>
              <p className="suggestion-body">{item.body}</p>
              <small>
                Suggested by {item.author} · <DateStamp value={item.createdAt} />
              </small>
              {item.note && <blockquote>{item.note}</blockquote>}
              {admin && <Review item={item} />}
            </article>
          ))}
      </div>
      {query.data && !query.data.pages[0]?.items.length && (
        <p className="command-empty">Be the first to suggest something.</p>
      )}
      {query.hasNextPage && (
        <button
          className="outline-button"
          disabled={query.isFetching}
          onClick={() => void query.fetchNextPage()}
        >
          More suggestions
        </button>
      )}
    </main>
  );
}
export function SuggestionReview() {
  return (
    <AdminGuard>
      <Suggestions review />
    </AdminGuard>
  );
}
