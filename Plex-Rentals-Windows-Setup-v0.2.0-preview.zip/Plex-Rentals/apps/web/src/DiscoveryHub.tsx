import { FilterRow } from './FilterRow';
import { useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { discoveryCollections, type TitleCard } from '@reelrequest/shared';
import { useSession } from './session';
export function DiscoveryHub({
  rows,
  refresh,
  render,
}: {
  rows: { items: TitleCard[] }[];
  refresh: () => void;
  render: (title: TitleCard) => ReactNode;
}) {
  const { session } = useSession();
  const storageKey = `reelrequest-dismissed:${session.profile?.id}`;
  const [dismissed, setDismissed] = useState<number[]>(() => {
    try {
      const value = JSON.parse(localStorage.getItem(storageKey) ?? '[]');
      return Array.isArray(value) ? value.filter((item) => typeof item === 'number') : [];
    } catch {
      return [];
    }
  });
  const [surprise, setSurprise] = useState(false);
  const items = [
    ...new Map(
      rows
        .flatMap((row) => row.items)
        .filter(
          (item) =>
            item.mediaType === 'movie' &&
            item.releaseState !== 'coming_soon' &&
            !dismissed.includes(item.tmdbId),
        )
        .map((item) => [item.tmdbId, item]),
    ).values(),
  ].slice(0, 3);
  function save(values: number[]) {
    setDismissed(values);
    try {
      localStorage.setItem(storageKey, JSON.stringify(values));
    } catch {
      /* Browsing works without storage. */
    }
  }
  return (
    <section className="discovery-hub">
      <div className="discovery-invitation">
        <img
          className="discovery-backdrop"
          src="/discovery/hero.svg"
          alt=""
          loading="lazy"
          decoding="async"
        />
        <p className="eyebrow">YOUR NEXT GREAT FIND</p>
        <h2>A whole world of movies.</h2>
        <p>Follow a mood, a decade, or a favorite face.</p>
        <Link className="primary-button" to="/explore">
          Explore everything →
        </Link>
      </div>
      <div className="row-heading">
        <h2>What are you in the mood for?</h2>
        <button
          className="text-button"
          onClick={() => {
            setSurprise(true);
            refresh();
          }}
        >
          Surprise me
        </button>
      </div>
      <div className="collection-mosaic">
        {Object.entries(discoveryCollections).map(([id, collection]) => (
          <Link key={id} to={`/explore?collection=${id}`} className={`discovery-tile tile-${id}`}>
            <img
              src={`/discovery/${id}.svg`}
              alt=""
              loading="lazy"
              decoding="async"
              width="960"
              height="540"
            />
            <div className="mood-caption">
              <strong>{id === 'space' ? 'Sci-fi after dark' : collection.name}</strong>
              <span className="mood-arrow" aria-hidden="true">
                ↗
              </span>
            </div>
            <span className="sr-only">{collection.description}</span>
          </Link>
        ))}
      </div>
      <FilterRow className="">
        {dismissed.length > 0 && (
          <button className="text-button" onClick={() => save([])}>
            Restore hidden picks
          </button>
        )}
      </FilterRow>
      {surprise && (
        <div className="poster-grid surprise-grid">
          {items.map((title) => (
            <div key={title.tmdbId}>
              {render(title)}
              <p className="muted">
                {title.plexState === 'available'
                  ? 'Ready in your Plex library'
                  : title.tmdbScore
                    ? `Audience score ${title.tmdbScore}/10`
                    : 'From today’s discovery collections'}
              </p>
              <button className="text-button" onClick={() => save([...dismissed, title.tmdbId])}>
                Not for me
              </button>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
