import { plexState, releaseState, requestStatus } from '@reelrequest/shared';
import type { PlexState, ReleaseState, RequestStatus } from '@reelrequest/shared';

// The presentation layer consumes the shared contract; it never infers Plex availability.
export const requestLabels: Record<RequestStatus, string> = {
  [requestStatus.enum.requested]: 'Requested',
  [requestStatus.enum.looking]: 'Looking',
  [requestStatus.enum.available]: 'Available in Plex',
  [requestStatus.enum.watched]: 'Watched',
  [requestStatus.enum.passed]: 'Not this time',
  [requestStatus.enum.cancelled]: 'Cancelled',
};
export const releaseLabels: Record<ReleaseState, string> = {
  [releaseState.enum.released]: 'Released',
  [releaseState.enum.coming_soon]: 'Coming Soon',
  [releaseState.enum.unknown]: 'Release date unknown',
};
export const plexLabels: Record<PlexState, string> = {
  [plexState.enum.available]: 'Available in Plex',
  [plexState.enum.unavailable]: 'Not in Plex yet',
  [plexState.enum.unknown]: "Can't confirm Plex right now",
};
