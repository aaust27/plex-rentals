import { useEffect, useState } from 'react';
import type { EffectsMode } from '@reelrequest/shared';

export const EFFECTS_STORAGE_KEY = 'reelrequest.effects';

export interface DeviceCapabilities {
  reducedMotion: boolean;
  memory?: number | undefined;
  cores?: number | undefined;
}

export function defaultEffects({ reducedMotion, memory, cores }: DeviceCapabilities): EffectsMode {
  return reducedMotion ||
    (memory !== undefined && memory <= 4) ||
    (cores !== undefined && cores <= 4)
    ? 'lite'
    : 'full';
}

export function resolveEffects(stored: string | null, device: DeviceCapabilities): EffectsMode {
  return stored === 'full' || stored === 'lite' ? stored : defaultEffects(device);
}

function readStoredEffects(): string | null {
  try {
    return localStorage.getItem(EFFECTS_STORAGE_KEY);
  } catch {
    return null;
  }
}

function prefersReducedMotion(): boolean {
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

export function useEffects() {
  const [reducedMotion, setReducedMotion] = useState(prefersReducedMotion);
  const [mode, setMode] = useState<EffectsMode>(() =>
    resolveEffects(readStoredEffects(), {
      reducedMotion: prefersReducedMotion(),
      memory: (navigator as Navigator & { deviceMemory?: number }).deviceMemory,
      cores: navigator.hardwareConcurrency,
    }),
  );
  const [saved, setSaved] = useState(true);

  useEffect(() => {
    const query = window.matchMedia('(prefers-reduced-motion: reduce)');
    const onChange = () => setReducedMotion(query.matches);
    query.addEventListener('change', onChange);
    return () => query.removeEventListener('change', onChange);
  }, []);

  useEffect(() => {
    document.documentElement.dataset.effects = mode;
    document.documentElement.dataset.reducedMotion = String(reducedMotion);
  }, [mode, reducedMotion]);

  function updateMode(next: EffectsMode) {
    setMode(next);
    try {
      localStorage.setItem(EFFECTS_STORAGE_KEY, next);
      setSaved(true);
    } catch {
      setSaved(false);
    }
  }

  return {
    mode,
    setMode: updateMode,
    reducedMotion,
    animate: mode === 'full' && !reducedMotion,
    saved,
  };
}
