import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { storageStatusSchema, storageReviewSchema } from '@reelrequest/shared';
import { api, ignoredResponse, message } from './api';
import { ErrorText, useSession } from './session';
import { Modal } from './Modal';
import { formatBytes } from './TransferDetails';
export function StorageDashboard() {
  const { session } = useSession();
  const [filter, setFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [large, setLarge] = useState(false);
  const [limit, setLimit] = useState(100);
  const [selection, setSelection] = useState<{ at: string; ids: string[] }>({ at: '', ids: [] });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [review, setReview] = useState<ReturnType<typeof storageReviewSchema.parse> | null>(null);
  const query = useQuery({
    queryKey: ['admin-storage', session.profile?.id],
    queryFn: ({ signal }) => api('/admin/storage', storageStatusSchema, 'GET', undefined, signal),
    refetchInterval: (q) => (q.state.data?.scanning ? 3000 : 30000),
  });
  const snapshot = query.data?.snapshot;
  const ids = selection.at === snapshot?.generatedAt ? selection.ids : [];
  const entries = (snapshot?.entries ?? []).filter(
    (e) =>
      (filter === 'All' || e.library === filter) &&
      e.name.toLowerCase().includes(search.toLowerCase()) &&
      (!large || e.bytes >= 8 * 1024 ** 3),
  );
  const total = snapshot?.entries.reduce((n, e) => n + e.bytes, 0) ?? 0;
  async function scan() {
    setBusy(true);
    setError('');
    try {
      await api('/admin/storage/scan', ignoredResponse, 'POST', {});
      await query.refetch();
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  async function preview() {
    setBusy(true);
    setError('');
    try {
      setReview(
        await api('/admin/storage/review', storageReviewSchema, 'POST', {
          generatedAt: snapshot!.generatedAt,
          ids,
        }),
      );
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(false);
    }
  }
  function exportList() {
    if (!review) return;
    const text = [
      'Plex Rentals — cleanup review',
      `Inventory: ${review.generatedAt}`,
      `Potential logical size: ${formatBytes(review.bytes)}`,
      'Review only; nothing has been deleted.',
      '',
      ...review.entries.map((e) => `${e.library}\t${e.name}\t${e.bytes} bytes`),
    ].join('\n');
    const url = URL.createObjectURL(new Blob([text], { type: 'text/plain' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = 'plex-rentals-cleanup-review.txt';
    a.click();
    URL.revokeObjectURL(url);
  }
  return (
    <main className="family-page storage-dashboard">
      <Link className="text-button" to="/requests">
        ← Command center
      </Link>
      <div className="row-heading">
        <div>
          <p className="eyebrow">LIBRARY HEALTH</p>
          <h1>Make room for what's next.</h1>
          <p className="muted">
            Movies and TV, largest first. Build a cleanup list before touching any files.
          </p>
        </div>
        <button
          className="primary-button"
          disabled={busy || query.data?.scanning || !query.data?.enabled}
          onClick={() => void scan()}
        >
          {query.data?.scanning ? 'Scanning…' : 'Refresh inventory'}
        </button>
      </div>
      <ErrorText
        error={error || query.data?.error || (query.isError ? message(query.error) : '')}
      />
      {query.data?.scanning && (
        <p role="status">
          Reading library sizes… {query.data.completed} entries checked. You can leave this page
          while it runs.
        </p>
      )}
      {!query.data?.enabled && query.data && (
        <p className="status-box">Storage scanning is not configured on this deployment.</p>
      )}
      {snapshot ? (
        <>
          <p className="muted">
            Snapshot: {new Date(snapshot.generatedAt).toLocaleString()} ·{' '}
            {snapshot.entries.length.toLocaleString()} top-level entries. Refresh after cleanup to
            update sizes.
          </p>
          <div className="storage-metrics">
            <article>
              <span>Media inventoried</span>
              <strong>{formatBytes(total)}</strong>
              <small>Movies + TV logical file sizes</small>
            </article>
            {snapshot.volumes.slice(0,1).map((v) => (
              <article key={v.library}>
                <span>NAS available space</span>
                <strong>{formatBytes(v.freeBytes)} free</strong>
                <progress
                  max={v.totalBytes || 1}
                  value={Math.max(0, v.totalBytes - v.freeBytes)}
                  aria-label={`${v.library} volume used space`}
                />
                <small>
                  {formatBytes(v.totalBytes)} total · shared by Movies, TV and other NAS data
                </small>
              </article>
            ))}
          </div>
          <div className="storage-controls">
            <label>
              Search folders
              <input
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setLimit(100);
                }}
                placeholder="Find a movie or show"
              />
            </label>
            <label>
              Library
              <select
                value={filter}
                onChange={(e) => {
                  setFilter(e.target.value);
                  setLimit(100);
                }}
              >
                {['All', 'Movies', 'TV'].map((v) => (
                  <option key={v}>{v}</option>
                ))}
              </select>
            </label>
            <label className="storage-check">
              <input
                type="checkbox"
                checked={large}
                onChange={(e) => {
                  setLarge(e.target.checked);
                  setLimit(100);
                }}
              />
              8 GiB or larger
            </label>
          </div>
          <div className="storage-review-bar">
            <span>
              {ids.length} selected ·{' '}
              {formatBytes(
                snapshot.entries.filter((e) => ids.includes(e.id)).reduce((n, e) => n + e.bytes, 0),
              )}{' '}
              to review
            </span>
            <button
              className="outline-button"
              disabled={!ids.length || busy}
              onClick={() => void preview()}
            >
              Review cleanup
            </button>
            {ids.length > 0 && (
              <button className="text-button" onClick={() => setSelection({ at: '', ids: [] })}>
                Clear selection
              </button>
            )}
          </div>
          <p className="muted">
            Size is a starting point, not a recommendation to delete. A TV entry can contain an
            entire series; extras are included. Hardlinks, snapshots and recycle bins may affect
            space actually reclaimed.
          </p>
          <div className="storage-list">
            {entries.slice(0, limit).map((e) => (
              <label className="storage-item" key={e.id}>
                <input
                  type="checkbox"
                  checked={ids.includes(e.id)}
                  disabled={!ids.includes(e.id) && ids.length >= 200}
                  onChange={() =>
                    setSelection({
                      at: snapshot.generatedAt,
                      ids: ids.includes(e.id) ? ids.filter((id) => id !== e.id) : [...ids, e.id],
                    })
                  }
                />
                <span>
                  <strong>{e.name}</strong>
                  <small>
                    {e.library} · {e.files.toLocaleString()} files
                    {e.skipped ? ` · ${e.skipped} links/special entries skipped` : ''}
                  </small>
                </span>
                <b>{formatBytes(e.bytes)}</b>
              </label>
            ))}
          </div>
          {entries.length === 0 && <p>No entries match these filters.</p>}
          {entries.length > limit && (
            <button className="outline-button" onClick={() => setLimit(limit + 100)}>
              Show 100 more
            </button>
          )}
        </>
      ) : query.isPending ? (
        <p>Loading storage…</p>
      ) : (
        <p className="status-box">Run your first inventory to see sizes and available space.</p>
      )}
      {review && (
        <Modal title="Review your cleanup list" onClose={() => setReview(null)}>
          <p>
            <strong>
              {review.entries.length} entries · {formatBytes(review.bytes)}
            </strong>
          </p>
          <p>
            Nothing will be deleted here. Export this list and review the exact folders in your NAS
            file manager before removing anything. Check whether Sonarr/Radarr still monitor a title
            so it is not downloaded again.
          </p>
          <ul className="storage-review-items">
            {review.entries.map((e) => (
              <li key={e.id}>
                {e.library}: {e.name} — {formatBytes(e.bytes)}
              </li>
            ))}
          </ul>
          <button className="primary-button" onClick={exportList}>
            Export reviewed list
          </button>
          <button className="text-button" onClick={() => setReview(null)}>
            Back to inventory
          </button>
        </Modal>
      )}
    </main>
  );
}


