export interface Health {
  status: 'ok';
  phase: 2;
  database: 'ready';
  plexMode: 'mock' | 'configured';
  plexReady: boolean;
}

export function parseHealth(data: unknown): Health {
  if (
    typeof data !== 'object' ||
    data === null ||
    !('status' in data) ||
    data.status !== 'ok' ||
    !('phase' in data) ||
    data.phase !== 2 ||
    !('database' in data) ||
    data.database !== 'ready' ||
    !('plexMode' in data) ||
    (data.plexMode !== 'mock' && data.plexMode !== 'configured') ||
    !('plexReady' in data) ||
    typeof data.plexReady !== 'boolean'
  )
    throw new Error('The server returned an unexpected response.');
  return {
    status: data.status,
    phase: data.phase,
    database: data.database,
    plexMode: data.plexMode,
    plexReady: data.plexReady,
  };
}

export async function fetchHealth({ signal }: { signal: AbortSignal }): Promise<Health> {
  const response = await fetch('/api/health', {
    signal: AbortSignal.any([signal, AbortSignal.timeout(8_000)]),
  });
  if (!response.ok) throw new Error('The Plex Rentals server is not ready.');
  const data: unknown = await response.json();
  return parseHealth(data);
}
