import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { AnimatePresence, MotionConfig, motion } from 'motion/react';
import { Link, Route, Routes } from 'react-router-dom';
import { useEffects } from './effects';
import { fetchHealth } from './health';

export function ReelIcon({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 64 64" fill="none" aria-hidden="true">
      <path d="M58 51H44A26 26 0 1 0 30 56h28Z" fill="currentColor" />
      <g fill="#0B0C10">
        <circle cx="30" cy="13" r="6.5" />
        <circle cx="47" cy="27" r="6.5" />
        <circle cx="36" cy="45" r="6.5" />
        <circle cx="15" cy="39" r="6.5" />
        <circle cx="13" cy="19" r="6" />
        <circle cx="29" cy="29" r="3.5" />
      </g>
    </svg>
  );
}

function SettingsIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
      <path d="M4 7h16M4 17h16" />
      <circle cx="8" cy="7" r="3" fill="var(--bg)" />
      <circle cx="16" cy="17" r="3" fill="var(--bg)" />
    </svg>
  );
}

function ArrowIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
      <path d="M5 12h14m-6-6 6 6-6 6" />
    </svg>
  );
}

export function Splash() {
  const effects = useEffects();
  const [settingsOpen, setSettingsOpen] = useState(false);
  const health = useQuery({
    queryKey: ['health'],
    queryFn: fetchHealth,
    refetchOnWindowFocus: false,
  });
  const isReady = health.isSuccess && !health.isError;
  const isBusy = health.isFetching;

  return (
    <MotionConfig reducedMotion={effects.animate ? 'user' : 'always'}>
      <div className="splash-shell" data-testid="splash">
        <div className="sunset-slot" aria-hidden="true" data-artwork-slot="welcome-backdrop">
          <div className="sunset-halo" />
        </div>

        <header className="site-header flex items-center justify-between">
          <Link to="/" className="wordmark" aria-label="Plex Rentals home">
            <ReelIcon />
            <span>
              Plex<span className="accent-text"> Rentals</span>
            </span>
          </Link>
          <button
            className="effects-trigger flex items-center gap-2"
            type="button"
            onClick={() => setSettingsOpen(!settingsOpen)}
            aria-expanded={settingsOpen}
            aria-controls="effects-panel"
          >
            <SettingsIcon />
            <span>Effects</span>
            <span className="effect-current">{effects.mode === 'full' ? 'Full' : 'Lite'}</span>
          </button>
        </header>

        <AnimatePresence>
          {settingsOpen && (
            <motion.section
              id="effects-panel"
              className="effects-panel"
              aria-label="Effects settings"
              initial={{ opacity: 0, y: effects.animate ? -6 : 0 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
            >
              <div className="flex items-center justify-between gap-4">
                <h2>Make yourself comfortable.</h2>
                <button
                  className="close-button"
                  aria-label="Close Effects settings"
                  onClick={() => setSettingsOpen(false)}
                >
                  ×
                </button>
              </div>
              <p>Choose the feel for this device.</p>
              <div className="effects-options" role="group" aria-label="Effects mode">
                <button
                  type="button"
                  aria-pressed={effects.mode === 'full'}
                  onClick={() => effects.setMode('full')}
                >
                  <span>Full</span>
                  <small>A little movie magic</small>
                </button>
                <button
                  type="button"
                  aria-pressed={effects.mode === 'lite'}
                  onClick={() => effects.setMode('lite')}
                >
                  <span>Lite</span>
                  <small>Quiet and simple</small>
                </button>
              </div>
              <p className="effects-note" role="status">
                {effects.reducedMotion
                  ? 'Your reduced-motion preference is respected in either mode.'
                  : effects.saved
                    ? 'Saved on this device.'
                    : 'This browser cannot save preferences. Your choice applies for this visit.'}
              </p>
            </motion.section>
          )}
        </AnimatePresence>

        <main id="main-content" className="hero-content">
          <motion.div
            className="hero-intro"
            initial={{ opacity: 0, y: effects.animate ? 12 : 0 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: effects.animate ? 0.65 : 0 }}
          >
            <div className="reel-medallion">
              <ReelIcon />
            </div>
            <p className="eyebrow">OUR FAMILY. OUR MOVIE NIGHTS.</p>
            <h1>
              Same great movies.
              <br />
              <span>A happier family.</span>
            </h1>
          </motion.div>

          <motion.section
            className="welcome-card"
            aria-labelledby="welcome-title"
            initial={{ opacity: 0, y: effects.animate ? 16 : 0 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: effects.animate ? 0.15 : 0, duration: effects.animate ? 0.65 : 0 }}
          >
            <div className="card-heading flex items-center justify-between gap-3">
              <p className="eyebrow">THE FIRST REEL</p>
              <span className="phase-badge">Phase 1</span>
            </div>
            <h2 id="welcome-title">Welcome to Plex Rentals.</h2>
            <Link className="primary-button" to="/">
              Start browsing →
            </Link>
            <p className="card-description">
              Your family’s movie spot is taking shape. Browse the catalog and explore title details
              today.
            </p>
            <div className="connection-line" role="status" aria-live="polite">
              <span
                className={`connection-dot ${isBusy ? 'checking' : isReady ? 'ready' : 'offline'}`}
              />
              <span>
                {isBusy
                  ? 'Checking the connection…'
                  : health.isError
                    ? 'We can’t reach Plex Rentals right now.'
                    : isReady
                      ? 'Plex Rentals is ready'
                      : 'Waiting for the server…'}
              </span>
            </div>
            {!isBusy && health.isError && (
              <p className="connection-explanation">
                Check that the server is running, then try again.
              </p>
            )}
            <button
              type="button"
              className="primary-button flex items-center justify-center gap-3"
              onClick={() => {
                void health.refetch();
              }}
              disabled={isBusy}
            >
              <span>
                {isBusy ? 'Checking…' : health.isError ? 'Try again' : 'Check connection'}
              </span>
              <ArrowIcon />
            </button>
            <div className="demo-note">
              <span className="demo-icon" aria-hidden="true">
                i
              </span>
              <span>
                {isReady && health.data.plexMode === 'configured'
                  ? 'Plex is configured. Live connection comes in Phase 3.'
                  : isReady
                    ? 'Demo mode. Your Plex library is not connected yet.'
                    : 'This preview does not connect to your Plex library.'}
              </span>
            </div>
          </motion.section>
        </main>

        <footer className="site-footer">
          <div className="footer-rule" />
          <p>A private movie app for your family.</p>
        </footer>
      </div>
    </MotionConfig>
  );
}

function NotFound() {
  return (
    <main className="not-found">
      <ReelIcon />
      <p className="eyebrow">PLEX RENTALS</p>
      <h1>This reel isn’t here.</h1>
      <p>Only the welcome screen is available in this first build.</p>
      <Link className="primary-button" to="/">
        Back to welcome
      </Link>
    </main>
  );
}

export function LegacyApp() {
  return (
    <Routes>
      <Route path="/" element={<Splash />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
