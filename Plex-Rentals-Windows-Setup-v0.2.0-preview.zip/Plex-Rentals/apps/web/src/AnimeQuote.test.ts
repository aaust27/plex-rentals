import { describe, it, expect } from 'vitest';
import { quoteForDay } from './AnimeQuote';
describe('daily anime quote', () => {
  it('is stable throughout a local calendar day and changes at midnight', () => {
    expect(quoteForDay(new Date(2026, 8, 26, 0))).toEqual(
      quoteForDay(new Date(2026, 8, 26, 23, 59)),
    );
    expect(quoteForDay(new Date(2026, 8, 27, 0))).not.toEqual(
      quoteForDay(new Date(2026, 8, 26, 23, 59)),
    );
    expect(
      new Set(Array.from({ length: 7 }, (_, day) => quoteForDay(new Date(2026, 8, 26 + day)).text))
        .size,
    ).toBe(7);
  });
});
