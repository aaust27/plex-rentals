CREATE TABLE suggestions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 profile_id INTEGER NOT NULL REFERENCES profiles(id),
 title TEXT NOT NULL,
 body TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','implementing','completed','declined','blocked')),
 implement_now INTEGER NOT NULL DEFAULT 0,
 reviewed_by INTEGER REFERENCES profiles(id),
 note TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
--> statement-breakpoint
CREATE TABLE suggestion_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 suggestion_id INTEGER NOT NULL REFERENCES suggestions(id),
 actor_id INTEGER REFERENCES profiles(id),
 status TEXT NOT NULL,
 note TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
