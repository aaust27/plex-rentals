ALTER TABLE profiles ADD COLUMN disabled INTEGER NOT NULL DEFAULT 0 CHECK(disabled IN (0,1));
--> statement-breakpoint
ALTER TABLE devices ADD COLUMN expires_at TEXT;
--> statement-breakpoint
ALTER TABLE devices ADD COLUMN admin_unlocked_until TEXT;
--> statement-breakpoint
CREATE TABLE auth_attempts (key TEXT PRIMARY KEY NOT NULL, failures INTEGER NOT NULL, window_start INTEGER NOT NULL);
