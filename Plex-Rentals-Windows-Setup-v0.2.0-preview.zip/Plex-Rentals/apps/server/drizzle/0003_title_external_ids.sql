ALTER TABLE titles ADD COLUMN imdb_id TEXT;
--> statement-breakpoint
ALTER TABLE titles ADD COLUMN tvdb_id INTEGER;
--> statement-breakpoint
CREATE INDEX titles_imdb_idx ON titles (imdb_id);
--> statement-breakpoint
CREATE INDEX titles_tvdb_idx ON titles (tvdb_id);
