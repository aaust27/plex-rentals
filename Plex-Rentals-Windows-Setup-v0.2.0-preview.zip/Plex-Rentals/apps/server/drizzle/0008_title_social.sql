CREATE TABLE title_ratings (
 title_id integer NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
 profile_id integer NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
 score real NOT NULL CHECK(score BETWEEN 0 AND 10 AND score*2=CAST(score*2 AS integer)),
 updated_at text NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(title_id,profile_id)
);
--> statement-breakpoint
CREATE TABLE title_comments (
 id integer PRIMARY KEY AUTOINCREMENT,
 title_id integer NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
 profile_id integer NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
 body text NOT NULL CHECK(length(body) BETWEEN 1 AND 2000),
 mentions text NOT NULL DEFAULT '[]',
 created_at text NOT NULL DEFAULT CURRENT_TIMESTAMP
);
--> statement-breakpoint
CREATE INDEX title_comments_page ON title_comments(title_id,id);
--> statement-breakpoint
CREATE INDEX title_comments_rate ON title_comments(profile_id,created_at);
