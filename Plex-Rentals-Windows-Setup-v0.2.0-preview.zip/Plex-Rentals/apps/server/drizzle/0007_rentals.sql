CREATE TABLE `request_rentals` (
	`request_id` integer PRIMARY KEY NOT NULL,
	`duration_days` integer DEFAULT 7 NOT NULL,
	`expires_at` text,
	`deleted_at` text,
	`last_error` text,
	`attempt_count` integer DEFAULT 0 NOT NULL,
	`next_attempt_at` text,
	`updated_at` text NOT NULL,
	`created_at` text DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')) NOT NULL,
	FOREIGN KEY (`request_id`) REFERENCES `requests`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "request_rentals_duration" CHECK("request_rentals"."duration_days" = 7)
);
--> statement-breakpoint
CREATE INDEX `request_rentals_due_idx` ON `request_rentals` (`expires_at`,`deleted_at`,`next_attempt_at`);
