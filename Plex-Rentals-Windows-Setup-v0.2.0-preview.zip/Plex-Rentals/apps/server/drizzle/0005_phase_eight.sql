CREATE TABLE automation_services (
 service TEXT PRIMARY KEY CHECK(service IN ('radarr','sonarr')),
 enabled INTEGER NOT NULL DEFAULT 0 CHECK(enabled IN (0,1)),
 base_url TEXT NOT NULL DEFAULT '', api_key TEXT,
 quality_profile_id INTEGER, root_folder_path TEXT,
 updated_at TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE TABLE request_automation (
 request_id INTEGER PRIMARY KEY REFERENCES requests(id) ON DELETE CASCADE,
 decision TEXT NOT NULL DEFAULT 'pending' CHECK(decision IN ('pending','approved','declined')),
 decided_by INTEGER REFERENCES profiles(id) ON DELETE SET NULL,
 decided_at TEXT, decline_reason TEXT,
 approved_scope TEXT CHECK(approved_scope IS NULL OR json_valid(approved_scope)),
 service TEXT NOT NULL CHECK(service IN ('radarr','sonarr')),
 submission_status TEXT NOT NULL DEFAULT 'not_submitted' CHECK(submission_status IN ('not_submitted','queued','submitting','sent','failed','skipped')),
 external_id INTEGER, last_error TEXT, attempt_count INTEGER NOT NULL DEFAULT 0,
 next_attempt_at TEXT, last_attempt_at TEXT, submitted_at TEXT,
 updated_at TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
 CHECK((decision='declined' AND decline_reason IS NOT NULL) OR decision<>'declined'),
 CHECK((decision='approved' AND approved_scope IS NOT NULL) OR decision<>'approved')
);
--> statement-breakpoint
CREATE INDEX request_automation_queue_idx ON request_automation(submission_status,next_attempt_at);
--> statement-breakpoint
CREATE TABLE automation_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 request_id INTEGER NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
 actor_profile_id INTEGER REFERENCES profiles(id) ON DELETE SET NULL,
 action TEXT NOT NULL, detail TEXT,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE INDEX automation_events_request_idx ON automation_events(request_id,created_at);
