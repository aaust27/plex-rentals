CREATE TABLE profiles (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, avatar TEXT NOT NULL, color TEXT NOT NULL,
 is_admin INTEGER NOT NULL DEFAULT 0 CHECK(is_admin IN (0,1)), pin_hash TEXT,
 max_rating_level INTEGER CHECK(max_rating_level BETWEEN 1 AND 5),
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE TABLE devices (
 id INTEGER PRIMARY KEY AUTOINCREMENT, token_hash TEXT NOT NULL UNIQUE, label TEXT, last_seen_at TEXT,
 current_profile_id INTEGER REFERENCES profiles(id) ON DELETE SET NULL,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE TABLE plex_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT, rating_key TEXT NOT NULL UNIQUE, section_id TEXT NOT NULL,
 media_type TEXT NOT NULL CHECK(media_type IN ('movie','tv')), title TEXT NOT NULL, year INTEGER,
 tmdb_id INTEGER, imdb_id TEXT, tvdb_id INTEGER, added_at TEXT, resolution TEXT,
 seasons TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(seasons)), last_seen_at TEXT,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE INDEX plex_tmdb_idx ON plex_items(tmdb_id, media_type);
--> statement-breakpoint
CREATE INDEX plex_imdb_idx ON plex_items(imdb_id);
--> statement-breakpoint
CREATE INDEX plex_tvdb_idx ON plex_items(tvdb_id);
--> statement-breakpoint
CREATE TABLE titles (
 id INTEGER PRIMARY KEY AUTOINCREMENT, tmdb_id INTEGER NOT NULL, media_type TEXT NOT NULL CHECK(media_type IN ('movie','tv')),
 title TEXT NOT NULL, year INTEGER, overview TEXT, poster_path TEXT, backdrop_path TEXT, logo_path TEXT,
 runtime_min INTEGER, certification TEXT, rating_level INTEGER CHECK(rating_level BETWEEN 1 AND 5),
 tmdb_score REAL CHECK(tmdb_score BETWEEN 0 AND 10), genres TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(genres)),
 "cast" TEXT NOT NULL DEFAULT '[]' CHECK(json_valid("cast")), crew TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(crew)),
 trailer_key TEXT, release_theatrical TEXT, release_digital TEXT, release_physical TEXT, next_air_date TEXT,
 release_state TEXT NOT NULL DEFAULT 'unknown' CHECK(release_state IN ('released','coming_soon','unknown')),
 color_hex TEXT, plex_rating_key TEXT REFERENCES plex_items(rating_key) ON DELETE SET NULL,
 plex_match TEXT CHECK(plex_match IN ('tmdb','imdb','tvdb','fuzzy','manual')), fetched_at TEXT,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX titles_tmdb_type_unique ON titles(tmdb_id, media_type);
--> statement-breakpoint
CREATE INDEX titles_release_idx ON titles(release_state);
--> statement-breakpoint
CREATE TABLE requests (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title_id INTEGER NOT NULL REFERENCES titles(id),
 created_by INTEGER NOT NULL REFERENCES profiles(id),
 status TEXT NOT NULL DEFAULT 'requested' CHECK(status IN ('requested','looking','available','watched','passed','cancelled')),
 reason TEXT, note TEXT CHECK(length(note)<=140), seasons TEXT CHECK(seasons IS NULL OR json_valid(seasons)),
 admin_note TEXT, available_at TEXT, watched_at TEXT, updated_at TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX requests_one_open_title ON requests(title_id) WHERE status NOT IN ('watched','passed','cancelled');
--> statement-breakpoint
CREATE INDEX requests_status_created_idx ON requests(status, created_at);
--> statement-breakpoint
CREATE TABLE request_supporters (
 id INTEGER PRIMARY KEY AUTOINCREMENT, request_id INTEGER NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
 profile_id INTEGER NOT NULL REFERENCES profiles(id), reason TEXT, note TEXT CHECK(length(note)<=140), withdrawn_at TEXT,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX supporters_request_profile_unique ON request_supporters(request_id,profile_id);
--> statement-breakpoint
CREATE TABLE request_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT, request_id INTEGER NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
 from_status TEXT CHECK(from_status IN ('requested','looking','available','watched','passed','cancelled')),
 to_status TEXT NOT NULL CHECK(to_status IN ('requested','looking','available','watched','passed','cancelled')),
 actor_profile_id INTEGER REFERENCES profiles(id) ON DELETE SET NULL,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE INDEX events_request_idx ON request_events(request_id,created_at);
--> statement-breakpoint
CREATE TRIGGER request_created AFTER INSERT ON requests BEGIN
 INSERT INTO request_supporters(request_id,profile_id,reason,note,created_at) VALUES(NEW.id,NEW.created_by,NEW.reason,NEW.note,NEW.created_at);
 INSERT INTO request_events(request_id,from_status,to_status,actor_profile_id,created_at) VALUES(NEW.id,NULL,NEW.status,NEW.created_by,NEW.created_at);
END;
--> statement-breakpoint
CREATE TRIGGER request_status_changed AFTER UPDATE OF status ON requests WHEN OLD.status <> NEW.status BEGIN
 INSERT INTO request_events(request_id,from_status,to_status,actor_profile_id,created_at) VALUES(NEW.id,OLD.status,NEW.status,NULL,NEW.updated_at);
END;
--> statement-breakpoint
CREATE TABLE reactions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
 title_id INTEGER NOT NULL REFERENCES titles(id) ON DELETE CASCADE, value TEXT NOT NULL CHECK(value IN ('up','down')),
 updated_at TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX reactions_profile_title_unique ON reactions(profile_id,title_id);
--> statement-breakpoint
CREATE TABLE signals (
 id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
 title_id INTEGER NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
 kind TEXT NOT NULL CHECK(kind IN ('detail_view','trailer_play','search_open')),
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE INDEX signals_profile_created_idx ON signals(profile_id,created_at);
--> statement-breakpoint
CREATE TABLE movie_nights (
 id INTEGER PRIMARY KEY AUTOINCREMENT, host_profile_id INTEGER NOT NULL REFERENCES profiles(id),
 status TEXT NOT NULL DEFAULT 'voting' CHECK(status IN ('voting','closed')), filters TEXT NOT NULL DEFAULT '{}' CHECK(json_valid(filters)),
 winner_title_id INTEGER REFERENCES titles(id), closed_at TEXT,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE TABLE movie_night_votes (
 id INTEGER PRIMARY KEY AUTOINCREMENT, movie_night_id INTEGER NOT NULL REFERENCES movie_nights(id) ON DELETE CASCADE,
 title_id INTEGER NOT NULL REFERENCES titles(id), profile_id INTEGER REFERENCES profiles(id), vote INTEGER,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
 CHECK((profile_id IS NULL AND vote IS NULL) OR (profile_id IS NOT NULL AND vote IS NOT NULL AND vote BETWEEN 0 AND 3))
);
--> statement-breakpoint
CREATE UNIQUE INDEX night_votes_unique ON movie_night_votes(movie_night_id,title_id,profile_id);
--> statement-breakpoint
CREATE UNIQUE INDEX night_candidates_unique ON movie_night_votes(movie_night_id,title_id) WHERE profile_id IS NULL;
--> statement-breakpoint
CREATE TABLE notifications (
 id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
 kind TEXT NOT NULL, request_id INTEGER REFERENCES requests(id) ON DELETE SET NULL,
 title_id INTEGER REFERENCES titles(id) ON DELETE SET NULL, body TEXT NOT NULL, read_at TEXT,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE INDEX notifications_profile_read_idx ON notifications(profile_id,read_at);
--> statement-breakpoint
CREATE TABLE push_subscriptions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
 device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE, endpoint TEXT NOT NULL UNIQUE,
 keys TEXT NOT NULL CHECK(json_valid(keys)), created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE TABLE list_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
 title_id INTEGER NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX list_items_profile_title_unique ON list_items(profile_id,title_id);
--> statement-breakpoint
CREATE TABLE settings (
 id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT NOT NULL UNIQUE, value TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
