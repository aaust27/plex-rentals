export type TransferSample = { at: number; downloaded: number; identity: string };
type QueueEntry = Record<string, unknown>;
export function transferMetrics(entries: QueueEntry[], at: number, previous?: TransferSample) {
  const valid =
    entries.length > 0 &&
    entries.every(
      (e) =>
        typeof e.size === 'number' &&
        Number.isFinite(e.size) &&
        e.size > 0 &&
        typeof e.sizeleft === 'number' &&
        Number.isFinite(e.sizeleft) &&
        e.sizeleft >= 0 &&
        e.sizeleft <= e.size,
    );
  if (!valid)
    return {
      bytesTotal: null,
      bytesDownloaded: null,
      speedBytesPerSecond: null,
      sample: undefined,
    };
  const total = entries.reduce((n, e) => n + Number(e.size), 0);
  const downloaded = entries.reduce((n, e) => n + Number(e.size) - Number(e.sizeleft), 0);
  const identity = entries
    .map((e) => `${e.id ?? e.downloadId ?? ''}:${e.size}`)
    .sort()
    .join('|');
  const seconds = previous ? (at - previous.at) / 1000 : 0;
  const active = entries.some((e) => String(e.status).toLowerCase() === 'downloading');
  const speed =
    active &&
    previous &&
    previous.identity === identity &&
    seconds >= 1 &&
    seconds <= 60 &&
    downloaded >= previous.downloaded
      ? (downloaded - previous.downloaded) / seconds
      : null;
  return {
    bytesTotal: total,
    bytesDownloaded: downloaded,
    speedBytesPerSecond: speed,
    sample: { at, downloaded, identity },
  };
}
export function trackingStage(
  state: string,
):
  | 'queued'
  | 'downloading'
  | 'transferring'
  | 'plex'
  | 'ready'
  | 'paused'
  | 'attention'
  | 'waiting' {
  if (/Ready in Plex|Watched/.test(state)) return 'ready';
  if (/attention|unavailable|failed/i.test(state)) return 'attention';
  if (/paused/i.test(state)) return 'paused';
  if (/waiting for Plex/i.test(state)) return 'plex';
  if (/Importing|awaiting import/i.test(state)) return 'transferring';
  if (state === 'Downloading') return 'downloading';
  if (/Queued|Monitoring/.test(state)) return 'queued';
  return 'waiting';
}
