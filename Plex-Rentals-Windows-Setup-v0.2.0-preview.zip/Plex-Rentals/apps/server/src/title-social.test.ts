import { beforeEach, afterEach, it, expect } from 'vitest';
import request from 'supertest';
import { createApp } from './app.js';
import { openDatabase, migrateDatabase, type AppDatabase } from './db/client.js';
import { seedDatabase } from './db/fixtures.js';
let db: AppDatabase;
let app: ReturnType<typeof createApp>;
const path = '/api/titles/movie/9900001/social';
beforeEach(() => {
  db = openDatabase(':memory:');
  migrateDatabase(db);
  seedDatabase(db);
  app = createApp(db, {
    plexUrl: '',
    catalog: { token: '' },
    auth: {
      householdPasscode: 'social-tests',
      sessionSecret: 'social-test-secret-at-least-32-characters',
      adminPin: '1234',
      baseUrl: 'http://localhost:8080',
    },
  });
});
afterEach(() => db.close());
async function member(id = 2) {
  const a = request.agent(app);
  await a.post('/api/household/join').send({ passcode: 'social-tests' }).expect(200);
  await a.post('/api/session').send({ profileId: id }).expect(200);
  return a;
}
it('requires authentication, rejects forged identity and fractional ratings, and updates only own rating', async () => {
  await request(app).get(path).expect(401);
  const a = await member();
  const b = await member(3);
  for (const score of [-1, 10.5, 2.2, '8'])
    await a
      .put(path + '/rating')
      .send({ score })
      .expect(400);
  await a
    .put(path + '/rating')
    .send({ score: 8, profileId: 3 })
    .expect(400);
  await a
    .put(path + '/rating')
    .send({ score: 0 })
    .expect(200);
  await b
    .put(path + '/rating')
    .send({ score: 10 })
    .expect(200);
  await a
    .put(path + '/rating')
    .send({ score: 8.5 })
    .expect(200);
  const r = (await a.get(path).expect(200)).body;
  expect(r).toMatchObject({ count: 2, average: 9.25, myScore: 8.5 });
  expect(r.ratings).toHaveLength(2);
  await a
    .put(path + '/rating')
    .set('Origin', 'https://evil.example')
    .send({ score: 3 })
    .expect(403);
});
it('persists plain text comments, deduplicates mentions and notifies only valid recipients', async () => {
  const a = await member();
  await a
    .post(path + '/comments')
    .send({ body: '<script>alert(1)</script>', mentions: [3, 3, 2] })
    .expect(201);
  const r = (await a.get(path)).body;
  expect(r.comments[0].body).toBe('<script>alert(1)</script>');
  expect(r.comments[0].mentions).toHaveLength(2);
  const notices = db.sqlite
    .prepare("SELECT profile_id,title_id FROM notifications WHERE kind='mention'")
    .all();
  expect(notices).toEqual([{ profile_id: 3, title_id: 1 }]);
  await a
    .post(path + '/comments')
    .send({ body: 'hello', mentions: [999] })
    .expect(400);
  await a
    .post(path + '/comments')
    .send({ body: ' ' })
    .expect(400);
  await a
    .post(path + '/comments')
    .send({ body: 'x'.repeat(2001) })
    .expect(400);
  db.sqlite.prepare('UPDATE profiles SET disabled=1 WHERE id=3').run();
  await a
    .post(path + '/comments')
    .send({ body: 'hello', mentions: [3] })
    .expect(400);
});
it('honors title restrictions for readers and tagged recipients, validates routes and paginates', async () => {
  const a = await member();
  db.sqlite.prepare("UPDATE titles SET certification='R' WHERE id=1").run();
  db.sqlite.prepare('UPDATE profiles SET max_rating_level=1 WHERE id=3').run();
  await a
    .post(path + '/comments')
    .send({ body: 'hello', mentions: [3] })
    .expect(400);
  const b = await member(3);
  await b.get(path).expect(404);
  await b
    .put(path + '/rating')
    .send({ score: 5 })
    .expect(404);
  await a.get('/api/titles/invalid/9900001/social').expect(400);
  await a.get(path + '?before=no').expect(400);
  const insert = db.sqlite.prepare(
    'INSERT INTO title_comments(title_id,profile_id,body) VALUES(1,2,?)',
  );
  for (let i = 0; i < 35; i++) insert.run('Comment ' + i);
  const page = (await a.get(path)).body;
  expect(page.comments).toHaveLength(30);
  const older = (await a.get(path + '?before=' + page.nextCursor)).body;
  expect(older.comments).toHaveLength(5);
  expect(older.nextCursor).toBeNull();
  await a
    .post(path + '/comments')
    .send({ body: 'rate limited' })
    .expect(429);
});
