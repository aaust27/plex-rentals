import {it,expect} from 'vitest';
import {transferMetrics,trackingStage} from './transfer-metrics.js';
it('samples speed only for consistent advancing downloads and rejects invalid telemetry',()=>{
 const initial=transferMetrics([{id:1,size:1000,sizeleft:800,status:'downloading'}],1000);expect(initial.speedBytesPerSecond).toBeNull();
 const next=transferMetrics([{id:1,size:1000,sizeleft:500,status:'downloading'}],6000,initial.sample);expect(next).toMatchObject({bytesTotal:1000,bytesDownloaded:500,speedBytesPerSecond:60});
 expect(transferMetrics([{id:2,size:1000,sizeleft:500,status:'downloading'}],6000,initial.sample).speedBytesPerSecond).toBeNull();
 expect(transferMetrics([{id:1,size:1000,sizeleft:900,status:'downloading'}],6000,initial.sample).speedBytesPerSecond).toBeNull();
 expect(transferMetrics([{id:1,size:1000,sizeleft:500,status:'paused'}],6000,initial.sample).speedBytesPerSecond).toBeNull();
 expect(transferMetrics([{id:1,size:1000,sizeleft:500,status:'downloading'}],100000,initial.sample).speedBytesPerSecond).toBeNull();
 expect(transferMetrics([{size:100,sizeleft:101}],0).bytesTotal).toBeNull();expect(transferMetrics([],0).bytesTotal).toBeNull();
});
it.each([['Downloading','downloading'],['Importing to NAS library','transferring'],['Imported · waiting for Plex confirmation','plex'],['Ready in Plex','ready'],['Download paused','paused'],['Live tracking unavailable · will retry','attention'],['Waiting for digital release','waiting']])('maps %s honestly to %s',(state,stage)=>expect(trackingStage(state)).toBe(stage));
