import { and, eq, isNull, desc } from 'drizzle-orm';
import {
  ratingLevels,
  openRequestStatuses,
  type MediaType,
  type TitleCard,
  type TitleDetail,
  type RequestRecord,
  type RequestStatus,
  type RequestReason,
} from '@reelrequest/shared';
import type { AppDatabase } from './db/client.js';
import {
  listItems,
  plexItems,
  profiles,
  reactions,
  requestAutomation,
  requestEvents,
  requests,
  requestSupporters,
  titles,
} from './db/schema.js';
import { ApiError, type ProfileRow } from './auth.js';
import { demoCard, createCatalog } from './catalog.js';
import type { PlexAdapter } from './integrations/plex/index.js';
import type { NotificationService } from './notifications.js';

type Catalog = ReturnType<typeof createCatalog>;
type TitleRow = typeof titles.$inferSelect;
type RequestRow = typeof requests.$inferSelect;
type LibraryEntry = {
  title: TitleRow | null;
  item: typeof plexItems.$inferSelect;
  card: TitleCard;
};
export function allowed(profile: Pick<ProfileRow, 'maxRatingLevel'>, certification: string | null): boolean {
  return (
    profile.maxRatingLevel === null ||
    (certification !== null && (ratingLevels[certification] ?? Infinity) <= profile.maxRatingLevel)
  );
}
export function createFamily(
  database: AppDatabase,
  catalog: Catalog,
  plex: PlexAdapter,
  now: () => Date,
  emit: (kind: 'requests' | 'profiles' | 'list' | 'notifications' | 'movie_night') => void,
  notificationService?: NotificationService,
) {
  const mockPlex = plex.mode === 'mock';
  const db = database.db;
  const movieDay = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Chicago' });
  function requestsCreatedToday(profileId: number, time: Date) {
    const today = movieDay.format(time);
    // Count cancelled and declined requests too: withdrawing cannot refund the allowance.
    return (database.sqlite.prepare(
      `SELECT r.created_at FROM requests r
       WHERE r.created_by=? AND julianday(r.created_at)>=julianday(?)`,
    ).all(profileId, new Date(time.getTime() - 48 * 3600000).toISOString()) as { created_at: string }[])
      .filter((entry) => movieDay.format(new Date(entry.created_at.includes('T')
        ? entry.created_at : entry.created_at.replace(' ', 'T') + 'Z')) === today).length;
  }
  const preview = createCatalog(database, { token: '', plexUrl: mockPlex ? '' : 'configured' });
  // Existing isolated demo rows predate metadata; backfill only those synthetic titles.
  for (const title of db
    .select()
    .from(titles)
    .all()
    .filter((entry) => entry.tmdbId >= 9900001 && entry.tmdbId <= 9900008)) {
    const fixture = demoCard(title.tmdbId - 9900001);
    db.update(titles)
      .set({
        posterPath: fixture.posterPath,
        backdropPath: fixture.backdropPath,
        certification: fixture.certification,
        ratingLevel: fixture.certification ? (ratingLevels[fixture.certification] ?? null) : null,
      })
      .where(eq(titles.id, title.id))
      .run();
  }
  function row(type: MediaType, id: number) {
    return db
      .select()
      .from(titles)
      .where(and(eq(titles.mediaType, type), eq(titles.tmdbId, id)))
      .get();
  }
  function currentRequest(titleId: number) {
    const all = db
      .select()
      .from(requests)
      .where(eq(requests.titleId, titleId))
      .orderBy(desc(requests.id))
      .all();
    return (
      all.find((entry) => openRequestStatuses.includes(entry.status)) ??
      all.find((entry) => entry.status !== 'cancelled')
    );
  }
  function ensureExactMatch(title: TitleRow): TitleRow {
    if (mockPlex || title.plexRatingKey || title.tmdbId >= 9900001) return title;
    const item = db
      .select()
      .from(plexItems)
      .where(and(eq(plexItems.tmdbId, title.tmdbId), eq(plexItems.mediaType, title.mediaType)))
      .get();
    if (!item) return title;
    db.update(titles)
      .set({ plexRatingKey: item.ratingKey, plexMatch: 'tmdb' })
      .where(eq(titles.id, title.id))
      .run();
    return { ...title, plexRatingKey: item.ratingKey, plexMatch: 'tmdb' };
  }
  function state<T extends TitleCard>(card: T): T {
    const result = { ...card };
    delete result.requestStatus;
    const stored = row(card.mediaType, card.tmdbId);
    const title = stored ? ensureExactMatch(stored) : undefined;
    const req = title && currentRequest(title.id);
    if (req) result.requestStatus = req.status;
    // Discovery cards arrive from TMDB before their complete metadata is necessarily
    // saved locally. The Plex mirror already has an exact TMDB identity, so consult
    // it directly as well as any previously saved title mapping.
    const item = title?.plexRatingKey
      ? db.select().from(plexItems).where(eq(plexItems.ratingKey, title.plexRatingKey)).get()
      : db
          .select()
          .from(plexItems)
          .where(
            and(
              eq(plexItems.tmdbId, card.tmdbId),
              eq(plexItems.mediaType, card.mediaType),
            ),
          )
          .get();
    const match = item
      ? {
          ratingKey: item.ratingKey,
          source: title?.plexMatch ?? ('tmdb' as const),
          confirmed: title?.plexMatch !== 'fuzzy',
          inMirror: true,
        }
      : null;
    if (mockPlex) {
      if (item && title?.plexMatch && title.plexMatch !== 'fuzzy') result.plexState = 'available';
    } else {
      result.plexState = plex.getAvailability({
        match,
        lastSuccessfulSyncAt: plex.lastSuccessfulSyncAt(),
        now: now(),
      });
    }
    return result;
  }
  function card(title: TitleRow): TitleCard {
    title = ensureExactMatch(title);
    const demo = title.tmdbId >= 9900001 && title.tmdbId <= 9900008;
    const offset = title.tmdbId - 9900001;
    const availability = mockPlex
      ? demo
        ? offset === 2 || offset === 3
          ? 'available'
          : offset === 5
            ? 'unknown'
            : 'unavailable'
        : title.tmdbId % 5 === 0
          ? 'available'
          : title.tmdbId % 5 === 4
            ? 'unknown'
            : 'unavailable'
      : 'unknown';
    const item =
      title.plexRatingKey &&
      (mockPlex || !title.plexRatingKey.startsWith('demo-')) &&
      title.plexMatch &&
      db.select().from(plexItems).where(eq(plexItems.ratingKey, title.plexRatingKey)).get();
    const liveAvailability = plex.getAvailability({
      match:
        item && title.plexMatch
          ? {
              ratingKey: item.ratingKey,
              source: title.plexMatch,
              confirmed: title.plexMatch !== 'fuzzy',
              inMirror: true,
            }
          : null,
      lastSuccessfulSyncAt: plex.lastSuccessfulSyncAt(),
      now: now(),
    });
    return state({
      tmdbId: title.tmdbId,
      mediaType: title.mediaType,
      title: title.title,
      year: title.year,
      releaseDate:
        title.mediaType === 'movie'
          ? (title.releaseDigital ?? title.releaseTheatrical ?? title.releasePhysical)
          : title.nextAirDate,
      posterPath: title.posterPath ?? (demo ? `/demo-${title.tmdbId}.svg` : null),
      backdropPath: title.backdropPath,
      tmdbScore: title.tmdbScore,
      certification: title.certification,
      runtimeMin: title.runtimeMin,
      seasonCount: null,
      colorHex: title.colorHex ?? '#263449',
      releaseState: title.releaseState,
      plexState: mockPlex
        ? item && title.plexMatch !== 'fuzzy'
          ? 'available'
          : availability
        : liveAvailability,
    });
  }
  function save(title: TitleDetail) {
    const values = {
      tmdbId: title.tmdbId,
      mediaType: title.mediaType,
      title: title.title,
      year: title.year,
      overview: title.overview,
      posterPath: title.posterPath,
      backdropPath: title.backdropPath,
      logoPath: title.logoPath,
      runtimeMin: title.runtimeMin,
      certification: title.certification,
      ratingLevel: title.certification ? (ratingLevels[title.certification] ?? null) : null,
      tmdbScore: title.tmdbScore,
      genres: title.genres,
      cast: title.cast,
      crew: title.crew,
      trailerKey: title.trailerKey,
      releaseTheatrical: title.releaseTheatrical,
      releaseDigital: title.releaseDigital,
      releasePhysical: title.releasePhysical,
      nextAirDate: title.nextAirDate,
      releaseState: title.releaseState,
      colorHex: title.colorHex,
    };
    db.insert(titles)
      .values(values)
      .onConflictDoUpdate({ target: [titles.tmdbId, titles.mediaType], set: values })
      .run();
    return row(title.mediaType, title.tmdbId)!;
  }
  async function permitted(
    type: MediaType,
    id: number,
    profile: ProfileRow,
    recheck?: () => ProfileRow,
  ) {
    const result =
      id >= 9900001 && id <= 9900008 && row(type, id)
        ? await preview.detail(type, id)
        : await catalog.detail(type, id);
    if (recheck) profile = recheck();
    if (!allowed(profile, result.title.certification))
      throw new ApiError(404, 'TITLE_NOT_FOUND', 'This title is unavailable for this profile.');
    const stored = save(result.title);
    const mirror = stored.plexRatingKey
      ? db.select().from(plexItems).where(eq(plexItems.ratingKey, stored.plexRatingKey)).get()
      : null;
    const decorated = {
      ...state(result.title),
      plexState: card(stored).plexState,
      resolution: mirror?.resolution ?? result.title.resolution,
      watchUrl: mirror ? plex.watchUrl(mirror.ratingKey) : null,
      seasons: result.title.seasons.map((season) => ({
        ...season,
        inPlex:
          mirror && stored.mediaType === 'tv'
            ? mirror.seasons.includes(season.number)
            : season.inPlex,
      })),
    };
    return { ...result, title: decorated, stored };
  }
  async function filterCards(items: TitleCard[], profile: ProfileRow): Promise<TitleCard[]> {
    const unique = [
      ...new Map(items.map((item) => [`${item.mediaType}:${item.tmdbId}`, item])).values(),
    ];
    const permittedCards = new Map<string, TitleCard>();
    let cursor = 0;
    let hydrated = 0;
    await Promise.all(
      Array.from({ length: Math.min(4, unique.length) }, async () => {
        while (cursor < unique.length) {
          const item = unique[cursor++]!;
          let result = item;
          if (profile.maxRatingLevel !== null && item.certification === null) {
            if (hydrated++ >= 20) continue;
            try {
              result = (await catalog.detail(item.mediaType, item.tmdbId)).title;
            } catch {
              continue;
            }
          }
          if (allowed(profile, result.certification))
            permittedCards.set(`${item.mediaType}:${item.tmdbId}`, state(result));
        }
      }),
    );
    return items.flatMap((item) => {
      const visible = permittedCards.get(`${item.mediaType}:${item.tmdbId}`);
      return visible ? [visible] : [];
    });
  }
  function findRequest(id: number, profile: ProfileRow) {
    const request = db.select().from(requests).where(eq(requests.id, id)).get();
    const title = request && db.select().from(titles).where(eq(titles.id, request.titleId)).get();
    if (!request || !title || !allowed(profile, title.certification))
      throw new ApiError(404, 'REQUEST_NOT_FOUND', 'This request is unavailable.');
    return { request, title };
  }
  function record(request: RequestRow, profile: ProfileRow, admin = false): RequestRecord {
    const title = db.select().from(titles).where(eq(titles.id, request.titleId)).get()!;
    const creator = db.select().from(profiles).where(eq(profiles.id, request.createdBy)).get()!;
    const supporters = db
      .select({ support: requestSupporters, profile: profiles })
      .from(requestSupporters)
      .innerJoin(profiles, eq(profiles.id, requestSupporters.profileId))
      .where(
        and(eq(requestSupporters.requestId, request.id), isNull(requestSupporters.withdrawnAt)),
      )
      .all()
      .map(({ support, profile: person }) => ({
        profileId: person.id,
        name: person.name,
        avatar: person.avatar,
        color: person.color,
        reason: support.reason as RequestReason | null,
        note: support.note,
        createdAt: support.createdAt,
      }));
    const events = db
      .select({ event: requestEvents, name: profiles.name })
      .from(requestEvents)
      .leftJoin(profiles, eq(profiles.id, requestEvents.actorProfileId))
      .where(eq(requestEvents.requestId, request.id))
      .all()
      .map(({ event, name }) => ({
        id: event.id,
        fromStatus: event.fromStatus,
        toStatus: event.toStatus,
        actorProfileId: event.actorProfileId,
        actorName: name,
        createdAt: event.createdAt,
      }));
    const automation = db
      .select({ approval: requestAutomation, decidedByName: profiles.name })
      .from(requestAutomation)
      .leftJoin(profiles, eq(profiles.id, requestAutomation.decidedBy))
      .where(eq(requestAutomation.requestId, request.id))
      .get();
    const scope = automation?.approval.approvedScope;
    const rental = database.sqlite
      .prepare(
        'SELECT duration_days durationDays,expires_at expiresAt,deleted_at deletedAt,last_error lastError FROM request_rentals WHERE request_id=?',
      )
      .get(request.id) as
      | { durationDays: number; expiresAt: string | null; deletedAt: string | null; lastError: string | null }
      | undefined;
    return {
      id: request.id,
      title: { ...card(title), requestStatus: request.status },
      createdBy: creator.id,
      createdByName: creator.name,
      status: request.status,
      reason: request.reason as RequestReason | null,
      note: request.note,
      seasons: request.seasons,
      ...(admin ? { adminNote: request.adminNote } : {}),
      createdAt: request.createdAt,
      updatedAt: request.updatedAt,
      availableAt: request.availableAt,
      watchedAt: request.watchedAt,
      supporters,
      events,
      activity: (
        database.sqlite
          .prepare(
            `SELECT e.id,e.action,p.name actorName,e.created_at createdAt FROM automation_events e LEFT JOIN profiles p ON p.id=e.actor_profile_id WHERE e.request_id=? ORDER BY e.id`,
          )
          .all(request.id) as {
          id: number;
          action: string;
          actorName: string | null;
          createdAt: string;
        }[]
      ).map((entry) => ({
        id: entry.id,
        actorName: entry.actorName,
        createdAt: entry.createdAt,
        label:
          (
            {
              approved: 'Approved',
              auto_approved: 'Automatically approved · daily movie allowance',
              declined: 'Declined',
              retry_queued: 'Retry queued',
              sent: 'Sent to download manager',
              failed: 'Submission failed',
              skipped: 'Submission skipped',
              dispatch_skipped: 'Submission skipped',
              'dispatch:SeriesSearch': 'Series search requested',
              'dispatch:SeasonSearch': 'Season search requested',
              rental_started: '7-day rental started',
              rental_upgraded: 'Kept permanently',
              rental_deleted: 'Rental expired · removed from library',
              rental_delete_failed: 'Rental cleanup needs attention',
            } as Record<string, string>
          )[entry.action] ?? 'Automation updated',
      })),
      isSupporter: supporters.some((support) => support.profileId === profile.id),
      automation: automation
        ? {
            decision: automation.approval.decision,
            decidedByName: automation.decidedByName,
            decidedAt: automation.approval.decidedAt,
            declineReason: automation.approval.declineReason,
            scopeLabel:
              title.mediaType === 'movie'
                ? 'Movie'
                : (scope ? scope.seasons : request.seasons) === null
                  ? 'Entire series, including future seasons'
                  : `Seasons ${(scope ? scope.seasons : request.seasons)!.join(', ')}`,
            service: automation.approval.service,
            submissionStatus: automation.approval.submissionStatus,
            externalId: automation.approval.externalId,
            lastError: automation.approval.lastError,
            attemptCount: automation.approval.attemptCount,
            submittedAt: automation.approval.submittedAt,
          }
        : null,
      rental: rental ?? null,
    };
  }
  function transition(request: RequestRow, status: RequestStatus, actor: number | null) {
    if (request.status === status) return;
    const time = now().toISOString();
    db.update(requests)
      .set({
        status,
        updatedAt: time,
        ...(status === 'available' ? { availableAt: time } : {}),
        ...(status === 'watched' ? { watchedAt: time } : {}),
        ...(status === 'requested' ? { watchedAt: null, availableAt: null } : {}),
      })
      .where(eq(requests.id, request.id))
      .run();
    // The invariant-enforcing trigger creates history; attribution is part of this same transaction.
    database.sqlite
      .prepare(
        'UPDATE request_events SET actor_profile_id = ? WHERE id = (SELECT MAX(id) FROM request_events WHERE request_id = ?)',
      )
      .run(actor, request.id);
  }
  function all(profile: ProfileRow, admin = false) {
    return db
      .select()
      .from(requests)
      .orderBy(desc(requests.id))
      .all()
      .filter((entry) => entry.status !== 'cancelled')
      .filter((entry) => {
        const title = db.select().from(titles).where(eq(titles.id, entry.titleId)).get();
        return title && allowed(profile, title.certification);
      })
      .map((entry) => record(entry, profile, admin));
  }
  return {
    card,
    row,
    state,
    permitted,
    findRequest,
    record,
    all,
    async home(profile: ProfileRow, type?: MediaType) {
      const result = await catalog.home(type);
      const cards = await filterCards(
        result.rows.flatMap((entry) => entry.items),
        profile,
      );
      const visible = new Map(cards.map((item) => [`${item.mediaType}:${item.tmdbId}`, item]));
      const rows = result.rows
        .map((entry) => ({
          ...entry,
          items: entry.items.flatMap((item) => {
            const title = visible.get(`${item.mediaType}:${item.tmdbId}`);
            return title ? [title] : [];
          }),
        }))
        .filter((entry) => entry.items.length);
      const favorites = database.sqlite
        .prepare(
          `SELECT t.id FROM titles t
           LEFT JOIN reactions r ON r.title_id=t.id AND r.value='up'
           LEFT JOIN request_supporters s ON s.request_id IN (SELECT id FROM requests WHERE title_id=t.id) AND s.withdrawn_at IS NULL
           GROUP BY t.id HAVING COUNT(DISTINCT r.id) + COUNT(DISTINCT s.id) > 0
           ORDER BY COUNT(DISTINCT r.id)*3 + COUNT(DISTINCT s.id)*2 DESC, t.id DESC LIMIT 20`,
        )
        .all() as { id: number }[];
      const favoriteCards = favorites
        .flatMap(({ id }) => {
          const title = db.select().from(titles).where(eq(titles.id, id)).get();
          return title &&
            allowed(profile, title.certification) &&
            (!type || title.mediaType === type)
            ? [card(title)]
            : [];
        })
        .filter((item) => item.plexState !== 'unknown');
      if (favoriteCards.length)
        rows.splice(Math.min(2, rows.length), 0, {
          id: 'family-favorites',
          title: 'Family Favorites',
          items: favoriteCards,
        });
      const liked = db
        .select({ reaction: reactions, title: titles })
        .from(reactions)
        .innerJoin(titles, eq(titles.id, reactions.titleId))
        .where(and(eq(reactions.profileId, profile.id), eq(reactions.value, 'up')))
        .orderBy(desc(reactions.updatedAt))
        .limit(2)
        .all();
      if (liked.length) {
        const recommendations = await Promise.all(
          liked.map(({ title }) => catalog.detail(title.mediaType, title.tmdbId).catch(() => null)),
        );
        const personalized = await filterCards(
          recommendations.flatMap((entry) => entry?.title.recommendations ?? []),
          profile,
        );
        const down = new Set(
          db
            .select({ titleId: reactions.titleId })
            .from(reactions)
            .where(and(eq(reactions.profileId, profile.id), eq(reactions.value, 'down')))
            .all()
            .map((entry) => entry.titleId),
        );
        const items = personalized.filter((item) => {
          const stored = row(item.mediaType, item.tmdbId);
          return !stored || !down.has(stored.id);
        });
        if (items.length)
          rows.splice(Math.min(3, rows.length), 0, {
            id: 'because-you-liked',
            title: `Because you liked ${liked.map(({ title }) => title.title).join(' and ')}`,
            items: items.slice(0, 20),
          });
      }
      return {
        ...result,
        rows,
      };
    },
    async discover(profile: ProfileRow, query: import('@reelrequest/shared').DiscoverQuery) {
      const result = await catalog.discover(query);
      const items = await filterCards(result.items, profile);
      return {
        ...result,
        items: items.filter((item) =>
          query.availability === 'ready'
            ? item.plexState === 'available'
            : query.availability === 'request'
              ? item.plexState === 'unavailable' && item.releaseState !== 'coming_soon'
              : true,
        ),
      };
    },
    async search(profile: ProfileRow, query: string) {
      const result = await catalog.search(query);
      return {
        ...result,
        items: await filterCards(result.items, profile),
        person: result.person
          ? { ...result.person, knownFor: await filterCards(result.person.knownFor, profile) }
          : null,
      };
    },
    async detail(profile: ProfileRow, type: MediaType, id: number, admin: boolean) {
      const result = await permitted(type, id, profile);
      const request = currentRequest(result.stored.id);
      const { stored, ...response } = result;
      return {
        ...response,
        title: {
          ...response.title,
          recommendations: await filterCards(response.title.recommendations, profile),
        },
        request: request ? record(request, profile, admin) : null,
        inMyList: Boolean(
          db
            .select()
            .from(listItems)
            .where(and(eq(listItems.profileId, profile.id), eq(listItems.titleId, stored.id)))
            .get(),
        ),
        reaction:
          db
            .select({ value: reactions.value })
            .from(reactions)
            .where(and(eq(reactions.profileId, profile.id), eq(reactions.titleId, stored.id)))
            .get()?.value ?? null,
      };
    },
    async create(
      profile: ProfileRow,
      input: {
        mediaType: MediaType;
        tmdbId: number;
        seasons?: number[] | null | undefined;
        rent?: boolean | undefined;
      },
      recheck?: () => ProfileRow,
    ) {
      const detail = await permitted(input.mediaType, input.tmdbId, profile, recheck);
      if (detail.title.plexState !== 'unavailable')
        throw new ApiError(
          409,
          'NOT_REQUESTABLE',
          detail.title.plexState === 'available'
            ? 'This title is already available in Plex.'
            : 'Plex availability must be confirmed before requesting.',
        );
      if (
        input.seasons &&
        input.seasons.some(
          (season) => !detail.title.seasons.some((available) => available.number === season),
        )
      )
        throw new ApiError(400, 'INVALID_SEASONS', 'Choose seasons listed for this show.');
      const result = db.transaction(() => {
        const existing = db
          .select()
          .from(requests)
          .where(eq(requests.titleId, detail.stored.id))
          .all()
          .find((entry) => openRequestStatuses.includes(entry.status));
        const time = now().toISOString();
        if (existing) {
          db.insert(requestSupporters)
            .values({ requestId: existing.id, profileId: profile.id, createdAt: time })
            .onConflictDoUpdate({
              target: [requestSupporters.requestId, requestSupporters.profileId],
              set: { withdrawnAt: null },
            })
            .run();
          const seasons =
            existing.seasons === null || input.seasons == null
              ? null
              : [...new Set([...existing.seasons, ...input.seasons])].sort((a, b) => a - b);
          db.update(requests)
            .set({ seasons, updatedAt: time })
            .where(eq(requests.id, existing.id))
            .run();
          if (!input.rent) {
            const removed = database.sqlite
              .prepare('DELETE FROM request_rentals WHERE request_id=? AND deleted_at IS NULL')
              .run(existing.id);
            if (removed.changes)
              database.sqlite
                .prepare(
                  'INSERT INTO automation_events(request_id,actor_profile_id,action,detail,created_at) VALUES(?,?,?,?,?)',
                )
                .run(existing.id, profile.id, 'rental_upgraded', 'A permanent request superseded the rental.', time);
          }
          return { id: existing.id, existing: true, creator: existing.createdBy };
        }
        // Decision and allowance are checked inside the same write transaction as creation.
        const autoApproved = requestsCreatedToday(profile.id, new Date(time)) < 10;
        const service = detail.stored.mediaType === 'movie' ? 'radarr' : 'sonarr';
        const serviceEnabled = Boolean(database.sqlite.prepare(
          'SELECT enabled FROM automation_services WHERE service=?',
        ).pluck().get(service));
        const id = db
          .insert(requests)
          .values({
            titleId: detail.stored.id,
            createdBy: profile.id,
            status: 'requested',
            seasons: input.seasons ?? null,
            createdAt: time,
            updatedAt: time,
          })
          .returning({ id: requests.id })
          .get()!.id;
        db.insert(requestAutomation)
          .values({
            requestId: id,
            service,
            decision: autoApproved ? 'approved' : 'pending',
            decidedAt: autoApproved ? time : null,
            approvedScope: autoApproved ? { seasons: input.seasons ?? null } : null,
            submissionStatus: autoApproved && serviceEnabled ? 'queued' : 'not_submitted',
            updatedAt: time,
          })
          .run();
        if (input.rent)
          database.sqlite
            .prepare(
              'INSERT INTO request_rentals(request_id,duration_days,updated_at,created_at) VALUES(?,7,?,?)',
            )
            .run(id, time, time);
        if (autoApproved) database.sqlite.prepare(
          'INSERT INTO automation_events(request_id,actor_profile_id,action,detail,created_at) VALUES(?,NULL,?,?,?)',
        ).run(id, 'auto_approved', 'First 10 new requests per profile per America/Chicago calendar day', time);
        return { id, existing: false, creator: profile.id };
      });
      const admins = db
        .select({ id: profiles.id })
        .from(profiles)
        .where(and(eq(profiles.isAdmin, true), eq(profiles.disabled, false)))
        .all()
        .map((entry) => entry.id);
      const recipients = result.existing
        ? [...admins, result.creator].filter((profileId) => profileId !== profile.id)
        : admins.filter((profileId) => profileId !== profile.id);
      notificationService?.notify(recipients, {
        kind: result.existing ? 'request_supported' : 'request_created',
        body: result.existing
          ? `${profile.name} also wants ${detail.title.title}.`
          : `${profile.name} requested ${detail.title.title}.`,
        requestId: result.id,
        titleId: detail.stored.id,
      });
      emit('requests');
      emit('notifications');
      return record(findRequest(result.id, profile).request, profile);
    },
    support(
      profile: ProfileRow,
      id: number,
      patch: { reason?: RequestReason | null | undefined; note?: string | null | undefined },
    ) {
      const { request } = findRequest(id, profile);
      const support = db
        .select()
        .from(requestSupporters)
        .where(
          and(
            eq(requestSupporters.requestId, id),
            eq(requestSupporters.profileId, profile.id),
            isNull(requestSupporters.withdrawnAt),
          ),
        )
        .get();
      if (!support)
        throw new ApiError(403, 'SUPPORT_REQUIRED', 'Only your own active support can be edited.');
      db.transaction(() => {
        db.update(requestSupporters).set(patch).where(eq(requestSupporters.id, support.id)).run();
        if (request.createdBy === profile.id)
          db.update(requests)
            .set({ ...patch, updatedAt: now().toISOString() })
            .where(eq(requests.id, id))
            .run();
      });
      emit('requests');
      return record(findRequest(id, profile).request, profile);
    },
    withdraw(profile: ProfileRow, id: number) {
      db.transaction(() => {
        const { request } = findRequest(id, profile);
        if (request.status !== 'requested')
          throw new ApiError(
            409,
            'INVALID_STATUS',
            'Only requests still marked Requested can be withdrawn.',
          );
        const changed = db
          .update(requestSupporters)
          .set({ withdrawnAt: now().toISOString() })
          .where(
            and(
              eq(requestSupporters.requestId, id),
              eq(requestSupporters.profileId, profile.id),
              isNull(requestSupporters.withdrawnAt),
            ),
          )
          .returning()
          .all();
        if (!changed.length)
          throw new ApiError(403, 'SUPPORT_REQUIRED', 'You are not supporting this request.');
        if (
          !db
            .select()
            .from(requestSupporters)
            .where(and(eq(requestSupporters.requestId, id), isNull(requestSupporters.withdrawnAt)))
            .get()
        )
          transition(request, 'cancelled', null);
      });
      emit('requests');
      return record(findRequest(id, profile).request, profile);
    },
    watched(profile: ProfileRow, id: number, admin: boolean) {
      db.transaction(() => {
        const { request } = findRequest(id, profile);
        const support = db
          .select()
          .from(requestSupporters)
          .where(
            and(
              eq(requestSupporters.requestId, id),
              eq(requestSupporters.profileId, profile.id),
              isNull(requestSupporters.withdrawnAt),
            ),
          )
          .get();
        if (!admin && !support)
          throw new ApiError(
            403,
            'SUPPORT_REQUIRED',
            'Only a supporter or an unlocked admin can mark this watched.',
          );
        if (request.status !== 'available')
          throw new ApiError(
            409,
            'INVALID_STATUS',
            'Only available requests can be marked watched.',
          );
        transition(request, 'watched', profile.id);
      });
      emit('requests');
      return record(findRequest(id, profile).request, profile, admin);
    },
    adminPatch(
      profile: ProfileRow,
      id: number,
      patch: {
        status?: RequestStatus | undefined;
        adminNote?: string | null | undefined;
        plexRatingKey?: string | undefined;
      },
    ) {
      let changedStatus: RequestStatus | undefined;
      let notificationTitle = '';
      let notificationTitleId: number | null = null;
      let supporterIds: number[] = [];
      db.transaction(() => {
        const { request, title } = findRequest(id, profile);
        notificationTitle = title.title;
        notificationTitleId = title.id;
        if (patch.plexRatingKey) {
          const item = db
            .select()
            .from(plexItems)
            .where(eq(plexItems.ratingKey, patch.plexRatingKey))
            .get();
          if (!item || item.mediaType !== title.mediaType)
            throw new ApiError(
              400,
              'INVALID_PLEX_ITEM',
              'Choose an existing Plex item with the same media type.',
            );
          db.update(titles)
            .set({ plexRatingKey: item.ratingKey, plexMatch: 'manual' })
            .where(eq(titles.id, title.id))
            .run();
        }
        if (patch.status && patch.status !== request.status) {
          const transitions: Record<RequestStatus, RequestStatus[]> = {
            requested: ['looking', 'available', 'passed'],
            looking: ['available', 'passed'],
            available: ['watched'],
            watched: ['requested'],
            passed: ['requested'],
            cancelled: ['requested'],
          };
          if (!transitions[request.status].includes(patch.status))
            throw new ApiError(409, 'INVALID_STATUS', 'That status change is not allowed.');
          if (
            patch.status === 'available' &&
            !patch.plexRatingKey &&
            card(title).plexState !== 'available'
          )
            throw new ApiError(
              409,
              'PLEX_MATCH_REQUIRED',
              'Match a Plex item before marking this available.',
            );
          if (patch.status === 'requested') {
            const other = db
              .select()
              .from(requests)
              .where(eq(requests.titleId, title.id))
              .all()
              .find((entry) => entry.id !== id && openRequestStatuses.includes(entry.status));
            if (other)
              throw new ApiError(
                409,
                'OPEN_REQUEST_EXISTS',
                'This title already has an open request.',
              );
            if (
              !db
                .select()
                .from(requestSupporters)
                .where(
                  and(eq(requestSupporters.requestId, id), isNull(requestSupporters.withdrawnAt)),
                )
                .get()
            )
              db.update(requestSupporters)
                .set({ withdrawnAt: null })
                .where(
                  and(
                    eq(requestSupporters.requestId, id),
                    eq(requestSupporters.profileId, request.createdBy),
                  ),
                )
                .run();
          }
          transition(request, patch.status, profile.id);
          changedStatus = patch.status;
          supporterIds = db
            .select({ profileId: requestSupporters.profileId })
            .from(requestSupporters)
            .where(and(eq(requestSupporters.requestId, id), isNull(requestSupporters.withdrawnAt)))
            .all()
            .map((entry) => entry.profileId)
            .filter((profileId) => profileId !== profile.id);
        }
        if (patch.adminNote !== undefined)
          db.update(requests)
            .set({ adminNote: patch.adminNote, updatedAt: now().toISOString() })
            .where(eq(requests.id, id))
            .run();
      });
      if (changedStatus && ['looking', 'available', 'passed'].includes(changedStatus)) {
        const phrase =
          changedStatus === 'looking'
            ? `${profile.name} is looking for ${notificationTitle}.`
            : changedStatus === 'available'
              ? `${notificationTitle} is in Plex. Watch now.`
              : `${profile.name} passed on ${notificationTitle}.`;
        notificationService?.notify(supporterIds, {
          kind: `request_${changedStatus}`,
          body: phrase,
          requestId: id,
          titleId: notificationTitleId,
        });
        emit('notifications');
      }
      emit('requests');
      return record(findRequest(id, profile).request, profile, true);
    },
    list(profile: ProfileRow) {
      return db
        .select({ title: titles })
        .from(listItems)
        .innerJoin(titles, eq(titles.id, listItems.titleId))
        .where(eq(listItems.profileId, profile.id))
        .orderBy(desc(listItems.id))
        .all()
        .filter(({ title }) => allowed(profile, title.certification))
        .map(({ title }) => card(title));
    },
    async library(profile: ProfileRow, sectionIds?: string[]) {
      const included = new Set(plex.includedSections());
      const mirror = db
        .select()
        .from(plexItems)
        .all()
        .filter(
          (item) =>
            (!included.size || included.has(item.sectionId)) &&
            (!sectionIds || sectionIds.includes(item.sectionId)),
        );
      const missing = mirror
        .filter(
          (item) =>
            item.tmdbId &&
            !db
              .select()
              .from(titles)
              .where(and(eq(titles.tmdbId, item.tmdbId), eq(titles.mediaType, item.mediaType)))
              .get(),
        )
        .sort((a, b) => (b.addedAt ?? '').localeCompare(a.addedAt ?? ''))
        .slice(0, 20);
      let cursor = 0;
      await Promise.all(
        Array.from({ length: Math.min(4, missing.length || 1) }, async () => {
          while (cursor < missing.length) {
            const item = missing[cursor++]!;
            try {
              const detail = await catalog.detail(item.mediaType, item.tmdbId!);
              const stored = save(detail.title);
              db.update(titles)
                .set({ plexRatingKey: item.ratingKey, plexMatch: 'tmdb' })
                .where(eq(titles.id, stored.id))
                .run();
            } catch {
              // Items without usable TMDB metadata remain in the mirror and can be matched manually.
            }
          }
        }),
      );
      const entries: LibraryEntry[] = [];
      for (const item of mirror) {
        if (!item.tmdbId) continue;
        const title = db
          .select()
          .from(titles)
          .where(and(eq(titles.tmdbId, item.tmdbId), eq(titles.mediaType, item.mediaType)))
          .get();
        if (!title) {
          if (profile.maxRatingLevel !== null) continue;
          entries.push({
            title: null,
            item,
            card: {
              tmdbId: item.tmdbId,
              mediaType: item.mediaType,
              title: item.title,
              year: item.year,
              releaseDate: null,
              posterPath: null,
              backdropPath: null,
              tmdbScore: null,
              certification: null,
              runtimeMin: null,
              seasonCount: item.mediaType === 'tv' ? item.seasons.length : null,
              colorHex: '#263449',
              releaseState: 'unknown' as const,
              plexState: 'available' as const,
            },
          });
          continue;
        }
        if (!allowed(profile, title.certification)) continue;
        if (title.plexRatingKey !== item.ratingKey && title.plexMatch !== 'manual') {
          db.update(titles)
            .set({ plexRatingKey: item.ratingKey, plexMatch: 'tmdb' })
            .where(eq(titles.id, title.id))
            .run();
          title.plexRatingKey = item.ratingKey;
          title.plexMatch = 'tmdb';
        }
        entries.push({ title, item, card: card(title) });
      }
      return entries;
    },
    async bookmark(
      profile: ProfileRow,
      type: MediaType,
      id: number,
      add: boolean,
      recheck?: () => ProfileRow,
    ) {
      const result = await permitted(type, id, profile, recheck);
      if (add)
        db.insert(listItems)
          .values({ profileId: profile.id, titleId: result.stored.id })
          .onConflictDoNothing()
          .run();
      else
        db.delete(listItems)
          .where(and(eq(listItems.profileId, profile.id), eq(listItems.titleId, result.stored.id)))
          .run();
      emit('list');
    },
  };
}

