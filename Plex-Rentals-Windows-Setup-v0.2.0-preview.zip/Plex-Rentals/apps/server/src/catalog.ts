import type {
  MediaType,
  TitleCard,
  TitleDetail,
  HomeResponse,
  DetailResponse,
  DiscoverQuery,
} from '@reelrequest/shared';
import { demoTitles } from './db/fixtures.js';
import type { AppDatabase } from './db/client.js';
import { createTmdbCatalog, CatalogError } from './integrations/tmdb/index.js';

export interface CatalogOptions {
  token?: string;
  plexUrl?: string;
  region?: string;
  language?: string;
  fetch?: typeof fetch;
}

const colors = [
  '#9A5933',
  '#275F68',
  '#394D85',
  '#A87842',
  '#685185',
  '#456C55',
  '#256786',
  '#825143',
];
const synopses = [
  'When a forgotten film arrives at a small-town cinema, its last projectionist follows a trail of clues through the places and people he thought he knew. An invented story about memory, friendship, and the magic of movie night.',
  'A restless musician returns to her coastal hometown after a storm, where an unexpected friendship gives her a reason to stay. An invented story about finding a new beginning.',
  'Far above Earth, two astronauts discover that the smallest signal can carry the biggest hope. An invented space adventure for this family movie preview.',
  'Four neighbors turn an ordinary summer into an unforgettable adventure when they decide to save their beloved neighborhood theater. An invented family comedy.',
  'A radio engineer hears a broadcast from tomorrow, and must decide which future is worth chasing. An invented mystery about the choices that connect us.',
  'A cartographer and her young apprentice set out to chart an island that appears on no map. An invented adventure through an extraordinary wilderness.',
  'At the edge of a quiet ocean, a young explorer follows a distant light toward an undiscovered world. An invented upcoming adventure.',
  'Every night at eleven thirty, a different traveler arrives at the last station on the line. An invented television mystery told across six episodes.',
];

export function demoCard(offset: number): TitleCard {
  const fixture = demoTitles[offset]!;
  return {
    tmdbId: 9900001 + offset,
    mediaType: offset === 7 ? 'tv' : 'movie',
    title: fixture.title,
    year: 2026,
    releaseDate: fixture.release === 'coming_soon' ? '2027-01-15' : '2026-06-01',
    posterPath: `/demo-${9900001 + offset}.svg`,
    backdropPath: `/demo-backdrop-${9900001 + offset}.svg`,
    tmdbScore: null,
    certification: ['PG-13', 'PG', 'PG', 'G', 'R', null, 'PG', 'TV-14'][offset] ?? null,
    runtimeMin: offset === 7 ? null : 105 + offset * 7,
    seasonCount: offset === 7 ? 1 : null,
    colorHex: colors[offset]!,
    releaseState: fixture.release,
    plexState:
      offset === 2 || offset === 3 ? 'available' : offset === 5 ? 'unknown' : 'unavailable',
  };
}

function demoDetail(offset: number): TitleDetail {
  const card = demoCard(offset);
  return {
    ...card,
    overview: synopses[offset]!,
    logoPath: null,
    genres: [
      { id: 12, name: offset === 2 || offset === 7 ? 'Science Fiction' : 'Adventure' },
      { id: 18, name: 'Drama' },
    ],
    cast: [],
    crew: [],
    trailerKey: null,
    releaseTheatrical: card.releaseState === 'released' ? '2026-06-01' : null,
    releaseDigital:
      card.releaseState === 'released'
        ? '2026-08-01'
        : card.releaseState === 'coming_soon'
          ? '2027-01-15'
          : null,
    releasePhysical: null,
    nextAirDate: null,
    seasons:
      card.mediaType === 'tv'
        ? [{ number: 1, name: 'Season 1', episodeCount: 6, airDate: null, inPlex: null }]
        : [],
    recommendations: demoTitles
      .map((_, index) => demoCard(index))
      .filter((item) => item.tmdbId !== card.tmdbId)
      .slice(0, 6),
    resolution: card.plexState === 'available' ? (offset === 2 ? '4K' : '1080p') : null,
    watchUrl: null,
  };
}

/** Mock status is an explicit Phase 1 presentation fixture, never live library evidence. */
function decorate<T extends TitleCard>(item: T, mock: boolean, demo: boolean): T {
  if (!mock) {
    const rest = { ...item };
    delete rest.requestStatus;
    return {
      ...rest,
      plexState: 'unknown',
      ...('resolution' in item ? { resolution: null, watchUrl: null } : {}),
    } as T;
  }
  if (demo) return item;
  const sample = item.tmdbId % 5;
  return {
    ...item,
    plexState: sample === 0 ? 'available' : sample === 4 ? 'unknown' : 'unavailable',
  };
}

export function createCatalog(database: AppDatabase, options: CatalogOptions = {}) {
  const token = options.token?.trim() ?? '';
  const demo = !token;
  const mock = !options.plexUrl?.trim();
  const live = demo
    ? null
    : createTmdbCatalog(database, {
        token,
        ...(options.region ? { region: options.region } : {}),
        ...(options.language ? { language: options.language } : {}),
        ...(options.fetch ? { fetch: options.fetch } : {}),
      });
  function meta(stale: boolean) {
    return {
      mode: demo ? ('demo' as const) : ('live' as const),
      plexMode: mock ? ('mock' as const) : ('configured' as const),
      stale,
      notice: [
        demo
          ? 'Preview catalog: invented titles and original sample artwork. Add a TMDB token on the server for real movies and trailers.'
          : null,
        mock
          ? 'Plex availability is simulated for this preview. Request activity is saved for your family.'
          : 'Plex availability is checked against the family library mirror.',
        stale ? 'Showing saved metadata while TMDB is unavailable.' : null,
      ]
        .filter(Boolean)
        .join(' '),
    };
  }
  return {
    async discover(query: DiscoverQuery) {
      if (live) return live.discover(query);
      return {
        items:
          query.page === 1
            ? demoTitles
                .map((_, index) => demoCard(index))
                .filter((item) => item.mediaType === 'movie')
            : [],
        nextPage: null,
        stale: false,
      };
    },

    async search(query: string) {
      if (live) {
        const result = await live.search(query);
        return {
          ...result,
          items: result.items.map((item) => decorate(item, mock, false)),
          person: result.person
            ? {
                ...result.person,
                knownFor: result.person.knownFor.map((item) => decorate(item, mock, false)),
              }
            : null,
        };
      }
      const value = query.toLocaleLowerCase();
      return {
        items: demoTitles
          .map((_, index) => decorate(demoCard(index), mock, true))
          .filter((item) => item.title.toLocaleLowerCase().includes(value)),
        person: null,
        stale: false,
      };
    },
    async home(type?: MediaType): Promise<HomeResponse> {
      if (live) {
        const result = await live.home(type);
        const rows = result.rows.map((row) => ({
          ...row,
          items: row.items.map((item) => decorate(item, mock, false)),
        }));
        const unique = (items: TitleCard[]) =>
          [
            ...new Map(items.map((item) => [`${item.mediaType}:${item.tmdbId}`, item])).values(),
          ].slice(0, 20);
        return {
          ...meta(result.stale),
          rows: [
            {
              id: 'available',
              title: 'Available in Plex',
              items: unique(
                rows.flatMap((row) => row.items).filter((item) => item.plexState === 'available'),
              ),
            },
            {
              id: 'trending',
              title: 'Tonight’s Picks',
              items: unique(
                rows.filter((row) => row.id.startsWith('trending')).flatMap((row) => row.items),
              ),
            },
            {
              id: 'new',
              title: 'New & Relevant',
              items: unique(
                rows
                  .filter((row) => row.id === 'now-playing' || row.id === 'on-the-air')
                  .flatMap((row) => row.items),
              ),
            },
            {
              id: 'coming-soon',
              title: 'Coming Soon',
              items: rows.find((row) => row.id === 'upcoming')?.items ?? [],
            },
            ...rows.filter((row) =>
              [
                'popular-movies',
                'hidden-gems',
                'under-100',
                'popular-tv',
                'top-rated-movies',
                'action-movies',
                'comedy-movies',
                'science-fiction-movies',
                'family-movies',
                'animated-movies',
                'thriller-movies',
                'documentary-movies',
                'classic-movies',
                'critically-acclaimed-movies',
                'netflix',
                'hulu',
                'apple-tv',
                'disney-plus',
                'anime-movies',
                'anime-series',
                'anime-trending',
                'anime-new',
                'anime-favorites',
                'anime-action',
                'anime-scifi',
                'anime-fantasy',
              ].includes(row.id),
            ),
          ].filter((row) => row.items.length > 0),
        };
      }
      const items = demoTitles
        .map((_, index) => decorate(demoCard(index), mock, true))
        .filter((item) => !type || item.mediaType === type);
      return {
        ...meta(false),
        rows: [
          {
            id: 'available',
            title: 'Available in Plex',
            items: items.filter((item) => item.plexState === 'available'),
          },
          { id: 'trending', title: 'Trending Tonight', items },
          { id: 'new', title: 'New & Relevant', items: [...items].reverse() },
          {
            id: 'coming-soon',
            title: 'Coming Soon',
            items: items.filter((item) => item.releaseState === 'coming_soon'),
          },
          {
            id: 'popular-movies',
            title: 'Popular movies',
            items: items.filter((item) => item.mediaType === 'movie'),
          },
        ].filter((row) => row.items.length > 0),
      };
    },
    async detail(type: MediaType, id: number): Promise<DetailResponse> {
      if (live) {
        const result = await live.detail(type, id);
        const title = decorate(result.title, mock, false);
        return {
          ...meta(result.stale),
          title: {
            ...title,
            recommendations: title.recommendations.map((item) => decorate(item, mock, false)),
          },
        };
      }
      const offset = id - 9900001;
      if (offset < 0 || offset >= demoTitles.length || demoCard(offset).mediaType !== type) {
        throw new CatalogError(404, 'TITLE_NOT_FOUND', 'This title is not in the preview catalog.');
      }
      const title = decorate(demoDetail(offset), mock, true);
      return {
        ...meta(false),
        title: {
          ...title,
          recommendations: title.recommendations.map((item) => decorate(item, mock, true)),
        },
      };
    },
    async refreshDetail(type: MediaType, id: number): Promise<DetailResponse> {
      if (!live) return this.detail(type, id);
      const result = await live.refreshDetail(type, id);
      const title = decorate(result.title, mock, false);
      return {
        ...meta(result.stale),
        title: {
          ...title,
          recommendations: title.recommendations.map((item) => decorate(item, mock, false)),
        },
      };
    },
  };
}

/** Local vector art for fictional fixtures. Never presented as TMDB imagery. */
export function demoArtwork(filename: string): string | null {
  const match = /^demo-(backdrop-)?(990000[1-8])\.svg$/.exec(filename);
  if (!match) return null;
  const index = Number(match[2]) - 9900001;
  const title = demoTitles[index]!.title;
  const wide = Boolean(match[1]);
  const width = wide ? 1280 : 500;
  const height = wide ? 720 : 750;
  const words = title.split(' ');
  const first = words
    .slice(0, Math.ceil(words.length / 2))
    .join(' ')
    .toUpperCase();
  const second = words
    .slice(Math.ceil(words.length / 2))
    .join(' ')
    .toUpperCase();
  const color = colors[index]!;
  const art =
    index === 2 || index === 4 || index === 7
      ? '<ellipse cx="280" cy="265" rx="190" ry="50" fill="none" stroke="#b9cfee" stroke-width="2" transform="rotate(-28 280 265)"/><circle cx="280" cy="265" r="98" fill="url(#orb)"/><path d="M210 585L244 450L274 442L308 585Z" fill="#0b101c"/><circle cx="260" cy="425" r="18" fill="#0b101c"/>'
      : '<path d="M0 510L155 248L245 390L335 225L500 480V750H0Z" fill="#172d37"/><path d="M0 585L110 420L212 512L360 375L500 520V750H0Z" fill="#0c1d29"/><path d="M0 660Q250 565 500 635V750H0Z" fill="#070f18"/><path d="M239 605L247 553L264 553L275 605Z" fill="#e5c08a"/><circle cx="255" cy="543" r="10" fill="#e5c08a"/>';
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 500 750" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="sky" x2="0.3" y2="1"><stop stop-color="#060e19"/><stop offset="0.55" stop-color="${color}"/><stop offset="1" stop-color="#040811"/></linearGradient><radialGradient id="orb"><stop stop-color="#f9e7b7"/><stop offset="0.65" stop-color="${color}"/><stop offset="1" stop-color="#172131"/></radialGradient><linearGradient id="shade" x2="0" y2="1"><stop offset="0.6" stop-color="#030710" stop-opacity="0"/><stop offset="1" stop-color="#030710"/></linearGradient></defs><rect width="500" height="750" fill="url(#sky)"/><g fill="#fff" opacity=".5"><circle cx="60" cy="90" r="1.5"/><circle cx="362" cy="115" r="2"/><circle cx="175" cy="140" r="1"/><circle cx="417" cy="220" r="1.5"/><circle cx="83" cy="320" r="1"/></g><circle cx="260" cy="270" r="110" fill="#ffc77b" opacity=".18"/>${art}<rect width="500" height="750" fill="url(#shade)"/>${wide ? '' : `<g text-anchor="middle" fill="#fff" font-family="Georgia,serif"><text x="250" y="650" font-size="30" letter-spacing="3">${first}</text><text x="250" y="691" font-size="32" letter-spacing="2">${second}</text><text x="250" y="725" font-family="sans-serif" font-size="9" letter-spacing="4" fill="#d3bf9b">PLEX RENTALS · PREVIEW COLLECTION</text></g>`}</svg>`;
}
