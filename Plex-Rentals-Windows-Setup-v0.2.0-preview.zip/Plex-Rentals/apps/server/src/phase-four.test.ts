import { describe, expect, it } from 'vitest';
import { eq } from 'drizzle-orm';
import { migrateDatabase, openDatabase } from './db/client.js';
import { notifications, profiles, requests, settings, titles } from './db/schema.js';
import { createNotificationService } from './notifications.js';
import { runReleaseWatcher } from './phase-four.js';
import type { createCatalog } from './catalog.js';

describe('Phase 4 notifications and release watcher', () => {
  it('creates one inbox item per unique recipient', () => {
    const database = openDatabase(':memory:');
    migrateDatabase(database);
    try {
      const first = database.db
        .insert(profiles)
        .values({ name: 'Andy', avatar: 'preset:director', color: '#F7A823', isAdmin: true })
        .returning()
        .get()!;
      const second = database.db
        .insert(profiles)
        .values({ name: 'Emma', avatar: 'preset:artist', color: '#123456' })
        .returning()
        .get()!;
      const service = createNotificationService(database);
      service.notify([first.id, first.id, second.id], {
        kind: 'request_created',
        body: 'A title was requested.',
      });
      expect(database.db.select().from(notifications).all()).toHaveLength(2);
      service.markRead(first.id);
      expect(
        database.db.select().from(notifications).where(eq(notifications.profileId, first.id)).get()
          ?.readAt,
      ).not.toBeNull();
      expect(
        database.db.select().from(notifications).where(eq(notifications.profileId, second.id)).get()
          ?.readAt,
      ).toBeNull();
    } finally {
      database.close();
    }
  });

  it('records newly released requested titles without changing request status', async () => {
    const database = openDatabase(':memory:');
    migrateDatabase(database);
    try {
      const profile = database.db
        .insert(profiles)
        .values({ name: 'Andy', avatar: 'preset:director', color: '#F7A823', isAdmin: true })
        .returning()
        .get()!;
      const title = database.db
        .insert(titles)
        .values({ tmdbId: 10, mediaType: 'movie', title: 'Tomorrow', releaseState: 'coming_soon' })
        .returning()
        .get()!;
      database.db
        .insert(requests)
        .values({
          titleId: title.id,
          createdBy: profile.id,
          status: 'requested',
          updatedAt: '2026-09-24T00:00:00.000Z',
        })
        .run();
      const catalog = {
        refreshDetail: async () => ({ title: { releaseState: 'released' } }),
      } as unknown as ReturnType<typeof createCatalog>;
      const count = await runReleaseWatcher(database, catalog, createNotificationService(database));
      expect(count).toBe(1);
      expect(database.db.select().from(requests).get()?.status).toBe('requested');
      expect(
        JSON.parse(
          database.db
            .select()
            .from(settings)
            .where(eq(settings.key, 'phase4_released_this_week'))
            .get()!.value,
        ),
      ).toEqual([title.id]);
    } finally {
      database.close();
    }
  });

  it('refreshes Coming Soon rows even when nobody has requested them', async () => {
    const database = openDatabase(':memory:');
    migrateDatabase(database);
    try {
      const title = database.db
        .insert(titles)
        .values({ tmdbId: 11, mediaType: 'movie', title: 'Soon', releaseState: 'coming_soon' })
        .returning()
        .get()!;
      const refreshed: number[] = [];
      const catalog = {
        refreshDetail: async (_mediaType: string, tmdbId: number) => {
          refreshed.push(tmdbId);
          return { title: { releaseState: 'released' } };
        },
      } as unknown as ReturnType<typeof createCatalog>;
      expect(await runReleaseWatcher(database, catalog, createNotificationService(database))).toBe(
        1,
      );
      expect(refreshed).toEqual([title.tmdbId]);
    } finally {
      database.close();
    }
  });
});
