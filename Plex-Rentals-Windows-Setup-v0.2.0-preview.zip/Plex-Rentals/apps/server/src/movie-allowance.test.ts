import request from 'supertest';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { createApp } from './app.js';
import { migrateDatabase, openDatabase, type AppDatabase } from './db/client.js';
import { seedDatabase } from './db/fixtures.js';

let database: AppDatabase;
let clock: Date;
const auth = {
  householdPasscode: 'allowance-household',
  sessionSecret: 'allowance-test-session-secret-at-least-thirty-two-characters',
  adminPin: '1234',
  baseUrl: 'http://localhost:8080',
  now: () => clock,
};
beforeEach(() => {
  clock = new Date('2028-09-29T04:59:00Z');
  database = openDatabase(':memory:');
  migrateDatabase(database);
  seedDatabase(database);
});
afterEach(() => database.close());

async function fixture() {
  let calls = 0;
  const app = createApp(database, { auth, plexUrl: '', catalog: { token: '' },
    automationFetch: async () => { calls++; return Response.json([]); },
  });
  const original = await app.locals.catalog.detail('movie', 9900001);
  app.locals.catalog.detail = async (mediaType: string, tmdbId: number) => ({
    ...original, stale: false,
    title: { ...original.title, mediaType, tmdbId, title: `Allowance title ${tmdbId}`,
      releaseDigital: '2029-01-01', releaseState: 'coming_soon', seasons: [], },
  });
  async function login(profileId = 2, unlock = false) {
    const agent = request.agent(app);
    await agent.post('/api/household/join').send({ passcode: auth.householdPasscode }).expect(200);
    await agent.post('/api/session').send({ profileId, ...(profileId === 1 ? { pin: '1234' } : {}) }).expect(200);
    if (unlock) await agent.post('/api/admin/unlock').send({ pin: '1234' }).expect(200);
    return agent;
  }
  return { app, login, calls: () => calls };
}
const movie = (index: number) => ({ mediaType: 'movie', tmdbId: 1101 + index * 5 });

describe('Daily request self-approval', () => {
  it('approves ten new titles across movies and TV, keeps the eleventh pending, and isolates profile allowances', async () => {
    const { login } = await fixture();
    const member = await login();
    for (let i = 0; i < 9; i++) {
      const response = await member.post('/api/requests').send(movie(i)).expect(201);
      expect(response.body.request.automation).toMatchObject({decision: 'approved', decidedByName: null, submissionStatus: 'not_submitted'});
      expect(response.body.request.activity.at(-1).label).toContain('Automatically approved');
    }
    const tv = await member.post('/api/requests').send({ mediaType: 'tv', tmdbId: 2201 }).expect(201);
    expect(tv.body.request.automation).toMatchObject({ decision: 'approved', service: 'sonarr' });
    const limited = await member.post('/api/requests').send(movie(10)).expect(201);
    expect(limited.body.request.automation.decision).toBe('pending');
    const admin = await login(1, true);
    const separate = await admin.post('/api/requests').send(movie(11)).expect(201);
    expect(separate.body.request.automation.decision).toBe('approved');
    await admin.post(`/api/admin/requests/${limited.body.request.id}/approval`).send({decision:'approved'}).expect(200);
    expect(database.sqlite.prepare('SELECT decision FROM request_automation WHERE request_id=?').pluck().get(limited.body.request.id)).toBe('approved');
  });

  it('does not spend an allowance for duplicate support or refund cancelled movies', async () => {
    const { login } = await fixture();
    const member = await login();
    const first = await member.post('/api/requests').send(movie(0)).expect(201);
    for (let i = 0; i < 12; i++) {
      const duplicate = await member.post('/api/requests').send(movie(0)).expect(201);
      expect(duplicate.body.request.id).toBe(first.body.request.id);
    }
    expect(database.sqlite.prepare("SELECT count(*) FROM automation_events WHERE action='auto_approved'").pluck().get()).toBe(1);
    await member.delete(`/api/requests/${first.body.request.id}/support`).expect(200);
    for (let i = 1; i < 10; i++) await member.post('/api/requests').send(movie(i)).expect(201);
    const limited = await member.post('/api/requests').send(movie(0)).expect(201);
    expect(limited.body.request.automation.decision).toBe('pending');
    clock = new Date('2028-09-29T05:00:00Z'); // Midnight America/Chicago, not midnight UTC.
    const reset = await member.post('/api/requests').send(movie(12)).expect(201);
    expect(reset.body.request.automation.decision).toBe('approved');
    const duplicatePending = await member.post('/api/requests').send(movie(0)).expect(201);
    expect(duplicatePending.body.request.automation.decision).toBe('pending');
  });

  it('serializes concurrent requests at the tenth-request boundary and survives app recreation', async () => {
    const { login } = await fixture();
    const member = await login();
    for (let i = 0; i < 9; i++) await member.post('/api/requests').send(movie(i)).expect(201);
    const results = await Promise.all([9,10,11].map(i => member.post('/api/requests').send(movie(i))));
    expect(results.map(r => r.status)).toEqual([201,201,201]);
    expect(results.filter(r => r.body.request.automation.decision === 'approved')).toHaveLength(1);
    const recreated = await fixture();
    const otherSession = await recreated.login();
    const limited = await otherSession.post('/api/requests').send(movie(12)).expect(201);
    expect(limited.body.request.automation.decision).toBe('pending');
  });

  it('auto-approves TV within the allowance, rejects forged decisions, and preserves movie release holds', async () => {
    const { app, login, calls } = await fixture();
    database.sqlite.prepare("UPDATE automation_services SET enabled=1,api_key='test-only',quality_profile_id=1,root_folder_path='/movies' WHERE service='radarr'").run();
    const member = await login();
    await request(app).post('/api/requests').send(movie(0)).expect(401);
    await member.post('/api/requests').send({ mediaType:'tv',tmdbId:2201,decision:'approved' }).expect(400);
    const tv = await member.post('/api/requests').send({ mediaType:'tv',tmdbId:2201 }).expect(201);
    expect(tv.body.request.automation).toMatchObject({decision:'approved',service:'sonarr',submissionStatus:'not_submitted'});
    await member.post(`/api/admin/requests/${tv.body.request.id}/approval`).send({decision:'approved'}).expect(403);
    const response = await member.post('/api/requests').send(movie(0)).expect(201);
    for (let i=0;i<40;i++) {
      const error = database.sqlite.prepare('SELECT last_error FROM request_automation WHERE request_id=?').pluck().get(response.body.request.id);
      if (String(error).startsWith('Waiting for digital')) break;
      await new Promise(resolve => setTimeout(resolve,10));
    }
    expect(database.sqlite.prepare('SELECT decision,submission_status,last_error FROM request_automation WHERE request_id=?').get(response.body.request.id)).toMatchObject({decision:'approved',submission_status:'queued',last_error:'Waiting for digital release on 2029-01-01'});
    expect(calls()).toBe(0);
  });
});
