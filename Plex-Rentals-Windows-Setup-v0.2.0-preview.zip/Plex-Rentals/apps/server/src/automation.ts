import {transferMetrics,trackingStage,type TransferSample} from './transfer-metrics.js';
import type { AutomationService, MediaType, TitleCard, RequestTracking } from '@reelrequest/shared';
import type { AppDatabase } from './db/client.js';
import type { createCatalog } from './catalog.js';
import { ApiError } from './auth.js';
import type { NotificationService } from './notifications.js';

type Fetch = typeof fetch;
export function digitalReleaseHold(
  date: string | null,
  stale: boolean,
  today: string,
  theatrical: string | null = null,
  physical: string | null = null,
): string | null {
  if (stale) return 'Waiting for current digital release information';
  if (!date) {
    if (physical && physical <= today) return null;
    if (theatrical && Date.parse(today) - Date.parse(theatrical) >= 365 * 86400000) return null;
    return 'Waiting for a confirmed digital release date';
  }
  if (date > today) return `Waiting for digital release on ${date}`;
  return null;
}
type ConfigRow = {
  service: AutomationService;
  enabled: number;
  base_url: string;
  api_key: string | null;
  quality_profile_id: number | null;
  root_folder_path: string | null;
};
type WorkRow = {
  request_id: number;
  decision: 'pending' | 'approved' | 'declined';
  submission_status: 'not_submitted' | 'queued' | 'submitting' | 'sent' | 'failed' | 'skipped';
  external_id: number | null;
  attempt_count: number;
  approved_scope: string | null;
  status: string;
  seasons: string | null;
  title_id: number;
  tmdb_id: number;
  tvdb_id: number | null;
  media_type: MediaType;
  title: string;
};
type Json = Record<string, unknown>;

class ArrError extends Error {
  constructor(
    message: string,
    readonly ambiguous = false,
  ) {
    super(message);
  }
}

function objects(value: unknown): Json[] {
  return Array.isArray(value)
    ? value.filter((entry): entry is Json => Boolean(entry) && typeof entry === 'object')
    : [];
}
function positive(value: unknown): number | null {
  return typeof value === 'number' && Number.isSafeInteger(value) && value > 0 ? value : null;
}
function baseUrl(value: string) {
  return value.trim().replace(/\/+$/, '');
}
export function isPathInsideRoot(path: string, root: string): boolean {
  const clean = (value: string) => value.trim().replace(/\\/g, '/').replace(/\/+$/, '');
  const candidate = clean(path);
  const parent = clean(root);
  return Boolean(parent && candidate && candidate !== parent && candidate.startsWith(`${parent}/`));
}
function serviceDefaults(service: AutomationService) {
  return service === 'radarr'
    ? {
        url: process.env.RADARR_URL?.trim() || 'http://radarr:7878',
        key: process.env.RADARR_API_KEY?.trim() || '',
      }
    : {
        url: process.env.SONARR_URL?.trim() || 'http://sonarr:8989',
        key: process.env.SONARR_API_KEY?.trim() || '',
      };
}

export function createAutomationService(
  database: AppDatabase,
  catalog: ReturnType<typeof createCatalog>,
  titleCard: (titleId: number) => TitleCard | null,
  emit: (kind: 'requests' | 'notifications') => void,
  notifications?: NotificationService,
  requestFetch: Fetch = fetch,
  now: () => Date = () => new Date(),
) {
  const sqlite = database.sqlite;
  const services: AutomationService[] = ['radarr', 'sonarr'];
  const timestamp = () => now().toISOString();
  for (const service of services)
    sqlite
      .prepare(
        `INSERT OR IGNORE INTO automation_services(service,enabled,base_url,updated_at)
         VALUES(?,0,'',?)`,
      )
      .run(service, timestamp());

  function stored(service: AutomationService): ConfigRow {
    return sqlite
      .prepare('SELECT * FROM automation_services WHERE service=?')
      .get(service) as ConfigRow;
  }
  function resolved(service: AutomationService) {
    const row = stored(service);
    const defaults = serviceDefaults(service);
    return {
      ...row,
      baseUrl: baseUrl(row.base_url || defaults.url),
      apiKey: defaults.key || row.api_key || '',
    };
  }
  async function call(
    config: ReturnType<typeof resolved>,
    path: string,
    init: RequestInit = {},
  ): Promise<unknown> {
    if (!config.apiKey) throw new ArrError(`${config.service} API key is not configured.`);
    let response: Response;
    try {
      response = await requestFetch(`${config.baseUrl}/api/v3${path}`, {
        ...init,
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          'X-Api-Key': config.apiKey,
          ...init.headers,
        },
        signal: AbortSignal.timeout(12_000),
      });
    } catch {
      throw new ArrError(`${config.service} did not respond. Check its URL and network.`, true);
    }
    if (!response.ok)
      throw new ArrError(
        `${config.service} returned HTTP ${response.status}. Check its configuration.`,
      );
    if (response.status === 204) return null;
    try {
      return await response.json();
    } catch {
      throw new ArrError(`${config.service} returned an unreadable response.`);
    }
  }
  async function inspect(service: AutomationService, includeOptions = true) {
    const config = resolved(service);
    const base = {
      service,
      enabled: Boolean(config.enabled),
      baseUrl: config.baseUrl,
      apiKeyConfigured: Boolean(config.apiKey),
      qualityProfileId: config.quality_profile_id,
      rootFolderPath: config.root_folder_path,
      connected: false,
      version: null as string | null,
      error: null as string | null,
      qualityProfiles: [] as { id: number; name: string }[],
      rootFolders: [] as { id: number; path: string }[],
    };
    if (!config.apiKey) return base;
    try {
      const status = (await call(config, '/system/status')) as Json;
      const [profiles, roots] = includeOptions
        ? await Promise.all([call(config, '/qualityprofile'), call(config, '/rootfolder')])
        : [[], []];
      return {
        ...base,
        connected: true,
        version: typeof status.version === 'string' ? status.version : null,
        qualityProfiles: objects(profiles).flatMap((row) => {
          const id = positive(row.id);
          return id && typeof row.name === 'string' ? [{ id, name: row.name }] : [];
        }),
        rootFolders: objects(roots).flatMap((row) => {
          const id = positive(row.id);
          return id && typeof row.path === 'string' ? [{ id, path: row.path }] : [];
        }),
      };
    } catch (error) {
      return {
        ...base,
        error: error instanceof Error ? error.message : `${service} is unavailable.`,
      };
    }
  }
  function save(
    service: AutomationService,
    input: {
      enabled: boolean;
      baseUrl: string;
      apiKey?: string | undefined;
      qualityProfileId: number | null;
      rootFolderPath: string | null;
    },
  ) {
    const url = new URL(input.baseUrl);
    if (!['http:', 'https:'].includes(url.protocol))
      throw new ApiError(400, 'INVALID_INTEGRATION_URL', 'Use an HTTP or HTTPS server URL.');
    sqlite
      .prepare(
        `UPDATE automation_services SET enabled=?,base_url=?,
         api_key=CASE WHEN ? IS NULL THEN api_key ELSE ? END,
         quality_profile_id=?,root_folder_path=?,updated_at=? WHERE service=?`,
      )
      .run(
        input.enabled ? 1 : 0,
        baseUrl(input.baseUrl),
        input.apiKey ?? null,
        input.apiKey ?? null,
        input.qualityProfileId,
        input.rootFolderPath,
        timestamp(),
        service,
      );
  }
  function event(requestId: number, actor: number | null, action: string, detail?: string | null) {
    sqlite
      .prepare(
        'INSERT INTO automation_events(request_id,actor_profile_id,action,detail) VALUES(?,?,?,?)',
      )
      .run(requestId, actor, action, detail ?? null);
  }
  function audience(requestId: number) {
    return (
      sqlite
        .prepare(
          `SELECT DISTINCT profile_id id FROM request_supporters
           WHERE request_id=? AND withdrawn_at IS NULL`,
        )
        .all(requestId) as { id: number }[]
    ).map((row) => row.id);
  }
  function admins() {
    return (
      sqlite.prepare('SELECT id FROM profiles WHERE is_admin=1 AND disabled=0').all() as {
        id: number;
      }[]
    ).map((row) => row.id);
  }
  function requestRow(requestId: number): WorkRow | undefined {
    return sqlite
      .prepare(
        `SELECT a.*,r.status,r.seasons,r.title_id,t.tmdb_id,t.tvdb_id,t.media_type,t.title
         FROM request_automation a JOIN requests r ON r.id=a.request_id
         JOIN titles t ON t.id=r.title_id WHERE a.request_id=?`,
      )
      .get(requestId) as WorkRow | undefined;
  }
  function decide(
    requestId: number,
    actorId: number,
    decision: 'approved' | 'declined',
    reason?: string,
  ) {
    const source = sqlite
      .prepare(
        `SELECT r.id,r.status,r.seasons,t.media_type,t.title,t.id title_id
         FROM requests r JOIN titles t ON t.id=r.title_id WHERE r.id=?`,
      )
      .get(requestId) as
      | {
          id: number;
          status: string;
          seasons: string | null;
          media_type: MediaType;
          title: string;
          title_id: number;
        }
      | undefined;
    if (!source) throw new ApiError(404, 'REQUEST_NOT_FOUND', 'That request is unavailable.');
    if (!['requested', 'looking'].includes(source.status))
      throw new ApiError(
        409,
        'INVALID_STATUS',
        'Only an active request can be approved or declined.',
      );
    const previous = requestRow(requestId);
    if (previous?.submission_status === 'sent' && decision === 'declined')
      throw new ApiError(
        409,
        'ALREADY_SENT',
        'This request was already sent. Passing on it will not remove shared media.',
      );
    const service: AutomationService = source.media_type === 'movie' ? 'radarr' : 'sonarr';
    const seasons = source.seasons === null ? null : (JSON.parse(source.seasons) as number[]);
    const config = resolved(service);
    const time = timestamp();
    sqlite.transaction(() => {
      sqlite
        .prepare(
          `INSERT INTO request_automation(request_id,decision,decided_by,decided_at,decline_reason,
             approved_scope,service,submission_status,updated_at)
           VALUES(?,?,?,?,?,?,?,?,?)
           ON CONFLICT(request_id) DO UPDATE SET decision=excluded.decision,
             decided_by=excluded.decided_by,decided_at=excluded.decided_at,
             decline_reason=excluded.decline_reason,approved_scope=excluded.approved_scope,
             service=excluded.service,
             submission_status=CASE
               WHEN request_automation.submission_status='sent' THEN 'sent'
               ELSE excluded.submission_status END,
             last_error=NULL,next_attempt_at=NULL,updated_at=excluded.updated_at`,
        )
        .run(
          requestId,
          decision,
          actorId,
          time,
          decision === 'declined' ? reason : null,
          decision === 'approved' ? JSON.stringify({ seasons }) : null,
          service,
          decision === 'approved' && config.enabled ? 'queued' : 'not_submitted',
          time,
        );
      event(
        requestId,
        actorId,
        decision,
        decision === 'declined' ? reason : JSON.stringify({ seasons }),
      );
      if (decision === 'declined') {
        sqlite
          .prepare(`UPDATE requests SET status='passed',updated_at=? WHERE id=?`)
          .run(time, requestId);
        sqlite
          .prepare(
            `UPDATE request_events SET actor_profile_id=? WHERE id=(SELECT MAX(id) FROM request_events WHERE request_id=?)`,
          )
          .run(actorId, requestId);
      }
    })();
    notifications?.notify(
      audience(requestId).filter((id) => id !== actorId),
      {
        kind: decision === 'approved' ? 'request_approved' : 'request_declined',
        body:
          decision === 'approved'
            ? `${source.title} was approved and is waiting for ${service === 'radarr' ? 'Radarr' : 'Sonarr'}.`
            : `${source.title} was declined${reason ? `: ${reason}` : '.'}`,
        requestId,
        titleId: source.title_id,
      },
    );
    emit('requests');
    emit('notifications');
    if (decision === 'approved' && config.enabled) void run();
  }
  function retry(requestId: number, actorId: number) {
    const work = requestRow(requestId);
    if (!work) throw new ApiError(404, 'APPROVAL_NOT_FOUND', 'Approve this request first.');
    if (work.decision !== 'approved')
      throw new ApiError(409, 'NOT_APPROVED', 'Only an approved request can be retried.');
    if (!resolved(work.media_type === 'movie' ? 'radarr' : 'sonarr').enabled)
      throw new ApiError(409, 'INTEGRATION_DISABLED', 'Enable this integration before retrying.');
    if (work.submission_status === 'sent') return;
    sqlite
      .prepare(
        `UPDATE request_automation SET submission_status='queued',last_error=NULL,
         next_attempt_at=NULL,updated_at=? WHERE request_id=?`,
      )
      .run(timestamp(), requestId);
    event(requestId, actorId, 'retry_queued');
    emit('requests');
    void run();
  }
  async function hydrate(work: WorkRow) {
    if (work.media_type === 'tv' && !work.tvdb_id) {
      await catalog.refreshDetail('tv', work.tmdb_id);
      return requestRow(work.request_id)!;
    }
    return work;
  }
  function validateConfig(config: ReturnType<typeof resolved>) {
    if (!config.enabled) throw new ArrError(`${config.service} is disabled.`);
    if (!config.apiKey) throw new ArrError(`${config.service} API key is not configured.`);
    if (!config.quality_profile_id)
      throw new ArrError(`${config.service} default quality profile is not configured.`);
    if (!config.root_folder_path)
      throw new ArrError(`${config.service} root folder is not configured.`);
  }
  async function dispatchMovie(work: WorkRow, config: ReturnType<typeof resolved>) {
    const existing = objects(await call(config, `/movie?tmdbId=${work.tmdb_id}`)).find(
      (item) => item.tmdbId === work.tmdb_id,
    );
    const existingId = positive(existing?.id);
    if (existingId) return existingId;
    const lookup = objects(await call(config, `/movie/lookup?term=tmdb:${work.tmdb_id}`));
    const matches = lookup.filter((item) => item.tmdbId === work.tmdb_id);
    if (matches.length !== 1)
      throw new ArrError('Radarr could not resolve one exact TMDB match. Review it in Radarr.');
    const remote = { ...matches[0]! };
    delete remote.id;
    const created = (await call(config, '/movie', {
      method: 'POST',
      body: JSON.stringify({
        ...remote,
        qualityProfileId: config.quality_profile_id,
        rootFolderPath: config.root_folder_path,
        monitored: true,
        minimumAvailability: 'released',
        addOptions: { monitor: 'movieOnly', searchForMovie: true },
      }),
    })) as Json;
    const result = positive(created.id);
    if (!result) throw new ArrError('Radarr did not return the added movie identifier.');
    return result;
  }
  async function commandOnce(
    work: WorkRow,
    config: ReturnType<typeof resolved>,
    action: string,
    body: Json,
  ) {
    const inserted = sqlite
      .prepare(
        `INSERT OR IGNORE INTO automation_events(request_id,actor_profile_id,action,detail)
         VALUES(?,NULL,?,?)`,
      )
      .run(work.request_id, `dispatch:${action}`, JSON.stringify(body));
    if (!inserted.changes) return;
    try {
      await call(config, '/command', { method: 'POST', body: JSON.stringify(body) });
    } catch (error) {
      if (!(error instanceof ArrError && error.ambiguous))
        sqlite
          .prepare('DELETE FROM automation_events WHERE request_id=? AND action=? AND detail=?')
          .run(work.request_id, `dispatch:${action}`, JSON.stringify(body));
      throw error;
    }
  }
  async function dispatchSeries(work: WorkRow, config: ReturnType<typeof resolved>) {
    if (!work.tvdb_id)
      throw new ArrError('Sonarr needs an exact TVDB identity. Refresh TMDB metadata and retry.');
    const scope = work.approved_scope
      ? (JSON.parse(work.approved_scope) as { seasons: number[] | null })
      : null;
    if (!scope) throw new ArrError('The approved TV scope is missing. Approve the request again.');
    let series = objects(await call(config, `/series?tvdbId=${work.tvdb_id}`)).find(
      (item) => item.tvdbId === work.tvdb_id,
    );
    let seriesId = positive(series?.id);
    if (!seriesId) {
      const lookup = objects(await call(config, `/series/lookup?term=tvdb:${work.tvdb_id}`));
      const matches = lookup.filter((item) => item.tvdbId === work.tvdb_id);
      if (matches.length !== 1)
        throw new ArrError('Sonarr could not resolve one exact TVDB match. Review it in Sonarr.');
      const remote = { ...matches[0]! };
      delete remote.id;
      series = (await call(config, '/series', {
        method: 'POST',
        body: JSON.stringify({
          ...remote,
          qualityProfileId: config.quality_profile_id,
          rootFolderPath: config.root_folder_path,
          seasonFolder: true,
          monitored: true,
          monitorNewItems: scope.seasons === null ? 'all' : 'none',
          addOptions: { monitor: 'none', searchForMissingEpisodes: false },
        }),
      })) as Json;
      seriesId = positive(series.id);
      if (!seriesId) throw new ArrError('Sonarr did not return the added series identifier.');
    }
    const fresh = (await call(config, `/series/${seriesId}`)) as Json;
    const seasons = objects(fresh.seasons).map((season) => ({
      ...season,
      monitored:
        scope.seasons === null ||
        scope.seasons.includes(
          typeof season.seasonNumber === 'number' ? season.seasonNumber : -1,
        ) ||
        season.monitored === true,
    }));
    await call(config, `/series/${seriesId}`, {
      method: 'PUT',
      body: JSON.stringify({
        ...fresh,
        seasons,
        monitored: true,
        monitorNewItems: scope.seasons === null ? 'all' : fresh.monitorNewItems,
      }),
    });
    if (scope.seasons === null)
      await commandOnce(work, config, 'series-search', { name: 'SeriesSearch', seriesId });
    else
      for (const seasonNumber of scope.seasons)
        await commandOnce(work, config, `season-${seasonNumber}-search`, {
          name: 'SeasonSearch',
          seriesId,
          seasonNumber,
        });
    return seriesId;
  }
  async function processOne(candidate: WorkRow) {
    let work = await hydrate(candidate);
    work = requestRow(work.request_id)!;
    const card = titleCard(work.title_id);
    if (
      work.decision !== 'approved' ||
      !['requested', 'looking'].includes(work.status) ||
      card?.plexState === 'available'
    ) {
      sqlite
        .prepare(
          `UPDATE request_automation SET submission_status='skipped',last_error=NULL,
           next_attempt_at=NULL,updated_at=? WHERE request_id=?`,
        )
        .run(timestamp(), work.request_id);
      event(
        work.request_id,
        null,
        'dispatch_skipped',
        card?.plexState === 'available' ? 'Already in Plex' : work.status,
      );
      return;
    }
    const config = resolved(work.media_type === 'movie' ? 'radarr' : 'sonarr');
    validateConfig(config);
    if (work.media_type === 'movie') {
      const metadata = await catalog.refreshDetail('movie', work.tmdb_id);
      const digital = metadata.title.releaseDigital;
      const reason = digitalReleaseHold(
        digital,
        metadata.stale,
        timestamp().slice(0, 10),
        metadata.title.releaseTheatrical,
        metadata.title.releasePhysical,
      );
      if (reason) {
        sqlite
          .prepare(
            "UPDATE request_automation SET submission_status='queued',last_error=?,next_attempt_at=?,updated_at=? WHERE request_id=?",
          )
          .run(
            reason,
            new Date(now().getTime() + 6 * 3600000).toISOString(),
            timestamp(),
            work.request_id,
          );
        return;
      }
    }
    const externalId =
      work.media_type === 'movie'
        ? await dispatchMovie(work, config)
        : await dispatchSeries(work, config);
    const time = timestamp();
    sqlite
      .prepare(
        `UPDATE request_automation SET submission_status='sent',external_id=?,last_error=NULL,
         next_attempt_at=NULL,submitted_at=?,updated_at=? WHERE request_id=?`,
      )
      .run(externalId, time, time, work.request_id);
    event(work.request_id, null, 'sent', `${config.service}:${externalId}`);
    notifications?.notify(audience(work.request_id), {
      kind: 'request_sent',
      body: `${work.title} was sent to ${config.service === 'radarr' ? 'Radarr' : 'Sonarr'} and is waiting for Plex.`,
      requestId: work.request_id,
      titleId: work.title_id,
    });
  }
  function scheduleRentalExpirations() {
    const rows = sqlite
      .prepare(
        `SELECT rr.request_id,r.available_at,t.title,t.id title_id
         FROM request_rentals rr JOIN requests r ON r.id=rr.request_id
         JOIN titles t ON t.id=r.title_id
         WHERE rr.expires_at IS NULL AND rr.deleted_at IS NULL
         AND r.available_at IS NOT NULL AND r.status IN ('available','watched')`,
      )
      .all() as { request_id: number; available_at: string; title: string; title_id: number }[];
    for (const row of rows) {
      const expiresAt = new Date(new Date(row.available_at).getTime() + 7 * 86400000).toISOString();
      const changed = sqlite
        .prepare(
          'UPDATE request_rentals SET expires_at=?,updated_at=? WHERE request_id=? AND expires_at IS NULL',
        )
        .run(expiresAt, timestamp(), row.request_id);
      if (!changed.changes) continue;
      event(row.request_id, null, 'rental_started', expiresAt);
      notifications?.notify(audience(row.request_id), {
        kind: 'rental_started',
        body: `${row.title} is ready in Plex. Its 7-day rental ends ${expiresAt.slice(0, 10)}.`,
        requestId: row.request_id,
        titleId: row.title_id,
      });
    }
  }
  async function processDueRentals() {
    scheduleRentalExpirations();
    const due = sqlite
      .prepare(
        `SELECT rr.request_id,rr.attempt_count,r.title_id,t.title,t.tmdb_id,
                a.external_id,a.service
         FROM request_rentals rr JOIN requests r ON r.id=rr.request_id
         JOIN titles t ON t.id=r.title_id
         LEFT JOIN request_automation a ON a.request_id=r.id
         WHERE rr.expires_at IS NOT NULL AND rr.expires_at<=? AND rr.deleted_at IS NULL
         AND (rr.next_attempt_at IS NULL OR rr.next_attempt_at<=?)
         AND r.status IN ('available','watched') AND t.media_type='movie'
         ORDER BY rr.expires_at LIMIT 3`,
      )
      .all(timestamp(), timestamp()) as {
      request_id: number;
      attempt_count: number;
      title_id: number;
      title: string;
      tmdb_id: number;
      external_id: number | null;
      service: string | null;
    }[];
    for (const rental of due) {
      const retryAt = new Date(now().getTime() + 6 * 3600000).toISOString();
      sqlite
        .prepare(
          'UPDATE request_rentals SET attempt_count=attempt_count+1,next_attempt_at=?,updated_at=? WHERE request_id=?',
        )
        .run(retryAt, timestamp(), rental.request_id);
      try {
        if (rental.service !== 'radarr' || !rental.external_id)
          throw new ArrError('Rental cleanup cannot verify a matching Radarr movie.');
        const config = resolved('radarr');
        if (!config.enabled || !config.root_folder_path)
          throw new ArrError('Rental cleanup requires the configured Radarr movie root.');
        const remote = (await call(config, `/movie/${rental.external_id}`)) as Json;
        if (positive(remote.id) !== rental.external_id || positive(remote.tmdbId) !== rental.tmdb_id)
          throw new ArrError('Rental cleanup stopped because the Radarr identity did not match.');
        if (remote.hasFile !== true || typeof remote.path !== 'string')
          throw new ArrError('Rental cleanup could not verify a library file in Radarr.');
        if (!isPathInsideRoot(remote.path, config.root_folder_path))
          throw new ArrError('Rental cleanup stopped because the movie path is outside the configured root.');
        await call(
          config,
          `/movie/${rental.external_id}?deleteFiles=true&addImportExclusion=false`,
          { method: 'DELETE' },
        );
        const time = timestamp();
        sqlite.transaction(() => {
          sqlite
            .prepare(
              'UPDATE request_rentals SET deleted_at=?,last_error=NULL,next_attempt_at=NULL,updated_at=? WHERE request_id=?',
            )
            .run(time, time, rental.request_id);
          sqlite
            .prepare("UPDATE requests SET status='cancelled',updated_at=? WHERE id=?")
            .run(time, rental.request_id);
          event(rental.request_id, null, 'rental_deleted', String(remote.path));
        })();
        notifications?.notify(audience(rental.request_id), {
          kind: 'rental_deleted',
          body: `${rental.title}'s 7-day rental ended and its library copy was removed.`,
          requestId: rental.request_id,
          titleId: rental.title_id,
        });
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Rental cleanup failed safely.';
        sqlite
          .prepare('UPDATE request_rentals SET last_error=?,updated_at=? WHERE request_id=?')
          .run(message, timestamp(), rental.request_id);
        event(rental.request_id, null, 'rental_delete_failed', message);
        notifications?.notify(admins(), {
          kind: 'rental_delete_failed',
          body: `${rental.title} was not removed: ${message}`,
          requestId: rental.request_id,
          titleId: rental.title_id,
        });
      }
    }
  }
  let running = false;
  async function run() {
    if (running) return;
    running = true;
    try {
      await processDueRentals();
      const stale = new Date(now().getTime() - 10 * 60_000).toISOString();
      sqlite
        .prepare(
          `UPDATE request_automation SET submission_status='queued',updated_at=?
           WHERE submission_status='submitting' AND last_attempt_at<?`,
        )
        .run(timestamp(), stale);
      for (let count = 0; count < 10; count += 1) {
        const candidate = sqlite
          .prepare(
            `SELECT a.*,r.status,r.seasons,r.title_id,t.tmdb_id,t.tvdb_id,t.media_type,t.title
             FROM request_automation a JOIN requests r ON r.id=a.request_id
             JOIN titles t ON t.id=r.title_id
             WHERE a.decision='approved' AND a.submission_status IN ('queued','failed')
             AND (a.next_attempt_at IS NULL OR a.next_attempt_at<=?)
             ORDER BY a.updated_at LIMIT 1`,
          )
          .get(timestamp()) as WorkRow | undefined;
        if (!candidate) break;
        const attemptAt = timestamp();
        const claimed = sqlite
          .prepare(
            `UPDATE request_automation SET submission_status='submitting',attempt_count=attempt_count+1,
             last_attempt_at=?,updated_at=? WHERE request_id=? AND submission_status IN ('queued','failed')`,
          )
          .run(attemptAt, attemptAt, candidate.request_id);
        if (!claimed.changes) continue;
        try {
          await processOne({ ...candidate, submission_status: 'submitting' });
        } catch (error) {
          const latest = requestRow(candidate.request_id)!;
          const delay = Math.min(60, 2 ** Math.min(latest.attempt_count, 5)) * 60_000;
          const next = new Date(now().getTime() + delay).toISOString();
          const message =
            error instanceof Error
              ? error.message
              : 'The integration could not submit this request.';
          sqlite
            .prepare(
              `UPDATE request_automation SET submission_status='failed',last_error=?,
               next_attempt_at=?,updated_at=? WHERE request_id=?`,
            )
            .run(message, next, timestamp(), candidate.request_id);
          event(candidate.request_id, null, 'failed', message);
          notifications?.notify(admins(), {
            kind: 'integration_failed',
            body: `${candidate.title} needs integration attention: ${message}`,
            requestId: candidate.request_id,
            titleId: candidate.title_id,
          });
        }
        emit('requests');
        emit('notifications');
      }
    } finally {
      running = false;
    }
  }
  function start() {
    void run();
    const timer = setInterval(() => void run(), 5 * 60_000);
    timer.unref();
    return () => clearInterval(timer);
  }
  type Tracking = RequestTracking;
  const transferSamples = new Map<number,TransferSample>();
  const trackingCache = new Map<number, { until: number; value: Promise<Tracking> }>();
  async function tracking(requestId: number): Promise<Tracking> {
    const cached = trackingCache.get(requestId);
    if (cached && cached.until > now().getTime()) return cached.value;
    const value = readTracking(requestId).then(value => ({...value,stage:trackingStage(value.state)}));
    if (trackingCache.size > 200) trackingCache.clear();
    trackingCache.set(requestId, { until: now().getTime() + 4_000, value });
    return value;
  }
  async function readTracking(requestId: number): Promise<Tracking> {
    const row = sqlite
      .prepare(
        `SELECT a.service,a.external_id,a.submission_status,a.decision,a.last_error,r.status FROM requests r LEFT JOIN request_automation a ON a.request_id=r.id WHERE r.id=?`,
      )
      .get(requestId) as {
      service: AutomationService | null;
      external_id: number | null;
      submission_status: string | null;
      decision: string | null;
      status: string;
      last_error: string | null;
    };
    const result: Tracking = {
      checkedAt: timestamp(),
      state: 'Awaiting approval',
      progress: null,
      eta: null,
      source: 'Plex Rentals',
      stage: 'waiting',
      bytesTotal:null, bytesDownloaded:null, speedBytesPerSecond:null,
      events: [],
    };
    const finalState =
      row.status === 'available' ? 'Ready in Plex' : row.status === 'watched' ? 'Watched' : null;
    if (row.status === 'cancelled') return { ...result, state: 'Cancelled' };
    if (row.decision === 'declined') return { ...result, state: 'Declined' };
    if (row.submission_status !== 'sent' || !row.external_id || !row.service)
      return {
        ...result,
        state:
          finalState ??
          (row.submission_status === 'failed'
            ? 'Submission needs attention'
            : row.decision === 'approved'
              ? row.last_error?.startsWith('Waiting for ')
                ? row.last_error
                : 'Approved · waiting for submission'
              : 'Awaiting approval'),
      };
    const config = resolved(row.service);
    result.source = row.service === 'radarr' ? 'Radarr' : 'Sonarr';
    const idKey = row.service === 'radarr' ? 'movieId' : 'seriesId';
    try {
      const [queue, history, media] = await Promise.all([
        call(
          config,
          `/queue/details?${idKey}=${row.external_id}&includeUnknownMovieItems=false&includeUnknownSeriesItems=false`,
        ),
        call(
          config,
          `/history?${idKey}=${row.external_id}&page=1&pageSize=30&sortKey=date&sortDirection=descending`,
        ),
        call(config, `/${row.service === 'radarr' ? 'movie' : 'series'}/${row.external_id}`),
      ]);
      const entries = objects(queue).filter((item) => item[idKey] === row.external_id);
      const labels: Record<string, string> = {
        grabbed: 'Release sent to download client',
        downloadFolderImported: 'Imported into library',
        downloadFailed: 'Download failed',
        downloadIgnored: 'Download ignored',
        movieFileDeleted: 'Library file removed',
        episodeFileDeleted: 'Episode file removed',
        movieFileRenamed: 'Library file renamed',
        episodeFileRenamed: 'Episode file renamed',
      };
      result.events = objects((history as Json)?.records)
        .filter(
          (item) =>
            item[idKey] === row.external_id &&
            typeof item.date === 'string' &&
            labels[String(item.eventType)],
        )
        .map((item) => ({ label: labels[String(item.eventType)]!, createdAt: String(item.date) }));
      const metrics=transferMetrics(entries,now().getTime(),transferSamples.get(requestId));
      if(transferSamples.size>200)transferSamples.clear();
      if(metrics.sample)transferSamples.set(requestId,metrics.sample);else transferSamples.delete(requestId);
      result.bytesTotal=metrics.bytesTotal;result.bytesDownloaded=metrics.bytesDownloaded;result.speedBytesPerSecond=metrics.speedBytesPerSecond;
      if (entries.length) {
        const size = entries.reduce(
          (sum, item) => sum + (typeof item.size === 'number' ? item.size : 0),
          0,
        );
        const left = entries.reduce(
          (sum, item) => sum + (typeof item.sizeleft === 'number' ? item.sizeleft : 0),
          0,
        );
        result.progress =
          size > 0 && entries.every((item) => typeof item.sizeleft === 'number')
            ? Math.round(Math.max(0, Math.min(100, ((size - left) / size) * 100)) * 10) / 10
            : null;
        const states = entries
          .map((item) => String(item.trackedDownloadState ?? '') + ' ' + String(item.status ?? ''))
          .join(' ')
          .toLowerCase();
        result.state = entries.some((item) =>
          ['warning', 'error'].includes(String(item.trackedDownloadStatus).toLowerCase()),
        )
          ? 'Download or import needs attention'
          : states.includes('importing')
            ? 'Importing to NAS library'
            : states.includes('importpending') || states.includes('completed')
              ? 'Downloaded · awaiting import'
              : states.includes('paused')
                ? 'Download paused'
                : states.includes('downloading')
                  ? 'Downloading'
                  : 'Queued in download client';
        const eta = entries.length === 1 ? entries[0]?.timeleft : null;
        result.eta = typeof eta === 'string' && /^[\d.:]+$/.test(eta) ? eta : null;
      } else {
        const imported = row.service === 'radarr' ? (media as Json)?.hasFile === true : false;
        result.state = imported
          ? 'Imported · waiting for Plex confirmation'
          : result.events.some((event) => event.label === 'Imported into library')
            ? 'Import activity recorded · waiting for Plex confirmation'
            : 'Monitoring · no active download reported';
      }
      result.checkedAt = timestamp();
      if (finalState) {
        result.state = finalState;
        result.bytesTotal=null;result.bytesDownloaded=null;result.speedBytesPerSecond=null;
        result.progress = null;
        result.eta = null;
      }
      return result;
    } catch {
      return {
        ...result,
        state: finalState ?? 'Live tracking unavailable · will retry',
        checkedAt: timestamp(),
      };
    }
  }
  return {
    tracking,
    inspect,
    settings: () => Promise.all(services.map((service) => inspect(service))),
    save,
    decide,
    retry,
    run,
    start,
  };
}

export type AutomationManager = ReturnType<typeof createAutomationService>;

