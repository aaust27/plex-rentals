import { createHash, createHmac, randomBytes, scrypt, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { and, eq } from 'drizzle-orm';
import type { Request, Response } from 'express';
import type { AppDatabase } from './db/client.js';
import { authAttempts, devices, profiles, settings } from './db/schema.js';

const derive = promisify(scrypt);
const COOKIE = 'reelrequest_device';
const lifetime = 180 * 86400000;
export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
  ) {
    super(message);
  }
}
export type ProfileRow = typeof profiles.$inferSelect;
export type DeviceRow = typeof devices.$inferSelect;
export type AuthOptions = {
  householdPasscode?: string;
  sessionSecret?: string;
  adminPin?: string;
  baseUrl?: string;
  now?: () => Date;
};
export function publicProfile(profile: ProfileRow) {
  return {
    id: profile.id,
    name: profile.name,
    avatar: profile.avatar,
    color: profile.color,
    isAdmin: profile.isAdmin,
    hasPin: Boolean(profile.pinHash),
    maxRatingLevel: profile.maxRatingLevel,
  };
}
export async function hashPin(pin: string): Promise<string> {
  const salt = randomBytes(16).toString('hex');
  const key = (await derive(pin, salt, 64)) as Buffer;
  return `scrypt:${salt}:${key.toString('hex')}`;
}
async function verifyPin(pin: string, stored: string): Promise<boolean> {
  const parts = stored.split(':');
  if (
    parts.length !== 3 ||
    parts[0] !== 'scrypt' ||
    !/^[a-f0-9]{32}$/.test(parts[1] ?? '') ||
    !/^[a-f0-9]{128}$/.test(parts[2] ?? '')
  )
    return false;
  const key = (await derive(pin, parts[1]!, 64)) as Buffer;
  return timingSafeEqual(key, Buffer.from(parts[2]!, 'hex'));
}
function digest(value: string): string {
  return createHash('sha256').update(value).digest('hex');
}
function constantEqual(a: string, b: string): boolean {
  return timingSafeEqual(Buffer.from(digest(a), 'hex'), Buffer.from(digest(b), 'hex'));
}

export function createAuth(database: AppDatabase, options: AuthOptions = {}) {
  const passcode = options.householdPasscode ?? process.env.HOUSEHOLD_PASSCODE ?? '';
  const secret = options.sessionSecret ?? process.env.SESSION_SECRET ?? '';
  const adminPin = options.adminPin ?? process.env.ADMIN_PIN ?? '';
  const baseUrl = options.baseUrl ?? process.env.BASE_URL ?? 'http://localhost:8080';
  const now = options.now ?? (() => new Date());
  const secure = baseUrl.startsWith('https://');
  const sign = (token: string) => createHmac('sha256', secret).update(token).digest('base64url');
  const ready = (async () => {
    if (!/^\d{4}$/.test(adminPin)) return;
    const admin = database.db
      .select()
      .from(profiles)
      .where(and(eq(profiles.isAdmin, true), eq(profiles.disabled, false)))
      .get();
    if (admin?.pinHash) return;
    const pinHash = await hashPin(adminPin);
    if (admin) database.db.update(profiles).set({ pinHash }).where(eq(profiles.id, admin.id)).run();
    else if (!database.db.select().from(profiles).get()) {
      database.db
        .insert(profiles)
        .values([
          { name: 'Owner', avatar: 'preset:director', color: '#F7A823', isAdmin: true, pinHash },
          { name: 'Family 1', avatar: 'preset:explorer', color: '#5AB8F0' },
          { name: 'Family 2', avatar: 'preset:dreamer', color: '#9B6BF0' },
          { name: 'Family 3', avatar: 'preset:stargazer', color: '#34C759' },
        ])
        .run();
    }
  })();
  function storedPasscode() {
    return database.db
      .select()
      .from(settings)
      .where(eq(settings.key, 'household_passcode_hash'))
      .get()?.value;
  }
  function configured() {
    return (Boolean(storedPasscode()) || passcode.length >= 8) && secret.length >= 32;
  }
  function requireConfiguration() {
    if (!configured())
      throw new ApiError(
        503,
        'HOUSEHOLD_NOT_CONFIGURED',
        'Set HOUSEHOLD_PASSCODE and a SESSION_SECRET of at least 32 characters on the server.',
      );
  }
  function device(request: Request): DeviceRow | undefined {
    if (!configured()) return undefined;
    const value = request.headers.cookie
      ?.split(';')
      .map((part) => part.trim())
      .find((part) => part.startsWith(`${COOKIE}=`))
      ?.slice(COOKIE.length + 1);
    if (!value) return undefined;
    const parts = value.split('.');
    if (parts.length !== 2) return undefined;
    const [token, signature] = parts;
    if (
      !token ||
      !signature ||
      !/^[\w-]{43}$/.test(token) ||
      !constantEqual(sign(token), signature)
    )
      return undefined;
    const row = database.db
      .select()
      .from(devices)
      .where(eq(devices.tokenHash, digest(token)))
      .get();
    return row?.expiresAt && Date.parse(row.expiresAt) > now().getTime() ? row : undefined;
  }
  function requireDevice(request: Request): DeviceRow {
    requireConfiguration();
    const row = device(request);
    if (!row)
      throw new ApiError(401, 'DEVICE_REQUIRED', 'Enter the household passcode to continue.');
    return row;
  }
  function selected(device: DeviceRow): ProfileRow | undefined {
    return device.currentProfileId
      ? database.db
          .select()
          .from(profiles)
          .where(and(eq(profiles.id, device.currentProfileId), eq(profiles.disabled, false)))
          .get()
      : undefined;
  }
  function context(request: Request) {
    const currentDevice = requireDevice(request);
    const profile = selected(currentDevice);
    if (!profile) throw new ApiError(401, 'PROFILE_REQUIRED', 'Choose who is watching.');
    return {
      device: currentDevice,
      profile,
      adminUnlocked: Boolean(
        profile.isAdmin &&
        currentDevice.adminUnlockedUntil &&
        Date.parse(currentDevice.adminUnlockedUntil) > now().getTime(),
      ),
    };
  }
  function admin(request: Request) {
    const result = context(request);
    if (!result.adminUnlocked)
      throw new ApiError(403, 'ADMIN_REQUIRED', 'Unlock an admin profile to continue.');
    return result;
  }
  function rate(request: Request) {
    const key = digest(request.ip ?? request.socket.remoteAddress ?? 'unknown');
    const row = database.db.select().from(authAttempts).where(eq(authAttempts.key, key)).get();
    if (row && now().getTime() - row.windowStart < 900000 && row.failures >= 5)
      throw new ApiError(
        429,
        'AUTH_LOCKED',
        'Too many incorrect attempts. Try again in 15 minutes.',
      );
    return { key, row };
  }
  function wrong(request: Request): never {
    const { key, row } = rate(request);
    const start = now().getTime();
    const failures = row && start - row.windowStart < 900000 ? row.failures + 1 : 1;
    database.db
      .insert(authAttempts)
      .values({
        key,
        failures,
        windowStart: row && start - row.windowStart < 900000 ? row.windowStart : start,
      })
      .onConflictDoUpdate({
        target: authAttempts.key,
        set: {
          failures,
          windowStart: row && start - row.windowStart < 900000 ? row.windowStart : start,
        },
      })
      .run();
    throw new ApiError(
      failures >= 5 ? 429 : 401,
      failures >= 5 ? 'AUTH_LOCKED' : 'INVALID_CREDENTIAL',
      failures >= 5
        ? 'Too many incorrect attempts. Try again in 15 minutes.'
        : 'The passcode or PIN is incorrect.',
    );
  }
  function mutationGuard(request: Request) {
    if (['GET', 'HEAD', 'OPTIONS'].includes(request.method)) return;
    const origin = request.headers.origin;
    if (
      request.headers['sec-fetch-site'] === 'cross-site' ||
      (origin && origin !== new URL(baseUrl).origin)
    )
      throw new ApiError(403, 'ORIGIN_REJECTED', 'This request did not come from Plex Rentals.');
    if (Number(request.headers['content-length'] ?? 0) > 0 && !request.is('application/json'))
      throw new ApiError(415, 'JSON_REQUIRED', 'Send this request as JSON.');
  }
  return {
    ready,
    now,
    configured,
    requireDevice,
    context,
    admin,
    device,
    selected,
    mutationGuard,
    async join(
      request: Request,
      response: Response,
      input: { passcode: string; label?: string | undefined },
    ) {
      await ready;
      requireConfiguration();
      rate(request);
      const stored = storedPasscode();
      if (
        !(stored
          ? await verifyPin(input.passcode, stored)
          : constantEqual(input.passcode, passcode))
      )
        wrong(request);
      const token = randomBytes(32).toString('base64url');
      const expiresAt = new Date(now().getTime() + lifetime).toISOString();
      database.db
        .insert(devices)
        .values({
          tokenHash: digest(token),
          label: input.label ?? 'Family device',
          expiresAt,
          lastSeenAt: now().toISOString(),
        })
        .run();
      response.cookie(COOKIE, `${token}.${sign(token)}`, {
        httpOnly: true,
        sameSite: 'strict',
        secure,
        maxAge: lifetime,
        path: '/',
      });
    },
    async select(request: Request, input: { profileId: number; pin?: string | undefined }) {
      await ready;
      const current = requireDevice(request);
      rate(request);
      const profile = database.db
        .select()
        .from(profiles)
        .where(and(eq(profiles.id, input.profileId), eq(profiles.disabled, false)))
        .get();
      if (!profile) throw new ApiError(404, 'PROFILE_NOT_FOUND', 'That profile is unavailable.');
      if (profile.isAdmin && !profile.pinHash)
        throw new ApiError(
          503,
          'ADMIN_PIN_NOT_CONFIGURED',
          'Set ADMIN_PIN on the server to initialize the admin profile.',
        );
      if (profile.pinHash && (!input.pin || !(await verifyPin(input.pin, profile.pinHash))))
        wrong(request);
      const fresh = requireDevice(request);
      const freshProfile = database.db
        .select()
        .from(profiles)
        .where(eq(profiles.id, profile.id))
        .get();
      if (
        fresh.id !== current.id ||
        !freshProfile ||
        freshProfile.disabled ||
        freshProfile.pinHash !== profile.pinHash
      )
        throw new ApiError(409, 'SESSION_CHANGED', 'The profile changed. Please try again.');
      database.db
        .update(devices)
        .set({
          currentProfileId: profile.id,
          adminUnlockedUntil: null,
          lastSeenAt: now().toISOString(),
        })
        .where(eq(devices.id, current.id))
        .run();
      return profile;
    },
    async unlock(request: Request, pin: string) {
      const current = context(request);
      rate(request);
      if (!current.profile.isAdmin)
        throw new ApiError(403, 'ADMIN_REQUIRED', 'Choose an admin profile first.');
      if (!current.profile.pinHash)
        throw new ApiError(
          503,
          'ADMIN_PIN_NOT_CONFIGURED',
          'Set ADMIN_PIN on the server to initialize the admin profile.',
        );
      if (!(await verifyPin(pin, current.profile.pinHash))) wrong(request);
      const fresh = context(request);
      if (
        fresh.profile.id !== current.profile.id ||
        !fresh.profile.isAdmin ||
        fresh.profile.pinHash !== current.profile.pinHash
      )
        throw new ApiError(409, 'SESSION_CHANGED', 'The profile changed. Please try again.');
      const until = new Date(now().getTime() + 12 * 3600000).toISOString();
      database.db
        .update(devices)
        .set({ adminUnlockedUntil: until })
        .where(eq(devices.id, current.device.id))
        .run();
      return until;
    },
    async resetPasscode(passcode: string, recheck: () => void) {
      const value = await hashPin(passcode);
      recheck();
      database.db
        .insert(settings)
        .values({ key: 'household_passcode_hash', value })
        .onConflictDoUpdate({ target: settings.key, set: { value } })
        .run();
    },
  };
}
