import {mountStorage} from './storage.js';
import { mountTitleSocial } from './title-social.js';
import { mountSuggestions } from './suggestions.js';
import type express from 'express';
import sharp from 'sharp';
import { and, desc, eq, inArray, isNull } from 'drizzle-orm';
import { timingSafeEqual } from 'node:crypto';
import {
  MAX_AVATAR_BYTES,
  adminRequestPatchSchema,
  approvalActionSchema,
  bulkApprovalSchema,
  adminUnlockSchema,
  browseQuerySchema,
  discoverQuerySchema,
  discoverResponseSchema,
  familyDetailResponseSchema,
  homeResponseSchema,
  requestTrackingSchema,
  integrationServiceUpdateSchema,
  automationServiceSchema,
  householdSettingsSchema,
  fuzzyMatchDecisionSchema,
  joinSchema,
  libraryQuerySchema,
  notificationReadSchema,
  movieNightCreateSchema,
  movieNightFiltersSchema,
  movieNightVoteSchema,
  movieNightWinnerSchema,
  pageQuerySchema,
  profileCreateSchema,
  profileUpdateSchema,
  plexSectionsUpdateSchema,
  pushSubscriptionSchema,
  reactionUpdateSchema,
  requestCreateSchema,
  requestsQuerySchema,
  selectProfileSchema,
  searchQuerySchema,
  signalsUpdateSchema,
  supporterPatchSchema,
  titleParamsSchema,
  type RequestRecord,
  type RequestStatus,
} from '@reelrequest/shared';
import type { AppDatabase } from './db/client.js';
import {
  devices,
  movieNights,
  movieNightVotes,
  notifications,
  plexItems,
  profiles,
  pushSubscriptions,
  reactions,
  signals,
  titles,
} from './db/schema.js';
import { ApiError, createAuth, hashPin, publicProfile, type AuthOptions } from './auth.js';
import { allowed, createFamily } from './family.js';
import type { createCatalog } from './catalog.js';
import type { PlexAdapter } from './integrations/plex/index.js';
import { createNotificationService } from './notifications.js';
import { createAutomationService } from './automation.js';

function parse<T>(
  schema: { safeParse: (value: unknown) => { success: true; data: T } | { success: false } },
  value: unknown,
): T {
  const parsed = schema.safeParse(value);
  if (!parsed.success)
    throw new ApiError(400, 'INVALID_INPUT', 'Check the submitted fields and try again.');
  return parsed.data;
}
function id(value: unknown) {
  const result = typeof value === 'string' && /^\d+$/.test(value) ? Number(value) : NaN;
  if (!Number.isSafeInteger(result) || result <= 0)
    throw new ApiError(400, 'INVALID_ID', 'Choose a valid item.');
  return result;
}
function page<T>(items: T[], query: { cursor?: string | undefined; limit: number }) {
  const offset =
    query.cursor === undefined ? 0 : /^\d+$/.test(query.cursor) ? Number(query.cursor) : NaN;
  if (!Number.isSafeInteger(offset) || offset < 0 || offset > 1000000)
    throw new ApiError(400, 'INVALID_CURSOR', 'This page cursor is invalid.');
  return {
    items: items.slice(offset, offset + query.limit),
    nextCursor: offset + query.limit < items.length ? String(offset + query.limit) : null,
  };
}
async function avatar(value: string): Promise<string> {
  if (value.startsWith('preset:')) return value;
  try {
    const bytes = Buffer.from(value.slice(value.indexOf(',') + 1), 'base64');
    if (bytes.byteLength > MAX_AVATAR_BYTES) throw new Error('Photo too large');
    const decoder = sharp(bytes, { limitInputPixels: 16000000, failOn: 'warning' });
    const metadata = await decoder.metadata();
    if (
      !metadata.format ||
      !['jpeg', 'png', 'webp'].includes(metadata.format) ||
      (metadata.pages ?? 1) !== 1
    )
      throw new Error('Unsupported photo');
    const sanitized = await decoder.rotate().resize(256, 256, { fit: 'cover' }).png().toBuffer();
    return `data:image/png;base64,${sanitized.toString('base64')}`;
  } catch {
    throw new ApiError(400, 'INVALID_AVATAR', 'Choose a valid PNG, JPEG, or WebP photo up to 2 MB.');
  }
}
export function mountFamilyRoutes(
  app: express.Express,
  database: AppDatabase,
  catalog: ReturnType<typeof createCatalog>,
  plex: PlexAdapter,
  options: AuthOptions = {},
  automationFetch: typeof fetch = fetch,
) {
  const auth = createAuth(database, options);
  const db = database.db;
  const streams = new Map<number, Set<express.Response>>();
  function closeStreams(deviceId: number) {
    const active = streams.get(deviceId);
    if (!active) return;
    for (const response of [...active]) {
      response.write('event: session\ndata: {}\n\n');
      response.end();
    }
    streams.delete(deviceId);
  }
  function emit(kind: 'requests' | 'profiles' | 'list' | 'notifications' | 'movie_night') {
    for (const active of streams.values())
      for (const response of active)
        response.write(`event: change\ndata: ${JSON.stringify({ kind })}\n\n`);
  }
  const notificationService = createNotificationService(database, auth.now);
  plex.setChangeListener(() => {
    emit('requests');
    emit('notifications');
    void notificationService.flushPush();
  });
  const family = createFamily(database, catalog, plex, auth.now, emit, notificationService);
  const automation = createAutomationService(
    database,
    catalog,
    (titleId) => {
      const title = db.select().from(titles).where(eq(titles.id, titleId)).get();
      return title ? family.card(title) : null;
    },
    emit,
    notificationService,
    automationFetch,
    auth.now,
  );
  async function plexAction<T>(action: () => Promise<T>): Promise<T> {
    try {
      return await action();
    } catch {
      throw new ApiError(
        502,
        'PLEX_UNAVAILABLE',
        'Plex could not complete that request. Check the server and try again.',
      );
    }
  }
  function sameSecret(value: string, expected: string) {
    const left = Buffer.from(value),
      right = Buffer.from(expected);
    return left.length === right.length && timingSafeEqual(left, right);
  }
  app.post('/api/plex/webhook/:secret', async (request, response) => {
    const secret = process.env.PLEX_WEBHOOK_SECRET ?? '';
    if (!secret || !sameSecret(request.params.secret ?? '', secret)) {
      response.status(404).json({ error: { code: 'NOT_FOUND', message: 'Webhook not found.' } });
      return;
    }
    const chunks: Buffer[] = [];
    let size = 0;
    for await (const chunk of request) {
      const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
      size += bytes.length;
      if (size > 1_000_000) {
        response
          .status(413)
          .json({ error: { code: 'WEBHOOK_TOO_LARGE', message: 'Webhook payload is too large.' } });
        return;
      }
      chunks.push(bytes);
    }
    const body = Buffer.concat(chunks).toString('utf8');
    const match = body.match(
      /name="payload"[^\r\n]*\r?\n(?:Content-Type:[^\r\n]*\r?\n)?\r?\n([\s\S]*?)\r?\n--/i,
    );
    let event: unknown;
    try {
      event = JSON.parse(match?.[1] ?? '');
    } catch {
      response
        .status(400)
        .json({ error: { code: 'INVALID_WEBHOOK', message: 'Webhook payload is invalid.' } });
      return;
    }
    const record = event && typeof event === 'object' ? (event as Record<string, unknown>) : {};
    if (record.event === 'library.new') {
      const timer = setTimeout(() => {
        void plex.sync().catch(() => undefined);
      }, 30_000);
      timer.unref();
    }
    response.status(202).json({ ok: true });
  });
  function recheck(request: express.Request, profileId: number, rating?: number | null) {
    const fresh = auth.context(request);
    if (
      fresh.profile.id !== profileId ||
      (rating !== undefined && fresh.profile.maxRatingLevel !== rating)
    )
      throw new ApiError(409, 'SESSION_CHANGED', 'Your profile changed. Reload this page.');
    return fresh.profile;
  }
  function session(request: express.Request) {
    const device = auth.device(request);
    const profile = device && auth.selected(device);
    return {
      configured: auth.configured(),
      trusted: Boolean(device),
      profile: profile ? publicProfile(profile) : null,
      adminUnlocked: Boolean(
        profile?.isAdmin &&
        device?.adminUnlockedUntil &&
        Date.parse(device.adminUnlockedUntil) > auth.now().getTime(),
      ),
      timeZone: process.env.TZ ?? 'America/Chicago',
    };
  }
  app.use('/api', async (request, response, next) => {
    await auth.ready;
    auth.mutationGuard(request);
    response.setHeader('Cache-Control', 'no-store');
    next();
  });
  mountStorage(app,database,auth,process.env.STORAGE_INVENTORY_ENABLED==='1'?[{library:'Movies',path:'/inventory/movies'},{library:'TV',path:'/inventory/tv'}]:[]);
  mountSuggestions(app, database, auth, notificationService, () => emit('notifications'));
  mountTitleSocial(app, database, auth, notificationService, () => emit('notifications'));
  app.get('/api/session', (request, response) => {
    response.json(session(request));
  });
  app.post('/api/household/join', async (request, response) => {
    await auth.join(request, response, parse(joinSchema, request.body));
    response.json({
      configured: true,
      trusted: true,
      profile: null,
      adminUnlocked: false,
      timeZone: process.env.TZ ?? 'America/Chicago',
    });
  });
  app.get('/api/profiles', (request, response) => {
    auth.requireDevice(request);
    response.json({
      profiles: db
        .select()
        .from(profiles)
        .where(eq(profiles.disabled, false))
        .all()
        .map(publicProfile),
    });
  });
  app.post('/api/session', async (request, response) => {
    const device = auth.requireDevice(request);
    await auth.select(request, parse(selectProfileSchema, request.body));
    closeStreams(device.id);
    response.json(session(request));
  });
  app.delete('/api/session', (request, response) => {
    const device = auth.requireDevice(request);
    db.update(devices)
      .set({ currentProfileId: null, adminUnlockedUntil: null })
      .where(eq(devices.id, device.id))
      .run();
    closeStreams(device.id);
    response.json(session(request));
  });
  app.post('/api/admin/unlock', async (request, response) => {
    await auth.unlock(request, parse(adminUnlockSchema, request.body).pin);
    response.json(session(request));
  });
  app.get('/api/home', async (request, response) => {
    const { profile } = auth.context(request);
    const query = parse(browseQuerySchema, request.query);
    const result = await family.home(profile, query.type);
    // Recheck after upstream waits so a profile switch/revocation cannot expose the old profile's data.
    recheck(request, profile.id, profile.maxRatingLevel);
    const requested = family
      .all(profile)
      .filter(
        (entry) =>
          ['requested', 'looking', 'available'].includes(entry.status) &&
          (!query.type || entry.title.mediaType === query.type),
      )
      .slice(0, 20)
      .map((entry) => entry.title);
    if (requested.length)
      result.rows.push({
        id: 'family-requests',
        title: 'Requested by Your Family',
        items: requested,
      });
    response.json(homeResponseSchema.parse(result));
  });
  app.get('/api/discover', async (request, response) => {
    const { profile } = auth.context(request);
    const query = parse(discoverQuerySchema, request.query);
    const result = await family.discover(profile, query);
    recheck(request, profile.id, profile.maxRatingLevel);
    response.json(discoverResponseSchema.parse(result));
  });
  app.get('/api/search', async (request, response) => {
    const { profile } = auth.context(request);
    const query = parse(searchQuerySchema, request.query);
    const library = await family.library(profile);
    const genres = [
      ...new Set(
        library.flatMap(
          ({ title }) =>
            title?.genres.flatMap((genre) =>
              genre &&
              typeof genre === 'object' &&
              'name' in genre &&
              typeof genre.name === 'string'
                ? [genre.name]
                : [],
            ) ?? [],
        ),
      ),
    ].sort();
    const result = query.q
      ? await family.search(profile, query.q)
      : { items: library.map((entry) => entry.card).slice(0, 100), person: null, stale: false };
    recheck(request, profile.id, profile.maxRatingLevel);
    if (query.type) result.items = result.items.filter((item) => item.mediaType === query.type);
    if (query.plex) result.items = result.items.filter((item) => item.plexState === query.plex);
    if (query.genre) {
      const permitted = new Set(
        library
          .filter(({ title }) =>
            title?.genres.some(
              (genre) =>
                genre && typeof genre === 'object' && 'name' in genre && genre.name === query.genre,
            ),
          )
          .map(({ card }) => `${card.mediaType}:${card.tmdbId}`),
      );
      result.items = result.items.filter((item) =>
        permitted.has(`${item.mediaType}:${item.tmdbId}`),
      );
    }
    response.json({ results: result.items, person: result.person, genres });
  });
  app.put('/api/reactions', async (request, response) => {
    const { profile } = auth.context(request);
    const input = parse(reactionUpdateSchema, request.body);
    const detail = await family.permitted(input.mediaType, input.tmdbId, profile, () =>
      recheck(request, profile.id, profile.maxRatingLevel),
    );
    if (input.reaction === null)
      db.delete(reactions)
        .where(and(eq(reactions.profileId, profile.id), eq(reactions.titleId, detail.stored.id)))
        .run();
    else
      db.insert(reactions)
        .values({
          profileId: profile.id,
          titleId: detail.stored.id,
          value: input.reaction,
          updatedAt: auth.now().toISOString(),
        })
        .onConflictDoUpdate({
          target: [reactions.profileId, reactions.titleId],
          set: { value: input.reaction, updatedAt: auth.now().toISOString() },
        })
        .run();
    response.json({ ok: true });
  });
  app.post('/api/signals', async (request, response) => {
    const { profile } = auth.context(request);
    const input = parse(signalsUpdateSchema, request.body);
    for (const item of input.signals) {
      const detail = await family.permitted(item.mediaType, item.tmdbId, profile, () =>
        recheck(request, profile.id, profile.maxRatingLevel),
      );
      db.insert(signals)
        .values({
          profileId: profile.id,
          titleId: detail.stored.id,
          kind: item.kind,
          ...(item.createdAt ? { createdAt: item.createdAt } : {}),
        })
        .run();
    }
    response.status(201).json({ ok: true });
  });
  app.get('/api/titles/:mediaType/:tmdbId', async (request, response) => {
    const context = auth.context(request);
    const params = parse(titleParamsSchema, request.params);
    const result = await family.detail(
      context.profile,
      params.mediaType,
      params.tmdbId,
      context.adminUnlocked,
    );
    recheck(request, context.profile.id, context.profile.maxRatingLevel);
    if (context.adminUnlocked) auth.admin(request);
    response.json(familyDetailResponseSchema.parse(result));
  });
  function requestList(request: express.Request, admin: boolean) {
    const context = admin ? auth.admin(request) : auth.context(request);
    const query = parse(requestsQuerySchema, request.query);
    let items = family
      .all(context.profile, admin)
      .filter(
        (entry) =>
          (query.scope !== 'mine' || entry.isSupporter) &&
          (!query.status || entry.status === query.status) &&
          (!query.person || entry.supporters.some((person) => person.profileId === query.person)) &&
          (!query.type || entry.title.mediaType === query.type),
      );
    if (query.filter === 'coming_soon')
      items = items.filter((entry) => entry.title.releaseState === 'coming_soon');
    if (query.filter === 'ready')
      items = items.filter(
        (entry) =>
          ['requested', 'looking'].includes(entry.status) &&
          entry.title.releaseState === 'released' &&
          entry.title.plexState === 'unavailable',
      );
    if (query.approval === 'awaiting')
      items = items.filter((entry) => !entry.automation || entry.automation.decision === 'pending');
    if (query.approval === 'approved')
      items = items.filter((entry) => entry.automation?.decision === 'approved');
    if (query.approval === 'declined')
      items = items.filter((entry) => entry.automation?.decision === 'declined');
    if (query.approval === 'attention')
      items = items.filter(
        (entry) =>
          entry.automation?.decision === 'approved' &&
          entry.automation.submissionStatus === 'failed',
      );
    items.sort((a, b) =>
      query.sort === 'supporters'
        ? b.supporters.length - a.supporters.length || b.id - a.id
        : query.sort === 'oldest'
          ? a.id - b.id
          : b.id - a.id,
    );
    const result = page(items, query);
    return { requests: result.items, nextCursor: result.nextCursor };
  }
  app.get('/api/requests', (request, response) => {
    response.json(requestList(request, false));
  });
  app.get('/api/admin/requests', (request, response) => {
    response.json(requestList(request, true));
  });
  app.get('/api/requests/:id', (request, response) => {
    const { profile, adminUnlocked } = auth.context(request);
    response.json({
      request: family.record(
        family.findRequest(id(request.params.id), profile).request,
        profile,
        adminUnlocked,
      ),
    });
  });
  app.get('/api/requests/:id/tracking', async (request, response) => {
    const { profile } = auth.context(request);
    const found = family.findRequest(id(request.params.id), profile);
    const result = await automation.tracking(found.request.id);
    recheck(request, profile.id, profile.maxRatingLevel);
    response.json(requestTrackingSchema.parse(result));
  });
  app.get('/api/admin/requests/:id', (request, response) => {
    const { profile } = auth.admin(request);
    response.json({
      request: family.record(
        family.findRequest(id(request.params.id), profile).request,
        profile,
        true,
      ),
    });
  });
  app.post('/api/requests', async (request, response) => {
    const { profile } = auth.context(request);
    const input = parse(requestCreateSchema, request.body);
    const result = await family.create(profile, input, () =>
      recheck(request, profile.id, profile.maxRatingLevel),
    );
    if (result.automation?.decision === 'approved') void automation.run();
    response.status(201).json({ request: result });
  });
  app.patch('/api/requests/:id/support', (request, response) => {
    const { profile } = auth.context(request);
    const patch = parse(supporterPatchSchema, request.body);
    response.json({
      request: Object.keys(patch).length
        ? family.support(profile, id(request.params.id), patch)
        : family.record(family.findRequest(id(request.params.id), profile).request, profile),
    });
  });
  app.delete('/api/requests/:id/support', (request, response) => {
    response.json({
      request: family.withdraw(auth.context(request).profile, id(request.params.id)),
    });
  });
  app.post('/api/requests/:id/watched', (request, response) => {
    const { profile, adminUnlocked } = auth.context(request);
    response.json({ request: family.watched(profile, id(request.params.id), adminUnlocked) });
  });
  app.patch('/api/admin/requests/:id', (request, response) => {
    response.json({
      request: family.adminPatch(
        auth.admin(request).profile,
        id(request.params.id),
        parse(adminRequestPatchSchema, request.body),
      ),
    });
  });
  app.post('/api/admin/requests/:id/approval', (request, response) => {
    const { profile } = auth.admin(request);
    const requestId = id(request.params.id);
    const input = parse(approvalActionSchema, request.body);
    automation.decide(
      requestId,
      profile.id,
      input.decision,
      input.decision === 'declined' ? input.reason : undefined,
    );
    response.json({
      request: family.record(family.findRequest(requestId, profile).request, profile, true),
    });
  });
  app.get('/api/admin/approval-preview', (request, response) => {
    const { profile } = auth.admin(request);
    const pending = family
      .all(profile, true)
      .filter(
        (entry) =>
          ['requested', 'looking'].includes(entry.status) &&
          (!entry.automation || entry.automation.decision === 'pending'),
      );
    response.json({ requests: pending.slice(0, 500), nextCursor: null });
  });
  app.post('/api/admin/approve-all', (request, response) => {
    const { profile } = auth.admin(request);
    const { ids } = parse(bulkApprovalSchema, request.body);
    const pending = new Set(
      family
        .all(profile, true)
        .filter(
          (entry) =>
            ['requested', 'looking'].includes(entry.status) &&
            (!entry.automation || entry.automation.decision === 'pending'),
        )
        .map((entry) => entry.id),
    );
    let approved = 0;
    for (const requestId of new Set(ids))
      if (pending.has(requestId)) {
        automation.decide(requestId, profile.id, 'approved');
        approved++;
      }
    response.json({ ok: true, approved });
  });
  app.post('/api/admin/requests/:id/retry', (request, response) => {
    const { profile } = auth.admin(request);
    const requestId = id(request.params.id);
    automation.retry(requestId, profile.id);
    response.json({
      request: family.record(family.findRequest(requestId, profile).request, profile, true),
    });
  });
  app.get('/api/list', (request, response) => {
    const items = family.list(auth.context(request).profile);
    const result = page(items, parse(pageQuerySchema, request.query));
    response.json(result);
  });
  app.get('/api/notifications', (request, response) => {
    const { profile } = auth.context(request);
    const rows = db
      .select({ notification: notifications, title: titles })
      .from(notifications)
      .leftJoin(titles, eq(titles.id, notifications.titleId))
      .where(eq(notifications.profileId, profile.id))
      .orderBy(desc(notifications.id))
      .limit(100)
      .all();
    response.json({
      notifications: rows.map(({ notification, title }) => ({
        id: notification.id,
        kind: notification.kind,
        requestId: notification.requestId,
        titleId: notification.titleId,
        title: title?.title ?? null,
        mediaType: title?.mediaType ?? null,
        tmdbId: title?.tmdbId ?? null,
        body: notification.body,
        readAt: notification.readAt,
        createdAt: notification.createdAt,
      })),
      unread: rows.filter(({ notification }) => !notification.readAt).length,
    });
  });
  app.post('/api/notifications/read', (request, response) => {
    const { profile } = auth.context(request);
    const input = parse(notificationReadSchema, request.body);
    notificationService.markRead(profile.id, input.all ? undefined : input.ids);
    emit('notifications');
    response.json({ ok: true });
  });
  app.get('/api/push/config', (request, response) => {
    auth.context(request);
    const base = process.env.BASE_URL ?? '';
    response.json({
      enabled: notificationService.enabled,
      publicKey: notificationService.publicKey,
      secureContext:
        /^https:\/\//.test(base) || /^http:\/\/(?:localhost|127\.0\.0\.1)(?::|\/|$)/.test(base),
    });
  });
  app.post('/api/push/subscribe', (request, response) => {
    const { profile, device } = auth.context(request);
    const input = parse(pushSubscriptionSchema, request.body);
    if (!notificationService.enabled)
      throw new ApiError(503, 'PUSH_NOT_CONFIGURED', 'Push notifications are not configured.');
    db.insert(pushSubscriptions)
      .values({
        profileId: profile.id,
        deviceId: device.id,
        endpoint: input.endpoint,
        keys: input.keys,
      })
      .onConflictDoUpdate({
        target: pushSubscriptions.endpoint,
        set: { profileId: profile.id, deviceId: device.id, keys: input.keys },
      })
      .run();
    response.status(201).json({ ok: true });
  });
  app.get('/api/library', async (request, response) => {
    const { profile } = auth.context(request);
    const query = parse(libraryQuerySchema, request.query);
    const sectionIds =
      query.section === 'standup'
        ? (await plex.sections())
            .filter((section) => /^stand[\s-]*up comedy$/i.test(section.title.trim()))
            .map((section) => section.key)
        : undefined;
    let entries = await family.library(profile, sectionIds);
    recheck(request, profile.id, profile.maxRatingLevel);
    const genres = [
      ...new Set(
        entries.flatMap(({ title }) =>
          title && Array.isArray(title.genres)
            ? title.genres.flatMap((genre) =>
                genre &&
                typeof genre === 'object' &&
                'name' in genre &&
                typeof genre.name === 'string'
                  ? [genre.name]
                  : [],
              )
            : [],
        ),
      ),
    ].sort();
    if (query.type) entries = entries.filter(({ card }) => card.mediaType === query.type);
    if (query.genre)
      entries = entries.filter(
        ({ title }) =>
          title &&
          Array.isArray(title.genres) &&
          title.genres.some(
            (genre) =>
              genre && typeof genre === 'object' && 'name' in genre && genre.name === query.genre,
          ),
      );
    entries.sort((a, b) =>
      query.sort === 'title'
        ? a.card.title.localeCompare(b.card.title)
        : query.sort === 'year'
          ? (b.card.year ?? 0) - (a.card.year ?? 0)
          : query.sort === 'score'
            ? (b.card.tmdbScore ?? 0) - (a.card.tmdbScore ?? 0)
            : (b.item.addedAt ?? '').localeCompare(a.item.addedAt ?? ''),
    );
    const result = page(
      entries.map((entry) => entry.card),
      query,
    );
    response.json({ ...result, genres, lastSuccessfulSyncAt: plex.lastSuccessfulSyncAt() });
  });
  for (const method of ['put', 'delete'] as const)
    app[method]('/api/list/:mediaType/:tmdbId', async (request, response) => {
      const params = parse(titleParamsSchema, request.params);
      const { profile } = auth.context(request);
      await family.bookmark(profile, params.mediaType, params.tmdbId, method === 'put', () =>
        recheck(request, profile.id, profile.maxRatingLevel),
      );
      response.json({ ok: true });
    });
  app.get('/api/admin/plex/items', (request, response) => {
    const { profile } = auth.admin(request);
    response.json({
      items: db
        .select()
        .from(plexItems)
        .all()
        .filter(
          (item) =>
            profile.maxRatingLevel === null ||
            Boolean(
              item.tmdbId &&
              allowed(profile, family.row(item.mediaType, item.tmdbId)?.certification ?? null),
            ),
        )
        .map((item) => ({
          ratingKey: item.ratingKey,
          title: item.title,
          mediaType: item.mediaType,
          year: item.year,
        })),
    });
  });
  app.get('/api/admin/plex', async (request, response) => {
    auth.admin(request);
    const description = plex.describe();
    let serverName: string | null = null,
      version: string | null = null,
      sections: Awaited<ReturnType<typeof plex.sections>> = [];
    if (description.ready) {
      try {
        const [identity, available] = await Promise.all([plex.test(), plex.sections()]);
        serverName = identity.serverName;
        version = identity.version;
        sections = available;
      } catch {
        /* The settings screen still reports the saved sync time during an outage. */
      }
    }
    const included = new Set(plex.includedSections());
    response.json({
      configured: description.mode === 'configured',
      connected: Boolean(serverName),
      serverName,
      version,
      lastSuccessfulSyncAt: plex.lastSuccessfulSyncAt(),
      sections: sections.map((section) => ({ ...section, included: included.has(section.key) })),
    });
  });
  app.post('/api/admin/plex/test', async (request, response) => {
    auth.admin(request);
    response.json(await plexAction(() => plex.test()));
  });
  app.put('/api/admin/plex/sections', async (request, response) => {
    auth.admin(request);
    const input = parse(plexSectionsUpdateSchema, request.body);
    await plexAction(() => plex.setIncludedSections(input.sectionIds));
    response.json({ ok: true });
  });
  app.post('/api/admin/plex/sync', async (request, response) => {
    auth.admin(request);
    response.json(await plexAction(() => plex.sync()));
  });
  app.get('/api/admin/plex/matches', (request, response) => {
    auth.admin(request);
    const matches = db
      .select()
      .from(titles)
      .where(eq(titles.plexMatch, 'fuzzy'))
      .all()
      .flatMap((title) => {
        const item = title.plexRatingKey
          ? db.select().from(plexItems).where(eq(plexItems.ratingKey, title.plexRatingKey)).get()
          : null;
        return item
          ? [
              {
                titleId: title.id,
                title: title.title,
                year: title.year,
                mediaType: title.mediaType,
                ratingKey: item.ratingKey,
                plexTitle: item.title,
                plexYear: item.year,
              },
            ]
          : [];
      });
    response.json({ matches });
  });
  app.post('/api/admin/plex/matches/:titleId', (request, response) => {
    auth.admin(request);
    const titleId = id(request.params.titleId);
    const decision = parse(fuzzyMatchDecisionSchema, request.body);
    if (!plex.decideFuzzy(titleId, decision.accept))
      throw new ApiError(404, 'MATCH_NOT_FOUND', 'That fuzzy match is no longer pending.');
    response.json({ ok: true });
  });
  app.get('/api/admin/stats', (request, response) => {
    const items = family.all(auth.admin(request).profile, true);
    const counts: Record<RequestStatus, number> = {
      requested: 0,
      looking: 0,
      available: 0,
      watched: 0,
      passed: 0,
      cancelled: 0,
    };
    items.forEach((entry) => counts[entry.status]++);
    const releaseDate = (entry: RequestRecord) => {
      const title = family.row(entry.title.mediaType, entry.title.tmdbId);
      return (
        title?.releaseDigital ??
        title?.releasePhysical ??
        title?.nextAirDate ??
        title?.releaseTheatrical ??
        '9999'
      );
    };
    const coming = items
      .filter((entry) => entry.title.releaseState === 'coming_soon')
      .sort((a, b) => releaseDate(a).localeCompare(releaseDate(b)));
    const ready = items.filter(
      (entry) =>
        ['requested', 'looking'].includes(entry.status) &&
        entry.title.releaseState === 'released' &&
        entry.title.plexState === 'unavailable',
    );
    const people = new Map<number, { profileId: number; name: string; count: number }>();
    items.forEach((entry) =>
      entry.supporters.forEach((person) => {
        const existing = people.get(person.profileId);
        people.set(person.profileId, {
          profileId: person.profileId,
          name: person.name,
          count: (existing?.count ?? 0) + 1,
        });
      }),
    );
    const recent = (a: RequestRecord, b: RequestRecord) =>
      (b.availableAt ?? '').localeCompare(a.availableAt ?? '');
    response.json({
      total: items.length,
      counts,
      comingSoon: coming.length,
      readyToGet: ready.length,
      mostRequested: [...items]
        .sort((a, b) => b.supporters.length - a.supporters.length)
        .slice(0, 5),
      byPerson: [...people.values()].sort((a, b) => b.count - a.count),
      comingSoonRequests: coming.slice(0, 5),
      recentlyAvailable: items
        .filter((entry) => entry.availableAt)
        .sort(recent)
        .slice(0, 5),
    });
  });
  app.get('/api/admin/profiles', (request, response) => {
    auth.admin(request);
    response.json({
      profiles: db
        .select()
        .from(profiles)
        .where(eq(profiles.disabled, false))
        .all()
        .map(publicProfile),
    });
  });
  app.post('/api/admin/profiles', async (request, response) => {
    auth.admin(request);
    const input = parse(profileCreateSchema, request.body);
    if (input.isAdmin && !input.pin)
      throw new ApiError(400, 'ADMIN_PIN_REQUIRED', 'Admin profiles require a PIN.');
    const { pin, ...fields } = input;
    const photo = await avatar(input.avatar);
    const pinHash = pin ? await hashPin(pin) : null;
    auth.admin(request);
    const result = db
      .insert(profiles)
      .values({ ...fields, avatar: photo, pinHash })
      .returning()
      .get()!;
    emit('profiles');
    response.status(201).json({ profile: publicProfile(result) });
  });
  function protectLastAdmin(profileId: number) {
    const admins = db
      .select()
      .from(profiles)
      .where(and(eq(profiles.isAdmin, true), eq(profiles.disabled, false)))
      .all();
    if (admins.length === 1 && admins[0]?.id === profileId)
      throw new ApiError(409, 'LAST_ADMIN', 'Keep at least one admin profile.');
  }
  app.patch('/api/admin/profiles/:id', async (request, response) => {
    auth.admin(request);
    const profileId = id(request.params.id);
    const original = db
      .select()
      .from(profiles)
      .where(and(eq(profiles.id, profileId), eq(profiles.disabled, false)))
      .get();
    if (!original) throw new ApiError(404, 'PROFILE_NOT_FOUND', 'That profile is unavailable.');
    const input = parse(profileUpdateSchema, request.body);
    const { pin, ...fields } = input;
    const photo = input.avatar === undefined ? undefined : await avatar(input.avatar);
    const pinHash = pin === undefined ? undefined : pin === null ? null : await hashPin(pin);
    auth.admin(request);
    db.transaction(() => {
      const current = db.select().from(profiles).where(eq(profiles.id, profileId)).get();
      if (!current || current.disabled)
        throw new ApiError(404, 'PROFILE_NOT_FOUND', 'That profile is unavailable.');
      if (input.isAdmin === false) protectLastAdmin(profileId);
      if (
        (input.isAdmin ?? current.isAdmin) &&
        !(pinHash === undefined ? current.pinHash : pinHash)
      )
        throw new ApiError(400, 'ADMIN_PIN_REQUIRED', 'Admin profiles require a PIN.');
      if (Object.keys(input).length)
        db.update(profiles)
          .set({
            ...fields,
            ...(photo === undefined ? {} : { avatar: photo }),
            ...(pinHash === undefined ? {} : { pinHash }),
          })
          .where(eq(profiles.id, profileId))
          .run();
      const affected = db
        .select()
        .from(devices)
        .where(eq(devices.currentProfileId, profileId))
        .all();
      for (const device of affected) {
        db.update(devices)
          .set({
            adminUnlockedUntil: null,
            ...(pin !== undefined ? { currentProfileId: null } : {}),
          })
          .where(eq(devices.id, device.id))
          .run();
        closeStreams(device.id);
      }
    });
    emit('profiles');
    response.json({
      profile: publicProfile(db.select().from(profiles).where(eq(profiles.id, profileId)).get()!),
    });
  });
  app.delete('/api/admin/profiles/:id', (request, response) => {
    auth.admin(request);
    const profileId = id(request.params.id);
    protectLastAdmin(profileId);
    const current = db.select().from(profiles).where(eq(profiles.id, profileId)).get();
    if (!current || current.disabled)
      throw new ApiError(404, 'PROFILE_NOT_FOUND', 'That profile is unavailable.');
    db.transaction(() => {
      db.update(profiles).set({ disabled: true }).where(eq(profiles.id, profileId)).run();
      const affected = db
        .select()
        .from(devices)
        .where(eq(devices.currentProfileId, profileId))
        .all();
      db.update(devices)
        .set({ currentProfileId: null, adminUnlockedUntil: null })
        .where(eq(devices.currentProfileId, profileId))
        .run();
      affected.forEach((device) => closeStreams(device.id));
    });
    emit('profiles');
    response.json({ ok: true });
  });
  app.get('/api/admin/devices', (request, response) => {
    const { device } = auth.admin(request);
    response.json({
      devices: db
        .select()
        .from(devices)
        .all()
        .map((entry) => ({
          id: entry.id,
          label: entry.label,
          lastSeenAt: entry.lastSeenAt,
          createdAt: entry.createdAt,
          isCurrent: entry.id === device.id,
        })),
    });
  });
  app.delete('/api/admin/devices/:id', (request, response) => {
    auth.admin(request);
    const deviceId = id(request.params.id);
    db.delete(devices).where(eq(devices.id, deviceId)).run();
    closeStreams(deviceId);
    response.json({ ok: true });
  });
  app.get('/api/admin/settings', (request, response) => {
    auth.admin(request);
    response.json({ passcodeConfigured: auth.configured() });
  });
  app.put('/api/admin/settings', async (request, response) => {
    auth.admin(request);
    const input = parse(householdSettingsSchema, request.body);
    await auth.resetPasscode(input.passcode, () => {
      auth.admin(request);
    });
    response.json({ ok: true });
  });
  app.get('/api/admin/integrations', async (request, response) => {
    auth.admin(request);
    response.json({ services: await automation.settings() });
  });
  app.put('/api/admin/integrations/:service', async (request, response) => {
    auth.admin(request);
    const service = parse(automationServiceSchema, request.params.service);
    automation.save(service, parse(integrationServiceUpdateSchema, request.body));
    response.json(await automation.inspect(service));
  });
  app.post('/api/admin/integrations/:service/test', async (request, response) => {
    auth.admin(request);
    const service = parse(automationServiceSchema, request.params.service);
    const result = await automation.inspect(service);
    if (!result.connected)
      throw new ApiError(
        502,
        'INTEGRATION_UNAVAILABLE',
        result.error ?? `${service} is unavailable.`,
      );
    response.json(result);
  });
  function nightFilters(row: typeof movieNights.$inferSelect) {
    const parsed = movieNightFiltersSchema.safeParse(row.filters);
    if (!parsed.success)
      throw new ApiError(500, 'MOVIE_NIGHT_INVALID', 'This Movie Night cannot be read.');
    return parsed.data;
  }
  function nightCandidates(
    participantRows: (typeof profiles.$inferSelect)[],
    filters: ReturnType<typeof nightFilters>,
    exclude: number[] = [],
  ) {
    const excluded = new Set(exclude);
    const candidates = db
      .select()
      .from(titles)
      .all()
      .filter((title) => !excluded.has(title.id))
      .filter((title) => family.card(title).plexState === 'available')
      .filter((title) => filters.type === 'both' || title.mediaType === filters.type)
      .filter(
        (title) =>
          !filters.maxRuntime || !title.runtimeMin || title.runtimeMin <= filters.maxRuntime,
      )
      .filter((title) => participantRows.every((profile) => allowed(profile, title.certification)))
      .map((title) => {
        const taste = database.sqlite
          .prepare(
            `SELECT COALESCE(SUM(CASE value WHEN 'up' THEN 3 ELSE -4 END),0) score
             FROM reactions WHERE title_id=? AND profile_id IN (${participantRows.map(() => '?').join(',')})`,
          )
          .get(title.id, ...participantRows.map((profile) => profile.id)) as { score: number };
        return { title, score: taste.score + Math.random() };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 10)
      .map(({ title }) => title);
    return candidates;
  }
  function populateNight(
    nightId: number,
    participantRows: (typeof profiles.$inferSelect)[],
    filters: ReturnType<typeof nightFilters>,
    exclude: number[] = [],
  ) {
    for (const title of nightCandidates(participantRows, filters, exclude))
      db.insert(movieNightVotes)
        .values({ movieNightId: nightId, titleId: title.id, profileId: null, vote: null })
        .run();
  }
  function serializeNight(row: typeof movieNights.$inferSelect, viewerId: number) {
    const filters = nightFilters(row);
    const participantRows = db
      .select()
      .from(profiles)
      .where(inArray(profiles.id, filters.participants))
      .all();
    const host = participantRows.find((profile) => profile.id === row.hostProfileId);
    const candidates = db
      .select()
      .from(movieNightVotes)
      .where(and(eq(movieNightVotes.movieNightId, row.id), isNull(movieNightVotes.profileId)))
      .all();
    const records = candidates.map((candidate) => {
      const title = db.select().from(titles).where(eq(titles.id, candidate.titleId)).get()!;
      const votes = db
        .select({ profileId: movieNightVotes.profileId, vote: movieNightVotes.vote })
        .from(movieNightVotes)
        .where(
          and(
            eq(movieNightVotes.movieNightId, row.id),
            eq(movieNightVotes.titleId, candidate.titleId),
          ),
        )
        .all()
        .flatMap((vote) => {
          const person = participantRows.find((profile) => profile.id === vote.profileId);
          return person && vote.vote !== null
            ? [{ profileId: person.id, name: person.name, vote: vote.vote }]
            : [];
        });
      const average = votes.length
        ? votes.reduce((sum, vote) => sum + vote.vote, 0) / votes.length
        : null;
      return {
        titleId: title.id,
        title: family.card(title),
        myVote: votes.find((vote) => vote.profileId === viewerId)?.vote ?? null,
        average,
        matchPercent: average === null ? null : Math.round((average / 3) * 100),
        hasNope: votes.some((vote) => vote.vote === 0),
        votes: row.status === 'closed' ? votes : [],
      };
    });
    records.sort(
      (a, b) =>
        Number(a.hasNope) - Number(b.hasNope) ||
        (b.average ?? -1) - (a.average ?? -1) ||
        a.title.title.localeCompare(b.title.title),
    );
    return {
      id: row.id,
      hostProfileId: row.hostProfileId,
      hostName: host?.name ?? 'Family host',
      status: row.status,
      filters,
      participants: participantRows.map(publicProfile),
      candidates: records,
      winnerTitleId: row.winnerTitleId,
      createdAt: row.createdAt,
      closedAt: row.closedAt,
    };
  }
  app.get('/api/movie-nights/current', (request, response) => {
    const { profile } = auth.context(request);
    const row = db
      .select()
      .from(movieNights)
      .where(eq(movieNights.status, 'voting'))
      .orderBy(desc(movieNights.id))
      .all()
      .find((night) => nightFilters(night).participants.includes(profile.id));
    response.json({ movieNight: row ? serializeNight(row, profile.id) : null });
  });
  app.post('/api/movie-nights', (request, response) => {
    const { profile } = auth.context(request);
    const filters = parse(movieNightCreateSchema, request.body);
    const participants = [...new Set([profile.id, ...filters.participants])];
    const participantRows = db
      .select()
      .from(profiles)
      .where(and(inArray(profiles.id, participants), eq(profiles.disabled, false)))
      .all();
    if (participantRows.length !== participants.length)
      throw new ApiError(400, 'INVALID_PARTICIPANTS', 'Choose active family profiles.');
    const savedFilters = { ...filters, participants };
    const row = db.transaction(() => {
      const created = db
        .insert(movieNights)
        .values({ hostProfileId: profile.id, filters: savedFilters })
        .returning()
        .get()!;
      populateNight(created.id, participantRows, savedFilters);
      return created;
    });
    emit('movie_night');
    response.status(201).json({ movieNight: serializeNight(row, profile.id) });
  });
  app.get('/api/movie-nights/:id', (request, response) => {
    const { profile } = auth.context(request);
    const row = db
      .select()
      .from(movieNights)
      .where(eq(movieNights.id, id(request.params.id)))
      .get();
    if (!row || !nightFilters(row).participants.includes(profile.id))
      throw new ApiError(404, 'MOVIE_NIGHT_NOT_FOUND', 'That Movie Night is unavailable.');
    response.json({ movieNight: serializeNight(row, profile.id) });
  });
  app.post('/api/movie-nights/:id/reshuffle', (request, response) => {
    const { profile } = auth.context(request);
    const row = db
      .select()
      .from(movieNights)
      .where(eq(movieNights.id, id(request.params.id)))
      .get();
    if (!row || row.status !== 'voting' || row.hostProfileId !== profile.id)
      throw new ApiError(403, 'HOST_REQUIRED', 'Only the host can reshuffle.');
    const filters = nightFilters(row);
    const participants = db
      .select()
      .from(profiles)
      .where(inArray(profiles.id, filters.participants))
      .all();
    const old = db
      .select({ titleId: movieNightVotes.titleId })
      .from(movieNightVotes)
      .where(and(eq(movieNightVotes.movieNightId, row.id), isNull(movieNightVotes.profileId)))
      .all()
      .map((item) => item.titleId);
    db.transaction(() => {
      db.delete(movieNightVotes).where(eq(movieNightVotes.movieNightId, row.id)).run();
      populateNight(row.id, participants, filters, old);
    });
    emit('movie_night');
    response.json({ movieNight: serializeNight(row, profile.id) });
  });
  app.put('/api/movie-nights/:id/vote', (request, response) => {
    const { profile } = auth.context(request);
    const input = parse(movieNightVoteSchema, request.body);
    const row = db
      .select()
      .from(movieNights)
      .where(eq(movieNights.id, id(request.params.id)))
      .get();
    if (!row || row.status !== 'voting')
      throw new ApiError(404, 'MOVIE_NIGHT_NOT_FOUND', 'That Movie Night is unavailable.');
    const filters = nightFilters(row);
    const voter = input.voterProfileId ?? profile.id;
    if (!filters.participants.includes(profile.id) || !filters.participants.includes(voter))
      throw new ApiError(403, 'PARTICIPANT_REQUIRED', 'Only participants can vote.');
    if (voter !== profile.id && (filters.mode !== 'pass_phone' || row.hostProfileId !== profile.id))
      throw new ApiError(403, 'VOTER_REQUIRED', 'Switch to that profile to record this vote.');
    const candidate = db
      .select()
      .from(movieNightVotes)
      .where(
        and(
          eq(movieNightVotes.movieNightId, row.id),
          eq(movieNightVotes.titleId, input.titleId),
          isNull(movieNightVotes.profileId),
        ),
      )
      .get();
    if (!candidate) throw new ApiError(400, 'INVALID_CANDIDATE', 'Choose a current candidate.');
    database.sqlite
      .prepare(
        `INSERT INTO movie_night_votes(movie_night_id,title_id,profile_id,vote) VALUES(?,?,?,?)
         ON CONFLICT(movie_night_id,title_id,profile_id) DO UPDATE SET vote=excluded.vote`,
      )
      .run(row.id, input.titleId, voter, input.vote);
    emit('movie_night');
    response.json({ movieNight: serializeNight(row, profile.id) });
  });
  app.post('/api/movie-nights/:id/close', (request, response) => {
    const { profile } = auth.context(request);
    const input = parse(movieNightWinnerSchema, request.body);
    const row = db
      .select()
      .from(movieNights)
      .where(eq(movieNights.id, id(request.params.id)))
      .get();
    if (!row || row.status !== 'voting' || row.hostProfileId !== profile.id)
      throw new ApiError(403, 'HOST_REQUIRED', 'Only the host can choose tonight’s pick.');
    const candidate = db
      .select()
      .from(movieNightVotes)
      .where(
        and(
          eq(movieNightVotes.movieNightId, row.id),
          eq(movieNightVotes.titleId, input.titleId),
          isNull(movieNightVotes.profileId),
        ),
      )
      .get();
    if (!candidate) throw new ApiError(400, 'INVALID_CANDIDATE', 'Choose a current candidate.');
    db.update(movieNights)
      .set({ status: 'closed', winnerTitleId: input.titleId, closedAt: auth.now().toISOString() })
      .where(eq(movieNights.id, row.id))
      .run();
    emit('movie_night');
    const closed = db.select().from(movieNights).where(eq(movieNights.id, row.id)).get()!;
    response.json({ movieNight: serializeNight(closed, profile.id) });
  });
  app.get('/api/stream', (request, response) => {
    const { device, profile } = auth.context(request);
    const active = streams.get(device.id) ?? new Set<express.Response>();
    if (active.size >= 5)
      throw new ApiError(429, 'STREAM_LIMIT', 'Close an unused Plex Rentals tab and try again.');
    response.status(200).set({
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-store',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    response.flushHeaders();
    response.write(': connected\n\n');
    active.add(response);
    streams.set(device.id, active);
    const timer = setInterval(() => {
      const current = auth.device(request);
      if (!current || current.currentProfileId !== profile.id || !auth.selected(current)) {
        closeStreams(device.id);
        return;
      }
      response.write(': keepalive\n\n');
    }, 15000);
    timer.unref();
    response.on('close', () => {
      clearInterval(timer);
      active.delete(response);
      if (!active.size) streams.delete(device.id);
    });
  });
  return { auth, family, closeStreams, notificationService, automation, emit };
}


