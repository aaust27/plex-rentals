import {it,expect,afterEach} from 'vitest';
import {mkdtemp,mkdir,writeFile,rm,symlink} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import request from 'supertest';
import {scanStorage} from './storage.js';
import {createApp} from './app.js';
import {migrateDatabase,openDatabase} from './db/client.js';
import {seedDatabase} from './db/fixtures.js';
let folder:string|undefined;afterEach(async()=>{if(folder){await rm(folder,{recursive:true,force:true});folder=undefined;}});
it('scans nested files, sorts largest first and skips links instead of traversing outside the library',async()=>{
 folder=await mkdtemp(join(tmpdir(),'plex-storage-test-'));const root=join(folder,'movies');await mkdir(join(root,'Big'),{recursive:true});await writeFile(join(root,'Big','film.mkv'),Buffer.alloc(100));await writeFile(join(root,'small.mkv'),Buffer.alloc(10));const outside=join(folder,'outside');await mkdir(outside);await writeFile(join(outside,'secret'),Buffer.alloc(999));await symlink(outside,join(root,'link'),process.platform==='win32'?'junction':'dir');
 const result=await scanStorage([{library:'Movies',path:root}]);expect(result.entries.map(e=>e.bytes)).toEqual([100,10,0]);expect(result.entries.find(e=>e.name==='link')?.skipped).toBe(1);expect(result.volumes[0]?.totalBytes).toBeGreaterThan(0);
 await expect(scanStorage([{library:'Movies',path:join(folder,'missing')}])).rejects.toThrow();await expect(scanStorage([{library:'Movies',path:root}],()=>{},0)).rejects.toThrow();
});
it('requires unlocked admin, validates selected IDs and rejects stale review snapshots',async()=>{
 const database=openDatabase(':memory:');migrateDatabase(database);seedDatabase(database);
 try{
 const app=createApp(database,{plexUrl:'',catalog:{token:''},auth:{householdPasscode:'storage-tests',sessionSecret:'storage-test-secret-at-least-32-chars',adminPin:'1234',baseUrl:'http://localhost:8080'}});
 await request(app).get('/api/admin/storage').expect(401);const a=request.agent(app);await a.post('/api/household/join').send({passcode:'storage-tests'}).expect(200);await a.post('/api/session').send({profileId:2}).expect(200);await a.get('/api/admin/storage').expect(403);await a.post('/api/admin/storage/scan').send({}).expect(403);
 await a.post('/api/session').send({profileId:1,pin:'1234'}).expect(200);await a.post('/api/admin/unlock').send({pin:'1234'}).expect(200);
 const id='a'.repeat(64);const snapshot={generatedAt:'2026-09-29T00:00:00Z',entries:[{id,library:'Movies',name:'Example',bytes:100,files:1,skipped:0}],volumes:[]};database.sqlite.prepare("INSERT INTO settings(key,value) VALUES('storage_inventory_v1',?)").run(JSON.stringify(snapshot));
 expect((await a.get('/api/admin/storage').expect(200)).body.snapshot).toEqual(snapshot);
 expect((await a.post('/api/admin/storage/review').send({generatedAt:snapshot.generatedAt,ids:[id,id]}).expect(200)).body.bytes).toBe(100);
 await a.post('/api/admin/storage/review').send({generatedAt:'old',ids:[id]}).expect(409);await a.post('/api/admin/storage/review').send({generatedAt:snapshot.generatedAt,ids:['b'.repeat(64)]}).expect(400);await a.post('/api/admin/storage/review').set('Origin','https://evil.example').send({generatedAt:snapshot.generatedAt,ids:[id]}).expect(403);
 await a.post('/api/admin/storage/scan').send({}).expect(503);
 }finally{database.close();}
});
