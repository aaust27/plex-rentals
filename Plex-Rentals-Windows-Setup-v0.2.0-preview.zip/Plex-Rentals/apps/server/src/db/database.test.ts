import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { releaseState, requestStatus } from '@reelrequest/shared';
import { migrateDatabase, openDatabase, type AppDatabase } from './client.js';
import { seedDatabase } from './fixtures.js';

let database: AppDatabase;
beforeEach(() => {
  database = openDatabase(':memory:');
  migrateDatabase(database);
});
afterEach(() => database.close());
const rows = (sql: string) => database.sqlite.prepare(sql).all() as Record<string, unknown>[];

describe('Phase 0 SQLite foundation', () => {
  it('migrates all 24 application tables and safely re-applies migrations', () => {
    migrateDatabase(database);
    expect(
      rows(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name <> '__drizzle_migrations'",
      ),
    ).toHaveLength(24);
    expect(database.sqlite.pragma('foreign_keys', { simple: true })).toBe(1);
  });
  it('seeds four profiles, eight requests and complete status/release coverage', () => {
    expect(seedDatabase(database)).toBe('seeded');
    expect(rows('SELECT * FROM profiles')).toHaveLength(4);
    expect(rows('SELECT name FROM profiles WHERE is_admin=1')).toEqual([{ name: 'Owner' }]);
    expect(rows('SELECT * FROM profiles WHERE max_rating_level IS NOT NULL')).toHaveLength(0);
    expect(rows('SELECT * FROM requests')).toHaveLength(8);
    expect(
      rows('SELECT DISTINCT status FROM requests')
        .map((r) => r.status)
        .sort(),
    ).toEqual([...requestStatus.options].sort());
    expect(
      rows('SELECT DISTINCT release_state FROM titles')
        .map((r) => r.release_state)
        .sort(),
    ).toEqual([...releaseState.options].sort());
    expect(
      rows(
        'SELECT * FROM requests r LEFT JOIN request_supporters s ON s.request_id=r.id AND s.profile_id=r.created_by WHERE s.id IS NULL',
      ),
    ).toHaveLength(0);
    expect(
      rows('SELECT * FROM request_supporters WHERE request_id=6 AND withdrawn_at IS NULL'),
    ).toHaveLength(0);
  });
  it('is idempotent without overwriting subsequent user changes', () => {
    seedDatabase(database);
    database.sqlite.prepare("UPDATE profiles SET name='Renamed' WHERE id=2").run();
    const before = rows('SELECT * FROM request_events');
    expect(seedDatabase(database)).toBe('already-seeded');
    expect(rows('SELECT * FROM requests')).toHaveLength(8);
    expect(rows('SELECT * FROM request_events')).toEqual(before);
    expect(rows('SELECT name FROM profiles WHERE id=2')).toEqual([{ name: 'Renamed' }]);
  });
  it('refuses demo seeding with any configured Plex URL', () => {
    expect(() => seedDatabase(database, 'http://plex:32400')).toThrow('PLEX_URL');
    expect(rows('SELECT * FROM profiles')).toHaveLength(0);
  });
  it('allows empty and whitespace Plex configuration as mock mode', () => {
    expect(seedDatabase(database, '   ')).toBe('seeded');
    expect(seedDatabase(database, '')).toBe('already-seeded');
  });
  it('refuses to mix fixtures with existing non-demo data', () => {
    database.sqlite
      .prepare(
        "INSERT INTO profiles(name,avatar,color) VALUES('Owner','preset:director','#F7A823')",
      )
      .run();
    expect(() => seedDatabase(database)).toThrow('empty database');
    expect(rows('SELECT * FROM profiles')).toHaveLength(1);
  });
  it('enforces one open request, supports archived history, and rejects duplicate supporters', () => {
    seedDatabase(database);
    const insert = database.sqlite.prepare(
      "INSERT INTO requests(title_id,created_by,status,updated_at) VALUES(?,?,?,'2026-09-23T00:00:00Z')",
    );
    expect(() => insert.run(1, 3, 'requested')).toThrow('UNIQUE');
    expect(() => insert.run(4, 2, 'requested')).not.toThrow();
    expect(() => insert.run(4, 3, 'looking')).toThrow('UNIQUE');
    expect(() =>
      database.sqlite
        .prepare('INSERT INTO request_supporters(request_id,profile_id) VALUES(1,2)')
        .run(),
    ).toThrow('UNIQUE');
  });
  it('enforces enums, foreign keys, ratings and request note length in SQLite', () => {
    seedDatabase(database);
    expect(() =>
      database.sqlite.prepare("UPDATE requests SET status='coming_soon' WHERE id=1").run(),
    ).toThrow('CHECK');
    expect(() =>
      database.sqlite.prepare("UPDATE titles SET release_state='available' WHERE id=1").run(),
    ).toThrow('CHECK');
    expect(() =>
      database.sqlite.prepare("UPDATE titles SET media_type='person' WHERE id=1").run(),
    ).toThrow('CHECK');
    expect(() =>
      database.sqlite.prepare('UPDATE profiles SET max_rating_level=6 WHERE id=1').run(),
    ).toThrow('CHECK');
    expect(() =>
      database.sqlite.prepare('UPDATE requests SET created_by=99 WHERE id=1').run(),
    ).toThrow('FOREIGN KEY');
    expect(() =>
      database.sqlite.prepare('UPDATE requests SET note=? WHERE id=1').run('a'.repeat(141)),
    ).toThrow('CHECK');
  });
  it('records initial and changed statuses and leaves request history intact on release changes', () => {
    seedDatabase(database);
    expect(
      rows('SELECT from_status,to_status FROM request_events WHERE request_id=4 ORDER BY id'),
    ).toEqual([
      { from_status: null, to_status: 'requested' },
      { from_status: 'requested', to_status: 'looking' },
      { from_status: 'looking', to_status: 'available' },
      { from_status: 'available', to_status: 'watched' },
    ]);
    const before = rows('SELECT * FROM request_events');
    database.sqlite.prepare("UPDATE titles SET release_state='released' WHERE id=7").run();
    expect(rows('SELECT * FROM request_events')).toEqual(before);
    expect(rows('SELECT status FROM requests WHERE id=7')).toEqual([{ status: 'requested' }]);
    database.sqlite
      .prepare("UPDATE requests SET status='looking',updated_at='2026-09-23T00:00:00Z' WHERE id=1")
      .run();
    expect(
      rows(
        'SELECT from_status,to_status FROM request_events WHERE request_id=1 ORDER BY id DESC LIMIT 1',
      ),
    ).toEqual([{ from_status: 'requested', to_status: 'looking' }]);
  });
  it('protects one candidate and one bounded vote per participant/title', () => {
    seedDatabase(database);
    database.sqlite.prepare('INSERT INTO movie_nights(id,host_profile_id) VALUES(1,1)').run();
    database.sqlite
      .prepare('INSERT INTO movie_night_votes(movie_night_id,title_id) VALUES(1,3)')
      .run();
    expect(() =>
      database.sqlite
        .prepare('INSERT INTO movie_night_votes(movie_night_id,title_id) VALUES(1,3)')
        .run(),
    ).toThrow('UNIQUE');
    expect(() =>
      database.sqlite
        .prepare(
          'INSERT INTO movie_night_votes(movie_night_id,title_id,profile_id,vote) VALUES(1,3,2,4)',
        )
        .run(),
    ).toThrow('CHECK');
  });
});

