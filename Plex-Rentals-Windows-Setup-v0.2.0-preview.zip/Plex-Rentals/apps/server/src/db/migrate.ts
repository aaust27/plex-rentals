import '../config.js';
import { migrateDatabase, openDatabase } from './client.js';
const database = openDatabase();
try {
  migrateDatabase(database);
  console.log('SQLite migrations applied.');
} finally {
  database.close();
}
