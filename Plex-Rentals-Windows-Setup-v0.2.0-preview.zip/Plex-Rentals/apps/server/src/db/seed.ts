import '../config.js';
import { migrateDatabase, openDatabase } from './client.js';
import { seedDatabase } from './fixtures.js';
const database = openDatabase();
try {
  migrateDatabase(database);
  console.log(
    `Demo database: ${seedDatabase(database, process.env.PLEX_URL)}. Four profiles, eight requests.`,
  );
} finally {
  database.close();
}
