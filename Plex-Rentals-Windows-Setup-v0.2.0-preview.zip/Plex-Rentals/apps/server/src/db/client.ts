import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import Database from 'better-sqlite3';
import { drizzle } from 'drizzle-orm/better-sqlite3';
import { migrate } from 'drizzle-orm/better-sqlite3/migrator';
import * as schema from './schema.js';

export function defaultDatabasePath(): string {
  const filename = process.env.DATABASE_PATH ?? 'data/reelrequest.db';
  return filename === ':memory:'
    ? filename
    : resolve(fileURLToPath(new URL('../../../../', import.meta.url)), filename);
}

export function openDatabase(filename = defaultDatabasePath()) {
  if (filename !== ':memory:') mkdirSync(dirname(filename), { recursive: true });
  const sqlite = new Database(filename);
  sqlite.pragma('foreign_keys = ON');
  sqlite.pragma('journal_mode = WAL');
  sqlite.pragma('busy_timeout = 5000');
  const db = drizzle(sqlite, { schema });
  return { sqlite, db, close: () => sqlite.close() };
}
export type AppDatabase = ReturnType<typeof openDatabase>;

export function migrateDatabase(database: AppDatabase): void {
  migrate(database.db, {
    migrationsFolder: fileURLToPath(new URL('../../drizzle', import.meta.url)),
  });
}
