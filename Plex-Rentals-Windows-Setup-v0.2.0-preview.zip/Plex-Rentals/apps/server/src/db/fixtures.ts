import { eq } from 'drizzle-orm';
import {
  releaseState,
  requestStatus,
  type ReleaseState,
  type RequestStatus,
} from '@reelrequest/shared';
import type { AppDatabase } from './client.js';
import { profiles, plexItems, requests, requestSupporters, settings, titles } from './schema.js';

const seedTime = '2026-09-01T18:00:00.000Z';
export const demoTitles: ReadonlyArray<{
  title: string;
  status: RequestStatus;
  release: ReleaseState;
}> = [
  { title: 'The Last Projection', status: 'requested', release: 'released' },
  { title: 'After the Rain', status: 'looking', release: 'released' },
  { title: 'Midnight in Orbit', status: 'available', release: 'released' },
  { title: 'Summer on Cedar Street', status: 'watched', release: 'released' },
  { title: 'Echoes of Tomorrow', status: 'passed', release: 'released' },
  { title: 'The Unwritten Map', status: 'cancelled', release: 'unknown' },
  { title: 'Beyond the Blue', status: 'requested', release: 'coming_soon' },
  { title: 'Station Eleven Thirty', status: 'looking', release: 'unknown' },
];

/** Isolated, invented fixtures. Never refresh these as if they were actual TMDB records. */
export function seedDatabase(database: AppDatabase, plexUrl?: string): 'seeded' | 'already-seeded' {
  if (plexUrl?.trim()) throw new Error('Demo seeding requires PLEX_URL to be unset.');
  const { db } = database;
  const marker = db.select().from(settings).where(eq(settings.key, 'demo_seed_version')).get();
  if (marker) return 'already-seeded';
  if (db.select().from(profiles).limit(1).get() || db.select().from(titles).limit(1).get()) {
    throw new Error('Demo seed requires an empty database; existing data was left unchanged.');
  }
  db.transaction((tx) => {
    tx.insert(profiles)
      .values([
        {
          id: 1,
          name: 'Owner',
          avatar: 'preset:director',
          color: '#F7A823',
          isAdmin: true,
          createdAt: seedTime,
        },
        {
          id: 2,
          name: 'Family 1',
          avatar: 'preset:explorer',
          color: '#5AB8F0',
          createdAt: seedTime,
        },
        {
          id: 3,
          name: 'Family 2',
          avatar: 'preset:dreamer',
          color: '#9B6BF0',
          createdAt: seedTime,
        },
        {
          id: 4,
          name: 'Family 3',
          avatar: 'preset:stargazer',
          color: '#34C759',
          createdAt: seedTime,
        },
      ])
      .run();
    for (const titleId of [3, 4]) {
      tx.insert(plexItems)
        .values({
          id: titleId - 2,
          ratingKey: `demo-${titleId}`,
          sectionId: 'demo-movies',
          mediaType: 'movie',
          title: demoTitles[titleId - 1]!.title,
          tmdbId: 9_900_000 + titleId,
          year: 2026,
          addedAt: seedTime,
          lastSeenAt: seedTime,
          resolution: titleId === 3 ? '4K' : '1080p',
          createdAt: seedTime,
        })
        .run();
    }
    for (const [offset, fixture] of demoTitles.entries()) {
      const id = offset + 1;
      const author = (offset % 3) + 2;
      const status = requestStatus.parse(fixture.status);
      const release = releaseState.parse(fixture.release);
      const matched = id === 3 || id === 4;
      tx.insert(titles)
        .values({
          id,
          tmdbId: 9_900_000 + id,
          mediaType: id === 8 ? 'tv' : 'movie',
          title: fixture.title,
          year: 2026,
          overview: 'Invented Phase 0 demo title. Metadata integration begins in Phase 1.',
          releaseState: release,
          plexRatingKey: matched ? `demo-${id}` : null,
          plexMatch: matched ? 'tmdb' : null,
          releaseDigital:
            release === 'released' ? '2026-08-01' : release === 'coming_soon' ? '2027-01-15' : null,
          createdAt: seedTime,
        })
        .run();
      tx.insert(requests)
        .values({
          id,
          titleId: id,
          createdBy: author,
          status: 'requested',
          reason: id % 2 === 0 ? 'Watch Together' : 'Movie Night',
          note: 'Phase 0 demo request.',
          seasons: id === 8 ? [1] : null,
          updatedAt: seedTime,
          createdAt: seedTime,
        })
        .run();
      const path: RequestStatus[] =
        status === 'watched'
          ? ['looking', 'available', 'watched']
          : status === 'available'
            ? ['looking', 'available']
            : status === 'requested'
              ? []
              : [status];
      for (const [step, next] of path.entries()) {
        const changedAt = `2026-09-0${step + 2}T18:00:00.000Z`;
        tx.update(requests)
          .set({
            status: next,
            updatedAt: changedAt,
            ...(next === 'available' ? { availableAt: changedAt } : {}),
            ...(next === 'watched' ? { watchedAt: changedAt } : {}),
          })
          .where(eq(requests.id, id))
          .run();
        // The DB trigger preserves every transition. Attribute manual seed actions atomically.
        if (next !== 'available' && next !== 'cancelled') {
          database.sqlite
            .prepare(
              'UPDATE request_events SET actor_profile_id = ? WHERE id = (SELECT MAX(id) FROM request_events WHERE request_id = ?)',
            )
            .run(next === 'watched' ? author : 1, id);
        }
      }
      if (status === 'cancelled') {
        tx.update(requestSupporters)
          .set({ withdrawnAt: '2026-09-02T18:00:00.000Z' })
          .where(eq(requestSupporters.requestId, id))
          .run();
      }
    }
    tx.insert(requestSupporters)
      .values({ requestId: 1, profileId: 4, reason: 'Watch Together', createdAt: seedTime })
      .run();
    tx.insert(settings)
      .values([
        { key: 'demo_seed_version', value: '1', createdAt: seedTime },
        { key: 'effects_default', value: 'full', createdAt: seedTime },
      ])
      .run();
  });
  return 'seeded';
}
