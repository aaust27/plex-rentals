import { sql } from 'drizzle-orm';
import {
  check,
  index,
  integer,
  real,
  primaryKey,
  sqliteTable,
  text,
  uniqueIndex,
} from 'drizzle-orm/sqlite-core';
import { mediaType, releaseState, requestStatus } from '@reelrequest/shared';

// Zod 4 exposes options as arrays; Drizzle requires a non-empty tuple.
function enumValues<T extends string>(values: T[]): [T, ...T[]] {
  const first = values[0];
  if (first === undefined) throw new Error('Database enum must have a value.');
  return [first, ...values.slice(1)];
}

const id = () => integer('id').primaryKey({ autoIncrement: true });
const createdAt = () =>
  text('created_at')
    .notNull()
    .default(sql`(strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))`);

export const profiles = sqliteTable(
  'profiles',
  {
    id: id(),
    name: text('name').notNull(),
    avatar: text('avatar').notNull(),
    color: text('color').notNull(),
    isAdmin: integer('is_admin', { mode: 'boolean' }).notNull().default(false),
    pinHash: text('pin_hash'),
    disabled: integer('disabled', { mode: 'boolean' }).notNull().default(false),
    maxRatingLevel: integer('max_rating_level'),
    createdAt: createdAt(),
  },
  (t) => [check('profile_rating', sql`${t.maxRatingLevel} between 1 and 5`)],
);

export const devices = sqliteTable('devices', {
  id: id(),
  tokenHash: text('token_hash').notNull().unique(),
  label: text('label'),
  lastSeenAt: text('last_seen_at'),
  currentProfileId: integer('current_profile_id').references(() => profiles.id, {
    onDelete: 'set null',
  }),
  expiresAt: text('expires_at'),
  adminUnlockedUntil: text('admin_unlocked_until'),
  createdAt: createdAt(),
});

export const authAttempts = sqliteTable('auth_attempts', {
  key: text('key').primaryKey(),
  failures: integer('failures').notNull(),
  windowStart: integer('window_start').notNull(),
});

export const plexItems = sqliteTable(
  'plex_items',
  {
    id: id(),
    ratingKey: text('rating_key').notNull().unique(),
    sectionId: text('section_id').notNull(),
    mediaType: text('media_type', { enum: enumValues(mediaType.options) }).notNull(),
    title: text('title').notNull(),
    year: integer('year'),
    tmdbId: integer('tmdb_id'),
    imdbId: text('imdb_id'),
    tvdbId: integer('tvdb_id'),
    addedAt: text('added_at'),
    resolution: text('resolution'),
    seasons: text('seasons', { mode: 'json' })
      .$type<number[]>()
      .notNull()
      .default(sql`'[]'`),
    lastSeenAt: text('last_seen_at'),
    missCount: integer('miss_count').notNull().default(0),
    createdAt: createdAt(),
  },
  (t) => [
    index('plex_tmdb_idx').on(t.tmdbId, t.mediaType),
    index('plex_imdb_idx').on(t.imdbId),
    index('plex_tvdb_idx').on(t.tvdbId),
  ],
);

export const titles = sqliteTable(
  'titles',
  {
    id: id(),
    tmdbId: integer('tmdb_id').notNull(),
    imdbId: text('imdb_id'),
    tvdbId: integer('tvdb_id'),
    mediaType: text('media_type', { enum: enumValues(mediaType.options) }).notNull(),
    title: text('title').notNull(),
    year: integer('year'),
    overview: text('overview'),
    posterPath: text('poster_path'),
    backdropPath: text('backdrop_path'),
    logoPath: text('logo_path'),
    runtimeMin: integer('runtime_min'),
    certification: text('certification'),
    ratingLevel: integer('rating_level'),
    tmdbScore: real('tmdb_score'),
    genres: text('genres', { mode: 'json' })
      .$type<unknown[]>()
      .notNull()
      .default(sql`'[]'`),
    cast: text('cast', { mode: 'json' })
      .$type<unknown[]>()
      .notNull()
      .default(sql`'[]'`),
    crew: text('crew', { mode: 'json' })
      .$type<unknown[]>()
      .notNull()
      .default(sql`'[]'`),
    trailerKey: text('trailer_key'),
    releaseTheatrical: text('release_theatrical'),
    releaseDigital: text('release_digital'),
    releasePhysical: text('release_physical'),
    nextAirDate: text('next_air_date'),
    releaseState: text('release_state', { enum: enumValues(releaseState.options) })
      .notNull()
      .default('unknown'),
    colorHex: text('color_hex'),
    plexRatingKey: text('plex_rating_key').references(() => plexItems.ratingKey, {
      onDelete: 'set null',
    }),
    plexMatch: text('plex_match', { enum: ['tmdb', 'imdb', 'tvdb', 'fuzzy', 'manual'] }),
    fetchedAt: text('fetched_at'),
    createdAt: createdAt(),
  },
  (t) => [
    uniqueIndex('titles_tmdb_type_unique').on(t.tmdbId, t.mediaType),
    index('titles_imdb_idx').on(t.imdbId),
    index('titles_tvdb_idx').on(t.tvdbId),
    index('titles_release_idx').on(t.releaseState),
    check('title_rating', sql`${t.ratingLevel} between 1 and 5`),
  ],
);

export const requests = sqliteTable(
  'requests',
  {
    id: id(),
    titleId: integer('title_id')
      .notNull()
      .references(() => titles.id),
    createdBy: integer('created_by')
      .notNull()
      .references(() => profiles.id),
    status: text('status', { enum: enumValues(requestStatus.options) })
      .notNull()
      .default('requested'),
    reason: text('reason'),
    note: text('note'),
    seasons: text('seasons', { mode: 'json' }).$type<number[] | null>(),
    adminNote: text('admin_note'),
    availableAt: text('available_at'),
    watchedAt: text('watched_at'),
    updatedAt: text('updated_at').notNull(),
    createdAt: createdAt(),
  },
  (t) => [
    uniqueIndex('requests_one_open_title')
      .on(t.titleId)
      .where(sql`${t.status} not in ('watched', 'passed', 'cancelled')`),
    index('requests_status_created_idx').on(t.status, t.createdAt),
    check('request_note_length', sql`length(${t.note}) <= 140`),
  ],
);

export const automationServices = sqliteTable('automation_services', {
  service: text('service', { enum: ['radarr', 'sonarr'] }).primaryKey(),
  enabled: integer('enabled', { mode: 'boolean' }).notNull().default(false),
  baseUrl: text('base_url').notNull().default(''),
  apiKey: text('api_key'),
  qualityProfileId: integer('quality_profile_id'),
  rootFolderPath: text('root_folder_path'),
  updatedAt: text('updated_at').notNull(),
  createdAt: createdAt(),
});

export const requestAutomation = sqliteTable(
  'request_automation',
  {
    requestId: integer('request_id')
      .primaryKey()
      .references(() => requests.id, { onDelete: 'cascade' }),
    decision: text('decision', { enum: ['pending', 'approved', 'declined'] })
      .notNull()
      .default('pending'),
    decidedBy: integer('decided_by').references(() => profiles.id, { onDelete: 'set null' }),
    decidedAt: text('decided_at'),
    declineReason: text('decline_reason'),
    approvedScope: text('approved_scope', { mode: 'json' }).$type<{
      seasons: number[] | null;
    } | null>(),
    service: text('service', { enum: ['radarr', 'sonarr'] }).notNull(),
    submissionStatus: text('submission_status', {
      enum: ['not_submitted', 'queued', 'submitting', 'sent', 'failed', 'skipped'],
    })
      .notNull()
      .default('not_submitted'),
    externalId: integer('external_id'),
    lastError: text('last_error'),
    attemptCount: integer('attempt_count').notNull().default(0),
    nextAttemptAt: text('next_attempt_at'),
    lastAttemptAt: text('last_attempt_at'),
    submittedAt: text('submitted_at'),
    updatedAt: text('updated_at').notNull(),
    createdAt: createdAt(),
  },
  (t) => [index('request_automation_queue_idx').on(t.submissionStatus, t.nextAttemptAt)],
);

export const requestRentals = sqliteTable(
  'request_rentals',
  {
    requestId: integer('request_id')
      .primaryKey()
      .references(() => requests.id, { onDelete: 'cascade' }),
    durationDays: integer('duration_days').notNull().default(7),
    expiresAt: text('expires_at'),
    deletedAt: text('deleted_at'),
    lastError: text('last_error'),
    attemptCount: integer('attempt_count').notNull().default(0),
    nextAttemptAt: text('next_attempt_at'),
    updatedAt: text('updated_at').notNull(),
    createdAt: createdAt(),
  },
  (t) => [
    index('request_rentals_due_idx').on(t.expiresAt, t.deletedAt, t.nextAttemptAt),
    check('request_rentals_duration', sql`${t.durationDays} = 7`),
  ],
);

export const automationEvents = sqliteTable(
  'automation_events',
  {
    id: id(),
    requestId: integer('request_id')
      .notNull()
      .references(() => requests.id, { onDelete: 'cascade' }),
    actorProfileId: integer('actor_profile_id').references(() => profiles.id, {
      onDelete: 'set null',
    }),
    action: text('action').notNull(),
    detail: text('detail'),
    createdAt: createdAt(),
  },
  (t) => [index('automation_events_request_idx').on(t.requestId, t.createdAt)],
);

export const requestSupporters = sqliteTable(
  'request_supporters',
  {
    id: id(),
    requestId: integer('request_id')
      .notNull()
      .references(() => requests.id, { onDelete: 'cascade' }),
    profileId: integer('profile_id')
      .notNull()
      .references(() => profiles.id),
    reason: text('reason'),
    note: text('note'),
    withdrawnAt: text('withdrawn_at'),
    createdAt: createdAt(),
  },
  (t) => [
    uniqueIndex('supporters_request_profile_unique').on(t.requestId, t.profileId),
    check('supporter_note_length', sql`length(${t.note}) <= 140`),
  ],
);

export const requestEvents = sqliteTable(
  'request_events',
  {
    id: id(),
    requestId: integer('request_id')
      .notNull()
      .references(() => requests.id, { onDelete: 'cascade' }),
    fromStatus: text('from_status', { enum: enumValues(requestStatus.options) }),
    toStatus: text('to_status', { enum: enumValues(requestStatus.options) }).notNull(),
    actorProfileId: integer('actor_profile_id').references(() => profiles.id, {
      onDelete: 'set null',
    }),
    createdAt: createdAt(),
  },
  (t) => [index('events_request_idx').on(t.requestId, t.createdAt)],
);

export const reactions = sqliteTable(
  'reactions',
  {
    id: id(),
    profileId: integer('profile_id')
      .notNull()
      .references(() => profiles.id, { onDelete: 'cascade' }),
    titleId: integer('title_id')
      .notNull()
      .references(() => titles.id, { onDelete: 'cascade' }),
    value: text('value', { enum: ['up', 'down'] }).notNull(),
    updatedAt: text('updated_at').notNull(),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex('reactions_profile_title_unique').on(t.profileId, t.titleId)],
);

export const signals = sqliteTable(
  'signals',
  {
    id: id(),
    profileId: integer('profile_id')
      .notNull()
      .references(() => profiles.id, { onDelete: 'cascade' }),
    titleId: integer('title_id')
      .notNull()
      .references(() => titles.id, { onDelete: 'cascade' }),
    kind: text('kind', { enum: ['detail_view', 'trailer_play', 'search_open'] }).notNull(),
    createdAt: createdAt(),
  },
  (t) => [index('signals_profile_created_idx').on(t.profileId, t.createdAt)],
);

export const movieNights = sqliteTable('movie_nights', {
  id: id(),
  hostProfileId: integer('host_profile_id')
    .notNull()
    .references(() => profiles.id),
  status: text('status', { enum: ['voting', 'closed'] })
    .notNull()
    .default('voting'),
  filters: text('filters', { mode: 'json' })
    .$type<Record<string, unknown>>()
    .notNull()
    .default(sql`'{}'`),
  winnerTitleId: integer('winner_title_id').references(() => titles.id),
  closedAt: text('closed_at'),
  createdAt: createdAt(),
});

export const movieNightVotes = sqliteTable(
  'movie_night_votes',
  {
    id: id(),
    movieNightId: integer('movie_night_id')
      .notNull()
      .references(() => movieNights.id, { onDelete: 'cascade' }),
    titleId: integer('title_id')
      .notNull()
      .references(() => titles.id),
    profileId: integer('profile_id').references(() => profiles.id),
    vote: integer('vote'),
    createdAt: createdAt(),
  },
  (t) => [
    uniqueIndex('night_votes_unique').on(t.movieNightId, t.titleId, t.profileId),
    uniqueIndex('night_candidates_unique')
      .on(t.movieNightId, t.titleId)
      .where(sql`${t.profileId} is null`),
    check(
      'night_vote_range',
      sql`(${t.profileId} is null and ${t.vote} is null) or (${t.profileId} is not null and ${t.vote} between 0 and 3 and ${t.vote} is not null)`,
    ),
  ],
);

export const notifications = sqliteTable(
  'notifications',
  {
    id: id(),
    profileId: integer('profile_id')
      .notNull()
      .references(() => profiles.id, { onDelete: 'cascade' }),
    kind: text('kind').notNull(),
    requestId: integer('request_id').references(() => requests.id, { onDelete: 'set null' }),
    titleId: integer('title_id').references(() => titles.id, { onDelete: 'set null' }),
    body: text('body').notNull(),
    readAt: text('read_at'),
    pushSentAt: text('push_sent_at'),
    createdAt: createdAt(),
  },
  (t) => [index('notifications_profile_read_idx').on(t.profileId, t.readAt)],
);

export const pushSubscriptions = sqliteTable('push_subscriptions', {
  id: id(),
  profileId: integer('profile_id')
    .notNull()
    .references(() => profiles.id, { onDelete: 'cascade' }),
  deviceId: integer('device_id')
    .notNull()
    .references(() => devices.id, { onDelete: 'cascade' }),
  endpoint: text('endpoint').notNull().unique(),
  keys: text('keys', { mode: 'json' }).$type<{ p256dh: string; auth: string }>().notNull(),
  createdAt: createdAt(),
});

export const listItems = sqliteTable(
  'list_items',
  {
    id: id(),
    profileId: integer('profile_id')
      .notNull()
      .references(() => profiles.id, { onDelete: 'cascade' }),
    titleId: integer('title_id')
      .notNull()
      .references(() => titles.id, { onDelete: 'cascade' }),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex('list_items_profile_title_unique').on(t.profileId, t.titleId)],
);

export const settings = sqliteTable('settings', {
  id: id(),
  key: text('key').notNull().unique(),
  value: text('value').notNull(),
  createdAt: createdAt(),
});

export const titleRatings = sqliteTable('title_ratings', {
 titleId: integer('title_id').notNull().references(()=>titles.id,{onDelete:'cascade'}),
 profileId: integer('profile_id').notNull().references(()=>profiles.id,{onDelete:'cascade'}),
 score: real('score').notNull(),
 updatedAt: text('updated_at').notNull().default(sql`CURRENT_TIMESTAMP`),
},t=>[primaryKey({columns:[t.titleId,t.profileId]}),check('title_rating_range',sql`${t.score} between 0 and 10 and ${t.score}*2=cast(${t.score}*2 as integer)`)]);
export const titleComments = sqliteTable('title_comments', {
 id:id(),titleId:integer('title_id').notNull().references(()=>titles.id,{onDelete:'cascade'}),
 profileId:integer('profile_id').notNull().references(()=>profiles.id,{onDelete:'cascade'}),
 body:text('body').notNull(),mentions:text('mentions').notNull().default('[]'),createdAt:createdAt(),
},t=>[index('title_comments_page').on(t.titleId,t.id),index('title_comments_rate').on(t.profileId,t.createdAt)]);

