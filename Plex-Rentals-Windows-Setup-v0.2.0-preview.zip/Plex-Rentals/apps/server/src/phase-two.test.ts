import request from 'supertest';
import sharp from 'sharp';
import { once } from 'node:events';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  adminStatsSchema,
  familyDetailResponseSchema,
  requestsResponseSchema,
  sessionResponseSchema,
} from '@reelrequest/shared';
import { createApp } from './app.js';
import { migrateDatabase, openDatabase, type AppDatabase } from './db/client.js';
import { seedDatabase } from './db/fixtures.js';
import { profiles } from './db/schema.js';
import { eq } from 'drizzle-orm';

const authOptions = {
  householdPasscode: 'family-test-passcode',
  sessionSecret: 'test-only-session-secret-at-least-32-characters',
  adminPin: '1234',
  baseUrl: 'http://localhost:8080',
};
let database: AppDatabase;
let clock: Date;
function app(options: Partial<Parameters<typeof createApp>[1]> = {}) {
  return createApp(database, {
    auth: { ...authOptions, now: () => clock },
    plexUrl: '',
    catalog: { token: '' },
    ...options,
  });
}
async function member(server: ReturnType<typeof app>, profileId = 2, admin = false) {
  const agent = request.agent(server);
  expect(
    (await agent.post('/api/household/join').send({ passcode: authOptions.householdPasscode }))
      .status,
  ).toBe(200);
  expect(
    (
      await agent
        .post('/api/session')
        .send({ profileId, ...(profileId === 1 ? { pin: '1234' } : {}) })
    ).status,
  ).toBe(200);
  if (admin) expect((await agent.post('/api/admin/unlock').send({ pin: '1234' })).status).toBe(200);
  return agent;
}
beforeEach(() => {
  database = openDatabase(':memory:');
  migrateDatabase(database);
  clock = new Date('2026-09-24T00:00:00Z');
});
afterEach(() => database.close());

describe('Phase 2 household and admin authorization', () => {
  it('fails closed without server configuration and gates every private surface', async () => {
    const unconfigured = app({ auth: { householdPasscode: '', sessionSecret: '', adminPin: '' } });
    expect((await request(unconfigured).get('/api/session')).body).toMatchObject({
      configured: false,
      trusted: false,
    });
    expect((await request(unconfigured).get('/api/home')).status).toBe(503);
    const server = app();
    for (const path of [
      '/api/home',
      '/api/profiles',
      '/api/requests',
      '/api/list',
      '/api/stream',
      '/api/titles/movie/9900001',
      '/api/admin/stats',
    ])
      expect((await request(server).get(path)).status).toBe(401);
    const agent = request.agent(server);
    const joined = await agent
      .post('/api/household/join')
      .send({ passcode: authOptions.householdPasscode });
    const cookie = String(joined.headers['set-cookie']);
    expect(cookie).toContain('HttpOnly');
    expect(cookie).toContain('SameSite=Strict');
    expect(cookie).toContain('Max-Age=15552000');
    expect(cookie).not.toContain(authOptions.sessionSecret);
    expect((await agent.get('/api/home')).body).toMatchObject({
      error: { code: 'PROFILE_REQUIRED' },
    });
    expect(
      (
        await request(server)
          .get('/api/profiles')
          .set('Cookie', cookie.replace('reelrequest_device=', 'reelrequest_device=x'))
      ).status,
    ).toBe(401);
    expect(database.sqlite.prepare('SELECT token_hash FROM devices').get()).not.toHaveProperty(
      'token',
    );
  });
  it('requires PINs, hashes them, scopes unlocks to device, expires them and clears on profile switch', async () => {
    const server = app();
    const agent = await member(server, 1);
    expect((await agent.get('/api/admin/stats')).status).toBe(403);
    expect((await agent.post('/api/admin/unlock').send({ pin: '1234' })).status).toBe(200);
    expect(adminStatsSchema.safeParse((await agent.get('/api/admin/stats')).body).success).toBe(
      true,
    );
    const another = await member(server, 1);
    expect((await another.get('/api/admin/stats')).status).toBe(403);
    const rows = database.sqlite
      .prepare('SELECT pin_hash FROM profiles WHERE is_admin = 1')
      .get() as { pin_hash: string };
    expect(rows.pin_hash).toMatch(/^scrypt:/);
    expect(rows.pin_hash).not.toContain('1234');
    clock = new Date(clock.getTime() + 12 * 3600000);
    expect((await agent.get('/api/admin/stats')).status).toBe(403);
    await agent.post('/api/admin/unlock').send({ pin: '1234' });
    await agent.post('/api/session').send({ profileId: 2 });
    expect(sessionResponseSchema.parse((await agent.get('/api/session')).body).adminUnlocked).toBe(
      false,
    );
    expect((await agent.get('/api/admin/stats')).status).toBe(403);
    clock = new Date(clock.getTime() + 180 * 86400000);
    expect((await agent.get('/api/home')).status).toBe(401);
  });
  it('persists five-attempt IP lockouts across app instances and rejects forged Origins', async () => {
    const server = app();
    for (let index = 0; index < 5; index++)
      expect(
        (await request(server).post('/api/household/join').send({ passcode: 'wrong' })).status,
      ).toBe(index === 4 ? 429 : 401);
    expect(
      (
        await request(app())
          .post('/api/household/join')
          .send({ passcode: authOptions.householdPasscode })
      ).status,
    ).toBe(429);
    clock = new Date(clock.getTime() + 900000);
    expect(
      (
        await request(server)
          .post('/api/household/join')
          .send({ passcode: authOptions.householdPasscode })
      ).status,
    ).toBe(200);
    expect(
      (
        await request(server)
          .post('/api/household/join')
          .set('Origin', 'https://evil.invalid')
          .send({ passcode: authOptions.householdPasscode })
      ).status,
    ).toBe(403);
    expect(
      (
        await request(server)
          .post('/api/household/join')
          .set('Sec-Fetch-Site', 'cross-site')
          .send({ passcode: authOptions.householdPasscode })
      ).status,
    ).toBe(403);
  });
  it('resets passcode with durable hash and revokes a device immediately', async () => {
    const server = app();
    const admin = await member(server, 1, true);
    const family = await member(server);
    expect(
      (await admin.put('/api/admin/settings').send({ passcode: 'new-family-passcode' })).status,
    ).toBe(200);
    expect(
      (
        await request(server)
          .post('/api/household/join')
          .send({ passcode: authOptions.householdPasscode })
      ).status,
    ).toBe(401);
    expect(
      (await request(server).post('/api/household/join').send({ passcode: 'new-family-passcode' }))
        .status,
    ).toBe(200);
    expect(
      (await request(app()).post('/api/household/join').send({ passcode: 'new-family-passcode' }))
        .status,
    ).toBe(200);
    const device = (await admin.get('/api/admin/devices')).body.devices.find(
      (entry: { id: number; isCurrent: boolean }) => !entry.isCurrent,
    ) as { id: number };
    await admin.delete(`/api/admin/devices/${device.id}`);
    expect((await family.get('/api/requests')).status).toBe(401);
  });
});

describe('Phase 2 requests, kid filters and private bookmarks', () => {
  it('rechecks a revoked device after an in-flight metadata fetch before creating requests', async () => {
    let release: ((value: Response) => void) | undefined;
    let started: (() => void) | undefined;
    const began = new Promise<void>((resolve) => {
      started = resolve;
    });
    const upstream = vi.fn<typeof fetch>().mockImplementation(
      () =>
        new Promise<Response>((resolve) => {
          release = resolve;
          started!();
        }),
    );
    const server = app({ catalog: { token: 'test-only', fetch: upstream } });
    const family = await member(server);
    const pending = family
      .post('/api/requests')
      .send({ mediaType: 'movie', tmdbId: 101 })
      .then((response) => response);
    await began;
    database.sqlite.prepare('DELETE FROM devices').run();
    release!(Response.json({ id: 101, title: 'Delayed title', status: 'Released' }));
    expect((await pending).status).toBe(401);
    expect(database.sqlite.prepare('SELECT count(*) AS n FROM requests').get()).toEqual({ n: 0 });
  });
  it('rejects an old unrestricted detail response when the same profile gets a kid limit during fetch', async () => {
    let release: ((value: Response) => void) | undefined;
    let started: (() => void) | undefined;
    const began = new Promise<void>((resolve) => {
      started = resolve;
    });
    const upstream = vi.fn<typeof fetch>().mockImplementation(
      () =>
        new Promise<Response>((resolve) => {
          release = resolve;
          started!();
        }),
    );
    const server = app({ catalog: { token: 'test-only', fetch: upstream } });
    const family = await member(server);
    const pending = family.get('/api/titles/movie/101').then((response) => response);
    await began;
    database.db.update(profiles).set({ maxRatingLevel: 2 }).where(eq(profiles.id, 2)).run();
    release!(Response.json({ id: 101, title: 'Restricted title', status: 'Released' }));
    const response = await pending;
    expect(response.status).toBe(409);
    expect(response.text).not.toContain('Restricted title');
  });
  it('broadcasts content-free SSE invalidation and closes the stream on profile switch', async () => {
    const application = app();
    const server = application.listen(0, '127.0.0.1');
    await once(server, 'listening');
    const address = server.address();
    if (!address || typeof address === 'string') throw new Error('Missing test server port');
    const base = `http://127.0.0.1:${address.port}`;
    const controller = new AbortController();
    try {
      const joined = await fetch(`${base}/api/household/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ passcode: authOptions.householdPasscode }),
      });
      const cookie = joined.headers.get('set-cookie')!.split(';')[0]!;
      const headers = { Cookie: cookie, 'Content-Type': 'application/json' };
      await fetch(`${base}/api/session`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ profileId: 2 }),
      });
      const stream = await fetch(`${base}/api/stream`, {
        headers: { Cookie: cookie },
        signal: controller.signal,
      });
      expect(stream.headers.get('content-type')).toContain('text/event-stream');
      const reader = stream.body!.getReader();
      expect(new TextDecoder().decode((await reader.read()).value)).toContain(': connected');
      await fetch(`${base}/api/requests`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ mediaType: 'movie', tmdbId: 9900001 }),
      });
      const event = new TextDecoder().decode((await reader.read()).value);
      expect(event).toContain('event: change');
      expect(event).toContain('"kind":"requests"');
      expect(event).not.toContain('The Last Projection');
      await fetch(`${base}/api/session`, { method: 'DELETE', headers });
      expect(new TextDecoder().decode((await reader.read()).value)).toContain('event: session');
      expect((await reader.read()).done).toBe(true);
    } finally {
      controller.abort();
      await new Promise<void>((resolve) => {
        server.close(() => resolve());
        server.closeAllConnections();
      });
    }
  });
  it('atomically merges concurrent requests and attributes every manual status transition', async () => {
    const server = app();
    const first = await member(server, 2);
    const second = await member(server, 3);
    const admin = await member(server, 1, true);
    const created = await Promise.all([
      first.post('/api/requests').send({ mediaType: 'movie', tmdbId: 9900001 }),
      second.post('/api/requests').send({ mediaType: 'movie', tmdbId: 9900001 }),
    ]);
    expect(created.map((response) => response.status)).toEqual([201, 201]);
    const requestId = created[0]!.body.request.id as number;
    expect(created[1]!.body.request.id).toBe(requestId);
    let listing = requestsResponseSchema.parse((await admin.get('/api/admin/requests')).body);
    expect(listing.requests).toHaveLength(1);
    expect(listing.requests[0]?.supporters).toHaveLength(2);
    expect(listing.requests[0]?.events).toHaveLength(1);
    await first
      .patch(`/api/requests/${requestId}/support`)
      .send({ reason: 'Movie Night', note: 'Friday together' });
    expect(
      (
        await admin
          .patch(`/api/admin/requests/${requestId}`)
          .send({ status: 'looking', adminNote: 'Private note' })
      ).status,
    ).toBe(200);
    listing = requestsResponseSchema.parse((await first.get('/api/requests')).body);
    expect(listing.requests[0]).toMatchObject({
      status: 'looking',
      reason: 'Movie Night',
      note: 'Friday together',
    });
    expect(listing.requests[0]).not.toHaveProperty('adminNote');
    expect(listing.requests[0]?.events.at(-1)).toMatchObject({
      fromStatus: 'requested',
      toStatus: 'looking',
      actorProfileId: 1,
    });
    expect(
      (await first.patch(`/api/admin/requests/${requestId}`).send({ status: 'passed' })).status,
    ).toBe(403);
    expect(
      (await admin.patch(`/api/admin/requests/${requestId}`).send({ status: 'available' })).status,
    ).toBe(409);
    expect(
      (await admin.patch(`/api/admin/requests/${requestId}`).send({ status: 'passed' })).status,
    ).toBe(200);
    expect(
      (await admin.patch(`/api/admin/requests/${requestId}`).send({ status: 'requested' })).status,
    ).toBe(200);
    const detail = familyDetailResponseSchema.parse(
      (await second.get('/api/titles/movie/9900001')).body,
    );
    expect(detail.request?.isSupporter).toBe(true);
    expect(detail.title.requestStatus).toBe('requested');
    expect((await first.get('/api/home')).text).toContain('Requested by Your Family');
  });
  it('cancels only after the last supporter withdraws and hides cancelled requests', async () => {
    const server = app();
    const first = await member(server, 2);
    const second = await member(server, 3);
    const req = (await first.post('/api/requests').send({ mediaType: 'movie', tmdbId: 9900002 }))
      .body.request as { id: number };
    await second.post('/api/requests').send({ mediaType: 'movie', tmdbId: 9900002 });
    await first.delete(`/api/requests/${req.id}/support`);
    expect((await second.get('/api/requests')).body.requests).toHaveLength(1);
    const result = await second.delete(`/api/requests/${req.id}/support`);
    expect(result.body.request.status).toBe('cancelled');
    expect(result.body.request.events.at(-1)).toMatchObject({
      toStatus: 'cancelled',
      actorProfileId: null,
    });
    expect((await second.get('/api/requests')).body.requests).toHaveLength(0);
  });
  it('marks watched only from Available for active supporters or unlocked admins', async () => {
    seedDatabase(database);
    const server = app();
    const owner = await member(server, 4);
    const other = await member(server, 3);
    expect((await other.post('/api/requests/3/watched')).status).toBe(403);
    expect((await owner.post('/api/requests/3/watched')).status).toBe(200);
    expect((await owner.post('/api/requests/3/watched')).status).toBe(409);
    const result = (await owner.get('/api/requests/3')).body.request;
    expect(result.events.at(-1)).toMatchObject({ toStatus: 'watched', actorProfileId: 4 });
  });
  it('fails closed for unrated/restricted titles across direct, related, requests, and list routes', async () => {
    seedDatabase(database);
    const server = app();
    const admin = await member(server, 1, true);
    const kid = await member(server, 2);
    await admin.patch('/api/admin/profiles/2').send({ maxRatingLevel: 2 });
    const home = await kid.get('/api/home');
    expect(home.status).toBe(200);
    expect(home.text).not.toContain('The Last Projection');
    expect(home.text).not.toContain('Echoes of Tomorrow');
    expect(home.text).not.toContain('The Unwritten Map');
    const detail = await kid.get('/api/titles/movie/9900002');
    expect(detail.status).toBe(200);
    expect(detail.text).not.toContain('Echoes of Tomorrow');
    for (const title of [9900001, 9900005, 9900006]) {
      expect((await kid.get(`/api/titles/movie/${title}`)).status).toBe(404);
      expect(
        (await kid.post('/api/requests').send({ mediaType: 'movie', tmdbId: title })).status,
      ).toBe(404);
      expect((await kid.put(`/api/list/movie/${title}`)).status).toBe(404);
    }
    expect((await kid.get('/api/requests')).text).not.toContain('The Last Projection');
    expect((await kid.get('/api/requests/1')).status).toBe(404);
    expect((await kid.patch('/api/requests/1/support').send({ note: 'bypass' })).status).toBe(404);
    expect((await kid.put('/api/list/movie/9900002')).status).toBe(200);
    expect((await kid.get('/api/list')).body.items).toHaveLength(1);
    expect((await admin.get('/api/list')).body.items).toHaveLength(0);
  });
  it('hydrates missing live list ratings and excludes failed or unknown certifications', async () => {
    const upstream = vi.fn<typeof fetch>().mockImplementation(async (input) => {
      const url = new URL(String(input));
      const id = Number(url.pathname.split('/').at(-1));
      if (url.pathname.includes('/movie/') && [101, 102, 103].includes(id))
        return Response.json({
          id,
          title: `Title ${id}`,
          release_dates: {
            results: [
              {
                iso_3166_1: 'US',
                release_dates: [
                  {
                    type: 3,
                    certification: id === 101 ? 'PG' : id === 102 ? 'R' : '',
                    release_date: '2020-01-01',
                  },
                ],
              },
            ],
          },
        });
      return Response.json({
        results: [101, 102, 103].map((id) => ({ id, title: `Title ${id}` })),
      });
    });
    const server = app({ catalog: { token: 'test-only', fetch: upstream } });
    const kid = await member(server);
    database.db.update(profiles).set({ maxRatingLevel: 2 }).where(eq(profiles.id, 2)).run();
    const result = await kid.get('/api/home?type=movie');
    expect(result.status).toBe(200);
    expect(result.text).toContain('Title 101');
    expect(result.text).not.toContain('Title 102');
    expect(result.text).not.toContain('Title 103');
  });
  it('preserves request details for isolated demo rows with a live metadata token', async () => {
    seedDatabase(database);
    const upstream = vi.fn<typeof fetch>();
    const server = app({ catalog: { token: 'test-only', fetch: upstream } });
    const family = await member(server);
    const result = await family.get('/api/titles/movie/9900001');
    expect(result.status).toBe(200);
    expect(result.body.mode).toBe('demo');
    expect(result.body.request.id).toBe(1);
    expect(upstream).not.toHaveBeenCalled();
  });
  it('prevents last-admin deletion, validates photos, and does not silently clear unchanged fields', async () => {
    const server = app();
    const admin = await member(server, 1, true);
    expect((await admin.delete('/api/admin/profiles/1')).status).toBe(409);
    expect(
      (
        await admin
          .patch('/api/admin/profiles/2')
          .send({ avatar: 'data:image/png;base64,aGVsbG8=' })
      ).status,
    ).toBe(400);
    await admin.patch('/api/admin/profiles/2').send({ maxRatingLevel: 2 });
    await admin.patch('/api/admin/profiles/2').send({ name: 'Kid' });
    expect(
      (await admin.get('/api/admin/profiles')).body.profiles.find(
        (profile: { id: number }) => profile.id === 2,
      ),
    ).toMatchObject({ name: 'Kid', maxRatingLevel: 2 });
  });
  it('accepts a 2 MB photo, sanitizes storage, and rejects larger photos', async () => {
    const server = app();
    const admin = await member(server, 1, true);
    const png = await sharp({ create: { width: 400, height: 300, channels: 3,
      background: '#123456' } }).png().toBuffer();
    // Legal trailing PNG padding exercises the full HTTP/base64 boundary with a decodable image.
    const bytes = Buffer.concat([png, Buffer.alloc(2_000_000 - png.length)]);
    expect((await admin.patch('/api/admin/profiles/2').send({
      avatar: `data:image/png;base64,${bytes.toString('base64')}`,
    })).status).toBe(200);
    const saved = database.db.select().from(profiles).where(eq(profiles.id, 2)).get()!.avatar;
    const stored = Buffer.from(saved.split(',')[1]!, 'base64');
    expect(stored.length).toBeLessThan(350_000);
    expect(await sharp(stored).metadata()).toMatchObject({ width: 256, height: 256, format: 'png' });
    expect((await admin.patch('/api/admin/profiles/2').send({
      avatar: `data:image/png;base64,${Buffer.concat([bytes, Buffer.alloc(1)]).toString('base64')}`,
    })).status).toBe(400);
    expect(database.db.select().from(profiles).where(eq(profiles.id, 2)).get()!.avatar).toBe(saved);
  });
});
