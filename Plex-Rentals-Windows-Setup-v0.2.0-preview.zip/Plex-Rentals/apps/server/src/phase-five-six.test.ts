import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from './app.js';
import { migrateDatabase, openDatabase } from './db/client.js';
import { plexItems, profiles, reactions, titles } from './db/schema.js';

describe('Phase 5 and 6 family workflows', () => {
  it('persists reactions, searches the library, and completes a Movie Night', async () => {
    const database = openDatabase(':memory:');
    migrateDatabase(database);
    try {
      const emma = database.db
        .insert(profiles)
        .values({ name: 'Emma', avatar: 'preset:explorer', color: '#5AB8F0' })
        .returning()
        .get()!;
      for (const [index, tmdbId] of [9900003, 9900004].entries()) {
        const ratingKey = `night-${tmdbId}`;
        database.db
          .insert(plexItems)
          .values({
            ratingKey,
            sectionId: 'movies',
            mediaType: 'movie',
            title: `Candidate ${index + 1}`,
            tmdbId,
          })
          .run();
        database.db
          .insert(titles)
          .values({
            tmdbId,
            mediaType: 'movie',
            title: `Candidate ${index + 1}`,
            certification: 'PG',
            plexRatingKey: ratingKey,
            plexMatch: 'tmdb',
          })
          .run();
      }
      const origin = 'http://localhost:8080';
      const agent = request.agent(
        createApp(database, {
          plexUrl: '',
          auth: {
            householdPasscode: 'qa-household-passcode',
            sessionSecret: 'qa-session-secret-with-at-least-thirty-two-characters',
            adminPin: '8173',
            baseUrl: origin,
          },
        }),
      );
      await agent
        .post('/api/household/join')
        .set('Origin', origin)
        .send({ passcode: 'qa-household-passcode' })
        .expect(200);
      await agent
        .post('/api/session')
        .set('Origin', origin)
        .send({ profileId: emma.id })
        .expect(200);

      const search = await agent.get('/api/search?plex=available').expect(200);
      expect(search.body.results).toHaveLength(2);
      await agent
        .put('/api/reactions')
        .set('Origin', origin)
        .send({ mediaType: 'movie', tmdbId: 9900003, reaction: 'up' })
        .expect(200);
      expect(database.db.select().from(reactions).all()).toHaveLength(1);

      const created = await agent
        .post('/api/movie-nights')
        .set('Origin', origin)
        .send({
          participants: [emma.id],
          type: 'movie',
          maxRuntime: null,
          inPlexOnly: true,
          mode: 'own_device',
        })
        .expect(201);
      expect(created.body.movieNight.candidates).toHaveLength(2);
      const titleId = created.body.movieNight.candidates[0].titleId as number;
      const voted = await agent
        .put(`/api/movie-nights/${created.body.movieNight.id}/vote`)
        .set('Origin', origin)
        .send({ titleId, vote: 3 })
        .expect(200);
      expect(
        voted.body.movieNight.candidates.find(
          (item: { titleId: number }) => item.titleId === titleId,
        ).myVote,
      ).toBe(3);
      const closed = await agent
        .post(`/api/movie-nights/${created.body.movieNight.id}/close`)
        .set('Origin', origin)
        .send({ titleId })
        .expect(200);
      expect(closed.body.movieNight).toMatchObject({ status: 'closed', winnerTitleId: titleId });
    } finally {
      database.close();
    }
  });
});
