import {
  ratingLevels,
  discoveryCollections,
  type DiscoverQuery,
  type HomeRow,
  type MediaType,
} from '@reelrequest/shared';
import { eq } from 'drizzle-orm';
import sharp from 'sharp';
import type { AppDatabase } from '../../db/client.js';
import { settings, titles } from '../../db/schema.js';
import {
  isSyntheticId,
  list,
  normalizeCard,
  normalizeDetail,
  object,
  type JsonObject,
} from './normalize.js';

export class CatalogError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
  ) {
    super(message);
    this.name = 'CatalogError';
  }
}
type Options = {
  token: string;
  region?: string;
  language?: string;
  fetch?: typeof fetch;
  now?: () => Date;
};
type Cached = { data: JsonObject; fetchedAt: number };
export function createTmdbCatalog(database: AppDatabase, options: Options) {
  const region = options.region ?? 'US';
  const language = options.language ?? 'en-US';
  const now = options.now ?? (() => new Date());
  const fetcher = options.fetch ?? fetch;
  const pending = new Map<string, Promise<Cached & { stale: boolean }>>();
  const configError = () =>
    new CatalogError(
      503,
      'TMDB_CONFIGURATION',
      'TMDB is not configured with a valid read access token.',
    );
  async function posterColor(path: unknown): Promise<string> {
    if (typeof path !== 'string' || !/^\/[a-zA-Z0-9_.-]+$/.test(path)) return '#263449';
    try {
      const response = await fetcher(`https://image.tmdb.org/t/p/w92${path}`, {
        signal: AbortSignal.timeout(3000),
        redirect: 'error',
      });
      if (
        !response.ok ||
        !response.body ||
        Number(response.headers.get('content-length')) > 1024 * 1024
      )
        return '#263449';
      const reader = response.body.getReader();
      const chunks: Uint8Array[] = [];
      let size = 0;
      try {
        while (true) {
          const part = await reader.read();
          if (part.done) break;
          size += part.value.byteLength;
          if (size > 1024 * 1024) {
            await reader.cancel();
            return '#263449';
          }
          chunks.push(part.value);
        }
      } finally {
        reader.releaseLock();
      }
      const stats = await sharp(Buffer.concat(chunks), { limitInputPixels: 1000000 })
        .resize(16, 16, { fit: 'inside' })
        .stats();
      return `#${[stats.dominant.r, stats.dominant.g, stats.dominant.b].map((channel) => channel.toString(16).padStart(2, '0')).join('')}`;
    } catch {
      return '#263449';
    }
  }
  async function load(
    endpoint: string,
    detail = false,
    force = false,
  ): Promise<Cached & { stale: boolean }> {
    if (!options.token.trim() || /[\r\n]/.test(options.token)) throw configError();
    const key = `tmdb:v1:${region}:${language}:${endpoint}`;
    const active = pending.get(key);
    if (active) return active;
    const work = (async () => {
      let cached: Cached | undefined;
      const row = database.db.select().from(settings).where(eq(settings.key, key)).get();
      if (row) {
        try {
          const parsed = object(JSON.parse(row.value) as unknown);
          if (typeof parsed.fetchedAt === 'number' && Object.keys(object(parsed.data)).length)
            cached = { fetchedAt: parsed.fetchedAt, data: object(parsed.data) };
        } catch {
          /* Invalid caches are replaced from the upstream. */
        }
      }
      const cacheHours = detail || endpoint.startsWith('/search/') ? 24 : 6;
      if (!force && cached && now().getTime() - cached.fetchedAt < cacheHours * 3600000)
        return { ...cached, stale: false };
      try {
        const url = new URL(`https://api.themoviedb.org/3${endpoint}`);
        url.searchParams.set('language', language);
        url.searchParams.set('region', region);
        if (detail) {
          url.searchParams.set(
            'append_to_response',
            `credits,videos,${endpoint.startsWith('/movie/') ? 'release_dates' : 'content_ratings'},recommendations,external_ids,images`,
          );
          url.searchParams.set('include_image_language', 'en,null');
        }
        const response = await fetcher(url, {
          headers: { Authorization: `Bearer ${options.token}`, Accept: 'application/json' },
          signal: AbortSignal.timeout(8000),
          redirect: 'error',
        });
        if (response.status === 401 || response.status === 403) throw configError();
        if (response.status === 404)
          throw new CatalogError(404, 'TITLE_NOT_FOUND', 'This title could not be found.');
        if (!response.ok)
          throw new CatalogError(
            503,
            'TMDB_UNAVAILABLE',
            'Movie information is temporarily unavailable.',
          );
        const data = object((await response.json()) as unknown);
        if (endpoint.startsWith('/collection/') && Array.isArray(data.parts))
          data.results = data.parts;
        if (detail ? data.id !== Number(endpoint.split('/').at(-1)) : !Array.isArray(data.results))
          throw new CatalogError(
            502,
            'TMDB_RESPONSE_INVALID',
            'Movie information could not be read.',
          );
        // Validate before caching so an upstream schema change cannot poison a healthy cache.
        if (detail) {
          normalizeDetail(data, endpoint.startsWith('/movie/') ? 'movie' : 'tv', now());
          data.reelrequest_color = await posterColor(data.poster_path);
        } else if (!endpoint.startsWith('/search/multi'))
          list(data.results).forEach((entry) =>
            normalizeCard(entry, endpoint.includes('movie') ? 'movie' : 'tv', now()),
          );
        const fetchedAt = now().getTime();
        const value = JSON.stringify({ data, fetchedAt });
        database.db
          .insert(settings)
          .values({ key, value })
          .onConflictDoUpdate({ target: settings.key, set: { value } })
          .run();
        return { data, fetchedAt, stale: false };
      } catch (error) {
        if (
          error instanceof CatalogError &&
          (error.code === 'TMDB_CONFIGURATION' || error.status === 404)
        )
          throw error;
        if (cached) return { ...cached, stale: true };
        throw error instanceof CatalogError
          ? error
          : new CatalogError(
              503,
              'TMDB_UNAVAILABLE',
              'Movie information is temporarily unavailable.',
            );
      }
    })();
    pending.set(key, work);
    try {
      return await work;
    } finally {
      pending.delete(key);
    }
  }
  async function detail(type: MediaType, id: number, force = false) {
    if (!Number.isSafeInteger(id) || id <= 0 || isSyntheticId(id))
      throw new CatalogError(404, 'TITLE_NOT_FOUND', 'This title could not be found.');
    const result = await load(`/${type}/${id}`, true, force);
    if (result.data.id !== id)
      throw new CatalogError(502, 'TMDB_RESPONSE_INVALID', 'Movie information could not be read.');
    const title = normalizeDetail(result.data, type, now());
    const externalIds = object(result.data.external_ids);
    const fields = {
      tmdbId: id,
      imdbId: typeof externalIds.imdb_id === 'string' ? externalIds.imdb_id : null,
      tvdbId: typeof externalIds.tvdb_id === 'number' ? externalIds.tvdb_id : null,
      mediaType: type,
      title: title.title,
      year: title.year,
      overview: title.overview,
      posterPath: title.posterPath,
      backdropPath: title.backdropPath,
      logoPath: title.logoPath,
      runtimeMin: title.runtimeMin,
      certification: title.certification,
      ratingLevel: title.certification ? (ratingLevels[title.certification] ?? null) : null,
      tmdbScore: title.tmdbScore,
      genres: title.genres,
      cast: title.cast,
      crew: title.crew,
      trailerKey: title.trailerKey,
      releaseTheatrical: title.releaseTheatrical,
      releaseDigital: title.releaseDigital,
      releasePhysical: title.releasePhysical,
      nextAirDate: title.nextAirDate,
      releaseState: title.releaseState,
      colorHex: title.colorHex,
      fetchedAt: new Date(result.fetchedAt).toISOString(),
    };
    database.db
      .insert(titles)
      .values(fields)
      .onConflictDoUpdate({ target: [titles.tmdbId, titles.mediaType], set: fields })
      .run();
    return { title, stale: result.stale };
  }
  return {
    async discover(query: DiscoverQuery) {
      const preset =
        query.collection && query.collection !== 'standup'
          ? discoveryCollections[query.collection]
          : null;
      const params = new URLSearchParams({
        page: String(query.page),
        include_adult: 'false',
        sort_by: 'popularity.desc',
        'vote_count.gte': '50',
      });
      const genre = query.genre || preset?.genre;
      if (genre) params.set('with_genres', genre);
      if (query.collection === 'standup') {
        params.set('with_keywords', '9716');
        params.delete('vote_count.gte');
      }
      const decade = query.decade ?? (query.collection === 'nineties' ? 1990 : undefined);
      if (decade) {
        params.set('primary_release_date.gte', `${decade}-01-01`);
        params.set('primary_release_date.lte', `${decade + 9}-12-31`);
      }
      if (query.score || ['mystery', 'space'].includes(query.collection ?? ''))
        params.set('vote_average.gte', String(query.score ?? 7));
      if (query.runtime || query.collection === 'short') {
        params.set('with_runtime.gte', '40');
        params.set('with_runtime.lte', String(query.runtime ?? 99));
      }
      if (query.provider) {
        params.set('watch_region', region);
        params.set('with_watch_providers', query.provider);
        params.set('with_watch_monetization_types', 'flatrate');
      }
      if (query.cast) params.set('with_cast', String(query.cast));
      if (query.director) params.set('with_crew', String(query.director));
      if (query.availability === 'soon') {
        params.delete('vote_count.gte');
        params.set(
          'primary_release_date.gte',
          new Date(now().getTime() + 86400000).toISOString().slice(0, 10),
        );
      }
      let endpoint = `/discover/movie?${params}`;
      if (query.similar) endpoint = `/movie/${query.similar}/recommendations?page=${query.page}`;
      if (query.franchise) {
        const movie = await load(`/movie/${query.franchise}`, true);
        const collectionId = object(movie.data.belongs_to_collection).id;
        if (typeof collectionId !== 'number')
          return { items: [], stale: movie.stale, nextPage: null };
        endpoint = `/collection/${collectionId}`;
      }
      const result = await load(endpoint);
      const items = list(result.data.results).flatMap((entry) => {
        try {
          return [normalizeCard(entry, 'movie', now())];
        } catch {
          return [];
        }
      });
      return {
        items,
        stale: result.stale,
        nextPage:
          query.page < Math.min(500, Number(result.data.total_pages) || 1) ? query.page + 1 : null,
      };
    },
    async search(query: string) {
      const result = await load(`/search/multi?query=${encodeURIComponent(query)}`);
      const entries = list(result.data.results);
      const cards = entries.flatMap((entry) => {
        const kind = entry.media_type;
        if (kind !== 'movie' && kind !== 'tv') return [];
        try {
          return [normalizeCard(entry, kind, now())];
        } catch {
          return [];
        }
      });
      const firstPerson = entries.find((entry) => entry.media_type === 'person');
      const knownFor = firstPerson
        ? list(firstPerson.known_for).flatMap((entry) => {
            const kind = entry.media_type;
            if (kind !== 'movie' && kind !== 'tv') return [];
            try {
              return [normalizeCard(entry, kind, now())];
            } catch {
              return [];
            }
          })
        : [];
      return {
        items: cards.slice(0, 40),
        person:
          firstPerson && typeof firstPerson.id === 'number' && typeof firstPerson.name === 'string'
            ? {
                id: firstPerson.id,
                name: firstPerson.name,
                profilePath:
                  typeof firstPerson.profile_path === 'string' ? firstPerson.profile_path : null,
                knownFor: knownFor.slice(0, 20),
              }
            : null,
        stale: result.stale,
      };
    },
    async home(type?: MediaType) {
      const definitions: {
        endpoint: string;
        type: MediaType;
        id: string;
        title: string;
        pages?: number;
      }[] = [
        {
          endpoint: '/trending/movie/week',
          type: 'movie',
          id: 'trending-movies',
          title: 'Trending movies',
        },
        { endpoint: '/trending/tv/week', type: 'tv', id: 'trending-tv', title: 'Trending shows' },
        { endpoint: '/movie/now_playing', type: 'movie', id: 'now-playing', title: 'In theaters' },
        { endpoint: '/movie/upcoming', type: 'movie', id: 'upcoming', title: 'Coming soon' },
        {
          endpoint: '/movie/popular',
          type: 'movie',
          id: 'popular-movies',
          title: 'Popular movies',
        },
        { endpoint: '/tv/popular', type: 'tv', id: 'popular-tv', title: 'Popular shows' },
        {
          endpoint: '/movie/top_rated',
          type: 'movie',
          id: 'top-rated-movies',
          title: 'Highly rated movies',
        },
        {
          endpoint: '/discover/movie?sort_by=popularity.desc&with_genres=28',
          type: 'movie',
          id: 'action-movies',
          title: 'Action Night',
        },
        {
          endpoint: '/discover/movie?sort_by=popularity.desc&with_genres=35',
          type: 'movie',
          id: 'comedy-movies',
          title: 'Laugh Out Loud',
        },
        {
          endpoint: '/discover/movie?sort_by=popularity.desc&with_genres=878',
          type: 'movie',
          id: 'science-fiction-movies',
          title: 'Science Fiction Worlds',
        },
        {
          endpoint: '/discover/movie?sort_by=popularity.desc&with_genres=10751',
          type: 'movie',
          id: 'family-movies',
          title: 'Family Movie Night',
        },
        {
          endpoint: '/discover/movie?sort_by=popularity.desc&with_genres=16',
          type: 'movie',
          id: 'animated-movies',
          title: 'Animated Favorites',
        },
        {
          endpoint: '/discover/movie?sort_by=popularity.desc&with_genres=53',
          type: 'movie',
          id: 'thriller-movies',
          title: 'Thrills & Suspense',
        },
        {
          endpoint: '/discover/movie?sort_by=popularity.desc&with_genres=99',
          type: 'movie',
          id: 'documentary-movies',
          title: 'Remarkable Documentaries',
        },
        {
          endpoint:
            '/discover/movie?sort_by=vote_average.desc&vote_count.gte=750&primary_release_date.lte=1999-12-31',
          type: 'movie',
          id: 'classic-movies',
          title: 'Modern Classics',
        },
        {
          endpoint: '/discover/movie?sort_by=vote_average.desc&vote_count.gte=1000',
          type: 'movie',
          id: 'critically-acclaimed-movies',
          title: 'Critically Acclaimed',
        },
        {
          endpoint:
            '/discover/movie?sort_by=vote_average.desc&vote_count.gte=100&vote_count.lte=1500&vote_average.gte=7&primary_release_date.lte=' +
            now().toISOString().slice(0, 10),
          type: 'movie',
          id: 'hidden-gems',
          title: 'Hidden Gems',
        },
        {
          endpoint:
            '/discover/movie?sort_by=popularity.desc&with_runtime.gte=40&with_runtime.lte=99&primary_release_date.lte=' +
            now().toISOString().slice(0, 10),
          type: 'movie',
          id: 'under-100',
          title: 'Under 100 Minutes',
        },
        {
          endpoint:
            '/discover/movie?watch_region=' +
            encodeURIComponent(region) +
            '&with_watch_monetization_types=flatrate&with_watch_providers=8&sort_by=popularity.desc',
          type: 'movie',
          id: 'netflix',
          title: 'Popular on Netflix',
          pages: 5,
        },
        {
          endpoint:
            '/discover/movie?watch_region=' +
            encodeURIComponent(region) +
            '&with_watch_monetization_types=flatrate&with_watch_providers=15&sort_by=popularity.desc',
          type: 'movie',
          id: 'hulu',
          title: 'Popular on Hulu',
          pages: 5,
        },
        { endpoint: '/tv/on_the_air', type: 'tv', id: 'on-the-air', title: 'On the air' },
        {
          endpoint:
            '/discover/movie?with_genres=16&with_original_language=ja&sort_by=popularity.desc',
          type: 'movie',
          id: 'anime-movies',
          title: 'Anime Films',
          pages: 2,
        },
        {
          endpoint: '/discover/tv?with_genres=16&with_original_language=ja&sort_by=popularity.desc',
          type: 'tv',
          id: 'anime-series',
          title: 'Anime Series',
          pages: 2,
        },
        {
          endpoint:
            '/discover/tv?with_genres=16&with_original_language=ja&sort_by=popularity.desc&vote_count.gte=50',
          type: 'tv',
          id: 'anime-trending',
          title: 'Trending Across Anime',
          pages: 2,
        },
        {
          endpoint:
            '/discover/tv?with_genres=16&with_original_language=ja&sort_by=first_air_date.desc&first_air_date.lte=' +
            now().toISOString().slice(0, 10),
          type: 'tv',
          id: 'anime-new',
          title: 'Fresh From Japan',
          pages: 2,
        },
        {
          endpoint:
            '/discover/tv?with_genres=16&with_original_language=ja&sort_by=vote_average.desc&vote_count.gte=250',
          type: 'tv',
          id: 'anime-favorites',
          title: 'All-Time Fan Favorites',
          pages: 2,
        },
        {
          endpoint:
            '/discover/tv?with_genres=16,10759&with_original_language=ja&sort_by=popularity.desc',
          type: 'tv',
          id: 'anime-action',
          title: 'Power, Battles & Adventure',
          pages: 2,
        },
        {
          endpoint:
            '/discover/tv?with_genres=16,10765&with_original_language=ja&sort_by=popularity.desc',
          type: 'tv',
          id: 'anime-scifi',
          title: 'Mecha, Sci-Fi & Other Worlds',
          pages: 2,
        },
        {
          endpoint:
            '/discover/movie?with_genres=16,14&with_original_language=ja&sort_by=vote_average.desc&vote_count.gte=100',
          type: 'movie',
          id: 'anime-fantasy',
          title: 'Fantasy Worlds',
          pages: 2,
        },
        {
          endpoint: `/discover/movie?watch_region=${encodeURIComponent(region)}&with_watch_monetization_types=flatrate&with_watch_providers=350&sort_by=popularity.desc`,
          type: 'movie',
          id: 'apple-tv',
          title: 'Popular on Apple TV',
          pages: 5,
        },
        {
          endpoint: `/discover/movie?watch_region=${encodeURIComponent(region)}&with_watch_monetization_types=flatrate&with_watch_providers=337&sort_by=popularity.desc`,
          type: 'movie',
          id: 'disney-plus',
          title: 'Popular on Disney+',
          pages: 5,
        },
      ];
      const providers = await load('/watch/providers/movie').catch(() => null);
      const providerIds: Record<string, number> = {
        netflix: 8,
        hulu: 15,
        'apple-tv': 350,
        'disney-plus': 337,
      };
      const results = await Promise.all(
        definitions
          .filter((row) => !type || row.type === type)
          .map(async (row) => {
            const pageResults = await Promise.all(
              Array.from({ length: row.pages ?? 1 }, (_, index) =>
                load(`${row.endpoint}${row.endpoint.includes('?') ? '&' : '?'}page=${index + 1}`),
              ),
            );
            const items = pageResults
              .flatMap((result) => list(result.data.results))
              .filter((entry) => typeof entry.id === 'number' && !isSyntheticId(entry.id))
              .map((entry) => normalizeCard(entry, row.type, now()));
            const homeRow: HomeRow = {
              id: row.id,
              title: row.title,
              logoPath: (() => {
                const provider = list(providers?.data.results).find(
                  (item) => item.provider_id === providerIds[row.id],
                );
                return typeof provider?.logo_path === 'string' ? provider.logo_path : null;
              })(),
              items: [
                ...new Map(
                  items.map((item) => [`${item.mediaType}:${item.tmdbId}`, item]),
                ).values(),
              ],
            };
            return { row: homeRow, stale: pageResults.some((result) => result.stale) };
          }),
      );
      return {
        rows: results.map((entry) => entry.row),
        stale: results.some((entry) => entry.stale),
      };
    },
    detail: (type: MediaType, id: number) => detail(type, id),
    refreshDetail: (type: MediaType, id: number) => detail(type, id, true),
  };
}
