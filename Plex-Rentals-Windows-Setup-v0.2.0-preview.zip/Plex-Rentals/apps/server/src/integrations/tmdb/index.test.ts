import { afterEach, describe, expect, it, vi } from 'vitest';
import { migrateDatabase, openDatabase, type AppDatabase } from '../../db/client.js';
import { createTmdbCatalog } from './index.js';
import { normalizeDetail, releaseFor, trailerFor } from './normalize.js';

const now = new Date('2026-09-24T00:00:00Z');
const movie = {
  id: 123,
  title: 'A movie',
  release_date: '2020-01-01',
  status: 'Released',
  vote_average: 8.123,
};
const dates = (entries: { type: number; release_date: string; certification?: string }[]) => ({
  release_dates: { results: [{ iso_3166_1: 'US', release_dates: entries }] },
});
const databases: AppDatabase[] = [];
function database() {
  const db = openDatabase(':memory:');
  migrateDatabase(db);
  databases.push(db);
  return db;
}
afterEach(() => {
  databases.splice(0).forEach((db) => db.close());
});

describe('TMDB normalization', () => {
  it('pages through stand-up without a popularity or vote-count cutoff',async()=>{
    const catalog=createTmdbCatalog(database(),{token:'test',now:()=>now,fetch:async input=>{
      const url=new URL(String(input));
      expect(url.searchParams.get('with_keywords')).toBe('9716');
      expect(url.searchParams.has('vote_count.gte')).toBe(false);
      expect(url.searchParams.get('page')).toBe('2');
      return Response.json({results:[movie],total_pages:70});
    }});
    expect(await catalog.discover({collection:'standup',page:2,availability:'all'})).toMatchObject({nextPage:3,items:[{tmdbId:123}]});
  });
  it('combines discovery filters, paginates and caches without losing constraints', async () => {
    let calls = 0;
    const catalog = createTmdbCatalog(database(), {
      token: 'test',
      now: () => now,
      fetch: async (input) => {
        calls++;
        const url = new URL(String(input));
        expect(url.pathname).toBe('/3/discover/movie');
        expect(url.searchParams.get('page')).toBe('2');
        expect(url.searchParams.get('with_genres')).toBe('35');
        expect(url.searchParams.get('with_runtime.lte')).toBe('99');
        expect(url.searchParams.get('with_watch_providers')).toBe('8');
        expect(url.searchParams.get('include_adult')).toBe('false');
        return Response.json({ results: [movie], total_pages: 4 });
      },
    });
    const query = {
      page: 2,
      collection: 'comedy' as const,
      runtime: 99,
      provider: '8' as const,
      availability: 'all' as const,
    };
    expect(await catalog.discover(query)).toMatchObject({ nextPage: 3, items: [{ tmdbId: 123 }] });
    await catalog.discover(query);
    expect(calls).toBe(1);
  });
  it('uses home-release dates and the strict 120-day theatrical threshold', () => {
    expect(releaseFor(dates([{ type: 4, release_date: '2026-09-24' }]), 'movie', now)).toBe(
      'released',
    );
    expect(releaseFor(dates([{ type: 4, release_date: '2026-09-25' }]), 'movie', now)).toBe(
      'coming_soon',
    );
    const theatrical = new Date(now.getTime() - 120 * 86400000).toISOString();
    expect(releaseFor(dates([{ type: 3, release_date: theatrical }]), 'movie', now)).toBe(
      'coming_soon',
    );
    expect(
      releaseFor(
        dates([{ type: 3, release_date: theatrical }]),
        'movie',
        new Date(now.getTime() + 86400000),
      ),
    ).toBe('released');
    expect(releaseFor({ status: 'Released' }, 'movie', now)).toBe('released');
    expect(releaseFor({ status: 'In Production' }, 'movie', now)).toBe('unknown');
    expect(releaseFor(dates([{ type: 4, release_date: '2026-02-31' }]), 'movie', now)).toBe(
      'unknown',
    );
  });
  it('does not treat theatrical list release_date as a home release', () => {
    expect(releaseFor({ release_date: '2026-01-01' }, 'movie', now)).toBe('unknown');
  });
  it('uses season one over the next unaired TV episode', () => {
    expect(
      releaseFor(
        { first_air_date: '2020-01-01', next_episode_to_air: { air_date: '2027-01-01' } },
        'tv',
        now,
      ),
    ).toBe('released');
    expect(releaseFor({ seasons: [{ season_number: 1, air_date: '2027-01-01' }] }, 'tv', now)).toBe(
      'coming_soon',
    );
    expect(releaseFor({}, 'tv', now)).toBe('unknown');
  });
  it('chooses official trailers before teasers and rejects unsafe keys', () => {
    const video = (key: string, type: string, official: boolean, published_at: string) => ({
      key,
      type,
      official,
      published_at,
      site: 'YouTube',
    });
    expect(
      trailerFor({
        videos: {
          results: [
            video('teaser00001', 'Teaser', true, '2026'),
            video('trailer0001', 'Trailer', false, '2026'),
            video('official001', 'Trailer', true, '2025'),
            video('../unsafe', 'Trailer', true, '2027'),
          ],
        },
      }),
    ).toBe('official001');
    expect(trailerFor({})).toBeNull();
  });
  it('normalizes detail and keeps availability and requests independent', () => {
    const title = normalizeDetail(
      {
        ...movie,
        ...dates([{ type: 3, release_date: '2020-01-01', certification: 'PG-13' }]),
        images: {
          logos: [
            { iso_639_1: 'fr', vote_average: 10, file_path: '/fr.png' },
            { iso_639_1: null, vote_average: 9, file_path: '/logo.png' },
          ],
        },
        credits: { cast: Array.from({ length: 18 }, (_, id) => ({ id, name: 'Actor' })) },
      },
      'movie',
      now,
    );
    expect(title).toMatchObject({
      logoPath: '/logo.png',
      tmdbScore: 8.1,
      certification: 'PG-13',
      plexState: 'unknown',
      releaseState: 'released',
      trailerKey: null,
    });
    expect(title.cast).toHaveLength(15);
    expect(title).not.toHaveProperty('requestStatus');
  });
});

describe('TMDB server cache and safety', () => {
  it('does not cache a detail response for the wrong title', async () => {
    const db = database();
    const fetcher = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(new Response(JSON.stringify({ ...movie, id: 456 })))
      .mockResolvedValueOnce(new Response(JSON.stringify(movie)));
    const catalog = createTmdbCatalog(db, { token: 'secret', fetch: fetcher });
    await expect(catalog.detail('movie', 123)).rejects.toMatchObject({
      code: 'TMDB_RESPONSE_INVALID',
    });
    expect(
      db.sqlite.prepare("SELECT count(*) AS count FROM settings WHERE key LIKE 'tmdb:%'").get(),
    ).toEqual({ count: 0 });
    expect((await catalog.detail('movie', 123)).title.tmdbId).toBe(123);
    expect(fetcher).toHaveBeenCalledTimes(2);
  });
  it('retains original metadata fetch timestamp when reading a fresh cache', async () => {
    const db = database();
    let clock = now;
    const catalog = createTmdbCatalog(db, {
      token: 'secret',
      now: () => clock,
      fetch: vi.fn<typeof fetch>().mockResolvedValueOnce(new Response(JSON.stringify(movie))),
    });
    await catalog.detail('movie', 123);
    clock = new Date(now.getTime() + 3600000);
    await catalog.detail('movie', 123);
    expect(db.sqlite.prepare('SELECT fetched_at FROM titles WHERE tmdb_id = 123').get()).toEqual({
      fetched_at: now.toISOString(),
    });
  });
  it('coalesces requests, caches details for 24h, and marks outage fallback stale', async () => {
    let clock = now;
    const fetcher = vi.fn<typeof fetch>().mockResolvedValue(new Response(JSON.stringify(movie)));
    const catalog = createTmdbCatalog(database(), {
      token: 'secret',
      now: () => clock,
      fetch: fetcher,
    });
    await Promise.all([catalog.detail('movie', 123), catalog.detail('movie', 123)]);
    expect(fetcher).toHaveBeenCalledTimes(1);
    clock = new Date(now.getTime() + 23 * 3600000);
    expect((await catalog.detail('movie', 123)).stale).toBe(false);
    clock = new Date(now.getTime() + 24 * 3600000);
    fetcher.mockRejectedValue(new Error('secret in upstream error'));
    expect((await catalog.detail('movie', 123)).stale).toBe(true);
    expect(fetcher).toHaveBeenCalledTimes(2);
  });
  it('caches lists for 6h and isolates locale namespaces', async () => {
    let clock = now;
    const fetcher = vi
      .fn<typeof fetch>()
      .mockImplementation(async () => new Response(JSON.stringify({ results: [movie] })));
    const db = database();
    const catalog = createTmdbCatalog(db, { token: 'secret', now: () => clock, fetch: fetcher });
    await catalog.home('movie');
    const firstLoadCalls = fetcher.mock.calls.length;
    await catalog.home('movie');
    expect(fetcher).toHaveBeenCalledTimes(firstLoadCalls);
    const urls = fetcher.mock.calls.map(([url]) => String(url));
    expect(urls.some((url) => url.includes('with_runtime.lte=99'))).toBe(true);
    expect(urls.some((url) => url.includes('vote_count.lte=1500'))).toBe(true);
    clock = new Date(now.getTime() + 6 * 3600000);
    await catalog.home('movie');
    expect(fetcher).toHaveBeenCalledTimes(firstLoadCalls * 2);
    await createTmdbCatalog(db, { token: 'secret', language: 'fr-FR', fetch: fetcher }).home(
      'movie',
    );
    expect(fetcher).toHaveBeenCalledTimes(firstLoadCalls * 3);
  });
  it('never fetches synthetic IDs or substitutes seed data for credentials', async () => {
    const fetcher = vi.fn<typeof fetch>();
    const catalog = createTmdbCatalog(database(), { token: '', fetch: fetcher });
    await expect(catalog.detail('movie', 9900001)).rejects.toMatchObject({ status: 404 });
    await expect(catalog.home()).rejects.toMatchObject({ code: 'TMDB_CONFIGURATION' });
    expect(fetcher).not.toHaveBeenCalled();
  });
  it('redacts upstream errors and refuses authentication errors even with cached data', async () => {
    let clock = now;
    const fetcher = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(new Response(JSON.stringify(movie)))
      .mockResolvedValueOnce(new Response('secret', { status: 401 }));
    const catalog = createTmdbCatalog(database(), {
      token: 'secret',
      now: () => clock,
      fetch: fetcher,
    });
    await catalog.detail('movie', 123);
    clock = new Date(now.getTime() + 86400000);
    await expect(catalog.detail('movie', 123)).rejects.toMatchObject({
      code: 'TMDB_CONFIGURATION',
      message: 'TMDB is not configured with a valid read access token.',
    });
    const failed = createTmdbCatalog(database(), {
      token: 'secret',
      fetch: vi.fn<typeof fetch>().mockRejectedValue(new Error('secret')),
    });
    await expect(failed.detail('movie', 123)).rejects.toMatchObject({
      message: 'Movie information is temporarily unavailable.',
    });
  });
  it('uses only fixed origins and never sends metadata credentials to posters', async () => {
    const fetcher = vi
      .fn<typeof fetch>()
      .mockImplementation(async (url) =>
        String(url).startsWith('https://image.')
          ? new Response('', { status: 404 })
          : new Response(JSON.stringify({ ...movie, poster_path: '/poster.jpg' })),
      );
    const catalog = createTmdbCatalog(database(), { token: 'secret', fetch: fetcher });
    await catalog.detail('movie', 123);
    await catalog.detail('movie', 123);
    expect(fetcher).toHaveBeenCalledTimes(2);
    expect(String(fetcher.mock.calls[0]?.[0])).toContain('https://api.themoviedb.org/3/movie/123?');
    expect(fetcher.mock.calls[1]?.[0]).toBe('https://image.tmdb.org/t/p/w92/poster.jpg');
    expect(fetcher.mock.calls[1]?.[1]?.headers).toBeUndefined();
  });
  it('preserves existing Plex matches when refreshing metadata', async () => {
    const db = database();
    const fetcher = vi
      .fn<typeof fetch>()
      .mockImplementation(async () => new Response(JSON.stringify(movie)));
    const catalog = createTmdbCatalog(db, { token: 'secret', fetch: fetcher });
    await catalog.detail('movie', 123);
    db.sqlite.prepare("UPDATE titles SET plex_match = 'manual' WHERE tmdb_id = 123").run();
    await catalog.detail('movie', 123);
    expect(db.sqlite.prepare('SELECT plex_match FROM titles WHERE tmdb_id = 123').get()).toEqual({
      plex_match: 'manual',
    });
  });
});
