import {
  titleCardSchema,
  titleDetailSchema,
  type MediaType,
  type ReleaseState,
  type TitleCard,
  type TitleDetail,
} from '@reelrequest/shared';

export type JsonObject = Record<string, unknown>;
export function object(value: unknown): JsonObject {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? (value as JsonObject)
    : {};
}
export function list(value: unknown): JsonObject[] {
  return Array.isArray(value) ? value.map(object) : [];
}
function str(value: unknown): string {
  return typeof value === 'string' ? value : '';
}
function num(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}
function path(value: unknown): string | null {
  return typeof value === 'string' && /^\/[a-zA-Z0-9_.-]+$/.test(value) ? value : null;
}
function date(value: unknown): string | null {
  const result = str(value).slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(result)) return null;
  const parsed = new Date(`${result}T00:00:00Z`);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === result
    ? result
    : null;
}
export function movieDates(data: JsonObject) {
  const us = list(object(data.release_dates).results).find((entry) => entry.iso_3166_1 === 'US');
  const releases = list(us?.release_dates);
  const earliest = (type: number) =>
    releases
      .filter((entry) => entry.type === type)
      .map((entry) => date(entry.release_date))
      .filter((entry): entry is string => entry !== null)
      .sort()[0] ?? null;
  return {
    releaseTheatrical: earliest(3),
    releaseDigital: earliest(4),
    releasePhysical: earliest(5),
  };
}
export function releaseFor(data: JsonObject, type: MediaType, now: Date): ReleaseState {
  const today = now.toISOString().slice(0, 10);
  if (type === 'tv') {
    const firstSeason = list(data.seasons).find((season) => season.season_number === 1);
    const first = date(firstSeason?.air_date) ?? date(data.first_air_date);
    return first ? (first <= today ? 'released' : 'coming_soon') : 'unknown';
  }
  const dates = movieDates(data);
  const home = [dates.releaseDigital, dates.releasePhysical].filter(
    (value): value is string => value !== null,
  );
  if (home.some((value) => value <= today)) return 'released';
  if (
    dates.releaseTheatrical &&
    now.getTime() - Date.parse(`${dates.releaseTheatrical}T00:00:00Z`) > 120 * 86400000
  )
    return 'released';
  if (home.length || dates.releaseTheatrical) return 'coming_soon';
  return data.status === 'Released' ? 'released' : 'unknown';
}
export function trailerFor(data: JsonObject): string | null {
  return (
    (list(object(data.videos).results)
      .filter(
        (video) =>
          video.site === 'YouTube' &&
          (video.type === 'Trailer' || video.type === 'Teaser') &&
          /^[a-zA-Z0-9_-]{11}$/.test(str(video.key)),
      )
      .sort(
        (a, b) =>
          Number(b.type === 'Trailer') - Number(a.type === 'Trailer') ||
          Number(b.official === true) - Number(a.official === true) ||
          str(b.published_at).localeCompare(str(a.published_at)),
      )[0]?.key as string | undefined) ?? null
  );
}
function certification(data: JsonObject, type: MediaType): string | null {
  if (type === 'tv')
    return (
      str(
        list(object(data.content_ratings).results).find((entry) => entry.iso_3166_1 === 'US')
          ?.rating,
      ) || null
    );
  const us = list(object(data.release_dates).results).find((entry) => entry.iso_3166_1 === 'US');
  return (
    list(us?.release_dates)
      .filter((entry) => [3, 4, 5].includes(num(entry.type) ?? -1))
      .sort((a, b) => (num(a.type) ?? 0) - (num(b.type) ?? 0))
      .map((entry) => str(entry.certification))
      .find(Boolean) ?? null
  );
}
export function normalizeCard(data: JsonObject, type: MediaType, now: Date): TitleCard {
  const first = date(type === 'movie' ? data.release_date : data.first_air_date);
  return titleCardSchema.parse({
    tmdbId: num(data.id),
    mediaType: type,
    title: str(type === 'movie' ? data.title : data.name),
    year: first ? Number(first.slice(0, 4)) : null,
    releaseDate: first,
    posterPath: path(data.poster_path),
    backdropPath: path(data.backdrop_path),
    tmdbScore:
      num(data.vote_average) === null ? null : Math.round(Number(data.vote_average) * 10) / 10,
    certification: certification(data, type),
    runtimeMin:
      type === 'movie'
        ? num(data.runtime)
        : num(Array.isArray(data.episode_run_time) ? data.episode_run_time[0] : null),
    seasonCount: type === 'tv' ? num(data.number_of_seasons) : null,
    colorHex: /^#[0-9a-fA-F]{6}$/.test(str(data.reelrequest_color))
      ? data.reelrequest_color
      : '#263449',
    plexState: 'unknown',
    releaseState:
      first && !data.release_dates && !data.seasons
        ? first > now.toISOString().slice(0, 10)
          ? 'coming_soon'
          : 'released'
        : releaseFor(data, type, now),
  });
}
export function normalizeDetail(data: JsonObject, type: MediaType, now: Date): TitleDetail {
  const logo = list(object(data.images).logos)
    .filter(
      (entry) => (entry.iso_639_1 === 'en' || entry.iso_639_1 === null) && path(entry.file_path),
    )
    .sort(
      (a, b) =>
        (num(b.vote_average) ?? 0) - (num(a.vote_average) ?? 0) ||
        (num(b.vote_count) ?? 0) - (num(a.vote_count) ?? 0),
    )[0];
  const credits = object(data.credits);
  const crew = list(credits.crew)
    .filter((entry) => entry.job === 'Director')
    .map((entry) => ({ id: num(entry.id), name: str(entry.name), job: 'Director' }));
  if (type === 'tv')
    crew.push(
      ...list(data.created_by).map((entry) => ({
        id: num(entry.id),
        name: str(entry.name),
        job: 'Creator',
      })),
    );
  return titleDetailSchema.parse({
    ...normalizeCard(data, type, now),
    overview: str(data.overview),
    logoPath: path(logo?.file_path),
    genres: list(data.genres).map((entry) => ({ id: num(entry.id), name: str(entry.name) })),
    cast: list(credits.cast)
      .slice(0, 15)
      .map((entry) => ({
        id: num(entry.id),
        name: str(entry.name),
        character: str(entry.character),
        profilePath: path(entry.profile_path),
      })),
    crew,
    trailerKey: trailerFor(data),
    ...movieDates(data),
    nextAirDate: date(object(data.next_episode_to_air).air_date),
    seasons: list(data.seasons).map((entry) => ({
      number: num(entry.season_number),
      name: str(entry.name),
      episodeCount: num(entry.episode_count) ?? 0,
      airDate: date(entry.air_date),
      inPlex: null,
    })),
    recommendations: list(object(data.recommendations).results)
      .slice(0, 20)
      .filter((entry) => !isSyntheticId(num(entry.id) ?? 0))
      .map((entry) => normalizeCard(entry, type, now)),
    resolution: null,
    watchUrl: null,
  });
}
export function isSyntheticId(id: number): boolean {
  return id >= 9900001 && id <= 9900008;
}
