import { and, eq, inArray, isNull } from 'drizzle-orm';
import { plexState, type MediaType, type PlexState } from '@reelrequest/shared';
import type { AppDatabase } from '../../db/client.js';
import {
  listItems,
  notifications,
  plexItems,
  requestSupporters,
  requests,
  settings,
  titles,
} from '../../db/schema.js';

export interface PlexMatch {
  ratingKey: string;
  source: 'tmdb' | 'imdb' | 'tvdb' | 'fuzzy' | 'manual';
  confirmed?: boolean;
  inMirror: boolean;
}
export interface PlexAvailabilitySnapshot {
  match: PlexMatch | null;
  lastSuccessfulSyncAt: Date | string | null;
  now?: Date;
}
export const PLEX_SYNC_FRESHNESS_MS = 3 * 60 * 60 * 1_000;
export function computePlexState(snapshot: PlexAvailabilitySnapshot): PlexState {
  const { match, lastSuccessfulSyncAt } = snapshot;
  if (match?.inMirror && match.ratingKey.trim()) {
    if (match.source === 'fuzzy' && match.confirmed !== true) return plexState.enum.unknown;
    return plexState.enum.available;
  }
  if (lastSuccessfulSyncAt === null) return plexState.enum.unknown;
  const syncedAt =
    lastSuccessfulSyncAt instanceof Date
      ? lastSuccessfulSyncAt.getTime()
      : Date.parse(lastSuccessfulSyncAt);
  const age = (snapshot.now ?? new Date()).getTime() - syncedAt;
  return !Number.isFinite(age) || age < 0 || age > PLEX_SYNC_FRESHNESS_MS
    ? plexState.enum.unknown
    : plexState.enum.unavailable;
}

export interface PlexSection {
  key: string;
  title: string;
  type: 'movie' | 'show';
}
export interface PlexAdapterDescription {
  mode: 'mock' | 'configured';
  ready: boolean;
  message: string;
}
export interface PlexSyncResult {
  sections: number;
  items: number;
  matched: number;
  requestsAvailable: number;
  completedAt: string;
}
export interface PlexAdapter {
  readonly mode: PlexAdapterDescription['mode'];
  describe(): PlexAdapterDescription;
  getAvailability(snapshot: PlexAvailabilitySnapshot): PlexState;
  lastSuccessfulSyncAt(): string | null;
  sections(): Promise<PlexSection[]>;
  includedSections(): string[];
  setIncludedSections(sectionIds: string[]): Promise<void>;
  test(): Promise<{ serverName: string; machineIdentifier: string; version: string | null }>;
  sync(sectionIds?: string[]): Promise<PlexSyncResult>;
  decideFuzzy(titleId: number, accept: boolean): boolean;
  setChangeListener(listener: () => void): void;
  watchUrl(ratingKey: string): string | null;
}

type JsonRecord = Record<string, unknown>;
type Fetch = typeof fetch;
function list(value: unknown): JsonRecord[] {
  return Array.isArray(value)
    ? value.filter((entry): entry is JsonRecord => Boolean(entry && typeof entry === 'object'))
    : [];
}
function text(value: unknown): string | null {
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}
function integer(value: unknown): number | null {
  const result = typeof value === 'number' ? value : Number(value);
  return Number.isSafeInteger(result) ? result : null;
}
function normalized(value: string): string {
  return value
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}
function setting(database: AppDatabase, key: string): string | null {
  return database.db.select().from(settings).where(eq(settings.key, key)).get()?.value ?? null;
}
function setSetting(database: AppDatabase, key: string, value: string) {
  database.db
    .insert(settings)
    .values({ key, value })
    .onConflictDoUpdate({ target: settings.key, set: { value } })
    .run();
}

export function createPlexAdapter(
  config: {
    plexUrl?: string | undefined;
    plexToken?: string | undefined;
    database?: AppDatabase;
    fetchImpl?: Fetch;
    now?: () => Date;
    onChange?: () => void;
  } = {},
): PlexAdapter {
  const url = config.plexUrl?.trim().replace(/\/+$/, '') ?? '';
  const token = config.plexToken?.trim() ?? '';
  const database = config.database;
  const fetchImpl = config.fetchImpl ?? fetch;
  const now = config.now ?? (() => new Date());
  let onChange = config.onChange;
  if (!url)
    return {
      mode: 'mock',
      describe: () => ({
        mode: 'mock',
        ready: true,
        message: 'Mock Plex mode: seeded library data; no live Plex connection.',
      }),
      getAvailability: computePlexState,
      lastSuccessfulSyncAt: () => null,
      sections: async () => [],
      includedSections: () => [],
      setIncludedSections: async () => {},
      test: async () => ({ serverName: 'Demo', machineIdentifier: '', version: null }),
      sync: async () => ({
        sections: 0,
        items: 0,
        matched: 0,
        requestsAvailable: 0,
        completedAt: now().toISOString(),
      }),
      decideFuzzy: () => false,
      setChangeListener: (listener) => {
        onChange = listener;
      },
      watchUrl: () => null,
    };

  const ready = Boolean(token && database);
  async function load(path: string, timeoutMs = 8000): Promise<JsonRecord> {
    if (!token) throw new Error('Plex token is not configured.');
    const response = await fetchImpl(`${url}${path}`, {
      headers: { Accept: 'application/json', 'X-Plex-Token': token },
      signal: AbortSignal.timeout(timeoutMs),
    });
    if (!response.ok) throw new Error(`Plex returned HTTP ${response.status}.`);
    const data: unknown = await response.json();
    if (!data || typeof data !== 'object') throw new Error('Plex returned an invalid response.');
    return data as JsonRecord;
  }
  async function identity() {
    const root = await load('/');
    const container = (root.MediaContainer ?? {}) as JsonRecord;
    const machineIdentifier = text(container.machineIdentifier);
    if (!machineIdentifier) throw new Error('Plex did not return a machine identifier.');
    if (database) setSetting(database, 'plex_machine_id', machineIdentifier);
    return {
      serverName: text(container.friendlyName) ?? 'Plex',
      machineIdentifier,
      version: text(container.version),
    };
  }
  async function sections(): Promise<PlexSection[]> {
    const payload = await load('/library/sections');
    const container = (payload.MediaContainer ?? {}) as JsonRecord;
    return list(container.Directory).flatMap((entry) => {
      const key = text(entry.key),
        title = text(entry.title),
        type = text(entry.type);
      return key && title && (type === 'movie' || type === 'show') ? [{ key, title, type }] : [];
    });
  }
  function includedSections() {
    if (!database) return [];
    try {
      const value: unknown = JSON.parse(setting(database, 'plex_included_sections') ?? '[]');
      return Array.isArray(value)
        ? value.filter((entry): entry is string => typeof entry === 'string')
        : [];
    } catch {
      return [];
    }
  }
  async function setIncludedSections(sectionIds: string[]) {
    if (!database) throw new Error('Plex storage is unavailable.');
    const allowed = new Set((await sections()).map((entry) => entry.key));
    if (!sectionIds.length || sectionIds.some((entry) => !allowed.has(entry)))
      throw new Error('Choose at least one available movie or TV library.');
    setSetting(database, 'plex_included_sections', JSON.stringify([...new Set(sectionIds)]));
  }
  function guidIds(entry: JsonRecord) {
    const ids: { tmdbId: number | null; imdbId: string | null; tvdbId: number | null } = {
      tmdbId: null,
      imdbId: null,
      tvdbId: null,
    };
    for (const guid of list(entry.Guid)) {
      const id = text(guid.id) ?? '';
      if (/^tmdb:\/\/\d+$/.test(id)) ids.tmdbId = Number(id.slice(7));
      if (/^imdb:\/\/tt\d+$/.test(id)) ids.imdbId = id.slice(7);
      if (/^tvdb:\/\/\d+$/.test(id)) ids.tvdbId = Number(id.slice(7));
    }
    return ids;
  }
  function resolution(entry: JsonRecord): string | null {
    return (
      list(entry.Media)
        .flatMap((media) => (text(media.videoResolution) ? [text(media.videoResolution)!] : []))
        .sort((a, b) => (Number.parseInt(b) || 0) - (Number.parseInt(a) || 0))[0] ?? null
    );
  }
  async function seasonsFor(ratingKey: string): Promise<number[]> {
    const payload = await load(`/library/metadata/${encodeURIComponent(ratingKey)}/children`);
    const container = (payload.MediaContainer ?? {}) as JsonRecord;
    return list(container.Metadata)
      .filter((entry) => text(entry.type) === 'season')
      .flatMap((entry) => {
        const number = integer(entry.index);
        return number !== null && number > 0 ? [number] : [];
      })
      .sort((a, b) => a - b);
  }
  async function sectionItems(section: PlexSection): Promise<JsonRecord[]> {
    const output: JsonRecord[] = [],
      size = 1000;
    for (let start = 0; ; start += size) {
      const payload = await load(
        `/library/sections/${encodeURIComponent(section.key)}/all?includeGuids=1&X-Plex-Container-Start=${start}&X-Plex-Container-Size=${size}`,
        30000,
      );
      const container = (payload.MediaContainer ?? {}) as JsonRecord;
      const page = list(container.Metadata);
      output.push(...page);
      const total = integer(container.totalSize) ?? integer(container.size) ?? output.length;
      if (!page.length || output.length >= total || page.length < size) break;
    }
    return output;
  }
  function matchTitles(): number {
    if (!database) return 0;
    const db = database.db,
      items = db.select().from(plexItems).all();
    let matched = 0;
    let rejected: string[] = [];
    try {
      const value: unknown = JSON.parse(setting(database, 'plex_rejected_fuzzy') ?? '[]');
      if (Array.isArray(value))
        rejected = value.filter((entry): entry is string => typeof entry === 'string');
    } catch {
      /* Ignore a malformed optional preference. */
    }
    const rejectedPairs = new Set(rejected);
    for (const title of db.select().from(titles).all()) {
      if (title.plexMatch === 'manual') continue;
      const tmdb = items.find(
        (item) => item.mediaType === title.mediaType && item.tmdbId === title.tmdbId,
      );
      const imdb =
        tmdb || !title.imdbId
          ? null
          : items.find(
              (item) => item.mediaType === title.mediaType && item.imdbId === title.imdbId,
            );
      const tvdb =
        tmdb || imdb || !title.tvdbId
          ? null
          : items.find(
              (item) => item.mediaType === title.mediaType && item.tvdbId === title.tvdbId,
            );
      const exact = tmdb ?? imdb ?? tvdb;
      const fuzzy = exact
        ? null
        : items.find(
            (item) =>
              item.mediaType === title.mediaType &&
              normalized(item.title) === normalized(title.title) &&
              (item.year === null ||
                title.year === null ||
                Math.abs(item.year - title.year) <= 1) &&
              !rejectedPairs.has(`${title.id}:${item.ratingKey}`),
          );
      const item = exact ?? fuzzy;
      if (!item) {
        if (title.plexMatch !== 'fuzzy')
          db.update(titles)
            .set({ plexRatingKey: null, plexMatch: null })
            .where(eq(titles.id, title.id))
            .run();
        continue;
      }
      db.update(titles)
        .set({
          plexRatingKey: item.ratingKey,
          plexMatch: tmdb ? 'tmdb' : imdb ? 'imdb' : tvdb ? 'tvdb' : 'fuzzy',
        })
        .where(eq(titles.id, title.id))
        .run();
      if (exact) matched++;
    }
    return matched;
  }
  function makeRequestsAvailable(): number {
    if (!database) return 0;
    const db = database.db;
    const open = db
      .select({ request: requests, title: titles })
      .from(requests)
      .innerJoin(titles, eq(titles.id, requests.titleId))
      .where(inArray(requests.status, ['requested', 'looking']))
      .all();
    let changed = 0;
    for (const { request, title } of open) {
      if (
        !title.plexRatingKey ||
        title.plexMatch === 'fuzzy' ||
        !db.select().from(plexItems).where(eq(plexItems.ratingKey, title.plexRatingKey)).get()
      )
        continue;
      const timestamp = now().toISOString();
      database.sqlite.transaction(() => {
        db.update(requests)
          .set({ status: 'available', availableAt: timestamp, updatedAt: timestamp })
          .where(eq(requests.id, request.id))
          .run();
        for (const supporter of db
          .select()
          .from(requestSupporters)
          .where(
            and(eq(requestSupporters.requestId, request.id), isNull(requestSupporters.withdrawnAt)),
          )
          .all())
          db.insert(notifications)
            .values({
              profileId: supporter.profileId,
              kind: 'plex_available',
              requestId: request.id,
              titleId: title.id,
              body: `${title.title} is now available in Plex.`,
            })
            .run();
      })();
      changed++;
    }
    return changed;
  }
  function notifyListArrivals() {
    if (!database) return;
    const db = database.db;
    const saved = db
      .select({ item: listItems, title: titles })
      .from(listItems)
      .innerJoin(titles, eq(titles.id, listItems.titleId))
      .all();
    for (const { item, title } of saved) {
      if (
        !title.plexRatingKey ||
        title.plexMatch === 'fuzzy' ||
        !db.select().from(plexItems).where(eq(plexItems.ratingKey, title.plexRatingKey)).get()
      )
        continue;
      const prior = database.sqlite
        .prepare(
          "SELECT 1 FROM notifications WHERE profile_id=? AND title_id=? AND kind='list_available' LIMIT 1",
        )
        .get(item.profileId, title.id);
      if (!prior)
        db.insert(notifications)
          .values({
            profileId: item.profileId,
            kind: 'list_available',
            titleId: title.id,
            body: `${title.title} from your list is now available in Plex.`,
          })
          .run();
    }
  }
  async function sync(requestedSections?: string[]): Promise<PlexSyncResult> {
    if (!database) throw new Error('Plex storage is unavailable.');
    setSetting(database, 'plex_last_attempt_at', now().toISOString());
    const available = await sections();
    let selected = requestedSections?.length ? requestedSections : includedSections();
    if (!selected.length) {
      selected = available.map((entry) => entry.key);
      setSetting(database, 'plex_included_sections', JSON.stringify(selected));
    }
    const chosen = available.filter((entry) => selected.includes(entry.key));
    if (!chosen.length) throw new Error('No included Plex libraries are available.');
    const seenAt = now().toISOString();
    let itemCount = 0;
    for (const section of chosen) {
      const queue = await sectionItems(section);
      await Promise.all(
        Array.from({ length: Math.min(6, queue.length || 1) }, async () => {
          while (queue.length) {
            const entry = queue.shift()!,
              ratingKey = text(entry.ratingKey),
              title = text(entry.title);
            if (!ratingKey || !title) continue;
            const mediaType: MediaType = section.type === 'show' ? 'tv' : 'movie';
            const epoch = integer(entry.addedAt);
            const values = {
              ratingKey,
              sectionId: section.key,
              mediaType,
              title,
              year: integer(entry.year),
              ...guidIds(entry),
              addedAt: epoch ? new Date(epoch * 1000).toISOString() : null,
              resolution: resolution(entry),
              seasons: mediaType === 'tv' ? await seasonsFor(ratingKey).catch(() => []) : [],
              lastSeenAt: seenAt,
              missCount: 0,
            };
            database.db
              .insert(plexItems)
              .values(values)
              .onConflictDoUpdate({ target: plexItems.ratingKey, set: values })
              .run();
            itemCount++;
          }
        }),
      );
    }
    for (const item of database.db
      .select()
      .from(plexItems)
      .all()
      .filter((entry) => entry.lastSeenAt !== seenAt)) {
      const misses = Math.min(3, (item.missCount ?? 0) + 1);
      if (misses >= 3) database.db.delete(plexItems).where(eq(plexItems.id, item.id)).run();
      else
        database.db
          .update(plexItems)
          .set({ missCount: misses })
          .where(eq(plexItems.id, item.id))
          .run();
    }
    const server = await identity();
    setSetting(database, 'plex_machine_id', server.machineIdentifier);
    setSetting(database, 'plex_last_success_at', seenAt);
    const matched = matchTitles(),
      requestsAvailable = makeRequestsAvailable();
    notifyListArrivals();
    onChange?.();
    return {
      sections: chosen.length,
      items: itemCount,
      matched,
      requestsAvailable,
      completedAt: seenAt,
    };
  }
  function decideFuzzy(titleId: number, accept: boolean): boolean {
    if (!database) return false;
    const db = database.db;
    const title = db
      .select()
      .from(titles)
      .where(and(eq(titles.id, titleId), eq(titles.plexMatch, 'fuzzy')))
      .get();
    if (!title?.plexRatingKey) return false;
    if (accept) {
      db.update(titles).set({ plexMatch: 'manual' }).where(eq(titles.id, titleId)).run();
      makeRequestsAvailable();
      notifyListArrivals();
    } else {
      let rejected: string[] = [];
      try {
        const value: unknown = JSON.parse(setting(database, 'plex_rejected_fuzzy') ?? '[]');
        if (Array.isArray(value))
          rejected = value.filter((entry): entry is string => typeof entry === 'string');
      } catch {
        /* Replace a malformed optional preference. */
      }
      setSetting(
        database,
        'plex_rejected_fuzzy',
        JSON.stringify([...new Set([...rejected, `${title.id}:${title.plexRatingKey}`])]),
      );
      db.update(titles)
        .set({ plexRatingKey: null, plexMatch: null })
        .where(eq(titles.id, titleId))
        .run();
    }
    onChange?.();
    return true;
  }
  function watchUrl(ratingKey: string) {
    if (!database) return null;
    const machine = setting(database, 'plex_machine_id');
    return machine
      ? `https://app.plex.tv/desktop/#!/server/${encodeURIComponent(machine)}/details?key=${encodeURIComponent(`/library/metadata/${ratingKey}`)}`
      : null;
  }
  return {
    mode: 'configured',
    describe: () => ({
      mode: 'configured',
      ready,
      message: ready
        ? 'Live Plex connection configured.'
        : 'Plex URL is configured but its token or storage is missing.',
    }),
    getAvailability: ready ? computePlexState : () => plexState.enum.unknown,
    lastSuccessfulSyncAt: () => (database ? setting(database, 'plex_last_success_at') : null),
    sections,
    includedSections,
    setIncludedSections,
    test: identity,
    sync,
    decideFuzzy,
    setChangeListener: (listener) => {
      onChange = listener;
    },
    watchUrl,
  };
}
