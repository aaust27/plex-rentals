import { describe, expect, it } from 'vitest';
import { eq } from 'drizzle-orm';
import { migrateDatabase, openDatabase } from '../../db/client.js';
import { notifications, plexItems, profiles, requests, titles } from '../../db/schema.js';
import {
  computePlexState,
  createPlexAdapter,
  PLEX_SYNC_FRESHNESS_MS,
  type PlexMatch,
} from './index.js';

const now = new Date('2026-09-23T18:00:00.000Z');
const match: PlexMatch = { ratingKey: 'demo-3', source: 'tmdb', inMirror: true };
const recentSync = new Date(now.getTime() - 60_000);

describe('Plex read-time availability', () => {
  it.each(['tmdb', 'imdb', 'tvdb', 'manual'] as const)(
    'preserves a verified %s match during an outage',
    (source) => {
      expect(
        computePlexState({
          match: { ...match, source },
          lastSuccessfulSyncAt: new Date(now.getTime() - 24 * 60 * 60 * 1_000),
          now,
        }),
      ).toBe('available');
    },
  );

  it('preserves a confirmed fuzzy match but hides an unconfirmed match', () => {
    for (const confirmed of [undefined, false, true]) {
      expect(
        computePlexState({
          match: { ...match, source: 'fuzzy', ...(confirmed === undefined ? {} : { confirmed }) },
          lastSuccessfulSyncAt: recentSync,
          now,
        }),
      ).toBe(confirmed ? 'available' : 'unknown');
    }
  });

  it('calls an unmatched title unavailable only while the mirror is fresh', () => {
    expect(computePlexState({ match: null, lastSuccessfulSyncAt: recentSync, now })).toBe(
      'unavailable',
    );
    expect(
      computePlexState({
        match: null,
        lastSuccessfulSyncAt: new Date(now.getTime() - PLEX_SYNC_FRESHNESS_MS),
        now,
      }),
    ).toBe('unavailable');
    expect(
      computePlexState({
        match: null,
        lastSuccessfulSyncAt: new Date(now.getTime() - PLEX_SYNC_FRESHNESS_MS - 1),
        now,
      }),
    ).toBe('unknown');
  });

  it.each([null, 'not-a-timestamp', '2026-09-24T18:00:00.000Z'])(
    'does not infer absence from unusable sync timestamp %s',
    (lastSuccessfulSyncAt) => {
      expect(computePlexState({ match: null, lastSuccessfulSyncAt, now })).toBe('unknown');
    },
  );

  it('accepts UTC timestamp strings from SQLite settings', () => {
    expect(
      computePlexState({ match: null, lastSuccessfulSyncAt: recentSync.toISOString(), now }),
    ).toBe('unavailable');
  });

  it('does not treat a removed mirror item as available', () => {
    expect(
      computePlexState({
        match: { ...match, inMirror: false },
        lastSuccessfulSyncAt: recentSync,
        now,
      }),
    ).toBe('unavailable');
  });

  it('does not treat an empty rating key as a verified match', () => {
    expect(
      computePlexState({ match: { ...match, ratingKey: '' }, lastSuccessfulSyncAt: null, now }),
    ).toBe('unknown');
  });
});

describe('Phase 0 Plex adapter', () => {
  it.each([undefined, '', '   '])('enables mock mode for an unset or empty URL (%s)', (plexUrl) => {
    const adapter = createPlexAdapter({ plexUrl });
    expect(adapter.mode).toBe('mock');
    expect(adapter.describe()).toMatchObject({ mode: 'mock', ready: true });
    expect(adapter.getAvailability({ match, lastSuccessfulSyncAt: null, now })).toBe('available');
  });

  it('defaults to mock mode when passed no configuration', () => {
    expect(createPlexAdapter().mode).toBe('mock');
  });

  it.each(['http://plex:32400', 'invalid-but-present-url'])(
    'never falls back to demo data for a configured URL (%s)',
    (plexUrl) => {
      const adapter = createPlexAdapter({ plexUrl });
      expect(adapter.describe()).toMatchObject({ mode: 'configured', ready: false });
      expect(adapter.describe().message).toContain('token or storage');
      expect(adapter.getAvailability({ match, lastSuccessfulSyncAt: recentSync, now })).toBe(
        'unknown',
      );
      expect(adapter.getAvailability({ match: null, lastSuccessfulSyncAt: recentSync, now })).toBe(
        'unknown',
      );
    },
  );

  it('never includes the configured URL in its public description', () => {
    const adapter = createPlexAdapter({ plexUrl: 'http://secret:password@plex:32400' });
    expect(JSON.stringify(adapter.describe())).not.toContain('password');
  });
});

describe('Phase 3 Plex sync', () => {
  it('mirrors selected libraries, matches TMDB ids, and promotes open requests', async () => {
    const database = openDatabase(':memory:');
    migrateDatabase(database);
    const profile = database.db
      .insert(profiles)
      .values({ name: 'Andy', avatar: 'preset:director', color: '#F7A823', isAdmin: true })
      .returning()
      .get()!;
    const title = database.db
      .insert(titles)
      .values({ tmdbId: 603, mediaType: 'movie', title: 'The Matrix', year: 1999 })
      .returning()
      .get()!;
    database.db
      .insert(titles)
      .values({
        tmdbId: 999999,
        imdbId: 'tt0111161',
        mediaType: 'movie',
        title: 'The Shawshank Redemption',
        year: 1994,
      })
      .run();
    database.db
      .insert(requests)
      .values({
        titleId: title.id,
        createdBy: profile.id,
        status: 'requested',
        updatedAt: now.toISOString(),
      })
      .run();
    const seenHeaders: string[] = [];
    const fakeFetch: typeof fetch = async (input, init) => {
      seenHeaders.push(new Headers(init?.headers).get('X-Plex-Token') ?? '');
      const path = new URL(String(input)).pathname;
      const MediaContainer =
        path === '/'
          ? { machineIdentifier: 'machine', friendlyName: 'Home Plex', version: '1.0' }
          : path === '/library/sections'
            ? { Directory: [{ key: '1', title: 'Movies', type: 'movie' }] }
            : {
                totalSize: 2,
                Metadata: [
                  {
                    ratingKey: '42',
                    title: 'The Matrix',
                    year: 1999,
                    addedAt: 100,
                    Guid: [{ id: 'tmdb://603' }, { id: 'imdb://tt0133093' }],
                    Media: [{ videoResolution: '1080' }],
                  },
                  {
                    ratingKey: '43',
                    title: 'The Shawshank Redemption',
                    year: 1994,
                    addedAt: 101,
                    Guid: [{ id: 'imdb://tt0111161' }],
                    Media: [{ videoResolution: '4k' }],
                  },
                ],
              };
      return new Response(JSON.stringify({ MediaContainer }), { status: 200 });
    };
    try {
      const adapter = createPlexAdapter({
        plexUrl: 'http://plex:32400',
        plexToken: 'private-token',
        database,
        fetchImpl: fakeFetch,
        now: () => now,
      });
      const result = await adapter.sync();
      expect(result).toMatchObject({ sections: 1, items: 2, matched: 2, requestsAvailable: 1 });
      expect(seenHeaders.every((value) => value === 'private-token')).toBe(true);
      expect(
        database.db.select().from(plexItems).where(eq(plexItems.ratingKey, '42')).get(),
      ).toMatchObject({ ratingKey: '42', tmdbId: 603, imdbId: 'tt0133093', resolution: '1080' });
      expect(database.db.select().from(titles).where(eq(titles.tmdbId, 603)).get()).toMatchObject({
        plexRatingKey: '42',
        plexMatch: 'tmdb',
      });
      expect(
        database.db.select().from(titles).where(eq(titles.tmdbId, 999999)).get(),
      ).toMatchObject({ plexRatingKey: '43', plexMatch: 'imdb' });
      expect(database.db.select().from(requests).get()?.status).toBe('available');
      expect(database.db.select().from(notifications).get()?.body).toContain('The Matrix');
      expect(adapter.watchUrl('42')).toContain('/server/machine/details');
    } finally {
      database.close();
    }
  });

  it('keeps a rejected fuzzy pair rejected on later syncs', async () => {
    const database = openDatabase(':memory:');
    migrateDatabase(database);
    const title = database.db
      .insert(titles)
      .values({ tmdbId: 1, mediaType: 'movie', title: 'Close Enough', year: 2024 })
      .returning()
      .get()!;
    const fakeFetch: typeof fetch = async (input) => {
      const path = new URL(String(input)).pathname;
      const MediaContainer =
        path === '/'
          ? { machineIdentifier: 'machine' }
          : path === '/library/sections'
            ? { Directory: [{ key: '1', title: 'Movies', type: 'movie' }] }
            : {
                totalSize: 1,
                Metadata: [{ ratingKey: '99', title: 'Close Enough', year: 2024, Guid: [] }],
              };
      return new Response(JSON.stringify({ MediaContainer }), { status: 200 });
    };
    try {
      const adapter = createPlexAdapter({
        plexUrl: 'http://plex:32400',
        plexToken: 'token',
        database,
        fetchImpl: fakeFetch,
        now: () => now,
      });
      await adapter.sync();
      expect(
        database.db.select().from(titles).where(eq(titles.id, title.id)).get()?.plexMatch,
      ).toBe('fuzzy');
      expect(adapter.decideFuzzy(title.id, false)).toBe(true);
      await adapter.sync();
      expect(database.db.select().from(titles).where(eq(titles.id, title.id)).get()).toMatchObject({
        plexRatingKey: null,
        plexMatch: null,
      });
    } finally {
      database.close();
    }
  });
});
