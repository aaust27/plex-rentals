import type express from 'express';
import { suggestionCreateSchema, suggestionUpdateSchema } from '@reelrequest/shared';
import { ApiError, type createAuth } from './auth.js';
import type { AppDatabase } from './db/client.js';
import type { NotificationService } from './notifications.js';
export function mountSuggestions(
  app: express.Express,
  database: AppDatabase,
  auth: ReturnType<typeof createAuth>,
  notifications: NotificationService,
  emit: () => void,
) {
  const sql = database.sqlite;
  const admins = () =>
    (
      sql.prepare('SELECT id FROM profiles WHERE is_admin=1 AND disabled=0').all() as {
        id: number;
      }[]
    ).map((p) => p.id);
  app.get('/api/suggestions', (req, res) => {
    auth.context(req);
    const cursor = Number(req.query.before ?? Number.MAX_SAFE_INTEGER);
    if (!Number.isSafeInteger(cursor) || cursor < 1)
      throw new ApiError(400, 'INVALID_CURSOR', 'Invalid page.');
    const rows = sql
      .prepare(
        `SELECT s.id,s.profile_id AS profileId,p.name AS author,s.title,s.body,s.status,s.implement_now AS implementNow,s.note,s.created_at AS createdAt,s.updated_at AS updatedAt FROM suggestions s JOIN profiles p ON p.id=s.profile_id WHERE s.id<? ORDER BY s.id DESC LIMIT 51`,
      )
      .all(cursor) as { id: number; implementNow: number }[];
    res.json({
      items: rows.slice(0, 50).map((r) => ({ ...r, implementNow: Boolean(r.implementNow) })),
      nextCursor: rows.length > 50 ? rows[49]!.id : null,
    });
  });
  app.post('/api/suggestions', (req, res) => {
    const { profile } = auth.context(req);
    const parsed = suggestionCreateSchema.safeParse(req.body);
    if (!parsed.success)
      throw new ApiError(
        400,
        'INVALID_INPUT',
        'Enter a title (3–120 characters) and description (5–4000 characters).',
      );
    const input = parsed.data;
    if (input.implementNow) auth.admin(req);
    const recent = sql
      .prepare(
        "SELECT count(*) AS count FROM suggestions WHERE profile_id=? AND created_at>datetime('now','-1 hour')",
      )
      .get(profile.id) as { count: number };
    if (recent.count >= 20)
      throw new ApiError(429, 'SLOW_DOWN', 'Please wait before submitting more suggestions.');
    const status = input.implementNow ? 'approved' : 'pending';
    const id = sql.transaction(() => {
      const id = Number(
        sql
          .prepare(
            'INSERT INTO suggestions(profile_id,title,body,status,implement_now,reviewed_by) VALUES(?,?,?,?,?,?)',
          )
          .run(
            profile.id,
            input.title,
            input.body,
            status,
            Number(input.implementNow),
            input.implementNow ? profile.id : null,
          ).lastInsertRowid,
      );
      sql
        .prepare('INSERT INTO suggestion_events(suggestion_id,actor_id,status) VALUES(?,?,?)')
        .run(id, profile.id, status);
      return id;
    })();
    notifications.notify(admins(), {
      kind: 'suggestion',
      body: `${profile.name} suggested: ${input.title}${input.implementNow ? ' · Approved for implementation' : ' · Needs approval'}`,
    });
    emit();
    res.status(201).json({ id });
  });
  app.patch('/api/suggestions/:id', (req, res) => {
    const { profile } = auth.admin(req);
    const parsed = suggestionUpdateSchema.safeParse(req.body);
    const id = Number(req.params.id);
    if (!parsed.success || !Number.isSafeInteger(id))
      throw new ApiError(400, 'INVALID_INPUT', 'Invalid suggestion update.');
    const input = parsed.data;
    const row = sql
      .prepare('SELECT profile_id,title,status,implement_now FROM suggestions WHERE id=?')
      .get(id) as
      { profile_id: number; title: string; status: string; implement_now: number } | undefined;
    if (!row) throw new ApiError(404, 'NOT_FOUND', 'Suggestion not found.');
    if (row.status === 'implementing' && ['pending', 'approved'].includes(input.status))
      throw new ApiError(409, 'IN_PROGRESS', 'This change is already being implemented.');
    if (input.implementNow && input.status !== 'approved')
      throw new ApiError(400, 'INVALID_INPUT', 'Immediate implementation must be approved.');
    sql.transaction(() => {
      sql
        .prepare(
          'UPDATE suggestions SET status=?,note=?,implement_now=?,reviewed_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',
        )
        .run(input.status, input.note, Number(input.implementNow ?? false), profile.id, id);
      sql
        .prepare(
          'INSERT INTO suggestion_events(suggestion_id,actor_id,status,note) VALUES(?,?,?,?)',
        )
        .run(id, profile.id, input.status, input.note);
    })();
    notifications.notify([...admins(), row.profile_id], {
      kind: 'suggestion',
      body: `${row.title} · ${input.status}${input.note ? `: ${input.note}` : ''}`,
    });
    emit();
    res.json({ ok: true });
  });
}
