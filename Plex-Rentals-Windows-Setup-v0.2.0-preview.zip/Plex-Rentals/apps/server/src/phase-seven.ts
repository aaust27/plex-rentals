import { mkdir, readdir, unlink } from 'node:fs/promises';
import path from 'node:path';
import type { AppDatabase } from './db/client.js';
import { settings } from './db/schema.js';
import { eq } from 'drizzle-orm';

export async function backupDatabase(
  database: AppDatabase,
  now = new Date(),
  databasePath = process.env.DATABASE_PATH ?? './data/reelrequest.db',
) {
  if (databasePath === ':memory:') return null;
  const directory = path.resolve(path.dirname(databasePath), 'backups');
  await mkdir(directory, { recursive: true });
  const stamp = now.toISOString().replace(/[:.]/g, '-');
  const target = path.join(directory, `reelrequest-${stamp}.db`);
  await database.sqlite.backup(target);
  const backups = (await readdir(directory))
    .filter((name) => /^reelrequest-\d{4}-\d{2}-\d{2}T.*\.db$/.test(name))
    .sort()
    .reverse();
  await Promise.all(backups.slice(14).map((name) => unlink(path.join(directory, name))));
  return target;
}

export function startBackupJob(database: AppDatabase, now: () => Date = () => new Date()) {
  const timeZone = process.env.TZ ?? 'America/Chicago';
  let running = false;
  async function tick() {
    if (running) return;
    const current = now();
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      hourCycle: 'h23',
    }).formatToParts(current);
    const value = (type: Intl.DateTimeFormatPartTypes) =>
      parts.find((part) => part.type === type)?.value ?? '';
    const date = `${value('year')}-${value('month')}-${value('day')}`;
    if (Number(value('hour')) < 2) return;
    const completed = database.db
      .select()
      .from(settings)
      .where(eq(settings.key, 'phase7_backup_date'))
      .get()?.value;
    if (completed === date) return;
    running = true;
    try {
      await backupDatabase(database, current);
      database.db
        .insert(settings)
        .values({ key: 'phase7_backup_date', value: date })
        .onConflictDoUpdate({ target: settings.key, set: { value: date } })
        .run();
    } catch {
      console.warn('Nightly database backup failed; the live database was left unchanged.');
    } finally {
      running = false;
    }
  }
  void tick();
  const timer = setInterval(() => void tick(), 60 * 60 * 1000);
  timer.unref();
  return () => clearInterval(timer);
}
