import { and, eq, inArray, or } from 'drizzle-orm';
import type { AppDatabase } from './db/client.js';
import { profiles, requests, settings, titles } from './db/schema.js';
import type { createCatalog } from './catalog.js';
import type { NotificationService } from './notifications.js';

type Catalog = ReturnType<typeof createCatalog>;

function getSetting(database: AppDatabase, key: string) {
  return database.db.select().from(settings).where(eq(settings.key, key)).get()?.value ?? null;
}
function setSetting(database: AppDatabase, key: string, value: string) {
  database.db
    .insert(settings)
    .values({ key, value })
    .onConflictDoUpdate({ target: settings.key, set: { value } })
    .run();
}
function localParts(date: Date, timeZone: string) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    weekday: 'short',
    hour: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date);
  const value = (type: Intl.DateTimeFormatPartTypes) =>
    parts.find((part) => part.type === type)?.value ?? '';
  return {
    date: `${value('year')}-${value('month')}-${value('day')}`,
    weekday: value('weekday'),
    hour: Number(value('hour')),
  };
}

export async function runReleaseWatcher(
  database: AppDatabase,
  catalog: Catalog,
  notificationService: NotificationService,
) {
  const db = database.db;
  const candidates = db
    .select({ title: titles })
    .from(titles)
    .leftJoin(requests, eq(titles.id, requests.titleId))
    .where(
      or(
        eq(titles.releaseState, 'coming_soon'),
        inArray(requests.status, ['requested', 'looking', 'available']),
      ),
    )
    .all();
  const unique = [...new Map(candidates.map(({ title }) => [title.id, title])).values()];
  const released: number[] = [];
  for (const title of unique) {
    try {
      const result = await catalog.refreshDetail(title.mediaType, title.tmdbId);
      if (title.releaseState === 'coming_soon' && result.title.releaseState === 'released')
        released.push(title.id);
    } catch {
      // One unavailable TMDB title must not prevent the remaining release checks.
    }
  }
  if (released.length) {
    let accumulated: number[] = [];
    try {
      const parsed: unknown = JSON.parse(getSetting(database, 'phase4_released_this_week') ?? '[]');
      if (Array.isArray(parsed))
        accumulated = parsed.filter((id): id is number => Number.isSafeInteger(id));
    } catch {
      /* Replace malformed job state. */
    }
    setSetting(
      database,
      'phase4_released_this_week',
      JSON.stringify([...new Set([...accumulated, ...released])]),
    );
  }
  await notificationService.flushPush();
  return released.length;
}

export function startPhaseFourJobs(
  database: AppDatabase,
  catalog: Catalog,
  notificationService: NotificationService,
  emit: () => void,
  now: () => Date = () => new Date(),
) {
  const timeZone = process.env.TZ ?? 'America/Chicago';
  let running = false;
  async function tick() {
    if (running) return;
    running = true;
    try {
      const current = now();
      const local = localParts(current, timeZone);
      if (local.hour >= 6 && getSetting(database, 'phase4_release_date') !== local.date) {
        await runReleaseWatcher(database, catalog, notificationService);
        setSetting(database, 'phase4_release_date', local.date);
        emit();
      }
      const warmedAt = Date.parse(getSetting(database, 'phase4_warmed_at') ?? '');
      if (!Number.isFinite(warmedAt) || current.getTime() - warmedAt >= 6 * 60 * 60 * 1000) {
        await catalog.home().catch(() => undefined);
        setSetting(database, 'phase4_warmed_at', current.toISOString());
      }
      if (
        local.weekday === 'Mon' &&
        local.hour >= 6 &&
        getSetting(database, 'phase4_digest_date') !== local.date
      ) {
        let released: number[] = [];
        try {
          const parsed: unknown = JSON.parse(
            getSetting(database, 'phase4_released_this_week') ?? '[]',
          );
          if (Array.isArray(parsed))
            released = parsed.filter((id): id is number => Number.isSafeInteger(id));
        } catch {
          /* Ignore malformed optional state. */
        }
        if (released.length) {
          const admins = database.db
            .select({ id: profiles.id })
            .from(profiles)
            .where(and(eq(profiles.isAdmin, true), eq(profiles.disabled, false)))
            .all()
            .map((profile) => profile.id);
          notificationService.notify(admins, {
            kind: 'weekly_release_digest',
            body: `${released.length} requested ${released.length === 1 ? 'title is' : 'titles are'} ready to get this week.`,
          });
          setSetting(database, 'phase4_released_this_week', '[]');
        }
        setSetting(database, 'phase4_digest_date', local.date);
        emit();
      }
    } finally {
      running = false;
    }
  }
  void tick();
  const timer = setInterval(() => void tick(), 15 * 60 * 1000);
  timer.unref();
  return () => clearInterval(timer);
}
