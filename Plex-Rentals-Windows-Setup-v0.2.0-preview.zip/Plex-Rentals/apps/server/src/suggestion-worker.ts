/** Local Codex queue adapter. Never executes suggestion text. */
import { openDatabase } from './db/client.js';
import { createNotificationService } from './notifications.js';
const database = openDatabase();
const sql = database.sqlite;
const [action, idText, note = ''] = process.argv.slice(2);
const id = Number(idText);
if (action === 'list') {
  console.log(
    JSON.stringify(
      sql
        .prepare(
          "SELECT id,title,body,note,status FROM suggestions WHERE status IN ('approved','implementing') ORDER BY id",
        )
        .all(),
    ),
  );
} else if (
  Number.isSafeInteger(id) &&
  id > 0 &&
  ['claim', 'completed', 'blocked'].includes(action ?? '')
) {
  const status = action === 'claim' ? 'implementing' : action!;
  const old = action === 'claim' ? 'approved' : 'implementing';
  const result = sql.transaction(() => {
    const row = sql
      .prepare('SELECT title,profile_id FROM suggestions WHERE id=? AND status=?')
      .get(id, old) as { title: string; profile_id: number } | undefined;
    if (!row) return null;
    sql
      .prepare(
        'UPDATE suggestions SET status=?,note=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND status=?',
      )
      .run(status, note.slice(0, 2000), id, old);
    sql
      .prepare('INSERT INTO suggestion_events(suggestion_id,status,note) VALUES(?,?,?)')
      .run(id, status, note.slice(0, 2000));
    return row;
  })();
  if (!result) {
    console.error('Suggestion unavailable or state changed.');
    process.exitCode = 1;
  } else {
    const admins = sql.prepare('SELECT id FROM profiles WHERE is_admin=1 AND disabled=0').all() as {
      id: number;
    }[];
    const notifications = createNotificationService(database);
    notifications.notify([...admins.map((p) => p.id), result.profile_id], {
      kind: 'suggestion',
      body: `${result.title} · ${status}${note ? `: ${note.slice(0, 1000)}` : ''}`,
    });
    console.log(JSON.stringify({ id, status }));
  }
} else {
  console.error(
    'Usage: suggestion-worker.js list | claim ID | completed ID NOTE | blocked ID NOTE',
  );
  process.exitCode = 1;
}
// Push delivery, when enabled, shares this connection until process exit.
