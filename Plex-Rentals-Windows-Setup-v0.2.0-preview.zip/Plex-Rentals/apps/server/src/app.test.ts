import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import request from 'supertest';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { createApp } from './app.js';
import { migrateDatabase, openDatabase, type AppDatabase } from './db/client.js';

let database: AppDatabase;
let directory: string;
beforeEach(() => {
  database = openDatabase(':memory:');
  migrateDatabase(database);
  directory = mkdtempSync(join(tmpdir(), 'reelrequest-web-'));
});
afterEach(() => {
  database.close();
  rmSync(directory, { recursive: true, force: true });
});

describe('Phase 0 Express app', () => {
  it('reports a real migrated database and mock mode without exposing configuration', async () => {
    const response = await request(createApp(database)).get('/api/health');
    expect(response.status).toBe(200);
    expect(response.body).toEqual({
      status: 'ok',
      phase: 8,
      database: 'ready',
      plexMode: 'mock',
      plexReady: true,
      plexLastSyncAt: null,
    });
    expect(response.headers['cache-control']).toBe('no-store');
    expect(response.headers['x-powered-by']).toBeUndefined();
  });
  it('does not claim a configured Plex connection is ready or reveal its URL', async () => {
    const response = await request(
      createApp(database, { plexUrl: 'http://private-plex:32400' }),
    ).get('/api/health');
    expect(response.body).toMatchObject({ plexMode: 'configured', plexReady: false });
    expect(response.text).not.toContain('private-plex');
  });
  it('serves built assets and SPA deep links without turning missing API paths into HTML', async () => {
    writeFileSync(join(directory, 'index.html'), '<!doctype html><title>ReelRequest</title>');
    writeFileSync(join(directory, 'app.js'), 'window.ready=true;');
    const app = createApp(database, { webDirectory: directory });
    expect((await request(app).get('/')).text).toContain('ReelRequest');
    expect((await request(app).get('/future/deep-link').accept('html')).text).toContain(
      'ReelRequest',
    );
    expect((await request(app).get('/app.js')).text).toContain('window.ready');
    const missing = await request(app).get('/api/not-a-route');
    expect(missing.status).toBe(404);
    expect(missing.body).toMatchObject({ error: { code: 'NOT_FOUND' } });
    expect((await request(app).get('/missing.js')).status).toBe(404);
    expect((await request(app).post('/api/not-a-route').send({ tmdbId: 1 })).status).toBe(404);
  });
  it('reports a missing web build clearly', async () => {
    const response = await request(createApp(database, { webDirectory: directory }))
      .get('/')
      .accept('html');
    expect(response.status).toBe(503);
    expect(response.body).toMatchObject({ error: { code: 'WEB_NOT_BUILT' } });
  });
});
