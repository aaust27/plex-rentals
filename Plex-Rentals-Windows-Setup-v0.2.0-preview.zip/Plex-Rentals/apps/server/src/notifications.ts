import { and, eq, inArray, isNull } from 'drizzle-orm';
import webpush from 'web-push';
import type { AppDatabase } from './db/client.js';
import { notifications, pushSubscriptions, titles } from './db/schema.js';

export type NotificationInput = {
  kind: string;
  body: string;
  requestId?: number | null;
  titleId?: number | null;
};

export function createNotificationService(
  database: AppDatabase,
  now: () => Date = () => new Date(),
) {
  const db = database.db;
  const publicKey = process.env.VAPID_PUBLIC_KEY?.trim() ?? '';
  const privateKey = process.env.VAPID_PRIVATE_KEY?.trim() ?? '';
  const subject = process.env.VAPID_SUBJECT?.trim() ?? '';
  const enabled = Boolean(publicKey && privateKey && /^mailto:|^https:/.test(subject));
  if (enabled) webpush.setVapidDetails(subject, publicKey, privateKey);

  async function flushPush() {
    if (!enabled) return;
    const pending = db.select().from(notifications).where(isNull(notifications.pushSentAt)).all();
    for (const notification of pending) {
      const title = notification.titleId
        ? db.select().from(titles).where(eq(titles.id, notification.titleId)).get()
        : null;
      const payload = JSON.stringify({
        title: 'Plex Rentals',
        body: notification.body,
        url: notification.kind === 'suggestion' ? '/settings/suggestions' : title
          ? `/title/${title.mediaType}/${title.tmdbId}`
          : notification.requestId
            ? `/requests`
            : '/notifications',
      });
      const subscriptions = db
        .select()
        .from(pushSubscriptions)
        .where(eq(pushSubscriptions.profileId, notification.profileId))
        .all();
      await Promise.all(
        subscriptions.map(async (subscription) => {
          try {
            await webpush.sendNotification(
              { endpoint: subscription.endpoint, keys: subscription.keys },
              payload,
              { TTL: 24 * 60 * 60 },
            );
          } catch (error) {
            const status =
              error && typeof error === 'object' && 'statusCode' in error
                ? Number(error.statusCode)
                : 0;
            if (status === 404 || status === 410)
              db.delete(pushSubscriptions).where(eq(pushSubscriptions.id, subscription.id)).run();
          }
        }),
      );
      db.update(notifications)
        .set({ pushSentAt: now().toISOString() })
        .where(eq(notifications.id, notification.id))
        .run();
    }
  }

  function notify(profileIds: number[], input: NotificationInput) {
    for (const profileId of [...new Set(profileIds)])
      db.insert(notifications)
        .values({
          profileId,
          kind: input.kind,
          body: input.body,
          requestId: input.requestId ?? null,
          titleId: input.titleId ?? null,
        })
        .run();
    void flushPush();
  }

  function markRead(profileId: number, ids?: number[]) {
    const timestamp = now().toISOString();
    if (ids?.length)
      db.update(notifications)
        .set({ readAt: timestamp })
        .where(and(eq(notifications.profileId, profileId), inArray(notifications.id, ids)))
        .run();
    else
      db.update(notifications)
        .set({ readAt: timestamp })
        .where(and(eq(notifications.profileId, profileId), isNull(notifications.readAt)))
        .run();
  }

  return { enabled, publicKey: publicKey || null, notify, flushPush, markRead };
}

export type NotificationService = ReturnType<typeof createNotificationService>;
