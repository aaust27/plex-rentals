import request from 'supertest';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { createApp } from './app.js';
import { isPathInsideRoot } from './automation.js';
import { migrateDatabase, openDatabase, type AppDatabase } from './db/client.js';
import { seedDatabase } from './db/fixtures.js';

const auth = {
  householdPasscode: 'rentals-household',
  sessionSecret: 'rentals-session-secret-at-least-thirty-two-characters',
  adminPin: '1234',
  baseUrl: 'http://localhost:8080',
};
let database: AppDatabase;
beforeEach(() => {
  database = openDatabase(':memory:');
  migrateDatabase(database);
  seedDatabase(database);
});
afterEach(() => database.close());

async function member(server: ReturnType<typeof createApp>) {
  const agent = request.agent(server);
  await agent.post('/api/household/join').send({ passcode: auth.householdPasscode }).expect(200);
  await agent.post('/api/session').send({ profileId: 2 }).expect(200);
  return agent;
}

describe('seven-day movie rentals', () => {
  it('accepts only an explicit movie rental and exposes its lifecycle', async () => {
    const server = createApp(database, { auth, plexUrl: '', catalog: { token: '' } });
    database.sqlite.prepare('DELETE FROM requests WHERE id=1').run();
    const agent = await member(server);
    const response = await agent
      .post('/api/requests')
      .send({ mediaType: 'movie', tmdbId: 9_900_001, rent: true })
      .expect(201);
    expect(response.body.request.rental).toMatchObject({ durationDays: 7, expiresAt: null });
    expect(
      database.sqlite
        .prepare('SELECT duration_days FROM request_rentals WHERE request_id=?')
        .pluck()
        .get(response.body.request.id),
    ).toBe(7);
    await agent
      .post('/api/requests')
      .send({ mediaType: 'tv', tmdbId: 9_900_008, rent: true })
      .expect(400);
  });

  it('deletes only a due, identity-matched Radarr file inside the configured root', async () => {
    const calls: { method: string; url: string }[] = [];
    const server = createApp(database, {
      auth,
      plexUrl: '',
      catalog: { token: '' },
      automationFetch: async (input, init) => {
        const url = String(input);
        const method = String(init?.method ?? 'GET');
        calls.push({ method, url });
        if (method === 'DELETE') return new Response(null, { status: 204 });
        return Response.json({ id: 55, tmdbId: 9_900_003, hasFile: true, path: '/media/Movies/Test Movie' });
      },
    });
    await member(server);
    database.sqlite
      .prepare(
        "UPDATE automation_services SET enabled=1,api_key='test',root_folder_path='/media/Movies' WHERE service='radarr'",
      )
      .run();
    database.sqlite
      .prepare(
        "INSERT INTO request_automation(request_id,decision,approved_scope,service,submission_status,external_id,updated_at) VALUES(3,'approved','{}','radarr','sent',55,?)",
      )
      .run(new Date().toISOString());
    database.sqlite
      .prepare(
        "INSERT INTO request_rentals(request_id,duration_days,expires_at,updated_at) VALUES(3,7,'2020-01-01T00:00:00.000Z',?)",
      )
      .run(new Date().toISOString());
    await server.locals.automation.run();
    expect(calls.some((entry) => entry.method === 'DELETE' && entry.url.includes('deleteFiles=true'))).toBe(true);
    expect(database.sqlite.prepare('SELECT deleted_at FROM request_rentals WHERE request_id=3').pluck().get()).toBeTruthy();
    expect(database.sqlite.prepare('SELECT status FROM requests WHERE id=3').pluck().get()).toBe('cancelled');
  });

  it('rejects a root path, a sibling path, and prefix lookalikes', () => {
    expect(isPathInsideRoot('/media/Movies/Title', '/media/Movies')).toBe(true);
    expect(isPathInsideRoot('/media/Movies', '/media/Movies')).toBe(false);
    expect(isPathInsideRoot('/media/Movies2/Title', '/media/Movies')).toBe(false);
    expect(isPathInsideRoot('/media/TV/Title', '/media/Movies')).toBe(false);
  });
});
