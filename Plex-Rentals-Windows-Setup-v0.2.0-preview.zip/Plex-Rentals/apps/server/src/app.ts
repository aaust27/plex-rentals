import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import type { AppDatabase } from './db/client.js';
import { createPlexAdapter } from './integrations/plex/index.js';
import { createCatalog, demoArtwork, type CatalogOptions } from './catalog.js';
import { CatalogError } from './integrations/tmdb/index.js';
import { ApiError, type AuthOptions } from './auth.js';
import { mountFamilyRoutes } from './routes.js';

export function createApp(
  database: AppDatabase,
  options: {
    webDirectory?: string;
    plexUrl?: string;
    plexToken?: string;
    catalog?: CatalogOptions;
    auth?: AuthOptions;
    automationFetch?: typeof fetch;
  } = {},
) {
  const app = express();
  const plexUrl = options.plexUrl ?? options.catalog?.plexUrl ?? process.env.PLEX_URL ?? '';
  const plexToken = options.plexToken ?? process.env.PLEX_TOKEN ?? '';
  const plex = createPlexAdapter({ plexUrl, plexToken, database });
  app.locals.plex = plex;
  const catalog = createCatalog(database, {
    token: process.env.TMDB_READ_TOKEN ?? '',
    region: process.env.TMDB_REGION ?? 'US',
    language: process.env.TMDB_LANGUAGE ?? 'en-US',
    ...options.catalog,
    plexUrl,
  });
  app.locals.catalog = catalog;
  const webDirectory =
    options.webDirectory ?? fileURLToPath(new URL('../../web/dist', import.meta.url));
  app.disable('x-powered-by');
  if (process.env.TRUST_PROXY === '1') app.set('trust proxy', 1);
  // Photo data URLs need space for base64 overhead; other endpoints retain their smaller limit.
  app.use(/^\/api\/admin\/profiles(?:\/\d+)?\/?$/, express.json({ limit: '3mb' }));
  app.use(express.json({ limit: '700kb' }));
  app.use((_request, response, next) => {
    response.setHeader('X-Content-Type-Options', 'nosniff');
    response.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });
  app.get('/api/health', (_request, response) => {
    database.sqlite.prepare('SELECT 1').get();
    const description = plex.describe();
    response.setHeader('Cache-Control', 'no-store');
    response.json({
      status: 'ok',
      phase: 8,
      database: 'ready',
      plexMode: description.mode,
      plexReady: description.ready,
      plexLastSyncAt: plex.lastSuccessfulSyncAt(),
    });
  });
  const familyRoutes = mountFamilyRoutes(
    app,
    database,
    catalog,
    plex,
    options.auth,
    options.automationFetch,
  );
  app.locals.notificationService = familyRoutes.notificationService;
  app.locals.automation = familyRoutes.automation;
  app.locals.emitFamilyChange = familyRoutes.emit;
  app.get('/api/demo-art/:file', (request, response) => {
    const svg = demoArtwork(request.params.file);
    if (!svg) {
      response.status(404).json({ error: { code: 'NOT_FOUND', message: 'Artwork not found.' } });
      return;
    }
    response.setHeader('Cache-Control', 'public, max-age=86400');
    response.setHeader(
      'Content-Security-Policy',
      "default-src 'none'; style-src 'unsafe-inline'; sandbox",
    );
    response.type('image/svg+xml').send(svg);
  });
  app.use('/api', (_request, response) => {
    response.status(404).json({
      error: { code: 'NOT_FOUND', message: 'This API route is not available.' },
    });
  });
  app.use(express.static(webDirectory));
  app.get('/{*path}', (request, response) => {
    if (!request.accepts('html') || /\.[a-z\d]+$/i.test(request.path)) {
      response.status(404).json({ error: { code: 'NOT_FOUND', message: 'File not found.' } });
      return;
    }
    const indexFile = resolve(webDirectory, 'index.html');
    if (!existsSync(indexFile)) {
      response.status(503).json({
        error: {
          code: 'WEB_NOT_BUILT',
          message: 'Build the web app with pnpm build, or use pnpm dev.',
        },
      });
      return;
    }
    response.setHeader('Cache-Control', 'no-cache');
    response.sendFile(indexFile);
  });
  app.use(
    (
      error: unknown,
      _request: express.Request,
      response: express.Response,
      _next: express.NextFunction,
    ) => {
      if (error instanceof CatalogError || error instanceof ApiError) {
        response.status(error.status).json({ error: { code: error.code, message: error.message } });
        return;
      }
      if (
        error instanceof SyntaxError ||
        (typeof error === 'object' &&
          error !== null &&
          'type' in error &&
          error.type === 'entity.too.large')
      ) {
        response.status(400).json({
          error: {
            code: 'INVALID_JSON',
            message: 'Send a valid JSON request within the size limit.',
          },
        });
        return;
      }
      if (error)
        response.status(500).json({
          error: {
            code: 'INTERNAL_ERROR',
            message: 'The server could not complete the request.',
          },
        });
    },
  );
  return app;
}
