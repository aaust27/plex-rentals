import { lstat, readdir, statfs } from 'node:fs/promises';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import type express from 'express';
import { ApiError, type createAuth } from './auth.js';
import type { AppDatabase } from './db/client.js';
import {
  storageSnapshotSchema,
  storageReviewInputSchema,
  type StorageSnapshot,
} from '@reelrequest/shared';
export type StorageRoot = { library: 'Movies' | 'TV'; path: string };
export async function scanStorage(
  roots: StorageRoot[],
  progress: (count: number) => void = () => {},
  deadline = Date.now() + 15 * 60 * 1000,
): Promise<StorageSnapshot> {
  let visited = 0,
    completed = 0;
  const entries: StorageSnapshot['entries'] = [];
  const volumes: StorageSnapshot['volumes'] = [];
  async function measure(path: string): Promise<{ bytes: number; files: number; skipped: number }> {
    if (Date.now() > deadline || ++visited > 250000)
      throw new Error('Inventory limit reached. Try scanning again later.');
    const stat = await lstat(path);
    if (stat.isSymbolicLink()) return { bytes: 0, files: 0, skipped: 1 };
    if (stat.isFile()) return { bytes: stat.size, files: 1, skipped: 0 };
    if (!stat.isDirectory()) return { bytes: 0, files: 0, skipped: 1 };
    const sum = { bytes: 0, files: 0, skipped: 0 };
    for (const name of await readdir(path)) {
      const item = await measure(join(path, name));
      sum.bytes += item.bytes;
      sum.files += item.files;
      sum.skipped += item.skipped;
    }
    return sum;
  }
  for (const root of roots) {
    const info = await lstat(root.path);
    if (!info.isDirectory() || info.isSymbolicLink())
      throw new Error('Library mount is unavailable.');
    const space = await statfs(root.path);
    volumes.push({
      library: root.library,
      totalBytes: space.blocks * space.bsize,
      freeBytes: space.bavail * space.bsize,
    });
    const names = await readdir(root.path);
    let next = 0;
    const workers = await Promise.allSettled(
      Array.from({ length: 4 }, async () => {
        while (next < names.length) {
          const name = names[next++]!;
          const measured = await measure(join(root.path, name));
          entries.push({
            id: createHash('sha256')
              .update(root.library + '\0' + name)
              .digest('hex'),
            library: root.library,
            name,
            ...measured,
          });
          progress(++completed);
        }
      }),
    );
    const failed = workers.find(result => result.status === 'rejected');
    if (failed?.status === 'rejected') throw failed.reason;
  }
  entries.sort((a, b) => b.bytes - a.bytes || a.name.localeCompare(b.name));
  return { generatedAt: new Date().toISOString(), entries, volumes };
}
export function mountStorage(
  app: express.Express,
  database: AppDatabase,
  auth: ReturnType<typeof createAuth>,
  roots: StorageRoot[] = [],
) {
  let scanning = false,
    completed = 0,
    error: string | null = null,
    startedAt: string | null = null;
  const sql = database.sqlite;
  const snapshot = () => {
    const row = sql.prepare("SELECT value FROM settings WHERE key='storage_inventory_v1'").get() as
      { value: string } | undefined;
    if (!row) return null;
    const parsed = storageSnapshotSchema.safeParse(JSON.parse(row.value));
    return parsed.success ? parsed.data : null;
  };
  app.get('/api/admin/storage', (req, res) => {
    auth.admin(req);
    res.json({
      enabled: roots.length > 0,
      scanning,
      completed,
      error,
      startedAt,
      snapshot: snapshot(),
    });
  });
  app.post('/api/admin/storage/scan', (req, res) => {
    auth.admin(req);
    if (!roots.length)
      throw new ApiError(503, 'NOT_CONFIGURED', 'Storage inventory mounts are not configured.');
    if (scanning) {
      res.status(202).json({ ok: true });
      return;
    }
    if (startedAt && Date.now() - Date.parse(startedAt) < 60000)
      throw new ApiError(429, 'SLOW_DOWN', 'Wait a minute before starting another scan.');
    scanning = true;
    completed = 0;
    error = null;
    startedAt = new Date().toISOString();
    void scanStorage(roots, (n) => {
      completed = n;
    })
      .then((value) => {
        sql
          .prepare(
            "INSERT INTO settings(key,value) VALUES('storage_inventory_v1',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
          )
          .run(JSON.stringify(value));
      })
      .catch(() => {
        error =
          'Inventory could not finish. Check the NAS connection and library read permissions; the last successful snapshot is preserved.';
      })
      .finally(() => {
        scanning = false;
      });
    res.status(202).json({ ok: true });
  });
  app.post('/api/admin/storage/review', (req, res) => {
    auth.admin(req);
    const parsed = storageReviewInputSchema.safeParse(req.body);
    if (!parsed.success)
      throw new ApiError(400, 'INVALID_INPUT', 'Select up to 200 inventory entries.');
    const current = snapshot();
    if (!current || current.generatedAt !== parsed.data.generatedAt)
      throw new ApiError(
        409,
        'STALE_INVENTORY',
        'The inventory changed. Refresh and review your selection again.',
      );
    const selected = current.entries.filter((e) => parsed.data.ids.includes(e.id));
    if (selected.length !== new Set(parsed.data.ids).size)
      throw new ApiError(400, 'INVALID_SELECTION', 'An entry is no longer in this inventory.');
    res.json({
      generatedAt: current.generatedAt,
      entries: selected,
      bytes: selected.reduce((n, e) => n + e.bytes, 0),
    });
  });
}

