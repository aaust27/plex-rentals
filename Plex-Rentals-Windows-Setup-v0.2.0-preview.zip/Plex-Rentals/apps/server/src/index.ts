import './config.js';
import { createApp } from './app.js';
import { migrateDatabase, openDatabase } from './db/client.js';
import { startPhaseFourJobs } from './phase-four.js';
import { startBackupJob } from './phase-seven.js';

const database = openDatabase();
migrateDatabase(database);
const port = Number(process.env.PORT ?? 8080);
if (!Number.isInteger(port) || port < 1 || port > 65535)
  throw new Error('PORT must be an integer from 1 to 65535.');
const host = process.env.HOST ?? '127.0.0.1';
const app = createApp(
  database,
  process.env.PLEX_URL === undefined ? {} : { plexUrl: process.env.PLEX_URL },
);
const server = app.listen(port, host, () => {
  console.log(`ReelRequest Phase 8 listening at http://${host}:${port}`);
  if (app.locals.plex.mode === 'configured')
    void app.locals.plex
      .sync()
      .catch(() => console.warn('Initial Plex sync failed; cached matches were preserved.'));
});
const stopPhaseFourJobs = startPhaseFourJobs(
  database,
  app.locals.catalog,
  app.locals.notificationService,
  () => app.locals.emitFamilyChange('notifications'),
);
const stopBackupJob = startBackupJob(database);
const stopAutomationJob = app.locals.automation.start();
const plexTimer = setInterval(
  () => {
    if (app.locals.plex.mode === 'configured')
      void app.locals.plex
        .sync()
        .catch(() => console.warn('Hourly Plex sync failed; cached matches were preserved.'));
  },
  60 * 60 * 1000,
);
plexTimer.unref();
for (const signal of ['SIGINT', 'SIGTERM'] as const) {
  process.on(signal, () =>
    server.close(() => {
      clearInterval(plexTimer);
      stopPhaseFourJobs();
      stopBackupJob();
      stopAutomationJob();
      database.close();
      process.exit(0);
    }),
  );
}
