import request from 'supertest';
import { beforeEach, afterEach, describe, expect, it } from 'vitest';
import { createApp } from './app.js';
import { digitalReleaseHold } from './automation.js';
import { migrateDatabase, openDatabase, type AppDatabase } from './db/client.js';
import { seedDatabase } from './db/fixtures.js';

const auth = {
  householdPasscode: 'phase-eight-household',
  sessionSecret: 'phase-eight-session-secret-at-least-thirty-two-characters',
  adminPin: '1234',
  baseUrl: 'http://localhost:8080',
};
let database: AppDatabase;
beforeEach(() => {
  database = openDatabase(':memory:');
  migrateDatabase(database);
  seedDatabase(database);
});
afterEach(() => database.close());

async function login(server: ReturnType<typeof createApp>, profileId: number, admin = false) {
  const agent = request.agent(server);
  await agent.post('/api/household/join').send({ passcode: auth.householdPasscode }).expect(200);
  await agent
    .post('/api/session')
    .send({ profileId, ...(profileId === 1 ? { pin: '1234' } : {}) })
    .expect(200);
  if (admin) await agent.post('/api/admin/unlock').send({ pin: '1234' }).expect(200);
  return agent;
}
async function waitForStatus(requestId: number, status: string) {
  for (let count = 0; count < 50; count += 1) {
    const value = database.sqlite
      .prepare('SELECT submission_status FROM request_automation WHERE request_id=?')
      .pluck()
      .get(requestId);
    if (value === status) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  const row = database.sqlite
    .prepare('SELECT submission_status,last_error FROM request_automation WHERE request_id=?')
    .get(requestId);
  throw new Error(`Request ${requestId} did not reach ${status}: ${JSON.stringify(row)}`);
}

describe('Phase 8 approvals and automation', () => {
  it('shares suggestions while protecting approval and notifying admins', async () => {
    const server=createApp(database,{auth,plexUrl:'',catalog:{token:''}});
    await request(server).get('/api/suggestions').expect(401);
    const member=await login(server,2);
    await member.post('/api/suggestions').send({title:'Better browsing',body:'Add a useful discovery filter',implementNow:true}).expect(403);
    await member.post('/api/suggestions').set('Origin','https://untrusted.example').send({title:'Not allowed',body:'Cross origin submission'}).expect(403);
    const created=await member.post('/api/suggestions').send({title:'Better browsing',body:'Add a useful discovery filter'}).expect(201);
    const id=created.body.id;
    await member.patch(`/api/suggestions/${id}`).send({status:'approved'}).expect(403);
    const locked=await login(server,1);
    await locked.patch(`/api/suggestions/${id}`).send({status:'approved'}).expect(403);
    const admin=await login(server,1,true);
    expect((await admin.get('/api/suggestions').expect(200)).body.items[0].status).toBe('pending');
    await admin.patch(`/api/suggestions/${id}`).send({status:'approved',note:'Let us build this.'}).expect(200);
    expect((await member.get('/api/suggestions').expect(200)).body.items[0].status).toBe('approved');
    await admin.post('/api/suggestions').send({title:'Fast admin idea',body:'A helpful change for everyone',implementNow:true}).expect(201);
    expect((await member.get('/api/suggestions').expect(200)).body.items[0].implementNow).toBe(true);
    expect(database.sqlite.prepare("SELECT count(*) FROM notifications WHERE kind='suggestion' AND profile_id=1").pluck().get()).toBeGreaterThan(0);
    expect(database.sqlite.prepare('SELECT count(*) FROM suggestion_events WHERE suggestion_id=?').pluck().get(id)).toBe(2);
    await member.post('/api/suggestions').send({title:'x',body:'short'}).expect(400);
    await member.get('/api/suggestions?before=bad').expect(400);
  });
  it('bulk approval requires admin unlock and is idempotent', async () => {
    const server = createApp(database, { auth, plexUrl: '', catalog: { token: '' } });
    await request(server).post('/api/admin/approve-all').send({ids:[7]}).expect(401);
    const member = await login(server, 2);
    await member.get('/api/admin/approval-preview').expect(403);
    const admin = await login(server, 1, true);
    const preview = await admin.get('/api/admin/approval-preview').expect(200);
    const ids = preview.body.requests.map((r: {id:number}) => r.id);
    expect(ids.length).toBeGreaterThan(0);
    await admin.post('/api/admin/approve-all').send({ids:[]}).expect(400);
    const first = await admin.post('/api/admin/approve-all').send({ids}).expect(200);
    expect(first.body.approved).toBe(ids.length);
    const second = await admin.post('/api/admin/approve-all').send({ids}).expect(200);
    expect(second.body.approved).toBe(0);
  });
  it('isolates the stand-up library and never falls back to all libraries', async () => {
    const server = createApp(database, { auth, plexUrl: '', catalog: { token: '' } });
    const member = await login(server, 2);
    server.locals.plex.sections = async () => [
      { key: 'comedy-test', title: 'Stand Up Comedy', type: 'movie' },
    ];
    database.sqlite
      .prepare("UPDATE plex_items SET section_id='comedy-test' WHERE tmdb_id=9900003")
      .run();
    const result = await member.get('/api/library?section=standup').expect(200);
    expect(result.body.items.map((item: { tmdbId: number }) => item.tmdbId)).toEqual([9900003]);
    server.locals.plex.sections = async () => [];
    expect((await member.get('/api/library?section=standup').expect(200)).body.items).toEqual([]);
    await member.get('/api/library?section=bad').expect(400);
  });
  it('holds unknown and stale digital dates and permits only confirmed dates on or before today', () => {
    expect(digitalReleaseHold(null, false, '2026-09-26')).toContain('confirmed');
    expect(digitalReleaseHold(null, false, '2026-09-26', '1998-12-18')).toBeNull();
    expect(digitalReleaseHold(null, false, '2026-09-26', null, '2019-02-12')).toBeNull();
    expect(digitalReleaseHold(null, false, '2026-09-26', '2026-08-01')).toContain('confirmed');
    expect(digitalReleaseHold('2027-01-01', false, '2026-09-26', '1998-12-18')).toContain('2027');
    expect(digitalReleaseHold(null, true, '2026-09-26', '1998-12-18')).toContain('current');
    expect(digitalReleaseHold('2020-01-01', true, '2026-09-26')).toContain('current');
    expect(digitalReleaseHold('2026-09-27', false, '2026-09-26')).toContain('2026-09-27');
    expect(digitalReleaseHold('2026-09-26', false, '2026-09-26')).toBeNull();
    expect(digitalReleaseHold('2020-01-01', false, '2026-09-26')).toBeNull();
  });
  it('requires authentication and validates discovery filters', async () => {
    const server = createApp(database, { auth, plexUrl: '', catalog: { token: '' } });
    await request(server).get('/api/discover').expect(401);
    const member = await login(server, 2);
    await member.get('/api/discover?page=501').expect(400);
    await member.get('/api/discover?genre=invalid').expect(400);
    const result = await member.get('/api/discover').expect(200);
    expect(result.body.items.length).toBeGreaterThan(0);
    expect(result.body.nextPage).toBeNull();
  });
  it('holds future digital releases without contacting Radarr', async () => {
    let calls = 0;
    const server = createApp(database, {
      auth,
      plexUrl: '',
      catalog: { token: '' },
      automationFetch: async () => {
        calls++;
        return Response.json([]);
      },
    });
    database.sqlite
      .prepare(
        "UPDATE automation_services SET enabled=1,api_key='test',quality_profile_id=1,root_folder_path='/movies' WHERE service='radarr'",
      )
      .run();
    const admin = await login(server, 1, true);
    await admin.post('/api/admin/requests/7/approval').send({ decision: 'approved' }).expect(200);
    for (let i = 0; i < 50; i++) {
      const row = database.sqlite
        .prepare('SELECT last_error FROM request_automation WHERE request_id=7')
        .get() as { last_error: string | null };
      if (row?.last_error?.startsWith('Waiting for digital')) break;
      await new Promise((resolve) => setTimeout(resolve, 10));
    }
    const row = database.sqlite
      .prepare(
        'SELECT submission_status,last_error,next_attempt_at FROM request_automation WHERE request_id=7',
      )
      .get();
    expect(row).toMatchObject({
      submission_status: 'queued',
      last_error: 'Waiting for digital release on 2027-01-15',
    });
    expect(calls).toBe(0);
    const tracking = await admin.get('/api/requests/7/tracking').expect(200);
    expect(tracking.body.state).toBe('Waiting for digital release on 2027-01-15');
  });
  it.each([
    [250, 75],
    [999, 0.1],
    [0, 100],
  ])(
    'reports authenticated read-only progress with %s bytes left as %s percent',
    async (remaining, percent) => {
      let calls = 0;
      const server = createApp(database, {
        auth,
        plexUrl: '',
        catalog: { token: '' },
        automationFetch: async (input, init) => {
          calls += 1;
          expect(init?.method ?? 'GET').toBe('GET');
          const url = new URL(String(input));
          if (url.pathname.endsWith('/queue/details'))
            return Response.json([
              {
                movieId: 55,
                size: 1000,
                sizeleft: remaining,
                status: 'downloading',
                trackedDownloadStatus: 'ok',
                timeleft: '00:02:00',
                outputPath: '/private-path',
              },
            ]);
          if (url.pathname.endsWith('/history'))
            return Response.json({
              records: [
                {
                  movieId: 55,
                  eventType: 'grabbed',
                  date: '2026-09-26T00:00:00Z',
                  data: { apiKey: 'never-return-this' },
                },
              ],
            });
          return Response.json({ hasFile: false });
        },
      });
      database.sqlite
        .prepare(
          "UPDATE automation_services SET api_key='server-secret',base_url='http://radarr:7878' WHERE service='radarr'",
        )
        .run();
      database.sqlite
        .prepare(
          "INSERT INTO request_automation(request_id,decision,approved_scope,service,submission_status,external_id,updated_at) VALUES(1,'approved','{}','radarr','sent',55,'2026-09-26T00:00:00Z')",
        )
        .run();
      await request(server).get('/api/requests/1/tracking').expect(401);
      const member = await login(server, 2);
      const result = await member.get('/api/requests/1/tracking').expect(200);
      expect(result.body).toMatchObject({
        state: 'Downloading',
        progress: percent,
        eta: '00:02:00',
        source: 'Radarr',
        events: [{ label: 'Release sent to download client' }],
      });
      expect(JSON.stringify(result.body)).not.toContain('private-path');
      expect(JSON.stringify(result.body)).not.toContain('never-return-this');
      await member.get('/api/requests/1/tracking').expect(200);
      expect(calls).toBe(3);
    },
  );
  it('rejects non-admin decisions and declines without contacting an integration', async () => {
    let calls = 0;
    const server = createApp(database, {
      auth,
      plexUrl: '',
      catalog: { token: '' },
      automationFetch: async () => {
        calls += 1;
        return Response.json({});
      },
    });
    const family = await login(server, 2);
    await family.post('/api/admin/requests/1/approval').send({ decision: 'approved' }).expect(403);

    const admin = await login(server, 1, true);
    const declined = await admin
      .post('/api/admin/requests/1/approval')
      .send({ decision: 'declined', reason: 'Not a fit for the household.' })
      .expect(200);
    expect(declined.body.request).toMatchObject({
      status: 'passed',
      automation: { decision: 'declined', declineReason: 'Not a fit for the household.' },
    });
    expect(calls).toBe(0);
  });

  it('submits approved movies once, preserves approval separately, and never grants Plex availability', async () => {
    let added = false;
    let adds = 0;
    const mockFetch: typeof fetch = async (input, init) => {
      const url = new URL(String(input));
      if (url.pathname.endsWith('/movie') && init?.method === 'POST') {
        adds += 1;
        added = true;
        return Response.json({ id: 55, tmdbId: 9900001 }, { status: 201 });
      }
      if (url.pathname.endsWith('/movie'))
        return Response.json(added ? [{ id: 55, tmdbId: 9900001 }] : []);
      if (url.pathname.endsWith('/movie/lookup'))
        return Response.json([{ title: 'The Last Projection', tmdbId: 9900001, images: [] }]);
      return Response.json({ version: '6.4.4' });
    };
    database.sqlite
      .prepare(
        `INSERT INTO automation_services(service,enabled,base_url,api_key,quality_profile_id,root_folder_path,updated_at)
         VALUES('radarr',1,'http://radarr:7878','server-secret',1,'/movies','2026-09-24T00:00:00Z')`,
      )
      .run();
    const server = createApp(database, {
      auth,
      plexUrl: '',
      catalog: { token: '' },
      automationFetch: mockFetch,
    });
    const admin = await login(server, 1, true);
    await admin.post('/api/admin/requests/1/approval').send({ decision: 'approved' }).expect(200);
    await waitForStatus(1, 'sent');
    await admin.post('/api/admin/requests/1/approval').send({ decision: 'approved' }).expect(200);
    expect(adds).toBe(1);
    const other = await login(server, 3);
    await other.post('/api/requests').send({ mediaType: 'movie', tmdbId: 9900001 }).expect(201);
    expect(adds).toBe(1);
    const result = await admin.get('/api/admin/requests/1').expect(200);
    expect(result.body.request).toMatchObject({
      status: 'requested',
      title: { plexState: 'unavailable' },
      automation: { decision: 'approved', submissionStatus: 'sent', externalId: 55 },
    });
    expect(JSON.stringify(await admin.get('/api/admin/integrations'))).not.toContain(
      'server-secret',
    );
  });

  it('uses TVDB and the approved season scope, fails visibly, and leaves legacy backlog untouched', async () => {
    database.sqlite.prepare('UPDATE titles SET tvdb_id=81189 WHERE id=8').run();
    database.sqlite
      .prepare(
        `INSERT INTO automation_services(service,enabled,base_url,api_key,quality_profile_id,root_folder_path,updated_at)
         VALUES('sonarr',1,'http://sonarr:8989','tv-secret',2,'/tv','2026-09-24T00:00:00Z')`,
      )
      .run();
    let added = false;
    let seriesAdds = 0;
    const commands: Json[] = [];
    type Json = Record<string, unknown>;
    const mockFetch: typeof fetch = async (input, init) => {
      const url = new URL(String(input));
      if (url.pathname.endsWith('/series') && init?.method === 'POST') {
        seriesAdds += 1;
        added = true;
        return Response.json({ id: 77, tvdbId: 81189 }, { status: 201 });
      }
      if (url.pathname.endsWith('/series'))
        return Response.json(added ? [{ id: 77, tvdbId: 81189 }] : []);
      if (url.pathname.endsWith('/series/lookup'))
        return Response.json([
          {
            title: 'Station Eleven Thirty',
            tvdbId: 81189,
            seasons: [0, 1, 2].map((seasonNumber) => ({ seasonNumber, monitored: false })),
          },
        ]);
      if (url.pathname.endsWith('/series/77') && init?.method === 'PUT')
        return Response.json(JSON.parse(String(init.body)));
      if (url.pathname.endsWith('/series/77'))
        return Response.json({
          id: 77,
          tvdbId: 81189,
          title: 'Station Eleven Thirty',
          monitorNewItems: 'none',
          seasons: [0, 1, 2].map((seasonNumber) => ({ seasonNumber, monitored: false })),
        });
      if (url.pathname.endsWith('/command')) {
        commands.push(JSON.parse(String(init?.body)) as Json);
        return Response.json({ id: 90 }, { status: 201 });
      }
      return Response.json({ version: '4.0.20' });
    };
    const server = createApp(database, {
      auth,
      plexUrl: '',
      catalog: { token: '' },
      automationFetch: mockFetch,
    });
    const admin = await login(server, 1, true);
    expect(database.sqlite.prepare('SELECT COUNT(*) FROM request_automation').pluck().get()).toBe(
      0,
    );
    await admin.post('/api/admin/requests/8/approval').send({ decision: 'approved' }).expect(200);
    await waitForStatus(8, 'sent');
    expect(seriesAdds).toBe(1);
    expect(commands).toEqual([{ name: 'SeasonSearch', seriesId: 77, seasonNumber: 1 }]);
    expect(database.sqlite.prepare('SELECT COUNT(*) FROM request_automation').pluck().get()).toBe(
      1,
    );
  });

  it('keeps integration failures actionable without breaking browsing', async () => {
    database.sqlite
      .prepare(
        `INSERT INTO automation_services(service,enabled,base_url,api_key,quality_profile_id,root_folder_path,updated_at)
         VALUES('radarr',1,'http://radarr:7878','bad-key',1,'/movies','2026-09-24T00:00:00Z')`,
      )
      .run();
    const server = createApp(database, {
      auth,
      plexUrl: '',
      catalog: { token: '' },
      automationFetch: async () => new Response('', { status: 503 }),
    });
    const admin = await login(server, 1, true);
    await admin.post('/api/admin/requests/1/approval').send({ decision: 'approved' }).expect(200);
    await waitForStatus(1, 'failed');
    const detail = await admin.get('/api/admin/requests/1').expect(200);
    expect(detail.body.request.automation).toMatchObject({
      decision: 'approved',
      submissionStatus: 'failed',
    });
    expect(detail.body.request.automation.lastError).toContain('HTTP 503');
    await admin.get('/api/home').expect(200);
  });

  it('skips cancelled queued work without contacting or deleting external media', async () => {
    let calls = 0;
    const server = createApp(database, {
      auth,
      plexUrl: '',
      catalog: { token: '' },
      automationFetch: async () => {
        calls += 1;
        return Response.json([]);
      },
    });
    database.sqlite
      .prepare(
        `INSERT INTO request_automation(request_id,decision,decided_by,decided_at,approved_scope,service,submission_status,updated_at)
         VALUES(6,'approved',1,'2026-09-24T00:00:00Z','{"seasons":null}','radarr','queued','2026-09-24T00:00:00Z')`,
      )
      .run();
    await server.locals.automation.run();
    expect(
      database.sqlite
        .prepare('SELECT submission_status FROM request_automation WHERE request_id=6')
        .pluck()
        .get(),
    ).toBe('skipped');
    expect(calls).toBe(0);
  });
});
