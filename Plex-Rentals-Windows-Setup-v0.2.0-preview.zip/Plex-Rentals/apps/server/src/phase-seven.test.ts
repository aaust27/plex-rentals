import { mkdtemp, readdir, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import Database from 'better-sqlite3';
import { afterEach, describe, expect, test } from 'vitest';
import { openDatabase } from './db/client.js';
import { backupDatabase } from './phase-seven.js';

const cleanup: string[] = [];
afterEach(async () => {
  await Promise.all(cleanup.splice(0).map((directory) => rm(directory, { recursive: true })));
});

describe('Phase 7 backups', () => {
  test('creates an online SQLite copy and retains the newest 14 nightly files', async () => {
    const directory = await mkdtemp(path.join(tmpdir(), 'reelrequest-backup-'));
    cleanup.push(directory);
    const databasePath = path.join(directory, 'reelrequest.db');
    const database = openDatabase(databasePath);
    database.sqlite.exec("CREATE TABLE proof(value TEXT); INSERT INTO proof VALUES ('safe')");

    for (let day = 1; day <= 16; day += 1) {
      await backupDatabase(database, new Date(Date.UTC(2026, 8, day, 7)), databasePath);
    }
    database.close();

    const files = (await readdir(path.join(directory, 'backups'))).sort();
    expect(files).toHaveLength(14);
    expect(files[0]).toContain('2026-09-03');
    expect(files.at(-1)).toContain('2026-09-16');

    const copy = new Database(path.join(directory, 'backups', files.at(-1)!));
    expect(copy.prepare('SELECT value FROM proof').pluck().get()).toBe('safe');
    copy.close();
    expect((await readFile(databasePath)).length).toBeGreaterThan(0);
  });
});
