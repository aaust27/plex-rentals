import request from 'supertest';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { detailResponseSchema, homeResponseSchema } from '@reelrequest/shared';
import { createApp } from './app.js';
import { createCatalog } from './catalog.js';
import { migrateDatabase, openDatabase, type AppDatabase } from './db/client.js';
let database: AppDatabase;
beforeEach(() => {
  database = openDatabase(':memory:');
  migrateDatabase(database);
});
afterEach(() => database.close());
describe('Metadata catalog isolated from family authorization', () => {
  it('labels invented metadata without inserting family records or fake requests', async () => {
    const result = homeResponseSchema.parse(await createCatalog(database).home());
    expect(result.mode).toBe('demo');
    expect(result.notice).toContain('invented');
    expect(result.notice).toContain('simulated');
    expect(result.rows.length).toBeGreaterThan(1);
    expect(result.rows.flatMap((row) => row.items).every((item) => !item.requestStatus)).toBe(true);
    expect(database.sqlite.prepare('SELECT count(*) AS n FROM profiles').get()).toEqual({ n: 0 });
  });
  it('filters movie and TV metadata', async () => {
    for (const type of ['movie', 'tv'] as const) {
      const result = await createCatalog(database).home(type);
      expect(result.rows.length).toBeGreaterThan(0);
      expect(result.rows.flatMap((row) => row.items).every((item) => item.mediaType === type)).toBe(
        true,
      );
    }
  });
  it('serves typed details and honest missing/unknown states', async () => {
    const catalog = createCatalog(database);
    const available = detailResponseSchema.parse(await catalog.detail('movie', 9900003));
    expect(available.title).toMatchObject({
      plexState: 'available',
      watchUrl: null,
      trailerKey: null,
      resolution: '4K',
    });
    expect((await catalog.detail('movie', 9900006)).title.plexState).toBe('unknown');
    await expect(catalog.detail('movie', 1)).rejects.toMatchObject({ status: 404 });
    await expect(catalog.detail('tv', 9900003)).rejects.toMatchObject({ status: 404 });
  });
  it('never claims configured Plex has simulated availability', async () => {
    const catalog = createCatalog(database, { plexUrl: 'http://private-plex:32400' });
    const result = await catalog.home();
    expect(result.plexMode).toBe('configured');
    expect(
      result.rows.flatMap((row) => row.items).every((item) => item.plexState === 'unknown'),
    ).toBe(true);
    const detail = await catalog.detail('movie', 9900003);
    expect(detail.title.resolution).toBeNull();
    expect(detail.title.recommendations.every((item) => item.plexState === 'unknown')).toBe(true);
  });
  it('returns safe auth errors without silently substituting fixtures', async () => {
    const upstream = vi
      .fn<typeof fetch>()
      .mockResolvedValue(new Response('secret-upstream', { status: 401 }));
    await expect(
      createCatalog(database, { token: 'secret', fetch: upstream }).home(),
    ).rejects.toMatchObject({ code: 'TMDB_CONFIGURATION' });
  });
  it('normalizes and caches live metadata with simulated Plex only', async () => {
    const upstream = vi.fn<typeof fetch>().mockImplementation(async (input) => {
      const metadata = {
        id: 550,
        title: 'API movie',
        name: 'API TV',
        status: 'Released',
        vote_average: 8.26,
        videos: {
          results: [{ site: 'YouTube', type: 'Trailer', official: true, key: 'abcdefghijk' }],
        },
      };
      return Response.json(
        new URL(String(input)).pathname.endsWith('/550') ? metadata : { results: [metadata] },
      );
    });
    const catalog = createCatalog(database, { token: 'private', fetch: upstream });
    expect((await catalog.home('movie')).mode).toBe('live');
    const result = await catalog.detail('movie', 550);
    expect(result.title).toMatchObject({
      title: 'API movie',
      tmdbScore: 8.3,
      trailerKey: 'abcdefghijk',
      watchUrl: null,
    });
    const calls = upstream.mock.calls.length;
    await catalog.detail('movie', 550);
    expect(upstream.mock.calls.length).toBe(calls);
  });
  it('serves only known original artwork publicly', async () => {
    const app = createApp(database, {
      auth: { householdPasscode: '', sessionSecret: '', adminPin: '' },
    });
    expect(
      (await request(app).get('/api/demo-art/demo-9900001.svg')).headers['content-type'],
    ).toContain('image/svg+xml');
    expect((await request(app).get('/api/demo-art/arbitrary.svg')).status).toBe(404);
  });
});
