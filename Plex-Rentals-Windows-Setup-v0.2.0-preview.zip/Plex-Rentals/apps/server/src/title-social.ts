import type express from 'express';
import { titleRatingInputSchema, titleCommentInputSchema } from '@reelrequest/shared';
import { ApiError, type createAuth } from './auth.js';
import { allowed } from './family.js';
import type { AppDatabase } from './db/client.js';
import type { NotificationService } from './notifications.js';

export function mountTitleSocial(
  app: express.Express,
  database: AppDatabase,
  auth: ReturnType<typeof createAuth>,
  notifications: NotificationService,
  emit: () => void,
) {
  const sql = database.sqlite;
  function context(req: express.Request) {
    const { profile } = auth.context(req);
    const tmdbId = Number(req.params.tmdbId);
    if (
      !['movie', 'tv'].includes(String(req.params.mediaType)) ||
      !Number.isSafeInteger(tmdbId) ||
      tmdbId < 1
    )
      throw new ApiError(400, 'INVALID_TITLE', 'Choose a valid title.');
    const title = sql
      .prepare('SELECT id,title,certification FROM titles WHERE media_type=? AND tmdb_id=?')
      .get(req.params.mediaType, tmdbId) as
      { id: number; title: string; certification: string | null } | undefined;
    if (!title || !allowed(profile, title.certification))
      throw new ApiError(404, 'NOT_FOUND', 'Title not available.');
    return { profile, title };
  }
  function people(certification: string | null) {
    return (
      sql
        .prepare(
          'SELECT id AS profileId,name,max_rating_level AS maxRatingLevel FROM profiles WHERE disabled=0',
        )
        .all() as { profileId: number; name: string; maxRatingLevel: number | null }[]
    ).filter((p) => allowed(p, certification));
  }
  const path = '/api/titles/:mediaType/:tmdbId/social';
  app.get(path, (req, res) => {
    const { profile, title } = context(req);
    const before = Number(req.query.before ?? Number.MAX_SAFE_INTEGER);
    if (!Number.isSafeInteger(before) || before < 1)
      throw new ApiError(400, 'INVALID_CURSOR', 'Invalid comment page.');
    const members = people(title.certification).map(({ profileId, name }) => ({ profileId, name }));
    const ratings = sql
      .prepare(
        'SELECT r.profile_id AS profileId,p.name,r.score FROM title_ratings r JOIN profiles p ON p.id=r.profile_id WHERE r.title_id=? AND p.disabled=0 ORDER BY p.name',
      )
      .all(title.id) as { profileId: number; name: string; score: number }[];
    const comments = sql
      .prepare(
        'SELECT c.id,c.profile_id AS profileId,p.name,c.body,c.mentions,c.created_at AS createdAt FROM title_comments c JOIN profiles p ON p.id=c.profile_id WHERE c.title_id=? AND c.id<? AND p.disabled=0 ORDER BY c.id DESC LIMIT 31',
      )
      .all(title.id, before) as {
      id: number;
      profileId: number;
      name: string;
      body: string;
      mentions: string;
      createdAt: string;
    }[];
    res.json({
      average: ratings.length ? ratings.reduce((n, r) => n + r.score, 0) / ratings.length : null,
      count: ratings.length,
      myScore: ratings.find((r) => r.profileId === profile.id)?.score ?? null,
      ratings,
      people: members,
      comments: comments
        .slice(0, 30)
        .map((c) => ({
          ...c,
          mentions: members.filter((p) =>
            (JSON.parse(c.mentions) as number[]).includes(p.profileId),
          ),
        })),
      nextCursor: comments.length > 30 ? comments[29]!.id : null,
    });
  });
  app.put(path + '/rating', (req, res) => {
    const { profile, title } = context(req);
    const parsed = titleRatingInputSchema.safeParse(req.body);
    if (!parsed.success)
      throw new ApiError(400, 'INVALID_INPUT', 'Choose 0–10 stars in half-point steps.');
    sql
      .prepare(
        'INSERT INTO title_ratings(title_id,profile_id,score) VALUES(?,?,?) ON CONFLICT(title_id,profile_id) DO UPDATE SET score=excluded.score,updated_at=CURRENT_TIMESTAMP',
      )
      .run(title.id, profile.id, parsed.data.score);
    emit();
    res.json({ ok: true });
  });
  app.post(path + '/comments', (req, res) => {
    const { profile, title } = context(req);
    const parsed = titleCommentInputSchema.safeParse(req.body);
    if (!parsed.success)
      throw new ApiError(400, 'INVALID_INPUT', 'Write 1–2,000 characters and tag up to 10 people.');
    const mentions = [...new Set(parsed.data.mentions)];
    const members = people(title.certification);
    if (mentions.some((id) => !members.some((p) => p.profileId === id)))
      throw new ApiError(
        400,
        'INVALID_MENTION',
        'Choose an active household member who can view this title.',
      );
    const recent = sql
      .prepare(
        "SELECT count(*) AS n FROM title_comments WHERE profile_id=? AND created_at>datetime('now','-1 hour')",
      )
      .get(profile.id) as { n: number };
    if (recent.n >= 20)
      throw new ApiError(429, 'SLOW_DOWN', 'Please wait before adding more comments.');
    const id = Number(
      sql
        .prepare('INSERT INTO title_comments(title_id,profile_id,body,mentions) VALUES(?,?,?,?)')
        .run(title.id, profile.id, parsed.data.body, JSON.stringify(mentions)).lastInsertRowid,
    );
    notifications.notify(
      mentions.filter((id) => id !== profile.id),
      {
        kind: 'mention',
        titleId: title.id,
        body: `${profile.name} tagged you in a comment on ${title.title}.`,
      },
    );
    emit();
    res.status(201).json({ id });
  });
}
