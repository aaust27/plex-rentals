# Windows desktop setup. No administrator elevation, global policy changes,
# automatic reboot or port forwarding. Additional setup is explicitly opt-in.
param([switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
function Get-Prerequisites {
    if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { return 'Install Docker Desktop, start it using Linux containers, then run Setup again.' }
    $engine = & docker info --format '{{.OSType}}' 2>$null
    if ($LASTEXITCODE -ne 0 -or $engine -ne 'linux') { return 'Start Docker Desktop and switch to Linux containers, then try again.' }
    & docker compose version *> $null
    if ($LASTEXITCODE -ne 0) { return 'Docker Compose v2 is required. Update Docker Desktop, then try again.' }
    return $null
}
if ($CheckOnly) {
    $problem = Get-Prerequisites
    if ($problem) { throw $problem }
    Write-Output 'Docker Linux engine and Compose are ready. No configuration changed.'
    exit 0
}
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$form = New-Object Windows.Forms.Form
$form.Text = 'Plex Rentals | Guided Setup'
$form.Size = New-Object Drawing.Size(760,850)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.BackColor = [Drawing.Color]::FromArgb(17,18,23)
$form.ForeColor = [Drawing.Color]::White
$form.Font = New-Object Drawing.Font('Segoe UI',10)
function Add-Label($text,$x,$y,$width,$height) {
    $item = New-Object Windows.Forms.Label
    $item.Text=$text; $item.Location=New-Object Drawing.Point($x,$y); $item.Size=New-Object Drawing.Size($width,$height)
    $form.Controls.Add($item); return $item
}
function Add-Input($x,$y,$width,$secret=$false) {
    $item=New-Object Windows.Forms.TextBox
    $item.Location=New-Object Drawing.Point($x,$y); $item.Width=$width; $item.UseSystemPasswordChar=$secret
    $item.BackColor=[Drawing.Color]::FromArgb(35,36,45); $item.ForeColor=[Drawing.Color]::White
    $item.BorderStyle='FixedSingle'
    $form.Controls.Add($item); return $item
}
$heading = Add-Label 'Your next great movie night.' 32 28 680 48
$heading.Font=New-Object Drawing.Font('Segoe UI',24,[Drawing.FontStyle]::Bold)
$heading.ForeColor=[Drawing.Color]::FromArgb(247,168,35)
$intro=Add-Label "1. Start Docker Desktop    2. Choose access details    3. Launch`r`nA private, local installation. Nothing is opened to the Internet." 34 88 680 55
$null=Add-Label 'Household passcode (8+ letters/numbers, . _ or -)' 34 155 470 25
$pass=Add-Input 34 183 470 $true
$null=Add-Label 'Owner PIN (4 digits)' 34 225 310 25
$pin=Add-Input 34 253 250 $true
$null=Add-Label 'Local port' 330 225 200 25
$port=Add-Input 330 253 174
$port.Text='8090'
$null=Add-Label 'TMDB Read Access Token (optional; blank = fictional preview)' 34 298 680 25
$token=Add-Input 34 326 670 $true
$null=Add-Label 'Plex server URL (optional; same PC: http://host.docker.internal:32400)' 34 365 670 25
$plexUrl=Add-Input 34 393 670
$null=Add-Label 'Your Plex token (optional)' 34 430 670 25
$plexToken=Add-Input 34 458 670 $true
$help=Add-Label 'Remember your passcode and PIN. Your initial administrator is Owner. Continue to guided service setup after the app starts.' 34 500 670 48
$status=Add-Label 'Ready to check your computer.' 34 560 670 70
$status.ForeColor=[Drawing.Color]::FromArgb(247,168,35)
$button=New-Object Windows.Forms.Button
$button.Text='Check and install'; $button.Location=New-Object Drawing.Point(34,650); $button.Size=New-Object Drawing.Size(260,44)
$button.BackColor=[Drawing.Color]::FromArgb(247,168,35); $button.ForeColor=[Drawing.Color]::Black
$button.FlatStyle='Flat'; $form.Controls.Add($button)
$dockerHelp=New-Object Windows.Forms.LinkLabel
$dockerHelp.Text='Install Docker Desktop'; $dockerHelp.Location=New-Object Drawing.Point(330,660); $dockerHelp.Size=New-Object Drawing.Size(350,30)
$dockerHelp.LinkColor=[Drawing.Color]::LightSkyBlue
$dockerHelp.add_LinkClicked({ Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+(Join-Path $PSScriptRoot 'setup/Docker.ps1')+'"')) -WindowStyle Hidden })
$form.Controls.Add($dockerHelp)
$servicesButton=New-Object Windows.Forms.Button
$servicesButton.Text='Next: guided Sonarr / Radarr / Prowlarr setup';$servicesButton.Location=New-Object Drawing.Point(34,710);$servicesButton.Size=New-Object Drawing.Size(670,44)
$servicesButton.add_Click({
    if(!(Test-Path -LiteralPath (Join-Path $PSScriptRoot '.env')) -or !$script:finished){$status.Text='Start Plex Rentals first, then continue to guided service setup.';return}
    Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+(Join-Path $PSScriptRoot 'setup/Services.ps1')+'"')) -WindowStyle Hidden
})
$form.Controls.Add($servicesButton)
$envPath=Join-Path $PSScriptRoot '.env'
$existing=Test-Path -LiteralPath $envPath
if ($existing) {
    $plexUrl.Enabled=$false; $plexToken.Enabled=$false
    $pass.Enabled=$false; $pin.Enabled=$false; $token.Enabled=$false; $port.Enabled=$false
    $portMatch=[regex]::Match([IO.File]::ReadAllText($envPath),'(?m)^INSTALL_PORT=(\d+)\s*$')
    if (-not $portMatch.Success) { throw 'Existing configuration is missing INSTALL_PORT. Restore the original configuration; Setup will not overwrite it.' }
    $port.Text=$portMatch.Groups[1].Value
    $status.Text='Existing installation detected. Your credentials and database will be preserved.'
    $button.Text='Start / update'
}
$script:process=$null
$script:readyAt=$null
$script:url=$null
$timer=New-Object Windows.Forms.Timer
$timer.Interval=1500
$onTick = {
    if ($script:process -and -not $script:process.HasExited) { return }
    if ($script:process) {
        $script:process.WaitForExit()
        $script:process.Refresh()
        if ($script:process.ExitCode -ne 0) {
            $timer.Stop(); $status.Text='Build/start failed. See setup-build.log and setup-error.log in this folder, then retry. Your data was preserved.'; $button.Enabled=$true; $script:process=$null; return
        }
        $script:process=$null; $script:readyAt=[DateTime]::UtcNow; $status.Text='Starting Plex Rentals and checking its health...'
    }
    try {
        $response=Invoke-WebRequest -Uri "$($script:url)/api/health" -UseBasicParsing -TimeoutSec 2
        $health=$response.Content | ConvertFrom-Json
        if ($response.StatusCode -eq 200 -and $health.status -eq 'ok') {
            $timer.Stop(); $status.Text="Ready! Sign in as Owner with the details you chose. Open Settings to connect TMDB/Plex and manage family profiles.`r`n$($script:url)"; $button.Text='Open Plex Rentals'; $button.Enabled=$true
            $script:finished=$true; Start-Process $script:url
        }
    } catch { }
    if ($script:readyAt -and ([DateTime]::UtcNow-$script:readyAt).TotalSeconds -gt 120 -and -not $script:finished) {
        $timer.Stop(); $status.Text='The container started but the app did not become healthy. Check Docker Desktop and setup-error.log. Rerun Setup to retry.'; $button.Enabled=$true
    }
}
$timer.add_Tick($onTick)
$onInstall = {
    try {
        if ($script:finished) { Start-Process $script:url; return }
        $status.Text='Checking Docker...'; $form.Refresh()
        $problem=Get-Prerequisites
        if ($problem) { $status.Text=$problem; return }
        $number=0
        if (-not [int]::TryParse($port.Text,[ref]$number) -or $number -lt 1024 -or $number -gt 65535) { throw 'Choose a port from 1024 through 65535.' }
        if (-not (Test-Path -LiteralPath $envPath)) {
            if ($pass.Text -notmatch '^[A-Za-z0-9._-]{8,128}$') { throw 'Choose a passcode of 8-128 letters, numbers, periods, underscores or hyphens.' }
            if ($pin.Text -notmatch '^\d{4}$') { throw 'Choose a four-digit Owner PIN.' }
            if ($token.Text -and $token.Text -notmatch '^[A-Za-z0-9._-]+$') { throw 'Paste only the TMDB Read Access Token, without spaces.' }
            if($plexUrl.Text -and $plexUrl.Text -notmatch '^https?://[A-Za-z0-9.:-]+/?$'){throw 'Enter a plain HTTP(S) Plex server URL, with no credentials or query string.'}
            if($plexToken.Text -and $plexToken.Text -notmatch '^[A-Za-z0-9_-]+$'){throw 'Paste only your Plex token, without spaces.'}
            if([bool]$plexUrl.Text -ne [bool]$plexToken.Text){throw 'Enter both Plex URL and token, or leave both blank for now.'}
            $oldVolume=& docker volume ls --filter 'name=^plexrentals_data$' --format '{{.Name}}'
            if ($oldVolume -eq 'plexrentals_data') { throw 'An existing Plex Rentals database was found. Use the original installation folder and .env; Setup will not attach new credentials to old data.' }
            $listener=New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback,$number)
            try { $listener.Start() } catch { throw 'That port is already in use. Choose another local port.' } finally { $listener.Stop() }
            $rng=[Security.Cryptography.RandomNumberGenerator]::Create()
            try {
                $bytes=New-Object byte[] 32; $rng.GetBytes($bytes); $secret=([BitConverter]::ToString($bytes)).Replace('-','').ToLowerInvariant()
                $rng.GetBytes($bytes); $webhook=([BitConverter]::ToString($bytes)).Replace('-','').ToLowerInvariant()
            } finally { $rng.Dispose() }
            # Secure the file before putting any credentials in it.
            $stream=[IO.File]::Open($envPath,[IO.FileMode]::CreateNew); $stream.Dispose()
            $acl=New-Object Security.AccessControl.FileSecurity
            $acl.SetAccessRuleProtection($true,$false)
            $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User
            $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($sid,'FullControl','Allow')))
            $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule('SYSTEM','FullControl','Allow')))
            Set-Acl -LiteralPath $envPath -AclObject $acl
            $text="INSTALL_PORT=$number`nHOUSEHOLD_PASSCODE=$($pass.Text)`nADMIN_PIN=$($pin.Text)`nSESSION_SECRET=$secret`nPLEX_WEBHOOK_SECRET=$webhook`nTMDB_READ_TOKEN=$($token.Text)`n"
            $text+="PLEX_URL=$($plexUrl.Text)`nPLEX_TOKEN=$($plexToken.Text)`n"
            [IO.File]::WriteAllText($envPath,$text,(New-Object Text.UTF8Encoding($false)))
            $pass.Clear(); $pin.Clear(); $token.Clear()
            $plexUrl.Clear();$plexToken.Clear();$plexUrl.Enabled=$false;$plexToken.Enabled=$false
        }
        $script:url="http://localhost:$number"
        $script:readyAt=$null
        $button.Enabled=$false; $pass.Enabled=$false; $pin.Enabled=$false; $token.Enabled=$false; $port.Enabled=$false
        $status.Text='Building your app. The first installation downloads dependencies and can take several minutes. You can keep this window open.'
        $composeArgs=@('compose','-f','compose.yaml')
        if([IO.File]::ReadAllText($envPath) -match '(?m)^SETUP_STACK=1\s*$'){$composeArgs+=@('-f','setup/stack.compose.yaml')}
        $script:process=Start-Process -FilePath 'docker' -ArgumentList ($composeArgs+@('up','-d','--build','--wait','--wait-timeout','180')) -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PSScriptRoot 'setup-build.log') -RedirectStandardError (Join-Path $PSScriptRoot 'setup-error.log') -PassThru
        # Retain the handle so Windows PowerShell can retrieve the exit code
        # even when a short-lived docker process exits between timer ticks.
        $null=$script:process.Handle
        $timer.Start()
    } catch { $status.Text=$_.Exception.Message; $button.Enabled=$true }
}
$button.add_Click($onInstall)
$form.add_FormClosing({
    param($sender,$event)
    if ($script:process -and -not $script:process.HasExited) {
        [Windows.Forms.MessageBox]::Show('Please wait for setup to finish. Docker is still building the app.','Setup in progress') | Out-Null
        $event.Cancel=$true
    }
})
[void]$form.ShowDialog()
$timer.Dispose(); $form.Dispose()
