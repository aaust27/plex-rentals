# Downloads only the official installer, checks its signature, then lets the user
# review Docker's interactive installer, terms, elevation and restart prompts.
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$f=New-Object Windows.Forms.Form;$f.Text='Plex Rentals | Docker prerequisite';$f.Size=New-Object Drawing.Size(650,360);$f.StartPosition='CenterScreen'
$l=New-Object Windows.Forms.Label;$l.Location=New-Object Drawing.Point(24,24);$l.Size=New-Object Drawing.Size(590,150)
$l.Text="Docker Desktop runs your private app containers.`r`n`r`nThis downloads Docker's official Windows installer and verifies its publisher. You review Docker's terms and any Windows/WSL or restart prompts yourself. Setup will not reboot this PC.`r`n`r`nAfter installation, start Docker Desktop, finish its welcome steps, then return to Plex Rentals Setup."
$f.Controls.Add($l)
$b=New-Object Windows.Forms.Button;$b.Location=New-Object Drawing.Point(24,210);$b.Size=New-Object Drawing.Size(290,45);$b.Text='Download and open Docker installer';$f.Controls.Add($b)
$link=New-Object Windows.Forms.LinkLabel;$link.Text='Requirements and licensing';$link.Location=New-Object Drawing.Point(335,222);$link.Width=240;$link.add_LinkClicked({Start-Process 'https://docs.docker.com/desktop/setup/install/windows-install/'});$f.Controls.Add($link)
$script:download=$null;$timer=New-Object Windows.Forms.Timer;$timer.Interval=1000
$b.add_Click({
  $answer=[Windows.Forms.MessageBox]::Show('Download and launch the official Docker Desktop installer? Windows may ask for elevation. You control any restart.','Install Docker','YesNo')
  if($answer -ne 'Yes'){return}
  $arch=if($env:PROCESSOR_ARCHITECTURE -eq 'ARM64'){'arm64'}else{'amd64'}
  $script:destination=Join-Path ([IO.Path]::GetTempPath()) ('PlexRentals-Docker-'+[Guid]::NewGuid().ToString('N')+'.exe')
  $script:download=Start-Job -ArgumentList $arch,$script:destination -ScriptBlock {param($arch,$dest) [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;Invoke-WebRequest -UseBasicParsing -Uri "https://desktop.docker.com/win/main/$arch/Docker%20Desktop%20Installer.exe" -OutFile $dest}
  $b.Enabled=$false;$l.Text='Downloading Docker Desktop from desktop.docker.com. This can take several minutes...';$timer.Start()
})
$timer.add_Tick({
  if($script:download.State -eq 'Running'){return}
  $timer.Stop()
  try{
    Receive-Job $script:download -ErrorAction Stop|Out-Null
    $sig=Get-AuthenticodeSignature -LiteralPath $script:destination
    if($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'O=Docker Inc\.?[, ]'){throw 'Docker publisher verification failed. The installer was not opened.'}
    # This is an explicitly requested interactive installer, so show its window.
    Start-Process -FilePath $script:destination
    $l.Text='Docker installer opened. Review its steps. Start Docker Desktop afterward, then return to the Plex Rentals setup window.'
  }catch{$l.Text=$_.Exception.Message;$b.Enabled=$true}
  Remove-Job $script:download;$script:download=$null
})
$f.add_FormClosing({param($s,$e) if($script:download -and $script:download.State -eq 'Running'){$e.Cancel=$true;$l.Text='Please wait for the Docker download to finish.'}})
[void]$f.ShowDialog();$timer.Dispose();$f.Dispose()
