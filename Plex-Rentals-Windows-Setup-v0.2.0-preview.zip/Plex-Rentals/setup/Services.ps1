# A guided, opt-in extension for a fresh installer-owned stack only.
$ErrorActionPreference='Stop'
$installRoot=Split-Path $PSScriptRoot -Parent
Set-Location -LiteralPath $installRoot
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$window=New-Object Windows.Forms.Form
$window.Text='Plex Rentals | Connect your movie night'
$window.Size=New-Object Drawing.Size(850,800)
$window.StartPosition='CenterScreen'; $window.BackColor='#111217'; $window.ForeColor='White'
$window.Font=New-Object Drawing.Font('Segoe UI',10)
$tabs=New-Object Windows.Forms.TabControl
$tabs.Location=New-Object Drawing.Point(20,20); $tabs.Size=New-Object Drawing.Size(795,570)
$window.Controls.Add($tabs)
function Page($title) {
  $p=New-Object Windows.Forms.TabPage; $p.Text=$title; $p.BackColor='#171922'; $p.ForeColor='White'; $tabs.TabPages.Add($p); return $p
}
function Label($p,$text,$y,$height=36) {
  $l=New-Object Windows.Forms.Label; $l.Text=$text; $l.Location=New-Object Drawing.Point(24,$y); $l.Size=New-Object Drawing.Size(720,$height); $p.Controls.Add($l)
}
function Input($p,$title,$y,$value='',$secret=$false) {
  Label $p $title $y 24
  $t=New-Object Windows.Forms.TextBox; $t.Location=New-Object Drawing.Point(24,($y+28));$t.Width=720;$t.Text=$value;$t.UseSystemPasswordChar=$secret;$p.Controls.Add($t);return $t
}
$services=Page '1  Services & folders'
Label $services 'New Sonarr + Radarr + Prowlarr containers. Existing installations are left alone. Local access only; accounts and library paths are connected automatically.' 20 60
$username=Input $services 'Choose a service username' 90 'owner'
$password=Input $services 'Choose a service password (12+ characters; used for all three new apps)' 165 '' $true
$media=Input $services 'New LOCAL media folder (must be empty; NAS storage needs a separate mount setup)' 240 (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'PlexRentalsMedia')
Label $services "Setup creates library\movies, library\tv and downloads inside this folder.`r`nDefault quality: HD-1080p. Service ports: 18989 / 17878 / 19696.`r`nNothing is imported, searched for, downloaded or deleted during setup." 330 105
$connections=Page '2  Download client'
Label $connections 'Optional: connect an existing qBittorrent Web UI. On this PC, use host.docker.internal instead of localhost. Leave blank to finish later.' 20 60
$qurl=Input $connections 'qBittorrent Web UI URL' 90
$quser=Input $connections 'qBittorrent username' 165
$qpass=Input $connections 'qBittorrent password' 240 '' $true
$qpath=Input $connections 'Path qBittorrent reports for downloads (must point to the chosen downloads folder)' 315
Label $connections 'We test the connection and create disabled clients + path mappings. Review category save paths in qBittorrent before enabling imports.' 400 75
$indexers=Page '3  Indexer & review'
Label $indexers 'Optional: connect your authorized Torznab provider. Other providers can be added directly in Prowlarr. Setup cannot create third-party accounts for you.' 20 60
$iurl=Input $indexers 'Torznab endpoint URL (no API key in the URL)' 90
$ikey=Input $indexers 'Torznab API key' 165 '' $true
Label $indexers "Plex and TMDB details can be entered in the main wizard on first install. To add them later, follow the private configuration steps in docs/SETUP.md.`r`n`r`nReview the results, enable your client/indexers, then explicitly enable acquisition when you are ready. A skipped step stays on the checklist." 250 130
$consent=New-Object Windows.Forms.CheckBox
$consent.Text='Set up these new services and grant them access to only the media folder above.'
$consent.Location=New-Object Drawing.Point(24,410);$consent.Size=New-Object Drawing.Size(720,65);$indexers.Controls.Add($consent)
$status=New-Object Windows.Forms.Label;$status.Location=New-Object Drawing.Point(24,603);$status.Size=New-Object Drawing.Size(790,70);$status.Text='Fill in the three tabs, then approve the setup.';$status.ForeColor='#f7a823';$window.Controls.Add($status)
$go=New-Object Windows.Forms.Button;$go.Text='Set it up for me';$go.Location=New-Object Drawing.Point(24,685);$go.Size=New-Object Drawing.Size(250,44);$go.BackColor='#f7a823';$go.ForeColor='Black';$window.Controls.Add($go)
function PrivateFile($path,$text) {
  $f=[IO.File]::Open($path,[IO.FileMode]::CreateNew);$f.Dispose()
  $acl=New-Object Security.AccessControl.FileSecurity;$acl.SetAccessRuleProtection($true,$false)
  foreach($identity in @([Security.Principal.WindowsIdentity]::GetCurrent().User,'SYSTEM')){$acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($identity,'FullControl','Allow')))}
  Set-Acl -LiteralPath $path -AclObject $acl
  [IO.File]::WriteAllText($path,$text,(New-Object Text.UTF8Encoding($false)))
}
$privatePath=Join-Path $installRoot '.setup-private.json'
$envFile=Join-Path $installRoot '.env'
$resume=(Test-Path -LiteralPath $privatePath)
if($resume){
  $saved=Get-Content -LiteralPath $privatePath -Raw|ConvertFrom-Json
  $username.Text=$saved.username;$username.Enabled=$false;$password.Enabled=$false;$media.Enabled=$false
  $qurl.Text=$saved.qbitUrl;$quser.Text=$saved.qbitUser;$qpass.Text=$saved.qbitPassword;$qpath.Text=$saved.qbitRemotePath;$iurl.Text=$saved.indexerUrl;$ikey.Text=$saved.indexerKey
  $status.Text='Resume detected. Service login is preserved. You can correct connection details and retry unfinished setup.'
}
$script:child=$null;$script:stage='';$script:done=$false
$compose=@('compose','-f','compose.yaml','-f','setup/stack.compose.yaml')
$poll=New-Object Windows.Forms.Timer;$poll.Interval=1500
function Launch($argsList,$inputFile=$null){
  $parameters=@{FilePath='docker';ArgumentList=$argsList;WorkingDirectory=$installRoot;WindowStyle='Hidden';PassThru=$true;RedirectStandardOutput=(Join-Path $installRoot 'setup-services.log');RedirectStandardError=(Join-Path $installRoot 'setup-services-error.log')}
  if($inputFile){$parameters.RedirectStandardInput=$inputFile}
  $script:child=Start-Process @parameters;$null=$script:child.Handle
}
$poll.add_Tick({
  if(!$script:child.HasExited){return}
  $script:child.WaitForExit();$script:child.Refresh()
  if($script:child.ExitCode -ne 0){$poll.Stop();$status.Text='Setup paused. See setup-services-error.log. Fix the reported connection, then retry; no data was removed.';$go.Enabled=$true;return}
  if($script:stage -eq 'start'){
    $script:stage='configure';$status.Text='Testing connections, configuring authentication and connecting the apps...'
    Launch ($compose+@('exec','-T','app','node','setup/configure-stack.mjs')) $privatePath
  }else{
    $poll.Stop();$script:done=$true;$go.Enabled=$true;$go.Text='Open setup checklist'
    $status.Text='Services installed and linked. Read setup-services.log for skipped steps and final activation. No downloads started.'
  }
})
$go.add_Click({
  try{
    if($script:done){Start-Process notepad.exe -ArgumentList ('"'+(Join-Path $installRoot 'setup-services.log')+'"');return}
    if(!$consent.Checked){$tabs.SelectedTab=$indexers;throw 'Please review and check the setup permission box.'}
    if(!(Test-Path -LiteralPath $envFile)){throw 'Run the main Setup first to create your household.'}
    if(!(Test-Path -LiteralPath $privatePath)){
      if($username.Text -notmatch '^[\w.-]{1,64}$' -or $password.Text.Length -lt 12){throw 'Choose a valid service username and a password of 12+ characters.'}
      $root=[IO.Path]::GetFullPath($media.Text)
      if($root -notmatch '^[A-Za-z]:\\' -or $root.Length -lt 5 -or $root -match '[\r\n$#''"]'){throw 'Choose a dedicated local folder with no special characters.'}
      if((New-Object IO.DriveInfo([IO.Path]::GetPathRoot($root))).DriveType -ne 'Fixed'){throw 'Choose a local fixed drive. Network shares require a separately verified Docker mount.'}
      if((Test-Path -LiteralPath $root) -and (Get-ChildItem -LiteralPath $root -Force | Select-Object -First 1)){throw 'Choose an empty folder. Setup never adopts an existing media library.'}
      foreach($p in @(18989,17878,19696)){$l=New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback,$p);try{$l.Start()}catch{throw "Service port $p is occupied. Existing apps were left alone."}finally{$l.Stop()}}
      $existingConfig=[IO.File]::ReadAllText($envFile)
      if($existingConfig -match '(?m)^SETUP_STACK='){throw 'Stack configuration already exists. Restore .setup-private.json or finish in the service interfaces.'}
      $projectName=if($env:COMPOSE_PROJECT_NAME){$env:COMPOSE_PROJECT_NAME}else{'plexrentals'}
      $previous=& docker volume ls --filter "label=com.docker.compose.project=$projectName" --format '{{.Name}}'
      if($previous -match '_(sonarr|radarr|prowlarr)_config$'){throw 'Existing service configuration found. Restore its original installer files instead of replacing authentication.'}
      foreach($sub in @('downloads','library/movies','library/tv')){New-Item -ItemType Directory -Force -Path (Join-Path $root $sub)|Out-Null}
      $inputData=@{username=$username.Text;password=$password.Text;quality='HD-1080p';qbitUrl=$qurl.Text;qbitUser=$quser.Text;qbitPassword=$qpass.Text;qbitRemotePath=$qpath.Text;indexerUrl=$iurl.Text;indexerKey=$ikey.Text}
      PrivateFile $privatePath ($inputData|ConvertTo-Json)
      $rng=[Security.Cryptography.RandomNumberGenerator]::Create()
      try{$extra="`nSETUP_STACK=1`nMEDIA_ROOT=$($root.Replace('\','/'))`n";foreach($name in @('SONARR','RADARR','PROWLARR')){$bytes=New-Object byte[] 16;$rng.GetBytes($bytes);$key=([BitConverter]::ToString($bytes)).Replace('-','').ToLowerInvariant();$extra+="SETUP_$($name)_KEY=$key`n"}}finally{$rng.Dispose()}
      [IO.File]::AppendAllText($envFile,$extra,(New-Object Text.UTF8Encoding($false)))
      $password.Clear();$qpass.Clear();$ikey.Clear()
    }else{
      $saved=Get-Content -LiteralPath $privatePath -Raw|ConvertFrom-Json
      $saved.qbitUrl=$qurl.Text;$saved.qbitUser=$quser.Text;$saved.qbitPassword=$qpass.Text;$saved.qbitRemotePath=$qpath.Text;$saved.indexerUrl=$iurl.Text;$saved.indexerKey=$ikey.Text
      [IO.File]::WriteAllText($privatePath,($saved|ConvertTo-Json),(New-Object Text.UTF8Encoding($false)))
    }
    $go.Enabled=$false;$script:stage='start';$status.Text='Installing the new service containers. First start may take several minutes...'
    Launch ($compose+@('up','-d','--build','--wait','--wait-timeout','180'));$poll.Start()
  }catch{$status.Text=$_.Exception.Message;$go.Enabled=$true}
})
$window.add_FormClosing({param($s,$e) if($script:child -and !$script:child.HasExited){$e.Cancel=$true;$status.Text='Please wait while setup is running.'}})
[void]$window.ShowDialog()
$poll.Dispose();$window.Dispose()
