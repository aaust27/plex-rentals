// Runs inside ONLY the new installer stack. All supplied credentials arrive on
// stdin or in the installer-generated environment. Never discover existing keys.
import { readFile, writeFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
export async function configure(input, { fetcher = fetch, env = process.env, report = console.log, checkpoint = async () => {} } = {}) {
  if (env.SETUP_STACK !== '1') throw new Error('This helper is only for the new installer-managed stack.');
  if (!/^[\w.-]{1,64}$/.test(input.username || '') || (input.password || '').length < 12)
    throw new Error('Choose a service username and a password of at least 12 characters.');
  const definitions = {
    sonarr: { url: 'http://sonarr:8989/api/v3', key: env.SONARR_API_KEY, root: '/data/library/tv' },
    radarr: { url: 'http://radarr:7878/api/v3', key: env.RADARR_API_KEY, root: '/data/library/movies' },
    prowlarr: { url: 'http://prowlarr:9696/api/v1', key: env.SETUP_PROWLARR_KEY },
  };
  for (const d of Object.values(definitions)) if (!/^[a-f0-9]{32}$/.test(d.key || '')) throw new Error('Installer-generated service key is missing.');
  async function call(service, route, method = 'GET', body) {
    const d = definitions[service];
    const result = await fetcher(`${d.url}/${route}`, {
      method, headers: { 'X-Api-Key': d.key, 'Content-Type': 'application/json' },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.timeout(15000),
    });
    // Do not echo third-party response bodies: validation errors can contain keys.
    if (!result.ok) {
      const errors = await result.json().catch(() => null);
      const fields = Array.isArray(errors) ? errors.map(e => e.propertyName).filter(v => typeof v === 'string' && /^[A-Za-z.]+$/.test(v)).join(', ') : '';
      throw new Error(`${service}: ${method} ${route.split('?')[0]} returned HTTP ${result.status}${fields ? ` (fields: ${fields})` : ''}. Check the connection and retry.`);
    }
    return result.status === 204 ? null : result.json();
  }
  function fields(template, changes) {
    const supported = new Set(template.fields.map(f => f.name));
    for (const key of Object.keys(changes)) if (!supported.has(key)) throw new Error(`Unsupported service field: ${key}`);
    return { ...template, fields: template.fields.map(f => f.name in changes ? { ...f, value: changes[f.name] } : f) };
  }
  // A resumed run never rotates passwords. Only initialize when no setup marker
  // exists, and create missing named resources instead of deleting or replacing.
  for (const service of Object.keys(definitions)) {
    for (let attempt = 0; ; attempt++) {
      try { await call(service, 'system/status'); break; }
      catch (error) { if (attempt >= 20) throw error; await new Promise(resolve => setTimeout(resolve, 1500)); }
    }
    if (!(input.authConfigured || []).includes(service)) {
      await call(service, 'config/host', 'PUT', {
        id: 1, allowedHosts: '', logSizeLimit: 1, bindAddress: '*', port: Number(new URL(definitions[service].url).port), sslPort: 9898,
        enableSsl: false, launchBrowser: false, authenticationMethod: 'forms', authenticationRequired: 'enabled',
        username: input.username, password: input.password, passwordConfirmation: input.password,
        apiKey: definitions[service].key, analyticsEnabled: false, logLevel: 'info', branch: 'master',
        consoleLogLevel: '', sslCertPath: '', sslCertPassword: '', urlBase: '', applicationUrl: '',
        updateScriptPath: '', proxyHostname: '', proxyUsername: '', proxyPassword: '', proxyBypassFilter: '',
        proxyEnabled: false, proxyPort: 8080, proxyType: 'http', trustedNetworks: '',
        updateAutomatically: false, updateMechanism: 'docker', certificateValidation: 'enabled',
        backupFolder: 'Backups', backupInterval: 7, backupRetention: 28, instanceName: service[0].toUpperCase() + service.slice(1),
      });
      await checkpoint(service);
    }
    report(`${service}: connected; authenticated access required.`);
  }
  const profiles = {};
  for (const service of ['sonarr', 'radarr']) {
    const roots = await call(service, 'rootfolder');
    if (!roots.some(r => r.path === definitions[service].root))
      await call(service, 'rootfolder', 'POST', { path: definitions[service].root });
    const available = await call(service, 'qualityprofile');
    const selected = available.find(p => p.name === (input.quality || 'HD-1080p'));
    if (!selected) throw new Error(`${service}: the selected quality profile was not found. Choose it in the app before enabling requests.`);
    profiles[service] = selected.id;
    report(`${service}: library root and ${selected.name} profile ready.`);
  }
  const applications = await call('prowlarr', 'applications');
  const templates = await call('prowlarr', 'applications/schema');
  for (const service of ['sonarr', 'radarr']) {
    const name = `Plex Rentals ${service}`;
    if (applications.some(a => a.name === name)) continue;
    const template = templates.find(t => t.implementation?.toLowerCase() === service);
    if (!template) throw new Error(`Prowlarr does not offer the ${service} application template.`);
    const candidate = { ...fields(template, {
      prowlarrUrl: 'http://prowlarr:9696', baseUrl: definitions[service].url.replace('/api/v3', ''),
      apiKey: definitions[service].key,
    }), name, syncLevel: 'addOnly', tags: [] };
    delete candidate.id;
    await call('prowlarr', 'applications/test', 'POST', candidate);
    await call('prowlarr', 'applications', 'POST', candidate);
  }
  report('Prowlarr: Sonarr and Radarr applications linked and tested.');
  if (input.qbitUrl) {
    const u = new URL(input.qbitUrl);
    if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password || u.search || u.hash)
      throw new Error('Use a plain HTTP(S) qBittorrent Web UI URL.');
    if (!input.qbitRemotePath) throw new Error('Enter the download path reported by your client so imports can be mapped correctly.');
    for (const service of ['sonarr', 'radarr']) {
      const clients = await call(service, 'downloadclient');
      if (clients.some(c => c.name === 'Plex Rentals qBittorrent')) continue;
      const schemas = await call(service, 'downloadclient/schema');
      const template = schemas.find(c => c.implementation === 'QBittorrent');
      if (!template) throw new Error(`${service}: qBittorrent template unavailable.`);
      const candidate = { ...fields(template, {
        host: u.hostname, port: Number(u.port || (u.protocol === 'https:' ? 443 : 80)), useSsl: u.protocol === 'https:',
        urlBase: u.pathname === '/' ? '' : u.pathname, username: input.qbitUser || '', password: input.qbitPassword || '',
        [service === 'sonarr' ? 'tvCategory' : 'movieCategory']: service === 'sonarr' ? 'plex-rentals-tv' : 'plex-rentals-movies',
      }), name: 'Plex Rentals qBittorrent', enable: false, priority: 1, removeCompletedDownloads: false, removeFailedDownloads: false };
      delete candidate.id;
      await call(service, 'downloadclient/test', 'POST', candidate);
      await call(service, 'downloadclient', 'POST', candidate);
      const mappings = await call(service, 'remotepathmapping');
      if (!mappings.some(m => m.host === u.hostname && m.remotePath === input.qbitRemotePath))
        await call(service, 'remotepathmapping', 'POST', { host: u.hostname, remotePath: input.qbitRemotePath, localPath: '/data/downloads/' });
    }
    report('qBittorrent: tested and saved disabled, with download path mappings.');
  }
  if (input.indexerUrl) {
    const u = new URL(input.indexerUrl);
    if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password || u.search || u.hash)
      throw new Error('Use a plain HTTP(S) Torznab URL; enter the API key separately.');
    const indexers = await call('prowlarr', 'indexer');
    if (!indexers.some(i => i.name === 'Plex Rentals Torznab')) {
      const templates = await call('prowlarr', 'indexer/schema');
      const template = templates.find(t => t.implementation === 'Torznab');
      if (!template) throw new Error('Prowlarr Torznab template unavailable. Add the provider in Prowlarr.');
      const appProfiles = await call('prowlarr', 'appprofile');
      if (!appProfiles.length) throw new Error('Prowlarr sync profile missing. Create one before adding your indexer.');
      const candidate = { ...fields(template, { baseUrl: u.origin + u.pathname, apiKey: input.indexerKey || '' }), name: 'Plex Rentals Torznab', enable: false, priority: 25, appProfileId: appProfiles[0].id };
      delete candidate.id;
      await call('prowlarr', 'indexer/test', 'POST', candidate);
      await call('prowlarr', 'indexer', 'POST', candidate);
    }
    report('Indexer: your Torznab source tested and saved disabled.');
  }
  // Use the normal authenticated Settings API, not direct production DB changes.
  let cookie = '';
  async function app(route, method, body) {
    const r = await fetcher(`http://127.0.0.1:8080/api/${route}`, { method, headers: { 'Content-Type': 'application/json', Origin: env.BASE_URL, Cookie: cookie }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(15000) });
    if (!r.ok) throw new Error(`Plex Rentals setup step ${route} failed (HTTP ${r.status}). Open Settings to finish safely.`);
    const setCookie = r.headers.get('set-cookie'); if (setCookie) cookie = setCookie.split(';')[0];
    return r.json();
  }
  await app('household/join', 'POST', { passcode: env.HOUSEHOLD_PASSCODE });
  const { profiles: household } = await app('profiles', 'GET');
  const owner = household.find(p => p.isAdmin);
  if (!owner) throw new Error('Owner profile not ready. Restart setup once the app is healthy.');
  await app('session', 'POST', { profileId: owner.id, pin: env.ADMIN_PIN });
  await app('admin/unlock', 'POST', { pin: env.ADMIN_PIN });
  for (const service of ['sonarr', 'radarr']) {
    await app(`admin/integrations/${service}`, 'PUT', { enabled: false, baseUrl: definitions[service].url.replace('/api/v3',''), qualityProfileId: profiles[service], rootFolderPath: definitions[service].root });
    await app(`admin/integrations/${service}/test`, 'POST', {});
  }
  const pending = ['Review then enable acquisition in Settings; no searches or downloads were started.'];
  if (!input.qbitUrl) pending.unshift('Connect your download client (Sonarr/Radarr > Settings > Download Clients).');
  else pending.unshift('Set qBittorrent category save paths under your chosen downloads folder, then enable the tested client.');
  if (!input.indexerUrl) pending.unshift('Add your authorized indexer accounts in Prowlarr > Indexers.');
  else pending.unshift('Review and enable your tested indexer in Prowlarr.');
  for (const item of pending) report(item);
  return { profiles, pending };
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  let source = ''; for await (const chunk of process.stdin) source += chunk;
  try {
    let input;
    try { input = JSON.parse(source); } catch { throw new Error('Setup input was invalid.'); }
    const marker = '/data/setup-auth-ready.json';
    input.authConfigured = await readFile(marker, 'utf8').then(JSON.parse, () => []);
    const result = await configure(input, { checkpoint: async service => {
      input.authConfigured.push(service);
      await writeFile(marker, JSON.stringify(input.authConfigured), { mode: 0o600 });
    } });
    await writeFile('/data/setup-checklist.json', JSON.stringify(result), { mode: 0o600 });
  } catch (error) { console.error(error.message.startsWith('Unexpected') ? 'Setup input was invalid.' : error.message); process.exitCode = 1; }
}
