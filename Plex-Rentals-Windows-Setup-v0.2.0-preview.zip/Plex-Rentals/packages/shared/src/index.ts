import { z } from 'zod';

export const requestStatus = z.enum([
  'requested',
  'looking',
  'available',
  'watched',
  'passed',
  'cancelled',
]);
export const releaseState = z.enum(['released', 'coming_soon', 'unknown']);
export const plexState = z.enum(['available', 'unavailable', 'unknown']);
export const mediaType = z.enum(['movie', 'tv']);
export const effectsMode = z.enum(['full', 'lite']);
export const automationServiceSchema = z.enum(['radarr', 'sonarr']);
export const approvalDecisionSchema = z.enum(['pending', 'approved', 'declined']);
export const submissionStatusSchema = z.enum([
  'not_submitted',
  'queued',
  'submitting',
  'sent',
  'failed',
  'skipped',
]);

export type RequestStatus = z.infer<typeof requestStatus>;
export type ReleaseState = z.infer<typeof releaseState>;
export type PlexState = z.infer<typeof plexState>;
export type MediaType = z.infer<typeof mediaType>;
export type EffectsMode = z.infer<typeof effectsMode>;
export type AutomationService = z.infer<typeof automationServiceSchema>;

export const openRequestStatuses: readonly RequestStatus[] = ['requested', 'looking', 'available'];
export const ratingLevels: Readonly<Record<string, number>> = {
  G: 1,
  'TV-Y': 1,
  'TV-Y7': 1,
  'TV-G': 1,
  PG: 2,
  'TV-PG': 2,
  'PG-13': 3,
  'TV-14': 3,
  R: 4,
  'TV-MA': 4,
  'NC-17': 5,
};

export const titleStatesSchema = z.object({
  plexState,
  releaseState,
  requestStatus: requestStatus.optional(),
});
export type TitleStates = z.infer<typeof titleStatesSchema>;

export const apiErrorSchema = z.object({
  error: z.object({ code: z.string(), message: z.string() }),
});

const imagePath = z
  .string()
  .regex(/^\/[a-zA-Z0-9_.-]+$/)
  .nullable();
export const titleCardSchema = titleStatesSchema.extend({
  tmdbId: z.number().int().positive(),
  mediaType,
  title: z.string(),
  year: z.number().int().nullable(),
  releaseDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .nullable(),
  posterPath: imagePath,
  backdropPath: imagePath,
  tmdbScore: z.number().nullable(),
  certification: z.string().nullable(),
  runtimeMin: z.number().nullable(),
  seasonCount: z.number().int().nullable(),
  colorHex: z.string().regex(/^#[0-9a-fA-F]{6}$/),
});
export const titleDetailSchema = titleCardSchema.extend({
  overview: z.string(),
  logoPath: imagePath,
  genres: z.array(z.object({ id: z.number(), name: z.string() })),
  cast: z.array(
    z.object({ id: z.number(), name: z.string(), character: z.string(), profilePath: imagePath }),
  ),
  crew: z.array(z.object({ id: z.number(), name: z.string(), job: z.string() })),
  trailerKey: z
    .string()
    .regex(/^[a-zA-Z0-9_-]{11}$/)
    .nullable(),
  releaseTheatrical: z.string().nullable(),
  releaseDigital: z.string().nullable(),
  releasePhysical: z.string().nullable(),
  nextAirDate: z.string().nullable(),
  seasons: z.array(
    z.object({
      number: z.number().int(),
      name: z.string(),
      episodeCount: z.number().int(),
      airDate: z.string().nullable(),
      inPlex: z.boolean().nullable(),
    }),
  ),
  recommendations: z.array(titleCardSchema),
  resolution: z.string().nullable(),
  watchUrl: z.string().url().nullable(),
});
export const homeRowSchema = z.object({
  id: z.string(),
  title: z.string(),
  logoPath: imagePath.optional(),
  items: z.array(titleCardSchema),
});
export const catalogMetaSchema = z.object({
  mode: z.enum(['demo', 'live']),
  stale: z.boolean(),
  plexMode: z.enum(['mock', 'configured']),
  notice: z.string().nullable(),
});
export const homeResponseSchema = catalogMetaSchema.extend({ rows: z.array(homeRowSchema) });
export const detailResponseSchema = catalogMetaSchema.extend({ title: titleDetailSchema });
export const browseQuerySchema = z.object({ type: mediaType.optional() });
export const titleParamsSchema = z.object({
  mediaType,
  tmdbId: z.coerce.number().int().positive().max(2147483647),
});
export type TitleCard = z.infer<typeof titleCardSchema>;
export type TitleDetail = z.infer<typeof titleDetailSchema>;
export type HomeRow = z.infer<typeof homeRowSchema>;
export type HomeResponse = z.infer<typeof homeResponseSchema>;
export type DetailResponse = z.infer<typeof detailResponseSchema>;

// Phase 2: one contract for browser and server mutations and private family data.
export const pinSchema = z.string().regex(/^\d{4}$/, 'Enter a four-digit PIN.');
export const profileSchema = z.object({
  id: z.number().int().positive(),
  name: z.string(),
  avatar: z.string(),
  color: z.string(),
  isAdmin: z.boolean(),
  hasPin: z.boolean(),
  maxRatingLevel: z.number().int().min(1).max(5).nullable(),
});
export const sessionResponseSchema = z.object({
  configured: z.boolean(),
  trusted: z.boolean(),
  profile: profileSchema.nullable(),
  adminUnlocked: z.boolean(),
  timeZone: z.string().default('America/Chicago'),
});
export const profilesResponseSchema = z.object({ profiles: z.array(profileSchema) });
export const joinSchema = z
  .object({ passcode: z.string().min(1).max(256), label: z.string().trim().max(80).optional() })
  .strict();
export const selectProfileSchema = z
  .object({ profileId: z.number().int().positive(), pin: pinSchema.optional() })
  .strict();
export const adminUnlockSchema = z.object({ pin: pinSchema }).strict();
export const presetAvatars = [
  'director',
  'explorer',
  'dreamer',
  'stargazer',
  'astronaut',
  'artist',
  'fox',
  'owl',
  'bear',
  'cat',
  'robot',
  'sunshine',
] as const;
export const MAX_AVATAR_BYTES = 2_000_000;
export const avatarSchema = z
  .string()
  .max(4 * Math.ceil(MAX_AVATAR_BYTES / 3) + 32)
  .refine(
    (value) =>
      presetAvatars.some((preset) => value === `preset:${preset}`) ||
      /^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(value),
    'Choose a preset or a PNG, JPEG, or WebP photo.',
  );
export const profileCreateSchema = z
  .object({
    name: z.string().trim().min(1).max(40),
    avatar: avatarSchema.default('preset:explorer'),
    color: z
      .string()
      .regex(/^#[0-9a-fA-F]{6}$/)
      .default('#F7A823'),
    pin: pinSchema.nullable().optional(),
    maxRatingLevel: z.number().int().min(1).max(5).nullable().default(null),
    isAdmin: z.boolean().default(false),
  })
  .strict();
// Patch fields must not inherit create defaults: renaming a kid must retain its rating cap.
export const profileUpdateSchema = z
  .object({
    name: z.string().trim().min(1).max(40).optional(),
    avatar: avatarSchema.optional(),
    color: z
      .string()
      .regex(/^#[0-9a-fA-F]{6}$/)
      .optional(),
    pin: pinSchema.nullable().optional(),
    maxRatingLevel: z.number().int().min(1).max(5).nullable().optional(),
    isAdmin: z.boolean().optional(),
  })
  .strict();
export const requestReasonSchema = z.enum(['Movie Night', 'For Me', 'Watch Together', 'Kids']);
export const requestCreateSchema = z
  .object({
    mediaType,
    tmdbId: z.number().int().positive().max(2147483647),
    seasons: z.array(z.number().int().min(0).max(1000)).min(1).max(100).nullable().optional(),
    rent: z.boolean().optional(),
  })
  .strict()
  .refine((v) => v.mediaType === 'tv' || v.seasons == null, 'Only TV titles have seasons.')
  .refine((v) => v.mediaType === 'movie' || !v.rent, 'Only movies can be rented.');
export const supporterPatchSchema = z
  .object({
    reason: requestReasonSchema.nullable().optional(),
    note: z.string().trim().max(140).nullable().optional(),
  })
  .strict();
export const adminRequestPatchSchema = z
  .object({
    status: requestStatus.optional(),
    adminNote: z.string().trim().max(2000).nullable().optional(),
    plexRatingKey: z.string().min(1).max(200).optional(),
  })
  .strict();
export const approvalActionSchema = z.discriminatedUnion('decision', [
  z.object({ decision: z.literal('approved') }).strict(),
  z
    .object({
      decision: z.literal('declined'),
      reason: z.string().trim().min(1).max(500),
    })
    .strict(),
]);
export const requestAutomationSchema = z.object({
  decision: approvalDecisionSchema,
  decidedByName: z.string().nullable(),
  decidedAt: z.string().nullable(),
  declineReason: z.string().nullable(),
  scopeLabel: z.string(),
  service: automationServiceSchema,
  submissionStatus: submissionStatusSchema,
  externalId: z.number().int().positive().nullable(),
  lastError: z.string().nullable(),
  attemptCount: z.number().int().nonnegative(),
  submittedAt: z.string().nullable(),
});
export const requestSupporterSchema = z.object({
  profileId: z.number().int(),
  name: z.string(),
  avatar: z.string(),
  color: z.string(),
  reason: requestReasonSchema.nullable(),
  note: z.string().nullable(),
  createdAt: z.string(),
});
export const requestEventSchema = z.object({
  id: z.number().int(),
  fromStatus: requestStatus.nullable(),
  toStatus: requestStatus,
  actorProfileId: z.number().int().nullable(),
  actorName: z.string().nullable(),
  createdAt: z.string(),
});
export const requestRecordSchema = z.object({
  id: z.number().int(),
  title: titleCardSchema,
  createdBy: z.number().int(),
  createdByName: z.string(),
  status: requestStatus,
  reason: requestReasonSchema.nullable(),
  note: z.string().nullable(),
  seasons: z.array(z.number().int()).nullable(),
  adminNote: z.string().nullable().optional(),
  createdAt: z.string(),
  updatedAt: z.string(),
  availableAt: z.string().nullable(),
  watchedAt: z.string().nullable(),
  supporters: z.array(requestSupporterSchema),
  events: z.array(requestEventSchema),
  activity: z
    .array(
      z.object({
        id: z.number(),
        label: z.string(),
        actorName: z.string().nullable(),
        createdAt: z.string(),
      }),
    )
    .default([]),
  isSupporter: z.boolean(),
  automation: requestAutomationSchema.nullable().default(null),
  rental: z
    .object({
      durationDays: z.number().int().positive(),
      expiresAt: z.string().nullable(),
      deletedAt: z.string().nullable(),
      lastError: z.string().nullable(),
    })
    .nullable()
    .default(null),
});
export const requestTrackingSchema = z.object({
  stage:z.enum(['queued','downloading','transferring','plex','ready','paused','attention','waiting']).default('waiting'),
  bytesTotal:z.number().nonnegative().nullable().default(null),
  bytesDownloaded:z.number().nonnegative().nullable().default(null),
  speedBytesPerSecond:z.number().nonnegative().nullable().default(null),
  checkedAt: z.string(),
  state: z.string(),
  progress: z.number().min(0).max(100).nullable(),
  eta: z.string().nullable(),
  source: z.string(),
  events: z.array(z.object({ label: z.string(), createdAt: z.string() })),
});
export type RequestTracking = z.infer<typeof requestTrackingSchema>;
export const requestResponseSchema = z.object({ request: requestRecordSchema });
export const requestsResponseSchema = z.object({
  requests: z.array(requestRecordSchema),
  nextCursor: z.string().nullable(),
});
export const listResponseSchema = z.object({
  items: z.array(titleCardSchema),
  nextCursor: z.string().nullable(),
});
export const pageQuerySchema = z.object({
  cursor: z.string().max(100).optional(),
  limit: z.coerce.number().int().min(1).max(100).default(30),
});
export const requestsQuerySchema = pageQuerySchema.extend({
  scope: z.enum(['mine', 'family']).default('family'),
  status: requestStatus.optional(),
  person: z.coerce.number().int().positive().optional(),
  type: mediaType.optional(),
  sort: z.enum(['newest', 'oldest', 'supporters']).default('newest'),
  filter: z.enum(['coming_soon', 'ready']).optional(),
  approval: z.enum(['awaiting', 'approved', 'declined', 'attention']).optional(),
});

export const integrationServiceUpdateSchema = z
  .object({
    enabled: z.boolean(),
    baseUrl: z.string().trim().url().max(500),
    apiKey: z.string().trim().min(8).max(500).optional(),
    qualityProfileId: z.number().int().positive().nullable(),
    rootFolderPath: z.string().trim().min(1).max(1000).nullable(),
  })
  .strict()
  .refine((value) => /^https?:\/\//i.test(value.baseUrl), 'Use an HTTP or HTTPS server URL.');
export const integrationOptionSchema = z.object({
  id: z.number().int().positive(),
  name: z.string(),
});
export const integrationServiceSchema = z.object({
  service: automationServiceSchema,
  enabled: z.boolean(),
  baseUrl: z.string(),
  apiKeyConfigured: z.boolean(),
  qualityProfileId: z.number().int().positive().nullable(),
  rootFolderPath: z.string().nullable(),
  connected: z.boolean(),
  version: z.string().nullable(),
  error: z.string().nullable(),
  qualityProfiles: z.array(integrationOptionSchema),
  rootFolders: z.array(z.object({ id: z.number().int().positive(), path: z.string() })),
});
export const integrationsResponseSchema = z.object({
  services: z.array(integrationServiceSchema),
});
export const integrationTestResponseSchema = integrationServiceSchema;
export const adminStatsSchema = z.object({
  total: z.number().int(),
  counts: z.record(requestStatus, z.number().int()),
  comingSoon: z.number().int(),
  readyToGet: z.number().int(),
  mostRequested: z.array(requestRecordSchema),
  byPerson: z.array(
    z.object({ profileId: z.number().int(), name: z.string(), count: z.number().int() }),
  ),
  comingSoonRequests: z.array(requestRecordSchema),
  recentlyAvailable: z.array(requestRecordSchema),
});
export const deviceSchema = z.object({
  id: z.number().int(),
  label: z.string().nullable(),
  lastSeenAt: z.string().nullable(),
  createdAt: z.string(),
  isCurrent: z.boolean(),
});
export const devicesResponseSchema = z.object({ devices: z.array(deviceSchema) });
export const plexItemsResponseSchema = z.object({
  items: z.array(
    z.object({
      ratingKey: z.string(),
      title: z.string(),
      mediaType,
      year: z.number().int().nullable(),
    }),
  ),
});
export const plexSectionSchema = z.object({
  key: z.string(),
  title: z.string(),
  type: z.enum(['movie', 'show']),
  included: z.boolean(),
});
export const plexSettingsSchema = z.object({
  configured: z.boolean(),
  connected: z.boolean(),
  serverName: z.string().nullable(),
  version: z.string().nullable(),
  lastSuccessfulSyncAt: z.string().nullable(),
  sections: z.array(plexSectionSchema),
});
export const plexTestResponseSchema = z.object({
  serverName: z.string(),
  machineIdentifier: z.string(),
  version: z.string().nullable(),
});
export const plexSectionsUpdateSchema = z
  .object({
    sectionIds: z.array(z.string().regex(/^\d+$/)).min(1),
  })
  .strict();
export const plexSyncResultSchema = z.object({
  sections: z.number().int(),
  items: z.number().int(),
  matched: z.number().int(),
  requestsAvailable: z.number().int(),
  completedAt: z.string(),
});
export const fuzzyMatchSchema = z.object({
  titleId: z.number().int().positive(),
  title: z.string(),
  year: z.number().int().nullable(),
  mediaType,
  ratingKey: z.string(),
  plexTitle: z.string(),
  plexYear: z.number().int().nullable(),
});
export const fuzzyMatchesResponseSchema = z.object({ matches: z.array(fuzzyMatchSchema) });
export const fuzzyMatchDecisionSchema = z.object({ accept: z.boolean() }).strict();
export const libraryQuerySchema = pageQuerySchema.extend({
  section: z.enum(['standup']).optional(),
  type: mediaType.optional(),
  genre: z.string().trim().max(80).optional(),
  sort: z.enum(['added', 'title', 'year', 'score']).default('added'),
});
export const libraryResponseSchema = z.object({
  items: z.array(titleCardSchema),
  nextCursor: z.string().nullable(),
  genres: z.array(z.string()),
  lastSuccessfulSyncAt: z.string().nullable(),
});
export const notificationSchema = z.object({
  id: z.number().int().positive(),
  kind: z.string(),
  requestId: z.number().int().positive().nullable(),
  titleId: z.number().int().positive().nullable(),
  title: z.string().nullable(),
  mediaType: mediaType.nullable(),
  tmdbId: z.number().int().positive().nullable(),
  body: z.string(),
  readAt: z.string().nullable(),
  createdAt: z.string(),
});
export const notificationsResponseSchema = z.object({
  notifications: z.array(notificationSchema),
  unread: z.number().int().nonnegative(),
});
export const notificationReadSchema = z
  .object({
    ids: z.array(z.number().int().positive()).max(100).optional(),
    all: z.boolean().optional(),
  })
  .strict()
  .refine(
    (value) => value.all === true || Boolean(value.ids?.length),
    'Choose notifications to read.',
  );
export const pushSubscriptionSchema = z
  .object({
    endpoint: z.string().url().max(2048),
    keys: z.object({ p256dh: z.string().min(1).max(512), auth: z.string().min(1).max(256) }),
  })
  .strict();
export const pushConfigSchema = z.object({
  enabled: z.boolean(),
  publicKey: z.string().nullable(),
  secureContext: z.boolean(),
});
export const householdSettingsSchema = z.object({ passcode: z.string().min(8).max(256) }).strict();
export const successSchema = z.object({ ok: z.literal(true) });
export const familyDetailResponseSchema = detailResponseSchema.extend({
  request: requestRecordSchema.nullable(),
  inMyList: z.boolean(),
  reaction: z.enum(['up', 'down']).nullable().default(null),
});

// Phase 5: search, explainable personalization, reactions and passive signals.
export const searchQuerySchema = z.object({
  q: z.string().trim().max(100).default(''),
  type: mediaType.optional(),
  plex: z.enum(['available', 'unavailable']).optional(),
  genre: z.string().trim().max(80).optional(),
});
export const searchPersonSchema = z.object({
  id: z.number().int().positive(),
  name: z.string(),
  profilePath: imagePath,
  knownFor: z.array(titleCardSchema),
});
export const searchResponseSchema = z.object({
  results: z.array(titleCardSchema),
  person: searchPersonSchema.nullable(),
  genres: z.array(z.string()),
});
export const reactionUpdateSchema = z
  .object({
    mediaType,
    tmdbId: z.number().int().positive(),
    reaction: z.enum(['up', 'down']).nullable(),
  })
  .strict();
export const signalKindSchema = z.enum(['detail_view', 'trailer_play', 'search_open']);
export const signalsUpdateSchema = z
  .object({
    signals: z
      .array(
        z.object({
          mediaType,
          tmdbId: z.number().int().positive(),
          kind: signalKindSchema,
          createdAt: z.string().datetime().optional(),
        }),
      )
      .min(1)
      .max(50),
  })
  .strict();

// Phase 6: Movie Night contracts.
export const movieNightModeSchema = z.enum(['own_device', 'pass_phone']);
export const movieNightFiltersSchema = z.object({
  participants: z.array(z.number().int().positive()).min(1).max(20),
  type: z.enum(['both', 'movie', 'tv']).default('both'),
  maxRuntime: z.number().int().min(30).max(360).nullable().default(null),
  inPlexOnly: z.boolean().default(true),
  mode: movieNightModeSchema.default('own_device'),
});
export const movieNightCreateSchema = movieNightFiltersSchema.strict();
export const movieNightVoteSchema = z
  .object({
    titleId: z.number().int().positive(),
    vote: z.number().int().min(0).max(3),
    voterProfileId: z.number().int().positive().optional(),
  })
  .strict();
export const movieNightWinnerSchema = z.object({ titleId: z.number().int().positive() }).strict();
export const movieNightCandidateSchema = z.object({
  titleId: z.number().int().positive(),
  title: titleCardSchema,
  myVote: z.number().int().min(0).max(3).nullable(),
  average: z.number().min(0).max(3).nullable(),
  matchPercent: z.number().int().min(0).max(100).nullable(),
  hasNope: z.boolean(),
  votes: z.array(
    z.object({
      profileId: z.number().int().positive(),
      name: z.string(),
      vote: z.number().int().min(0).max(3),
    }),
  ),
});
export const movieNightSchema = z.object({
  id: z.number().int().positive(),
  hostProfileId: z.number().int().positive(),
  hostName: z.string(),
  status: z.enum(['voting', 'closed']),
  filters: movieNightFiltersSchema,
  participants: z.array(profileSchema),
  candidates: z.array(movieNightCandidateSchema),
  winnerTitleId: z.number().int().positive().nullable(),
  createdAt: z.string(),
  closedAt: z.string().nullable(),
});
export const movieNightResponseSchema = z.object({ movieNight: movieNightSchema.nullable() });
export type Profile = z.infer<typeof profileSchema>;
export type SessionResponse = z.infer<typeof sessionResponseSchema>;
export type RequestRecord = z.infer<typeof requestRecordSchema>;
export type RequestReason = z.infer<typeof requestReasonSchema>;
export type FamilyDetailResponse = z.infer<typeof familyDetailResponseSchema>;
export type AdminStats = z.infer<typeof adminStatsSchema>;
export type Device = z.infer<typeof deviceSchema>;
export type SearchResponse = z.infer<typeof searchResponseSchema>;
export type MovieNight = z.infer<typeof movieNightSchema>;
export type IntegrationService = z.infer<typeof integrationServiceSchema>;
export const bulkApprovalSchema = z
  .object({ ids: z.array(z.number().int().positive()).min(1).max(500) })
  .strict();

export const discoveryCollections = {
  mystery: {
    name: 'Keep me guessing',
    description: 'Mysteries with a strong audience rating.',
    genre: '9648',
  },
  comedy: {
    name: 'Something funny',
    description: 'Comedies for an easy movie night.',
    genre: '35',
  },
  comfort: {
    name: 'Comfort movies',
    description: 'Popular family films to settle in with.',
    genre: '10751',
  },
  nineties: {
    name: 'Back to the ’90s',
    description: 'Rediscover a whole decade of movies.',
    genre: '',
  },
  space: {
    name: 'Science fiction after dark',
    description: 'Highly rated science-fiction discoveries.',
    genre: '878',
  },
  short: {
    name: 'One more before bed',
    description: 'Feature films under 100 minutes.',
    genre: '',
  },
} as const;
export const discoverQuerySchema = z.object({
  page: z.coerce.number().int().min(1).max(500).default(1),
  collection: z
    .enum(['mystery', 'comedy', 'comfort', 'nineties', 'space', 'short', 'standup'])
    .optional(),
  genre: z.enum(['28', '12', '16', '35', '18', '27', '9648', '878', '10751', '99']).optional(),
  decade: z.coerce.number().int().min(1920).max(2030).optional(),
  score: z.coerce.number().min(0).max(9).optional(),
  runtime: z.coerce.number().int().min(40).max(240).optional(),
  provider: z.enum(['8', '15', '350', '337']).optional(),
  availability: z.enum(['all', 'ready', 'request', 'soon']).default('all'),
  cast: z.coerce.number().int().positive().optional(),
  director: z.coerce.number().int().positive().optional(),
  franchise: z.coerce.number().int().positive().optional(),
  similar: z.coerce.number().int().positive().optional(),
});
export type DiscoverQuery = z.infer<typeof discoverQuerySchema>;
export const discoverResponseSchema = z.object({
  items: z.array(titleCardSchema),
  nextPage: z.number().nullable(),
  stale: z.boolean(),
});

export const suggestionStatusSchema = z.enum(['pending','approved','implementing','completed','declined','blocked']);
export const suggestionCreateSchema = z.object({title:z.string().trim().min(3).max(120),body:z.string().trim().min(5).max(4000),implementNow:z.boolean().default(false)}).strict();
export const suggestionUpdateSchema = z.object({status:suggestionStatusSchema, note:z.string().trim().max(2000).default(''),implementNow:z.boolean().optional()}).strict();
export const suggestionSchema = z.object({id:z.number(),profileId:z.number(),author:z.string(),title:z.string(),body:z.string(),status:suggestionStatusSchema,implementNow:z.boolean(),note:z.string(),createdAt:z.string(),updatedAt:z.string()});
export const suggestionsResponseSchema=z.object({items:z.array(suggestionSchema),nextCursor:z.number().nullable()});
export type Suggestion = z.infer<typeof suggestionSchema>;

export const titleRatingInputSchema = z.object({score:z.number().min(0).max(10).multipleOf(0.5)}).strict();
export const titleCommentInputSchema = z.object({body:z.string().trim().min(1).max(2000),mentions:z.array(z.number().int().positive()).max(10).default([])}).strict();
const socialPersonSchema = z.object({profileId:z.number(),name:z.string()});
export const titleSocialResponseSchema = z.object({
 average:z.number().nullable(),count:z.number(),myScore:z.number().nullable(),
 ratings:z.array(socialPersonSchema.extend({score:z.number()})),
 people:z.array(socialPersonSchema),
 comments:z.array(socialPersonSchema.extend({id:z.number(),body:z.string(),createdAt:z.string(),mentions:z.array(socialPersonSchema)})),
 nextCursor:z.number().nullable(),
});


export const storageEntrySchema=z.object({id:z.string(),library:z.enum(['Movies','TV']),name:z.string(),bytes:z.number().nonnegative(),files:z.number().int().nonnegative(),skipped:z.number().int().nonnegative()});
export const storageSnapshotSchema=z.object({generatedAt:z.string(),entries:z.array(storageEntrySchema),volumes:z.array(z.object({library:z.enum(['Movies','TV']),totalBytes:z.number().nonnegative(),freeBytes:z.number().nonnegative()}))});
export type StorageSnapshot=z.infer<typeof storageSnapshotSchema>;
export const storageStatusSchema=z.object({enabled:z.boolean(),scanning:z.boolean(),completed:z.number(),error:z.string().nullable(),startedAt:z.string().nullable(),snapshot:storageSnapshotSchema.nullable()});
export const storageReviewInputSchema=z.object({generatedAt:z.string(),ids:z.array(z.string().regex(/^[a-f0-9]{64}$/)).min(1).max(200)}).strict();
export const storageReviewSchema=z.object({generatedAt:z.string(),entries:z.array(storageEntrySchema),bytes:z.number()});
