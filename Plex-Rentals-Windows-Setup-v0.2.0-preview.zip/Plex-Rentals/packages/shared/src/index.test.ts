import { describe, expect, it } from 'vitest';
import {
  openRequestStatuses,
  plexState,
  ratingLevels,
  releaseState,
  requestStatus,
  titleStatesSchema,
  requestCreateSchema,
  profileCreateSchema,
  profileUpdateSchema,
  supporterPatchSchema,
  joinSchema,
  avatarSchema,
  adminRequestPatchSchema,
} from './index.js';

describe('shared product contract', () => {
  it('keeps coming soon independent of request status', () => {
    expect(requestStatus.safeParse('coming_soon').success).toBe(false);
    expect(
      titleStatesSchema.parse({
        requestStatus: 'requested',
        releaseState: 'coming_soon',
        plexState: 'unknown',
      }),
    ).toEqual({ requestStatus: 'requested', releaseState: 'coming_soon', plexState: 'unknown' });
  });
  it('exports exactly the specified states', () => {
    expect(requestStatus.options).toEqual([
      'requested',
      'looking',
      'available',
      'watched',
      'passed',
      'cancelled',
    ]);
    expect(releaseState.options).toEqual(['released', 'coming_soon', 'unknown']);
    expect(plexState.options).toEqual(['available', 'unavailable', 'unknown']);
    expect(openRequestStatuses).toEqual(['requested', 'looking', 'available']);
  });
  it('maps movie and TV certifications to the same scale', () => {
    expect(ratingLevels['PG-13']).toBe(ratingLevels['TV-14']);
    expect(ratingLevels['G']).toBe(ratingLevels['TV-Y7']);
    expect(ratingLevels['unrated']).toBeUndefined();
  });
});

describe('Phase 2 mutation boundaries', () => {
  it('does not reset kid limits or admin privileges when editing only a name', () => {
    expect(profileUpdateSchema.parse({ name: 'Emma' })).toEqual({ name: 'Emma' });
    expect(profileUpdateSchema.parse({})).toEqual({});
  });
  it('does not allow client-supplied identity or request status on creation', () => {
    const movie = { mediaType: 'movie', tmdbId: 42 };
    expect(requestCreateSchema.safeParse(movie).success).toBe(true);
    expect(requestCreateSchema.safeParse({ ...movie, createdBy: 1 }).success).toBe(false);
    expect(requestCreateSchema.safeParse({ ...movie, status: 'available' }).success).toBe(false);
    expect(requestCreateSchema.safeParse({ ...movie, seasons: [1] }).success).toBe(false);
    expect(requestCreateSchema.safeParse({ ...movie, rent: true }).success).toBe(true);
    expect(requestCreateSchema.safeParse({ mediaType: 'tv', tmdbId: 42, rent: true }).success).toBe(false);
    expect(
      requestCreateSchema.safeParse({ mediaType: 'tv', tmdbId: 42, seasons: [1, 2] }).success,
    ).toBe(true);
  });
  it('bounds profile credentials, rating limits and notes', () => {
    expect(
      profileCreateSchema.safeParse({ name: 'Emma', pin: '0123', maxRatingLevel: 2 }).success,
    ).toBe(true);
    expect(profileCreateSchema.safeParse({ name: 'Emma', pin: '123' }).success).toBe(false);
    expect(profileCreateSchema.safeParse({ name: 'Emma', maxRatingLevel: 6 }).success).toBe(false);
    expect(supporterPatchSchema.safeParse({ note: 'a'.repeat(141) }).success).toBe(false);
    expect(supporterPatchSchema.safeParse({ reason: 'unlisted' }).success).toBe(false);
    expect(adminRequestPatchSchema.safeParse({ status: 'coming_soon' }).success).toBe(false);
    expect(joinSchema.safeParse({ passcode: '' }).success).toBe(false);
  });
  it('rejects executable or remote avatar URLs', () => {
    expect(avatarSchema.safeParse('preset:director').success).toBe(true);
    expect(avatarSchema.safeParse('javascript:alert(1)').success).toBe(false);
    expect(avatarSchema.safeParse('https://example.com/track').success).toBe(false);
    expect(avatarSchema.safeParse('data:image/svg+xml;base64,PHN2Zz4=').success).toBe(false);
  });
});
